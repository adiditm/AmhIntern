-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 26, 2020 at 11:35 AM
-- Server version: 5.7.30
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `k6010526_aminaht`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(2) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `singkat` text NOT NULL,
  `panjang` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `foto`, `judul`, `singkat`, `panjang`) VALUES
(1, '5311261_abstract.jpg', 'PT AMINAH (AMINAH TOUR)', 'singkat', '<p style=\"text-align:justify\">Aminah Tour adalah Divisi Umroh dari PT. Aminah yang bergerak sebagai sebuah Perusahaan Penyelenggara Perjalanan Ziarah Muslim Internasional yang menjembatani anda mudah menuju ke Baitulloh dan telah memiliki izin resmi berupa :</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">SURAT KETERANGAN :</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp; TDP &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : No. 503/10380.D/436.6.11/2013</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp; DISPARTA &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : No. 503.08/083/436.6.14/2014</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp; IZIN UMROH &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: PPIU. No. 819 tahun 2016</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">Kami menyadari bahwa dalam memenuhi kebutuhannya antara jamaah satu dengan yang lainnya berbeda. Namun kami juga yakin yang diidamkan dalam sebuah perjalanan adalah rasa nyaman (Comfort). &nbsp;Ukuran rasa nyaman yang dirasakan seseorang amatlah subjektive dan relative dan tidak dapat diseragamkan atau digantikan dan diukur dengan materi,untuk itu kami dengan sumberdaya manusia berpengalaman serta dukungan jaringan akomodasi dan transportasi yang telah terjalin cukup lama, baik di Saudi Arabia maupun kota-kota lain akan memfasilitasi kebutuhan akan rasa nyaman para jamaah, sehingga Kekhusyuan dalam melakukan Ibadah Umroh dan Haji serta perjalanan Ziarah Muslim dapat utuh dirasakan.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">MOTTO</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Aman</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Nyaman</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Amanah</p>\r\n\r\n<p style=\"text-align:justify\">VISI MISI</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Beribadah</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Berniaga</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; &nbsp;Melayani dengan baik</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;Produk</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh 9 Hari</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh Reguler 12 hari</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh Reguler 15 hari</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh VIP</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh Bulan Ramadhan</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Umroh Plus</p>\r\n\r\n<p style=\"text-align:justify\">&bull; &nbsp; &nbsp; &nbsp; Paket Haji Khusus&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `no` int(5) UNSIGNED NOT NULL,
  `userid` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `pass` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `status` char(3) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `alamat` text COLLATE latin1_general_ci NOT NULL,
  `kota` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `telp` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `bank` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `norek` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `anbank` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `cabang` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(25) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`no`, `userid`, `pass`, `email`, `status`, `nama`, `alamat`, `kota`, `telp`, `bank`, `norek`, `anbank`, `cabang`, `level`) VALUES
(1, 'admin', 'bd65721ec9d6b371466d2ff9f663e136', 'admin@yahoo.co.id', '1', 'Admin', '', 'Blitar', '', '', '', '', '', 'utama');

-- --------------------------------------------------------

--
-- Table structure for table `bayar`
--

CREATE TABLE `bayar` (
  `id` int(2) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `panjang` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bayar`
--

INSERT INTO `bayar` (`id`, `foto`, `judul`, `panjang`) VALUES
(1, '', 'Cara Pembayaran', '1. Mengisi Formulir Pendaftaran Umroh yang telah disediakan yang bermaterai 6000\r\n\r\n2. Membayar di rekening atas nama \r\nPT. AMINAH\r\nBank Mandiri    1420013662985\r\nBank BNI             8888881455\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `no` int(5) UNSIGNED NOT NULL,
  `judul` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `berita` text COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `tgl` date NOT NULL DEFAULT '0000-00-00',
  `published` varchar(5) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bulan`
--

CREATE TABLE `bulan` (
  `no` int(3) NOT NULL,
  `bulan` varchar(15) NOT NULL,
  `time` int(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulan`
--

INSERT INTO `bulan` (`no`, `bulan`, `time`) VALUES
(1, 'Februari 2017', 1485882000),
(2, 'Maret 2017', 1488301200),
(3, 'Januari 2017', 1483203600),
(4, 'April 2017', 1490979600),
(5, 'Mei 2017', 1493571600),
(6, 'Juni 2017', 1496250000),
(7, 'Desember 2018', 1543597200),
(8, 'Februari 2018', 1517418000),
(9, 'Maret 2018', 1519837200),
(10, 'Maret 2018', 1519837200),
(11, 'April 2018', 1522515600),
(12, 'Juli 2018', 1530378000),
(13, 'Juli 2018', 1530378000),
(14, 'September 2018', 1535734800),
(15, 'Agustus 2017', 1501520400),
(16, 'November 2017', 1509469200),
(17, 'Desember 2017', 1512061200),
(18, 'Januari 2018', 1514739600),
(19, 'September 2019', 1567270800),
(20, 'Oktober 2019', 1569862800),
(21, 'November 2019', 1572541200),
(22, 'Desember 2019', 1575133200),
(23, 'Januari 2020', 1577811600),
(24, 'April 2019', 1554051600),
(25, 'Februari 2020', 1580490000),
(26, 'Maret 2020', 1582995600),
(27, 'Oktober 2020', 1601485200);

-- --------------------------------------------------------

--
-- Table structure for table `bulantour`
--

CREATE TABLE `bulantour` (
  `no` int(3) NOT NULL,
  `bulan` varchar(15) NOT NULL,
  `time` int(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bulantour`
--

INSERT INTO `bulantour` (`no`, `bulan`, `time`) VALUES
(1, 'Februari 2017', 1485882000),
(3, 'April 2017', 1490979600),
(4, 'Desember 2018', 1543597200),
(5, 'Maret 2018', 1519837200),
(6, 'April 2018', 1522515600),
(7, 'Juli 2018', 1530378000),
(8, 'Agustus 2017', 1501520400),
(9, 'September 2018', 1535734800);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `alias` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `section` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE `configuration` (
  `id` int(5) NOT NULL,
  `title` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `description` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `keyword` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `under` varchar(2) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `configuration`
--

INSERT INTO `configuration` (`id`, `title`, `description`, `keyword`, `under`) VALUES
(1, 'Aminah Tour hebat KOK', 'Umroh Haji lebih murah dan mudah', 'umroh, haji', '0');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `alias` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `title_alias` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `introtext` mediumtext COLLATE latin1_general_ci NOT NULL,
  `maintext` mediumtext COLLATE latin1_general_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `frontpage` int(5) UNSIGNED NOT NULL DEFAULT '0',
  `catid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` int(11) NOT NULL DEFAULT '0',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text COLLATE latin1_general_ci NOT NULL,
  `urls` text COLLATE latin1_general_ci NOT NULL,
  `attribs` text COLLATE latin1_general_ci NOT NULL,
  `version` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `parentid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text COLLATE latin1_general_ci NOT NULL,
  `metadesc` text COLLATE latin1_general_ci NOT NULL,
  `access` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `hits` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `metadata` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `depan`
--

CREATE TABLE `depan` (
  `no` int(1) NOT NULL,
  `alasan` varchar(250) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `isi` text NOT NULL,
  `judul1` varchar(250) NOT NULL,
  `isi1` text NOT NULL,
  `judul2` varchar(250) NOT NULL,
  `isi2` text NOT NULL,
  `judul3` varchar(250) NOT NULL,
  `isi3` text NOT NULL,
  `judul4` varchar(250) NOT NULL,
  `isi4` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depan`
--

INSERT INTO `depan` (`no`, `alasan`, `judul`, `isi`, `judul1`, `isi1`, `judul2`, `isi2`, `judul3`, `isi3`, `judul4`, `isi4`) VALUES
(1, 'ALASAN UTAMA', 'KENAPA MEMILIH KAMI ?', 'KAMI PELAYAN TAMU ALLOH', 'PELAYANAN', 'Pelayanan yang AMANAH, HANDAL dan TERPERCAYA membuat Anda YAKIN dipanggil ALLOH  ke tanah suci.', 'TOUR LEADER', 'Komitmen kami untuk melayani sepenuh hati, agar ibadah Anda nyaman dan khusuk.', 'FASILITAS', 'Kami memberikan fasilitas hotel, makanan, dan transportasi terbaik dengan biaya yang sesuai', 'PERLENGKAPAN', 'Kami memberikan perlengkapan yang memadai sesuai kebutuhan jamaah');

-- --------------------------------------------------------

--
-- Table structure for table `dokumen`
--

CREATE TABLE `dokumen` (
  `id` int(2) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `panjang` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokumen`
--

INSERT INTO `dokumen` (`id`, `foto`, `judul`, `panjang`) VALUES
(1, '71xx.jpg', 'Dokumen Kelengkapan', '<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/mms/userfiles/images/xx.jpg\" style=\"height:325px; width:600px\" /></p>\r\n\r\n<p><strong><u>Persyaratan&nbsp;Umroh&nbsp;:</u></strong></p>\r\n\r\n<p><!--[if !supportLists]-->1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<!--[endif]-->Mengisi&nbsp;Formulir</p>\r\n\r\n<p><!--[if !supportLists]-->2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<!--[endif]-->Menyerahkan&nbsp;Berkas:</p>\r\n\r\n<ol>\r\n	<li>&nbsp;&nbsp;<!--[endif]-->Passport&nbsp;Asli&nbsp;&nbsp;yang&nbsp;masih&nbsp;berlaku&nbsp;(8&nbsp;bulan)&nbsp;dan&nbsp;nama&nbsp;terdiri&nbsp;dari&nbsp;3&nbsp;Suku&nbsp;kata</li>\r\n	<li>&nbsp;&nbsp;Buku&nbsp;suntik&nbsp;Manangitis&nbsp;Asli</li>\r\n	<li>&nbsp;&nbsp;Kartu&nbsp;Keluarga&nbsp;(KK)&nbsp;Foto&nbsp;Copy</li>\r\n	<li>&nbsp;&nbsp;Kartu&nbsp;tanda&nbsp;penduduk&nbsp;(KTP)&nbsp;foto&nbsp;copy</li>\r\n	<li>&nbsp;&nbsp;Akte/&nbsp;Buku&nbsp;Nikah&nbsp;Asli&nbsp;(untuk&nbsp;suami&nbsp;istri)</li>\r\n	<li>&nbsp;&nbsp;Akte&nbsp;lahir&nbsp;Asli&nbsp;(untuk&nbsp;yang&nbsp;berangkat&nbsp;sendiri&nbsp;khususnya&nbsp;anak-anak)</li>\r\n	<li>&nbsp;&nbsp;&nbsp;Pass&nbsp;Foto&nbsp;terbaru&nbsp;berwarna&nbsp;background&nbsp;putih,&nbsp;tidak&nbsp;memakai&nbsp;kacamata&nbsp;dan&nbsp;tampak&nbsp;kepala&nbsp;80%&nbsp;dalam&nbsp;lingkar&nbsp;Badan,&nbsp;wanita&nbsp;mengunakan&nbsp;Jilbab</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `fotogallery`
--

CREATE TABLE `fotogallery` (
  `no` int(3) NOT NULL,
  `gallery` varchar(3) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `isi` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fotogallery`
--

INSERT INTO `fotogallery` (`no`, `gallery`, `foto`, `judul`, `isi`) VALUES
(3, '3', '52WhatsApp Image 2017-02-07 at 09.47.06.jpeg', 'Luar biasa', 'Indahnya berbagi'),
(4, '3', '541fcddcb8-421f-495a-8cc1-59a83d0e5320.jpg', 'kASIH HIJAU', 'PASTIKAN INDAHNYA SEMANGAT');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `no` int(1) NOT NULL,
  `foto` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`no`, `foto`) VALUES
(2, '63avanza.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `haji`
--

CREATE TABLE `haji` (
  `id` int(2) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `singkat` text NOT NULL,
  `panjang` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `haji`
--

INSERT INTO `haji` (`id`, `foto`, `judul`, `singkat`, `panjang`) VALUES
(1, 'test.jpeg', 'Haji Plus', 'kami singkat', '<p>kmi&nbsp;pawwwwwwwwwwwwwnjang</p>');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE `header` (
  `no` int(1) NOT NULL,
  `header1` varchar(200) NOT NULL,
  `header2` varchar(200) NOT NULL,
  `header3` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`no`, `header1`, `header2`, `header3`) VALUES
(1, '792x1.jpg', '44ggg.jpg', '22WhatsApp Image 2017-08-03 at 09.38n.23.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `no` int(2) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `bulan` varchar(15) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `paket` varchar(1) NOT NULL,
  `kamar1` varchar(20) NOT NULL,
  `kamar2` varchar(20) NOT NULL,
  `kamar3` varchar(20) NOT NULL,
  `kamar4` varchar(20) NOT NULL,
  `pesawat` varchar(20) NOT NULL,
  `htlmadinah` varchar(250) NOT NULL,
  `htlmakkah` varchar(250) NOT NULL,
  `berangkat` varchar(100) NOT NULL,
  `tujuan` varchar(100) NOT NULL,
  `transit` varchar(100) NOT NULL,
  `pembimbing` varchar(30) NOT NULL,
  `lama` varchar(2) NOT NULL,
  `kapasitas` varchar(5) NOT NULL,
  `terisi` varchar(5) NOT NULL,
  `singkat` text NOT NULL,
  `ket` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`no`, `foto`, `bulan`, `tanggal`, `paket`, `kamar1`, `kamar2`, `kamar3`, `kamar4`, `pesawat`, `htlmadinah`, `htlmakkah`, `berangkat`, `tujuan`, `transit`, `pembimbing`, `lama`, `kapasitas`, `terisi`, `singkat`, `ket`) VALUES
(22, '80PicsArt_03-19-10.05.26.jpg', 'Oktober 2020', '2020-10-05', '7', '-', '-', '-', '-', 'LION AIR', 'Luluk Mubarok', 'KARAM AR REFA', 'JUANDA SURABAYA', 'SAUDI JEDDAH', '-', 'H. Y.Adi Suseno', '16', '430', '160', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jadwaltour`
--

CREATE TABLE `jadwaltour` (
  `no` int(2) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `bulan` varchar(15) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `paket` varchar(1) NOT NULL,
  `kamar1` varchar(20) NOT NULL,
  `kamar2` varchar(20) NOT NULL,
  `kamar3` varchar(20) NOT NULL,
  `kamar4` varchar(20) NOT NULL,
  `pesawat` varchar(20) NOT NULL,
  `htlmadinah` varchar(250) NOT NULL,
  `htlmakkah` varchar(250) NOT NULL,
  `berangkat` varchar(100) NOT NULL,
  `tujuan` varchar(100) NOT NULL,
  `transit` varchar(100) NOT NULL,
  `pembimbing` varchar(30) NOT NULL,
  `lama` varchar(2) NOT NULL,
  `kapasitas` varchar(5) NOT NULL,
  `terisi` varchar(5) NOT NULL,
  `singkat` text NOT NULL,
  `ket` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwaltour`
--

INSERT INTO `jadwaltour` (`no`, `foto`, `bulan`, `tanggal`, `paket`, `kamar1`, `kamar2`, `kamar3`, `kamar4`, `pesawat`, `htlmadinah`, `htlmakkah`, `berangkat`, `tujuan`, `transit`, `pembimbing`, `lama`, `kapasitas`, `terisi`, `singkat`, `ket`) VALUES
(5, '87Table.Mountain.National.Park_.original.687.jpg', 'Desember 2018', '2018-12-25', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '11', '0', '0', '11 hari TOUR SOUTH AFRICA & GARDEN ROUTE', '<p style=\"text-align:justify\"><strong>â€‹Hari 1, 25 Dec&nbsp; : Jakarta &ndash; cape Town</strong></p>\r\n\r\n<p style=\"text-align:justify\">Dengan mengucap Bismillahirrahmanirrahim Para peserta diharapkan sudahberkumpul di bandara Soekarno-Hatta 2,5&nbsp; jam sebelum waktu keberangkatan &nbsp;<strong><img alt=\"\" src=\"/mms/userfiles/images/Untitled.jpg\" style=\"float:left; height:185px; opacity:0.9; width:250px\" /></strong></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 2, 26 Dec : Cape Town &nbsp;</strong></p>\r\n\r\n<p style=\"text-align:justify\">Tiba di Bandara Internasional Cape Town, langsung berwisata keliling kota mengunjungi / melewati The Houses of Parliament, City Hall ,&nbsp; Castle of Good hope,&nbsp;&nbsp; Kemudian acara wisata berlanjut dengan kereta gantung Anda akan naik ke puncak <strong>Table Mountain</strong>&nbsp; &nbsp;dimana Anda dapat memandang keindahan kota Cape Town&nbsp; (apabila cuaca memungkinkan).</p>\r\n\r\n<div>\r\n<div>\r\n<p style=\"text-align:justify\"><img alt=\"\" src=\"/mms/userfiles/images/d.jpg\" style=\"float:right; height:149px; opacity:0.9; width:200px\" /></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 3. 27 Dec : Cape Town </strong></p>\r\n\r\n<p style=\"text-align:justify\">Dipagi hari bila cuaca memungkinkan kita akan menuju Hout Bay, dari sana dengan kapal ferry menuju Seal Island untuk melihat anjing laut yang hidup di alam bebas, kita juga akan melewati jalur tercuram dan menantang di Chapmans peak, setelah makan siang dengan lobster seafood, tour dilanjutkan menuju tempat tertinggi&nbsp; di Cape Town&nbsp; yaitu<strong> Cape Point </strong>dengan<strong> funicular </strong>menuju<strong>&nbsp; Mercu suar </strong>&nbsp;untuk melihat &nbsp;&nbsp;pertemuan antara Samudera Atlantik dan Samudera Hindia. Juga mengunjungi Boulder beach untuk melihat burung Penguin Africa yang disebut Jackass&nbsp; Penguin.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari&nbsp; 4, &nbsp;28 Dec&nbsp; : CAPE TOWN &ndash; MOSSEL BAY&nbsp; - KNYSNA &nbsp;</strong></p>\r\n\r\n<p style=\"text-align:justify\">Perjalanan dilanjutkan dengan bus wisata menuju Mossel Bay untuk kembali ke 500 tahun lalu, melihat sejarah dari Bartolomeu Dias yang merupakan seorang bangsawan bangsa Portugis yang menjelajah ke selatan Afrika , setibanya&nbsp;diajak untuk mengunjungi dan melewati <strong>Post Office Tree</strong> dan <strong>Diaz&nbsp;Museum</strong>. Setelah makan siang Anda akan diantar menuju kota Knysna&nbsp;yang terkenal sebagai kota seni dan budaya dan menikmati pemandangan Knysna Head dengan <strong>John Benn Cruise</strong>.</p>\r\n\r\n<p style=\"text-align:justify\"><img alt=\"\" src=\"/mms/userfiles/images/w.jpg\" style=\"float:right; height:150px; opacity:0.9; width:200px\" /></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 5, &nbsp;&nbsp;&nbsp;29 Dec &nbsp;: KNYSNA &ndash; OUDTSHOON - GEORGE</strong></p>\r\n\r\n<p style=\"text-align:justify\">Pagi ini Anda akan melanjutkan perjalanan menuju kota <strong>Oudtshoorn </strong>yang terkenal dengan Feather Capital Of The World. Anda akan mengunjungi <strong>Cango Caves </strong>yang merupakan gua alam yang indah dengan stalagtit dan stalagmitnya. Kemudian ke&nbsp;<strong>Ostrich Farm </strong>(peternakan Burung Unta yang&nbsp;merupakan salah satu binatang khas Africa) . &nbsp;Setelah bersantap siang Anda akan mengunjungi <strong>Cango Wildlife&nbsp;</strong><strong>Ranch&nbsp; </strong>untuk melihat dari dekat binatang reptile dan cheetah dan bermalam di kota George.</p>\r\n</div>\r\n\r\n<div>\r\n<div style=\"text-align: justify;\"><br />\r\n<strong>Hari 6, &nbsp;30 Dec : George &ndash; Johannesburg &ndash; Sun City</strong></div>\r\n\r\n<p style=\"text-align:justify\">Perjalanan hari ini akan dilanjutkan dengan pesawat udara menuju&nbsp;Johannesburg Setibanya, dengan bus wisata kita akan menuju&nbsp;Sun City, ditengah perjalanan singgah di kota Pretoria yang merupakan&nbsp;ibukota dari negara Afrika Selatan untuk sightseeing tour melewati&nbsp;Voortrekker Monument, Union Building, Kruger House dan Church&nbsp;Square.</p>\r\n<img alt=\"\" src=\"/mms/userfiles/images/dfg.jpg\" style=\"float:right; height:143px; opacity:0.9; text-align:justify; width:200px\" />\r\n<div style=\"text-align: justify;\">Hari <strong>7. &nbsp;&nbsp;31 Dec&rsquo;16 : Sun City</strong></div>\r\n\r\n<p style=\"text-align:justify\">&nbsp;Pagi hari ini Anda akan mengikuti <strong>GAME DRIVE</strong> di <strong>PILANESBURG NATIONAL PARK</strong> &nbsp;melihat binatang-binatang khas Afrika yang&nbsp;merupakan acara yang sangat menarik dimana Anda dapat mengamati&nbsp;dari dekat kehidupan satwa - satwa liar di Afrika . Malam hari&nbsp;menyaksikan pertunjukan Odyssey Show yang terkenal.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;<strong>Hari 8, &nbsp;&nbsp;&nbsp;01 Jan&rsquo;17: Sun City </strong></p>\r\n\r\n<p style=\"text-align:justify\">Menikmati kemegahan &nbsp;dan bersantai di Sun City</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 9, &nbsp;02 Jan.17 : Sun City &ndash; Johanesburg</strong></p>\r\n\r\n<p style=\"text-align:justify\">Dengan bus wisata kembali ke kota Johanesburg, Acara tour di&nbsp;mengunjungi Gold Reef City yang merupakan contoh dari peninggalan&nbsp;jaman penggalian emas dan melihat pabrik pemotongan berlian. Malam&nbsp;hari Anda akan menikmati makan malam special dengan penyajian&nbsp;berbagai macam daging binatang seperti rusa dan buaya di Carnivore&nbsp;Restaurant.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 10, &nbsp;03 Jan&rsquo;17&nbsp; : Johannesburg &ndash; Jakarta</strong></p>\r\n\r\n<p style=\"text-align:justify\">Hari ini Anda akan diantar ke Airport untuk penerbangan kembali ke&nbsp;Jakarta. &nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong><img alt=\"\" src=\"/mms/userfiles/images/hghh.jpg\" style=\"float:right; height:138px; opacity:0.9; width:205px\" /></strong></p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 11, &nbsp;04 Jan. 17 : Jakarta</strong></p>\r\n\r\n<p style=\"text-align:justify\">InsyaAllah tiba di Jakarta. Dengan demikian berakhirlah perjalana Anda&nbsp;dengan membawa penuh kenangan bersama AMINAH &nbsp;TOUR. Sampai&nbsp;jumpa lagi pada lain kesempatan.</p>\r\n\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n'),
(6, '56PA0537-hr.jpg', 'Februari 2018', '2018-02-16', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '8 ', '0', '0', '8 HARI INDOCHINA LAOS, KAMBOJA , VIETNAM PLUS HALONG BAY CRUISE ', '<p><strong>Hari&nbsp; 01,&nbsp; Kamis 16. Pebruari : JAKARTA &ndash; *SAIGON &ndash; SIEM REAP </strong><br />\r\n<img alt=\"\" src=\"/mms/userfiles/images/angkor-wat.jpg\" style=\"float:left; height:199px; width:300px\" />Berkumpul di bandara international Soekarno-Hatta menuju kota bersejarah Kamboja , yaitu kota Siem Reap&nbsp; Setibanya dijemput lalu makan malam dan&nbsp; ke hotel untuk beristirahat.<br />\r\n<br />\r\n<strong>Hari 02, Jum&rsquo;at 17. Pebruari : SIEM REAP</strong><br />\r\nHari ini memulai perjalanan wisata&nbsp; ke candi yang paling terkenal &nbsp;karena keindahan dan kemegahannya Angkor Wat. Situs warisan dunia sejak tahun 1992 . menceritakan kisah-kisah dari mitologi Hindu. Kita akan mengunjungi&nbsp;&nbsp; Angkor Thom dengan memulai dari gerbang selatan ke kuil &nbsp;Bayon &nbsp;yang terkenal. Kita akan melihat 54 menara yang dihiasi dengan lebih 200 wajah tersenyum Avolokitesvara, Phimeanakas, Teras Gajah , kuil Ta Prohm , bantey Kdei. Malamnya menikmati makan malam dengan diiringi pertunjukan tarian tradisional Apsara Performance, kemudian kembali ke hotel.<br />\r\n&nbsp;</p>\r\n\r\n<p><strong>Hari 03, Sabtu 18. Pebruari : SIEM REAP &ndash; LUANG PRABANG (LAOS) - REP-LPQ&nbsp; VN.930&nbsp; 16.55-18.20</strong></p>\r\n\r\n<p>Setelah sarapan, mengunjungi&nbsp; pusat kerajinan di Artisan D&#39;Angkor , kemudian ke Old Market &lsquo;Pha Chas&rdquo; kita dapat membeli barang antik, perhiasan perak dan emas, permata, sutra, kramas, batu dan ukiran kayu, serta T-Shirts, CD dan souvenir lainnya , setelah makan siang melanjutkan perjalanan ke Luang Prabang&nbsp; dengan pesawat. Setibanya, kita&nbsp; akan makan malam dan istirahat di hotel.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Hari 04, Minggu 19. Pebruari : LUANG PRABANG &ndash; PAK OU CAVES </strong></p>\r\n\r\n<p>Hari ini Kita akan&nbsp; mengunjungi kuil tertua Wat Sene dan Wat Xiengthong yang terkenal dengan arsitektur klasik Laos. Lalu berlayar di hulu sungai Mekong yang akan memberikan pemandangan pedesaan yang tenang dan Kita juga&nbsp; akan&nbsp; menjelajah Gua Pak Ou, terdapat &nbsp;patung Buddha dari berbagai bentuk dan ukuran yang ditinggalkan oleh peziarah, kurang lebih 5000 patung Budha berbagai ukuran , kemudian akan singgah di desa Ban Xiengkong dan Ban Xienglek &nbsp;yang terkenal dengan kain tenunnya. Setelah itu&nbsp; Naik kepuncak Gunung Phousi untuk menikmati sunset. Sore hari&nbsp; menuju pasar malam disana Kita dapat menemukan kain textile&nbsp;buatan tangan yang dibuat oleh suku bukit atau orang-orang sekitar Luang Prabang.&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/mms/userfiles/images/images.jpg\" style=\"float:right; height:178px; opacity:0.9; width:284px\" /></p>\r\n\r\n<div>&nbsp;\r\n<div>\r\n<p><strong>&nbsp;Hari&nbsp; 05, Senin 20. Pebruari : LUANG PRABANG - HANOI&nbsp;&nbsp; ( LPQ-HAN VN.930 19.30-20.45 )</strong></p>\r\n\r\n<p>Pagi hari mengunjungi Museum &nbsp;Istana Kerajaan , di dalamnya terdapat &nbsp;berbagai macam artefak peninggalan kerajaan laos. Mengunjungi stupa mengesankan Wat Visoun dan kuil Wat Aham Lalu kita akan ke central Market , juga mengunjungi desa-desa dari kelompok minoritas etnis Lao di Ban Ouay, desa Hmong, Ban Ou dan &nbsp;desa Laoloum ini kemudian membawa kita ke Khuang Si Waterfall yang indah di mana Anda dapat mendinginkan dengan menyegarkan berenang di kolam renang atau berjalan di sepanjang jalan hutan. Sore hari menuju ke bandara &nbsp;&nbsp;untuk penerbangan ke kota Hanoi<br />\r\n&nbsp;</p>\r\n\r\n<p><strong>Hari&nbsp; 06, Selasa 21. &nbsp;Pebruari : HANOI &ndash; HALONG</strong><br />\r\nKita menuju ke Halong, merupakan salah satu warisan dunia yang diakui UNESCO sejak 1994 dengan kapal menyusuri perairan di teluk yang terkenal di seluruh penjuru dunia karena keindahannya.&nbsp; Kemudian, kita akan mengunjungi Surprise Cave, goa terindah di Halong Bay yang terkenal dengan stalagtit dan stalagmit dan menikmati pemandangan pantai berpasir putih, Titop Island . Kita&nbsp; akan menikmati makan malam dengan sajian seafood dan bermalam di kapal. ( B.L.D)<img alt=\"\" src=\"/mms/userfiles/images/hanoi.jpg\" style=\"float:left; height:181px; width:300px\" /><br />\r\n<br />\r\n<strong>Hari 07, Rabu 22. Pebruari : HALONG - HANOI</strong><br />\r\nPagi hari, berlatih Tai Chi&nbsp; dan melihat peragaan Cooking Class&nbsp; oleh chef kapal. Siang hari,&nbsp; kembali ke Hanoi dan setibanya di Hanoi,&nbsp; dapat berbelanja di area Old Quarter Hanoi (BLD)&nbsp;&nbsp;<br />\r\n<br />\r\n<strong>Hari&nbsp; 08, &nbsp;Kamis 23. Pebruari : HANOI &ndash; *SAIGON &ndash; JAKARTA </strong><br />\r\nHari ini&nbsp; kita akan&nbsp; kembali ke Jakarta. Dengan demikian, berakhirlah acara tour bersama kami. Terima kasih dan sampai jumpa di acara wisata kita yang lain.&nbsp;</p>\r\n</div>\r\n</div>\r\n'),
(7, '14ruinas-de-petra-mosteiro-jordania.jpg', 'Maret 2018', '2018-03-01', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '17', '0', '0', '17 HARI NAPAK TILAS PARA NABI\r\nJORDANIA-PALESTINE-ISRAEL-MESIR\r\n', '<p style=\"text-align: justify;\"><strong>Hari&nbsp; 01, Rabu 1 Mar&nbsp; :&nbsp; JAKARTA - AMMAN </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Berkumpul di Bandara SoeTa terminal 2 . InsyaAllah Anda akan memiliki pengalaman yang belum pernah terjadi sebelumnya. Mengungkap hal-hal yang Anda belum ketahui&nbsp; menjadi tahu. Kami mengajak Anda melihat budaya dan keramahan dari penduduk dunia&nbsp; sampai kunjungan yang&nbsp; memompa adrenalin&nbsp; Anda</p>\r\n\r\n<p><strong style=\"text-align:justify\"><img alt=\"\" src=\"/mms/userfiles/images/Center-Amman1.jpg\" style=\"float:right; height:200px; opacity:0.9; width:400px\" /></strong></p>\r\n\r\n<div>\r\n<div style=\"text-align: justify;\"><strong>Hari 02. Kamis 2&nbsp; Mar&nbsp; : AMMAN</strong></div>\r\n\r\n<p style=\"text-align: justify;\">Tiba di Amman, Sarapan pagi mengunjungi Ashabul Kafi, Mt. Nebo, dimana Nabi Musa alaihi Salam terlihat terakhir kali dan ke Kota Madian kota Nabi Syuaib Alaihisalam ( Mertua nabi Musa Alaihisalam)</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 02 Jum&rsquo;at&nbsp; 3&nbsp; Mar :&nbsp; AMMAN &ndash; &nbsp;PETRA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari menuju kota Petra melewati Uyun Musa (Mata air nabi Musa) Kemudian menuju <strong>Petra,</strong> merupakan daerah Edom, ibu kota serta tempat pertahanan Kerajaan Nabatean sejak abad ke 4 SM sampai abad ke 2 M. Semua peninggalan bangunan dan makam di tempat ini dipahat pada Bukit Tebing Batu berwarna kemerah-merahan. Itulah sebabnya tempat ini pun dikenal sebagai &ldquo;The Red Rose City&rdquo;.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 04, Sabtu&nbsp; 4 Mar&nbsp; :&nbsp; PETRA - KARAK &ndash; LAUT MATI</strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/PETRA.jpg\" style=\"float:left; height:169px; width:300px\" />&nbsp;melanjutkan perjalanan ke kotaKarak.Tiba di&nbsp; Karak mengunjungi Pemakaman&nbsp; 3 sahabat Nabi Muhammad&nbsp; Shallalahu alaihi wasallam pada saat perang Mutah&nbsp; :&nbsp; <strong>Ja&rsquo;far&nbsp; bin Abi Thalib</strong> ( Ja&rsquo;far al&nbsp; Tayyar Shirine), Abdullah bin <strong>Ruwaha , Zaid bin&nbsp; Haritshah</strong>&nbsp; dan mengunjungi&nbsp; istana&nbsp; Salahudin kemudian menuju Laut&nbsp; Mati&nbsp; untuk&nbsp; berendam ,serta bermalam di daerah laut mati.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 05. Minggu 5 Mar&nbsp; :&nbsp; LAUT MATI &ndash; JERICHO &ndash;TIBERIAS</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari &nbsp;menuju Perbatasan Jordania dan Palestina/Israel melalui Alenby Brigth &nbsp;kota<strong> Jericho</strong>, terletak di Lembah&nbsp; Yordan.&nbsp; Letaknya&nbsp; 280 m&nbsp; di bawah permukaan laut, Yerikho salah satu&nbsp; kota tertua di dunia.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 06, Senin 6 Mar&nbsp; :&nbsp; TIBERIAS &ndash; CANA &ndash; NAZARET- YARDENIT - TIBERIAS</strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;Pagi hari mengunjungi Tabgha&nbsp; tempat ini dahulu dinamakan &ldquo;Khotbah di Bukit&rdquo;&nbsp; yang terkenal dengan pemberian makan kepada ribuan orang dari lima roti 2 ikan, juga &nbsp;kota kuno Capernahum yang dikenal The Town Of Jesus. menyusuri Danau Galilea, merupakan sejarah&nbsp;&nbsp; sejumlah peristiwa perjalanan nabi Isa As . Lalu &nbsp;menuju kota Cana, &nbsp;tempat Nabi Isa As melakukan mujijatNya yang pertama mengubah air menjadi &nbsp;anggur.&nbsp; menuju Nazareth, mengunjungi Basilica of the Announciation, dimana Maria menerima kabar &nbsp;Gembira. Menuju kota Yardenit, dipinggir Sungai Yordan, tempat Nabi Isa Alaishisalam &nbsp;dibaptis oleh Nabi Yahya Alahisalam<img alt=\"\" src=\"/mms/userfiles/images/TIBEREAS.jpg\" style=\"float:right; height:179px; width:281px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 07.</strong><strong> Selasa&nbsp; 7 </strong><strong>&nbsp;Mar : TIBERIAS </strong><strong>&ndash; HAIFA-TEL AVIV &ndash; JERUSALEM</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Meninggalkan kota Tiberias &nbsp;menuju kota Haifa, &nbsp;mengunjungi maskot kota Haifa ialah kuil pusat kebudayaan kepercayaan Bahai, dengan kubah emas yang berkilauan dengan megahnya. Mengunjungi Caesarea, kota terbesar pada zaman Romawi, kita melihat dari dekat Aquaduct Theater yang dibangun Herodes. Melewati Tel Aviv, kota termodern di Israel yang menjadi pusat &nbsp;komersil, industri, hiburan, &nbsp;berteknologi tinggi. Kita singgah di Jaffa, kotanya Nabi Yunus As, yang pernah tinggal didalam perut ikan selama 3 hari. Kita dapat mengabadikan pemandangan tepi pantai laut Tengah yang indah disenja hari, kemudian menuju Jerussalem, Check in hotel, makan malam</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 08. Rabu 8 Mar</strong> : Dilanjutkan menuju ke kota Jerusalem, mengunjungi&nbsp; <strong>Dome of the Rock</strong>.&nbsp; Al Quran nur karim&nbsp; menyatakan Bahwa Nabi Muhammad&nbsp;&nbsp; Shallalahu alaihi wasallam&nbsp; diangkat ke Sidratul Muntaha&nbsp; dari lokasi ini pada tahun 621 Masehi dibangun pada era kekholifahan Bani Umayah, Abdul Malik bin Marwan, antara tahun 65-86 H atau 684 &ndash; 705 M. Masjidil <strong>Aqsho</strong>, arti harfiah: &quot;masjid terjauh&quot; Masjid Al-Aqsa dulunya&nbsp; dikenal sebagai Baitul Maqdis, merupakan Kiblat Sholat&nbsp; umat Islam yang&nbsp; pertama .Sholat Magrib dan Isa di Masjidil Aqsho</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 08, Rabu 8 Mar : JERUSALEM &ndash; HEBRON &ndash; BETHELHEM &ndash; JERUSALEM</strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/JERUSALEM.jpg\" style=\"float:left; height:168px; width:300px\" />Sholat tahajud dan Subuh di Masjidil Aqsho, mengunjungi Bukit Zaitun tempat dimana Nabi Isa Alahi Salam&nbsp; berdoa kepada Allah Subhanahuwataa&rsquo;ala lalu menuju kota <strong>Hebron</strong> , dimana terdapat makam dari <strong>Nabi Ibrahim Alahi Salam</strong> istri nya <strong>Sarah</strong>, Nabi Ishaq Alahi Salam,&nbsp; Nabi Ya&#39;kub Alahi Salam Lalu menuju <strong>Betlehem </strong>Tempat lahir Nabi Isa As&nbsp; sekarang menjadi Gereja Basilika (Gereja Nativity)<strong>mengunjungi Mt.Zion, terdapat</strong>Basilika Dormitio di dalam Basilika Dormitio terdapat <strong>Senakel ( Ruang Perjamuan&nbsp;&nbsp; dan Makam Nabi Daud As&nbsp;</strong>Melewati <strong>Jalan Salib Via Dolorosa</strong> dan berakhir di Gereja Makam suci. Juga mengunjungi&nbsp;<strong>Tembok Ratapan, </strong>Tembok luar di sebelah barat Bait Suci Yahudi disebut Tembok &nbsp;Ratapan, yang saat ini menjadi tempat paling suci bagi umat Yahudi dunia. Kembali ke Jerusalem. &nbsp;Sholat di Masjid Al-Aqsa yang dulunya dikenal sebagai <strong>Baitul Maqdis</strong>, merupakan Kiblat &nbsp;Shalat umat Islam yang <a href=\"http://id.wikipedia.org/wiki/Pertama\" title=\"Pertama\">pertama</a> sebelum dipindahkan ke Ka&#39;bah. Mengunjungi <strong>D</strong><strong>ome </strong>&nbsp;<strong>of the Rock </strong>ditempat inilaah peristiwa Isra-Mi&rsquo;raj Rasulallah Shalalahu Alahisalam.&nbsp; Qubbah Sakhra &nbsp;dibangun secara bersama-sama oleh tiga bangsa dunia, Arab, Romawi dan Turki dengan arahan dua insinyur terkenal, Raja bin Hayah al-Kindi (salah seorang &nbsp;ilmuwan Chechnya) dan Yazid bin Salam (ilmuwan Al-Quds ).</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 09, Kamis&nbsp; 9 Mar : JERUSALEM - </strong><strong>&nbsp;EILAT &ndash; TABA BORDER-ST.CATHERINE</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Menuju perbatasan&nbsp; Thaba &nbsp;adalah batas tiga negara antara Mesir, Israel dan Yordania Dalam perjalanan melewati daerah kaum Sodom dan Gumorah (nabi Luth As) jugamelewati jalan yang membelah kota Eilat,Kota Tunis modern di ujung Selatan Israel,ditepi Laut Mati. Tiba di perbatasn Mesir, langsung menuju <strong>ST. C</strong><strong>atherine, </strong>di lembah ini terdapat sebuah biara bernama Saint Catherine yangdibangun pada abad ke 6 M. Nama ini diambil dari nama seorang anak pemimpin Alexandria ketika itu yang disiksa karena memeluk agama Kristen</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 10, </strong><strong>Jum&rsquo;at 10 Mar &nbsp;</strong><strong>:</strong><strong> :&nbsp; ST.CATHERINE - MT.SINAI &ndash;</strong><strong> SHARM&nbsp; el SHEIKH -</strong><strong> CAIRO</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><span style=\"text-align:right\">P</span><strong style=\"text-align:right\">erjalanan menuju&nbsp; </strong><strong style=\"text-align:right\">Gunung Sinai</strong><strong style=\"text-align:right\">. </strong><span style=\"text-align:right\">Tiba di </span><strong style=\"text-align:right\">gunung Thur</strong><span style=\"text-align:right\"> inilah</span><strong style=\"text-align:right\"> Nabi Musa </strong><strong style=\"text-align:right\">As</strong><span style=\"text-align:right\">. berbicara dengan Allah Swt, ketika menerima wahyu (Ten Commandments). Gunung ThursinaTerletak pada ketinggian 2500 m dari permukaan laut. ziarah </span><strong style=\"text-align:right\">makam Nabi Saleh</strong><span style=\"text-align:right\"> dan </span><strong style=\"text-align:right\">Nabi Harun serta patung `ijl</strong><span style=\"text-align:right\">(anak lembu) yang dibuat oleh Samiri ketika Nabi Musa berkontempalsi selama 40 hari . Melanjutkan perjalanan menuju </span><strong style=\"text-align:right\">&nbsp;Sharm el-Sheikh </strong><span style=\"text-align:right\">lalu melanjutkan dengan penerbangan menuju kota</span><strong style=\"text-align:right\"> Cairo.<img alt=\"\" src=\"/mms/userfiles/images/MT_%20SINAI.jpg\" style=\"float:right; height:194px; width:259px\" /></strong></p>\r\n\r\n<p style=\"text-align: right;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 11. Sabtu&nbsp; 11 </strong><strong>&nbsp;Mar </strong><strong>: CAIRO &ndash; GIZA - ASWAN</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Mengunjungi <strong>M</strong><strong>useum Egyptian</strong>di dalamnya ada&nbsp;&nbsp; mumi Fir&rsquo;aun yang masih terawat dengan baik sejak sebelum masehi sampai sekarang.Mengunjungi&nbsp;<strong>T</strong><strong>iga Piramid</strong>di dataran Tinggi izadibangun untuk tiga Firaun dari dinasti keempat, yaitu :<strong>C</strong><strong>heops</strong> (Khufu),<strong>C</strong><strong>hepren</strong>(Khafre) dan <strong>M</strong><strong>ycerinus</strong> (Menkaure) Mereka merupakan 3 generasi Firaun yang memerintah turun temurun mulai dari Kakek, anak dan cucu pada abad ke 26 SM. <strong>S</strong><strong>phink</strong> &ndash;yangberbadan singa berkepala manusia, dengan panjang 57 meter serta tinggi 20 meter . Menghunjungi <strong>Citadel of Saladin, Masjid Moh Ali</strong>.kemudian dengan naik kereta malam &nbsp;dari Cairo menuju&nbsp; kota Aswan</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 12, , Minggu 12 Mar :&nbsp;&nbsp; </strong><strong>ASWAN &ndash; ABU SIMBEL &ndash; ASWAN&nbsp; </strong><strong>KOMOMBO - EDFU</strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/ASWAN.jpg\" style=\"float:left; height:200px; width:300px\" />Tiba di Aswan (makan pagi di sajikan di kreta api)diantar ke Sungai Nil, untuk check in kapal pesiar Sungai berbintang 5.Melanjutkan perjalanan ke kota <strong>Abu&nbsp;</strong><strong>Simbel</strong> dengan bus.Abu Simbel adalah dua bukit yang diukir berbentuk patung fir&rsquo;aun Ramsis II yang berjumlah 4 patung dan patung istri tercintanya yang bernama Nefertari. Dalam sejarah fara&rsquo;inah, ada dua fira&rsquo;un yang membangun situs ma&rsquo;bad untuk istrinya yakni Ramsis II untuk Nefertari dan Akhneten untuk Nefertiti.Jika Ramsis II membangun situs peribadatan di Aswan, Akhneten membangun di kuil Akhneten di Luxor. Tiba&nbsp; kembali di Aswan Mengunjungi <strong>High Dam, Unfinished Obelisk, Kitchner Island (Botanical&nbsp;</strong><strong>garden) of Felucca</strong>, Setelah makan siang dan&nbsp; berlayar menuju <strong>Komombo</strong>,mengunjungi <strong>the Temple of Sobek</strong>: kuil yang dibangun oleh Thutmosis III,fir&rsquo;aun ke enam dari dinasti ke delapan belas Thutmosis memimpin Hatshepshut. Pembangunan kuil&nbsp; bertujuan untuk menghormati salah satu&nbsp;<strong>dewa ya</strong><strong>itu Sobek</strong>, dewa yang berbadan manusia dan berkepala buaya. Sobek sering dikaitkan dengan dewa keburukan, selanjutnya berlayar ke <strong>kota Edfu</strong>, dalam perjalanan melihat <strong>Aga KhanMausoleum dan Pulau Kitchener</strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 13, Senin&nbsp; 13&nbsp; Mar</strong> &nbsp;<strong>: EDFU &ndash;ESNA - &nbsp;LUXOR</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Tiba di kota Edfu . Edfu adalah pemerintahan keturunan Ptolemeus dari Yunani. &nbsp;Mengunjungi <strong>kuil Horus</strong> di dirikan pada masa Cleopatra VII pada tahun 237 SM. Horus adalah nama dewa kebaikan &nbsp;Berlayar ke<strong> Luxor</strong> melalui <strong>Esna Lock (</strong>kunci Esna).Acara bebas sembari menikmati pemandangan sungai Nil sembari &nbsp;minum teh&nbsp; .Mengujungi Kuil Edfu, siang hari berlayar ke Luxor. Tiba diLuxor mengujungi Kuil <strong>Hatshepsu</strong><strong>t</strong>. Hatshepsut adalah pharaoh wanita yang sukses memerintah selama 20 tahun<img alt=\"\" src=\"/mms/userfiles/images/Luxor-Egypt.jpg\" style=\"float:right; height:199px; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 14, Selasa 14&nbsp; Mar </strong>: &nbsp;<strong>LUXOR</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Mengunjungi . <strong>Candi Karnak</strong> dipenuhi dengan 134 buah gigantic columns dengan ruangan super besar yang tak berujung, di kedua sisi gerbang utama sebelum lorong Great Hypostyle berdiri patung granit Raja Ramses II. Dan pada jantung kompleks candi Karnak terdapat Kuil Anum yang didedikasikan untuk raja para dewa. dibangun oleh Pharaoh Amenhotep III.&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari </strong><strong>15.&nbsp; Rabu 15&nbsp; Mar </strong><strong>: &nbsp;LUXOR - CAIRO</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Mengunjungi Luxor timur merupakan pusat aktivitas peradaban dimana segala mahluk hidup lahir, tumbuh, dan menjalani kehidupan. Sedangkan Luxor barat merupakan lokasi kubur/makam dan kuil penyembahan dewa kematian.&nbsp; atau dikenal juga dengan sebutan Thebes. Setelah menyeberang Nil perhentian pertama di <strong>Colossi of Memnon</strong>, namun kemegahan Colossi of Memnon hanya tersisa dengan <strong>dua patung Pharaoh Amenhotep III</strong> yang berposisi duduk dan tangan menangkup lutut serta pandangan ke arah timur Nil. dari Luxor menuju Cairo&nbsp; dengan MS. 358. Tiba di CairoCheck in hotel, istirahat</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 16, Kamis. 16 Mar&nbsp; CAIRO </strong><strong>&ndash; JAKARTA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Check out hotel, Mengunjungi Citadel dan Masjid Muhamad Ali Pasya juga bisa berfoto mengunakan gaun khas Mesir. Sore hari menuju airport untuk kembali ke tanah air tercinta.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 17 . Jum&rsquo;at 17&nbsp; Mar&nbsp;&nbsp; </strong><strong>&nbsp;&nbsp;&nbsp;: JAKARTA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Insyaallah tiba di Jakarta dengan sejuta kenangan yang tak terlupakan&nbsp;</p>\r\n</div>\r\n'),
(8, '64pamukalle.jpg', 'Maret 2018', '2018-03-23', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '18', '0', '0', '', '<p style=\"text-align: justify;\"><strong>Hari 1, Kamis 23 &nbsp;Mar&nbsp; :&nbsp; JAKARTA &ndash; ISTANBUL&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Peserta berkumpul di bandara Soekarno hatta terminal 2. D.I. Keberangkatan dari Jakarta menuju Istanbul .</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/istanbul.jpg\" style=\"float:right; height:150px; opacity:0.9; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 2, Jum&rsquo;at&nbsp; 24 Mar : ISTANBUL &ndash; BURSA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Tiba di kota Istanbul langsung menuju kota Bursa melalui kota Eskihisar dan Topcular dengan Fery sepanjang perjalanan dengan fery. Tiba di kota Bursa yang termasuk 4 kota terbesar di Turkiye dan terkenal sebagai kota hijau. Bursa termasuk kota Budaya&nbsp; terpenting dengan&nbsp; bangunan-bangunan bersejarah. Bermalam di Bursa Check in hotel</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 3, Sabtu 25 &nbsp;Mar: BURSA &ndash; IZMIR -&nbsp; KUSADASI</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Mengunjungi&nbsp; Ulu&nbsp; Mosque&nbsp; (masjid Ulu), Green Mosque = Yesil Cami (dibaca Yesil Jami)&nbsp; dibangun oleh sultan Mehmet I tahun 1419 dan 1923.&nbsp; Sebutan Masjid hijau&nbsp; karena&nbsp; ornamenya berwarna hijau dan biru, berbelanja ditoko cendra mataHari ini kita akan menuju kota Kusadasi kota tepi pantai melalui kota Izmir, tiba di kota Kusadasi check in hotel istirahat<img alt=\"\" src=\"/mms/userfiles/images/Bursa.jpg\" style=\"float:left; height:221px; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 4, Minggu 26 Mar&nbsp; : IZMIR &ndash; EPHESUS -&nbsp; PAMUKALE</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini kita akan mengunjungi Ephesus kota tua jaman Romawi&nbsp; salah satu peninggalan terbesar yang masih ada hingga kini, bangunan perpustakaan Celcius, Hadrian Temple,Marble Street dan&nbsp; Agora. juga terdapat House of Virgin Mary.Setelah itu kita juga akan&nbsp; menikmati Fashion show jaket kulit di outlet center, acara berbelanja, dilanjutkan ke kota Pamukkale. Bermalam di Pamukkale</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 5, Senin 27 &nbsp;Mar : PAMUKALE - KONYA- SULTANHANI- CAPPODOCIA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Kita akan mengunjungi reruntuhan dari Kota Kuno Hierapolis&nbsp; yang menyimpan sejarah &nbsp;awal kerajaaan Turki, berorientasi ke cotton Castle, kolam air&nbsp; yang dikenali dengan panggilan Cleopatra Bath, merupakan harta warisan dunia, di sini kita dapat melihat kolam air mineral dalam bentuk terasering yang sangat indah&nbsp; dan melanjutkan perjalanan ke kota Konya. Tiba di Konya engunjungi Masjid Mevlana&nbsp; dan Mevlana Museum.&nbsp;&nbsp; Mevlana merupakan pendiri&nbsp; tarian sufi&nbsp; Whirling Derwish&nbsp; (tarian dimana penarinya mampu berputar lama) disinilah&nbsp; awal mula Islam di Turki, juga melihat berbagai peninggalan&nbsp; Mevlana seperti al quran, ukiran kayu, karpet, alat muzik, dll.&nbsp; dan melanjutkan perjalanan ke kota Cappadocia. Tiba di Cappodacia kota yang dikenal dng &ldquo;The Flinstone city. Kita langsung bermalam</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 6, Selasa 28 &nbsp;Mar :&nbsp; CAPPADOCIA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari Optional naik balon udara Hot Air Baloon, setelah santap pagi kita akan &nbsp;Mengikuti Full day tour di cappadocia, dengan pemandangan alam yang unik yang terbentuk secara alami, masuk ke Underground City of Kaymakli (kota bawah tanah yang dibangun di dalam goa dan kawasan gua yang &nbsp;pernah didiami oleh koloni kristian pada zaman dahulu) mengunjungi Fairy Chimney Urgup , kumpulan batu karang yang menyerupai cerobong asap yang terbentuk akibat letusan gunung merapi,&nbsp; Goreme Open-Air Museum, Uchisar, photo stop di Valley of the Birds dan Uchisar Castle.<img alt=\"\" src=\"/mms/userfiles/images/Turkey-cappacodia.jpg\" style=\"height:500px; width:1000px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 7, Rabu 29 &nbsp;Mar : CAPPADOCIA &ndash; CORUM - AMASYA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Meninggalkan kota Cappadocia dan&nbsp; menuju Black Sea Region. Pertama menuju kota Corum untuk mengunjungi Hattusas yang merupakan ibukota dari Kerajaan Hittite Kuno dan merupakan salah satu UNESCO World Heritage. juga akan&nbsp; melihat Yazilikaya yang merupakan tempat suci bagi Kerajaan Hittite. Pada zaman dahulu tempat ini digunakan sebagai tempat diadakannya&nbsp;berbagai upacara keagamaan atau adat. Melanjutkan perjalanan ke kota Amasya</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 8, Kamis 30 &nbsp;Mar&nbsp;&nbsp; : AMASYA &ndash; SYAFRAN BOLU</strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/Amasya_16878.jpg\" style=\"float:left; height:199px; opacity:0.9; width:300px\" /></p>\r\n\r\n<div>\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">Pagi ini orientasi &quot;kota seribu jendela&quot;&nbsp; dengan mengunjungi Sultan Beyazit II Mosque. Kemudian menuju Green river gate untuk berfoto di&nbsp;Patung Selfie Ottoman Prince&nbsp; patung pangeran ttoman yang terlihat seperti selfie memegang ponsel di tangannya. Photostop di&nbsp; Amasya Castle,&nbsp; mengunjungi&nbsp; Rock Tombs&nbsp; dan&nbsp; Museum Arkeologi&nbsp; &amp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;Mummy. Perjalanan dilanjutkan menuju Safran Bolu</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 9, Jum&rsquo;at 31 &nbsp;Mar&nbsp; : &nbsp;&nbsp;SYAFRAN BOLU- ISTANBUL</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini Anda akan diajak berorientasi kota sejenak dengan melihat Cinci Hoda Caravanserai, Cinci Hamami, Hodja bath Temple, Kaymaklar Museum dan berbelanja di&nbsp; Safran Bolu Bazaar. lanjutkan perjalanan menuju Istanbul</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 10. Sabtu&nbsp; 01 Apr&nbsp;&nbsp; : &nbsp;ISTANBUL</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini kita memulai dengan mengunjungi IstanaTopkapiI&nbsp; Inilah istana peninggalan 24 raja dari Dinasti Ottoman Turki yang sangat terkenal.di istana ini kita dapat menikmati koleksi benda peninggalan kerajaan, seperti jubah Sultan, mahkota dan berbagai benda bersejarah lainnya.&nbsp; juga&nbsp; menyimpan koleksibenda bersejarah bagi agama Yahudi, Kristen dan Islam. Antara lain,tongkat Nabi Musa, potongan tangan kanan milik Yohannes Pembaptis yang dikenal dalam sejarah kristiani, juga pedang,&nbsp; rambut , janggut, gigi, stanpel dan jubah Nabi Muhamad Saw. Hagia Sofia atau Aya Sofia. Bangunan yang berdiri pada abad ke 5 ini sampai 1453 Masehi masih menjadi gereja kathedral basilika Byzantium. Ketika Sultan Muhammad II,&nbsp;&nbsp; menguasai Konstantinopel pada 27 Mei 1453, beliau merubah bangunan ini menjadi mesjid.&nbsp; Sebagai bukti bahwa bangunan ini bekas gereja, diatas langit-langit mimbar mesjid, diantara tulisan Allah dan Muhammad, masih terdapat gambar Bunda Maria dan Jesus yang dulunya pernah ditutupi oleh cat putih. Kini tempat ini menjadi museum sekaligus simbol perdamaian antara Islam dan Nasrani . Mengunjungi&nbsp; Hippodrome Square, merupakan bekas kediaman resmi Dinasty Ottoman selama 800 tahun juga merupakan sisa pengaruh budaya Mesir yang ditandai dengan tiga menara batu Obelix. Blue Mosque atau mesjid Sultan Ahmed&nbsp; atau Mesjid Biru&nbsp;&nbsp; yang&nbsp; terkenal dengan keunikan arsitekturnya, dibangun oleh Mehmet Alga, anak murid dari arkitek agung, Ibnu Sinan. Sore hari menikmati keindahan Selat Bosphorus dengan kapal,&nbsp; . Kembali ke hotel istirahat.</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/istanbul2.jpg\" style=\"float:left; height:120px; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 11, Minggu&nbsp; 02 Apr:&nbsp;&nbsp; ISTANBUL &ndash; MADINAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setelah makan pagi&nbsp; check out hotel , safar&nbsp; Maqam Ayub al&nbsp; Anasyori (sahabat Nabi Muhammad SAW yang mempunyai tanah Masjid Nabawi) transfer menuju ke&nbsp; airport untuk penerbangan menuju kota Madinah.Setelah tiba di kota Madinah, Jamaah akan check in hotel dan bagi Jamaah pria dapat berziarah&nbsp; ke Raudah,&nbsp; makam nabi Muhammad Saw dan&nbsp; Sahabat &nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 12, Senin 03 Apr&nbsp; : MADINAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Memperbanyak ibadah di Masjid Nabawi&nbsp;<img alt=\"\" src=\"/mms/userfiles/images/mdnh.jpg\" style=\"float:right; height:313px; width:640px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 13, Selasa 04 Apr&nbsp; MADINAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Sholat Tahajud dan Subuh di Masjid Nabawi. Setelah sarapan pagi, Jamaah akan diajak untuk berziarah kota Madinah diantaranya ke, Masjid Quba, Jabal Uhud, pasar Qurma dan Percetakan al Quran.&nbsp; Para&nbsp; Jamaah&nbsp; dapat berziarah kembali ke Raudah dan Makam Nabi Muhammad Saw, makam sahabat Nabi Abu bakar Ra serta makam Umar bin Khatab Ra.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 14, Rabu 05 Apr &nbsp;: MADINAH &ndash; MAKKAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setelah Shola t&nbsp; Zhuhur , Jamaah akan meninggalkan kota suci Madinah menuju kota suci Makkah, dan akan mengambil miqot di Masjid Bir Ali.&nbsp; Tiba di kota suci Makkah, tempat lahirnya Islam dan Nabi Muhammad S.a.w. serta tempat Baginda menerima wahyu dari Allah Swt Kota tempat melaksanakan ibadah haji dan umrah. Jamaah&nbsp; check in hotel&nbsp; lalu melaksanakan umroh</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 15, Kamis &nbsp;06 Apr &nbsp;: MAKKAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Memperbanyak ibadah di masjidil Haram.&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 16, Jum&rsquo;at&nbsp; 07 Apr&nbsp;&nbsp; :&nbsp; MAKKAH</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setelah santap pagi di hotel Jamaah akan di ajak untuk berziarah di seputar kota Makkah Jabal Tsur, Jabal Nur, Padang Arafah / Jabal Rahmah, Mina&nbsp; dan terakhir di Masjid Ji&rsquo;ronah</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 17, Sabtu&nbsp; 08 Apr&nbsp;&nbsp; : MAKKAH&ndash; JEDDAH - JAKARTA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini kita akan meninggalkan kota suci Makkah&nbsp; menuju kota Jeddah. Tiba di kota Jeddah melihat indahnya kota Jeddah di malam hari, sholat magrib di Masjid laut merah. Makan malam dan transfer airport untuk penerbangan kembali ke Tanah air.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari&nbsp; 18, Minggu&nbsp; 09 Apr&nbsp;&nbsp; :&nbsp; JAKARTA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">InsyaAllah tiba di kota Jakarta ,&nbsp; dengan membawa kenangan&nbsp; yang tak terlupakan dan semoga mendapatkan Umroh Makbul</p>\r\n</div>\r\n');
INSERT INTO `jadwaltour` (`no`, `foto`, `bulan`, `tanggal`, `paket`, `kamar1`, `kamar2`, `kamar3`, `kamar4`, `pesawat`, `htlmadinah`, `htlmakkah`, `berangkat`, `tujuan`, `transit`, `pembimbing`, `lama`, `kapasitas`, `terisi`, `singkat`, `ket`) VALUES
(9, '65stock-photo-beautiful-amsterdam-76796579.jpg', 'April 2018', '2018-04-17', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '13', '0', '0', '', '<p style=\"text-align:justify\"><strong>Hari 1, Apr. 17 &nbsp;Senin&nbsp; : JAKARTA &ndash; AMSTERDAM</strong></p>\r\n\r\n<p style=\"text-align:justify\"><img alt=\"\" src=\"/mms/userfiles/images/stock-photo-beautiful-amsterdam-76796579.jpg\" style=\"height:213px; width:500px\" /></p>\r\n\r\n<p style=\"text-align:justify\">Dengan mengucap Bismillahirrahmanirrahim Para peserta diharapkan sudah berkumpul di bandara Soekarno-Hatta 2,5&nbsp; jam sebelum waktu keberangkatan menuju&nbsp; Amsterdam</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 2, Apr. 18.Selasa </strong>&nbsp;<strong>: AMSTERDAM</strong></p>\r\n\r\n<p style=\"text-align:justify\">Tiba di Amsterdam langsung berwisata ke kota kecil yang dahulu merupakan desa nelayan yaitu <strong>Volendam. </strong>Anda dapat berfoto menggunakan pakaian tradisional Belanda. &nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 3, Apr 19. Rabu &nbsp;: AMSTERDAM &ndash; LISSE - AMSTERDAM</strong></p>\r\n\r\n<p style=\"text-align:justify\">Mengunjungi kota Lisse disana terdapat taman bunga yang ada pada saat musim semi saja yaitu taman bungga Tulip tepatnya di <strong>Keukenhof ,</strong>dilanjutkan dengan wisata <strong>Canal Cruise</strong>. Kemudianmelewati <strong>Old town&nbsp;</strong><strong>Amsterdam&nbsp; </strong>terdapat <strong>Royal Palace, National Monument dan Central Station </strong>mengunjungi <strong>Worskshop penasahan berlian </strong>&nbsp;&nbsp;<img alt=\"\" src=\"/mms/userfiles/images/download.jpg\" style=\"float:right; height:175px; width:288px\" /></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 4, Apr. 20. Kamis &nbsp;: AMSTERDAM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>\r\n\r\n<p style=\"text-align:justify\">Pagi hari menuju desa <strong>Kinderdijk</strong> adalah sebuah desa di Belanda, dibangun sekitar 1740. &nbsp;Tempat ini pun telah ditetapkan menjadi Situs Warisan Dunia UNESCO pada tahun 1997. &nbsp;Sore hari berbelanja di&nbsp; Pasar <strong>Albert Cuyp Market</strong> yang terletak di distrik &lsquo;De Pijp&rsquo;. Pasar ini adalah pasar terbuka terbesar di Eropa. Anda dapat menemukan semuanya disini.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 5. Apr. 21. Jum&rsquo;at : AMSTERDAM &ndash; BRUSSELS (BELGIA)&nbsp; </strong></p>\r\n\r\n<p style=\"text-align:justify\">Hari ini meninggalkan kota Amsterdam dilanjutkan perjalanan&nbsp; ke kota Brussels, Setibanya di Brussels, Berfoto di &nbsp;<strong>Atomium</strong> &nbsp;sebuah ikon bangunan yang menampilkan sembilan bola baja tahan karat yang dihubungkan dengan tabung metal besar untuk menyerupai sebuah kristal besi. Struktur ini awalnya dibuat sebagai atraksi utama untuk World Expo 1958 Belgia . Anda dapat memasuki empat bola teratas Atomium yang salah satu bola berisi restoran, sedangkan bola-bola lainnya memajang pameran permanen. Kemdian ke taman&nbsp; <strong>Parc du Cinquantenaire </strong>/ <strong>Taman Jubilee</strong>, ini adalah monumen nasional sekaligus taman kota. Taman seluas 30 hektare ini dibangun atas perintah Raja Leopold II untuk menandai ulang tahun ke-50 kemerdekaan Belgia. Mengunjungi <strong>Islamic centre</strong>.&nbsp; Kemudian &ldquo;Walking Tour&rdquo; ke Old Town, &nbsp;<strong>La Grand Palace (Grotte Mark )</strong>&nbsp;&nbsp; ini merupakan kawasan alun-alun kota dan dikelilingi bangunan tua berarsitektur gotik yang menawan. Selain sebagai salah satu tujuan wisata, kawasan ini juga sering digunakan sebagai tempat pertunjukan festival kebudayaan internasional. Di sekitarnya terdapat kafe dan pertokoan yang bisa dijadikan pilihan untuk berwisata belanja. Terutama belanja cokelat dan waffle khas Belgia yang sangat terkenal kelezatannya.</p>\r\n\r\n<div style=\"text-align: justify;\">H<strong>ari </strong><strong>6 </strong><strong>,&nbsp; </strong><strong>Apr</strong><strong> 22 , Sabtu </strong><strong>: BRUSSELS- PARIS</strong></div>\r\n\r\n<p style=\"text-align:justify\"><img alt=\"\" src=\"/mms/userfiles/images/brusles.jpg\" style=\"height:159px; width:318px\" /></p>\r\n\r\n<p style=\"text-align:justify\">Pagi hari menuju kota mode Paris , Tiba di kota Paris berbelanja di <strong>outlet La</strong><strong>fayette.</strong></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari </strong><strong>7</strong><strong>, </strong><strong>Apr.23, Minggu </strong>&nbsp;: <strong>PARIS</strong></p>\r\n\r\n<p style=\"text-align:justify\">Pagi hari &nbsp;menuju Islamic centre lalu city tour &nbsp;ke <strong>ARC DeTriomphe, Place De La&nbsp;</strong><strong>Concorde</strong>, Terowongan Pont De Alma, Des Invalides, &nbsp;<strong>siang hari </strong>mengunjungi &nbsp;<strong>M</strong><strong>enara Eiffel</strong> <strong>Melihat Eifel </strong>hingga tingkat ke-2 dimana kita dapat menikmati keindahan kota Paris dari atas.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 8,</strong><strong> Apr. 24, Senin :&nbsp; PARIS<img alt=\"\" src=\"/mms/userfiles/images/paris.jpg\" style=\"float:right; height:290px; width:500px\" /></strong></p>\r\n\r\n<p style=\"text-align:justify\">Berfoto di <strong>Museum Musee de Louvre</strong>, &nbsp;Louvre mengandung seni yang terkenal di dunia, patung dan artefak dari periode yang mencakup lebih dari 2.000 tahun sejarah. Walaupun, bangunan itu sendiri di bangun di abad ke-12. Berbelanja Parfum.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 9 &nbsp;Apr&nbsp; 25, Selasa PARIS &nbsp;- INTERLAKEN</strong></p>\r\n\r\n<p style=\"text-align:justify\">Hari ini kita akan tinggalkan kota Mode Paris menuju Negara Swizerland tepatnya&nbsp; ke kota Interlaken Lunch : An Shu&nbsp; Restaurant ---------- Dinner : Hotel</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hotel :&nbsp; LINDNER GRAND BEAU RIVAGE</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari </strong><strong>10 </strong><strong>&nbsp;Apr&nbsp; 26 , Rabu </strong>&nbsp; <strong>:&nbsp; &nbsp;&nbsp;INTERLAKEN</strong></p>\r\n\r\n<p style=\"text-align:justify\">Hari ini Anda akan mengunjungi kota <strong>Gstaad</strong>, kota tradisional Swiss yang sangat&nbsp; unik. Kemudian mengunjungi <strong>Gunung Glacier 3000</strong> yang menakjubkan dengan menggunakan <strong>Cable Car</strong> husus, mencapai ketinggian 3210 m dari permukaan laut. Anda dapat menikmati salju abadi dan dari sini memandang 3 gunung paling terkenal di Eropa :<strong>Mt.Blanc, Jungfraujoh</strong> dan &nbsp;<strong>Matterhorn</strong>. setibanya di <strong>Glacier 3000</strong> Anda akan menikmati makan siang sambil menikmati keindahan salju dan mencoba <strong>Snow Bus </strong>&nbsp;(mobil khusus yang digunakan di padang es). Pada musim panas (20 April - 31 October tergantung cuaca) Anda dapat mengikuti optional tour mencoba <strong>Dog&nbsp;</strong><strong>sled ride </strong>( tergantung situasi dan kondisi ) Lunch : Botta&nbsp; 3000 -------- Dinner : Local Restaurant</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari </strong><strong>11</strong><strong>,&nbsp; Apr.</strong><strong> 27. Kamis </strong><strong>&nbsp;&nbsp;:&nbsp;&nbsp; INTERLAKEN</strong> &nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Menuju </strong><strong>Harder Kulm</strong> (1.322 meter di atas permukaan laut), dengan Trem menuju lokasi mendaki bukit dengan gradient kemiringan 45 persen. Melihat kota Interlaken dari Harder Kulm &nbsp;kota itu, terhampar di antara dua lembah kaki-kaki Gunung Eiger (3.970 meter dpl) dan M&ouml;nch (3.970 meter dpl). Di antara dua puncak gunung, yang termasuk rangkaian pengunungan Alpen, itu tampak pula<em> top of Europe</em> Jungfaujoch (3.454 meter dpl) yang terkenal. serta Danau Brienz dan Danau Thuner<img alt=\"\" src=\"/mms/userfiles/images/interlaken.jpg\" style=\"float:right; height:183px; width:276px\" /></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 12 , Apr&nbsp; 28 &nbsp;Jum&rsquo;at </strong><strong>:&nbsp; INTERLAKEN &ndash; </strong>&nbsp;<strong>&nbsp;ZURICH - JAKARTA </strong></p>\r\n\r\n<p style=\"text-align:justify\">Setelah santap pagi menuju kota Zurich unuk melakukan penerbangan kembali ke tanah air.</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong>Hari 13 , Apr&nbsp; 29 &nbsp;Sabtu :&nbsp;&nbsp; &nbsp;</strong><strong>JAKARTA</strong></p>\r\n\r\n<p style=\"text-align:justify\">InsyaAllah tiba di kota Jakarta ,&nbsp; dengan membawa kenangan&nbsp; yang tak terlupakan</p>\r\n'),
(10, '60xglasgow.jpg.pagespeed.ic.i5d1UAOXEm.jpg', 'Juli 2018', '2018-07-27', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '14', '0', '0', '', '<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 1 , 27 Jun.17 : JAKARTA &ndash; LONDON.</strong><br />\r\nHari ini berkumpul di Airport Soekarno-Hatta untuk bersama-sama berangkat menuju London, ibukota United Kingdom&nbsp; dengan Garuda Airlines</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 2, 28 Jun.17&nbsp; :&nbsp; LONDON.</strong><br />\r\nPagi hari tiba di London, kita akan mengunjungi <strong>Tower&nbsp; Bridge</strong>&nbsp; dan <strong>London&nbsp; Bridge</strong>, kemudian melewati <strong>ST. Paul Cathedral, Trafalgar Square, Buckingham Palace, Westminster Abbey, London Eye, House of</strong> <strong>Parliament</strong>&nbsp; dengan <strong>Big Ben -nya</strong>. Setelah itu diantar ke hotel untuk beristirahat.&nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/inggris.jpg\" style=\"height:165px; opacity:0.9; width:306px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 3, 29 Jun.17&nbsp; : LONDON &ndash; STONEHENGE &ndash; BATH &ndash; CARDIFF</strong><br />\r\nHari ini ke menuju ke <strong>Stonehenge </strong>&nbsp;untuk melihat salah satu warisan budaya UNESCO, berupa peninggalan monumen arkeologi yang sudah berusia 4000 tahun. Kemudian menuju kota bersejarah <strong>BATH</strong> yang terkenal sebagai kota Spa. Anda diajak mengunjungi <strong>Roman Bath </strong>&nbsp;(kolam spa ala Romawi) dan melewati bangunan-bangunan berarsitektur Georgia. Setelah itu menuju ibukota Wales : <strong>Cardiff</strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/cardiff.jpg\" style=\"float:left; height:225px; width:400px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 4, 30 Jun.17&nbsp; :&nbsp; </strong><strong>CARDIFF &ndash; BIRMINGHAM</strong><br />\r\nCity tour Cardiff melewati <strong>The Senedd</strong> (gedung parlemen), <strong>Cardiff Castle, City Hall, Cathedral A </strong>&nbsp;dan lain lain. Setelah itu melanjutkan perjalanan ke kota metropolitan <strong>Birmingham</strong>. Setibanyadi Birmingham, city tour melewati <strong>Jewellery Quarter, St. Paul&rsquo;s&nbsp; Church, Victoria Law Courts, Town Hall, Birmingham Museum &amp; Art Gallery, Alexandra Theatre, Birmingham Hippodrome, Birmingham Repertory Theatre.</strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 5, 01 Jul.17 :</strong>. &nbsp;<strong>BIRMINGHAM &ndash; LIVERPOOL</strong><br />\r\nPerjalanan dilanjutkan ke kota <strong>Liverpool</strong>. Anda akan diajak mengunjungi situs warisan <strong>UNESCO, Liverpool Maritime Mercantile City </strong>&nbsp;yang meliputi antara lain daerah: <strong>Pier Head, albert Dock dan William Brown Street</strong>. Anda juga diajak melewati <strong>Cavern Club </strong>, di mana band <strong>The Beatles </strong>&nbsp;memulai karir mereka yang legendaris, <strong>Stadium Sepak bola Liverpool dan The Beatles Story </strong>, tempat di mana sejarah the Beatles &nbsp;diabadikan.&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 6, 02 Jul.17 : LIVERPOOL &ndash; HOLYHEAD &ndash; DUN LAOGHAIRE &ndash; LIMERICK</strong><br />\r\nPerjalanan dilanjutkan menuju ke kota <strong>Holyhead</strong> &nbsp;untuk naik ferry menuju kota Dun Laoghaire &nbsp;di Irlandia. Selanjutnya menuju kota <strong>Limerick </strong>&nbsp;atau sekitarnya untuk bermalam.&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/limerick.jpg\" style=\"float:right; height:168px; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 7. 03 Jul 17 : LIMERICK &ndash; CLIFF OF MOHER &ndash; DUBLIN</strong><br />\r\nPagi hari Anda akan mengagumi keindahan alam yang spektakuler di <strong>Cliff of Moher </strong>, berupa jajaran batu karang yang menjulang tinggi di Lautan Atlantik, setinggi 200 meter dari atas permukaan laut dan sepanjang 10 kilometer. Kemudian menuju Ibukota Negara Republik Irlandia: <strong>Dublin</strong>, kota berkumpulnya para seniman dan merupakan &quot;Fair City &quot; setibanya di Dublin, Anda diajak melewati <strong>Trinity College, Nassau Shopping Street, Phoenix Park, St. Patrick Cathedral, Dublin city hall&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 8. 04 Jul.17 : DUBLIN &ndash; GIANT CAUSEWAY &ndash; BELFAST</strong><br />\r\nHari ini diajak mengunjungi <strong>Giant Causeway </strong>&nbsp;untuk melihat keajaiban fenomena alam yang membentuk batu-batu karang seperti sengaja disusun dengan rapih, dan sangat langka ditemukan di belahan bumi lainnya. Setelah itu menuju ibukota Irlandia Utara: <strong>Belfast </strong>, tempat diberangkatkannya kapal Titanic. Setibanya di Belfast, Anda diajak mengunjungi <strong>Museum Titanic </strong>yang sangat mengesankan.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 9, 05 Jul. 17 : BELFAST / LARNE &ndash; CAIRNRYAN / STRANRAER &ndash; GLASGOW</strong><br />\r\nPagi hari dengan bus menuju ke pelabuhan Belfast / Larne &nbsp;untuk naik ferry menyeberang ke kota Cairnryan / Stranraer . Setelah itu dengan bus menuju kota metropolitan terbesar di Scotlandia &nbsp;<strong>Glasgow </strong>&nbsp;untuk bermalam.</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/INTO-GCU-river-Clyde-Glasgow-hero.jpg\" style=\"float:right; height:169px; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 10. 06 Jul.17 GLASGOW &ndash; EDINBURGH</strong><br />\r\nCity tour hari ini melewati <strong>George Square, Cathedral </strong>&nbsp;yang dibangun abad 16, <strong>Art Museum, Glasgow University </strong>&nbsp;yang terkenal, <strong>Transport Museum </strong>&nbsp;dan lain-lain. Kemudian menuju kota <strong>Edinburgh </strong>&nbsp;yang indah, yang merupakan ibukota negara bagian United Kingdom: Scotlandia. &nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 11. 07 Jul.17 : EDINBURGH - LONDON<br />\r\nEdinburgh Castle</strong> &nbsp;yang terletak di atas bukit, adalah obyek wisata utama Anda hari ini. Istana yang megah ini dibangun mulai abad 11 dan sebagian besar pada abad 16, merupakan istana yang sangat bersejarah. Anda juga diajak melewati <strong>St. Andrew Square, Scott Monument</strong> &nbsp;pusat perbelanjaan <strong>Princess Street</strong> &nbsp;yang memisahkan old town dan new town, National Gallery, St. Giles Cathedral, &nbsp;Edinburgh University, Royal Palace ( Holyrood House) , Carlton Hill &nbsp;dan lain-lain. Sore penerbangan menuju ke London.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 12. 08 Jul.17 LONDON</strong><br />\r\nPagi hari Anda diajak mengunjungi <strong>Windsor Palace</strong>, istana yang megah dan anggun, pertama kali dibangun pada tahun 1070, Anda akan berfoto dengan baju tradisional Inggris.&nbsp; barang berharga milik&nbsp; . Sore hari acara bebas untuk berbelanja.&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 13. 09 Jul.17 LONDON - JAKARTA</strong><br />\r\nTiba saatnya kita akan kembali ke tanah air dengan Garuda Indonesia</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 14.10 Jul.17 : JAKARTA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">InsyaAllah tiba di Jakarta dengan tambahan ilmu dan kenangan yang tak terlupakan</p>\r\n'),
(11, '78CaribouDenali.jpg', 'Juli 2018', '2018-07-25', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '20', '0', '0', '', '<p style=\"text-align: justify;\"><strong>Hari 1, </strong><strong>Selasa,</strong><strong> 25 Jul.17&nbsp; : JAKARTA &ndash; VANCOUVER&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/Aerial_Sunset_Vancouver_a59b88be-e776-43cb-8d46-efe3117ac949.jpg\" style=\"float:left; height:146px; opacity:0.9; width:300px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">Dengan mengucap Bismillahirrahmanirrahim kita akan berangkat&nbsp; menuju Vancouver via Hongkong.Tiba di Vancouver kita akan mengunjungi Gas Town (tempat pemukiman tertua orang kulit putih di Vancouver), Steam Clock, makan malam dan check in hotel.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 2, Rabu, &nbsp;&nbsp;26 Jul.17 : VANCOUVER &ndash;VICTORIA ISLAND </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari dengan ferry menyeberangi Selat Georgia&nbsp; menuju kota VictoriaI, ibu kota propinsi British Columbia. Setibanya di Victoria, Anda juga diajak melewati &nbsp;Gedung Parlemen, China Town, Inner Harbour, Royal British Columbia Museum, bangunan-bangunan berarsitektur Inggris dan mengunjungi Butchard Garden,salah satu taman yang paling indah di dunia</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 3, </strong><strong>Kamis, </strong><strong>&nbsp;27 Jul .17 </strong><strong>&nbsp;: VICTORIA ISLAND-VANCOUVER&nbsp; (B.L.D)</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Melihat dari dekat <strong>Ikan Orca</strong> yang sangat terkenal di perairan Victoria, bulan April sampai Oktober menjadi bulan yang ideal untuk melihat <strong>Southern Resident</strong> <strong>Orcas,</strong> sore hari kembali ke Vancouver dan bermalam di Vancouver&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><img alt=\"\" src=\"/mms/userfiles/images/df17046c48944b922e3f86b727470ef3.jpg\" style=\"float:right; height:493px; width:600px\" /></p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 4, Jum&rsquo;at, &nbsp;28 Jul.17 : VANCOUVER &ndash; ANCHORAGE</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Perjalanan menuju Alaska dimulai dengan tujuan pertama ke kota Anchorage, berdiri sebagai kota metropolis yang&nbsp; menyajikan pemandangan indah puncak salju &nbsp;dan tundra beku. &nbsp;Kota terbesar di Alaska, pusat seni pertunjukan, restoran gourmet dan berbagai pusat perbelanjaan . Anda juga akan diajak mengunjungi Alaska Native Heritage Centre &nbsp;untuk melihat kebudayaan suku asli penghuni Kutub (Eskimo) dari berbagai egara dan mempelajari sejarah dari kota Anchorage yang menarik</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 05, Sabtu, 29 Jul.17&nbsp; : </strong><strong>ANCHORAGE &ndash; TOK&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari menuju ke kota Tok. Yang terkenal dengan&nbsp; &ldquo;Dog Sled Capital of the World.&rdquo; &nbsp;&nbsp;Kita akan&nbsp; menikmati pemandangan Bridal Veil Falls, Worthington Glacier, dan Thompson Pass.&nbsp;&nbsp; Bermalam di Tok</p>\r\n\r\n<p style=\"text-align: justify;\"><br />\r\n<strong>Hari 06, Minggu, &nbsp;30 Jul .17 :&nbsp; TOK &ndash;FAIRBANKS</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari meninggalkan kota Tok menuju ke kota &nbsp;Fairbanks Dalam perjalanan kita dapat mampir untuk berfoto dan membeli souvenir . Tiba di kota Fairbanks yang dikenal sebagai &ldquo;Gateway ke Kutub Utara,&rdquo; kota terbesar kedua di Alaska memiliki sejarah yang berwarna-warni. Di kota ini&nbsp; kita dapat menikmati keindahan aurora . (fenomena ini hanya akan muncul bila cuaca Memungkinkan)Tentunya hal ini akan sangat menyenangkan dan membuat pengalaman sedikit berbeda.Fairbanks juga merupakan lokasi dari Institut Geofisik Alaska yang merilis perkiraan mengenai waktu dan lokasi aurora akan terlihat. Sore hari kita akan &nbsp;mengunjungiUniversitas Alaska Museum of the North, yang terletak di University of Alaska Fairbanks. Museum olahraga, sejarah Trans-Alaska Pipeline.&nbsp; Makan malam Anda adalah Alaska Salmon Bake (khas Alaska)&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 07. </strong><strong>Senin, </strong><strong>&nbsp;31 Jul.17&nbsp; : FAIRBANKS</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Kita akan memulai kegiatan dengan kapal menyusuri Sungai Chena, sebuah Mississippi gaya sternwheeler. Menuju ke sebuah desa Athabascan, diciptakan kembali seperti&nbsp; aslinya, lengkap dengan rumah-rumah kayu, rumah asap yang lengkap, dan cache sebuah perangkap otentik. Mengamati demonstrasi teknik yang digunakan untuk kegiatan seperti&nbsp;&nbsp; proses tanning-tradisional yang jarang digunakan saat ini.&nbsp; Sore hari menuju 10 mil di luar Fairbanks ke kota kecil Fox. Kita akan&nbsp; memulai eksplorasi&nbsp; emas , &nbsp;Anda &nbsp;akan mencoba&nbsp; mendulang emas sendiri.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 08, </strong><strong>Selasa, </strong><strong>01 Aug.17&nbsp; :&nbsp; FAIRBANKS-DENALI/Distance: </strong><strong>125 Miles / 200 Kilometers </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari menuju Denali National Park&nbsp; dmana terdapat gunung tertinggi di Amerika Utara yaitu Gunung Mc. Kinley&nbsp; Disana Anda akan melihat pemandangan indah dan taman di Denali, serta diajak mengunjungi&nbsp; Murie Science Andlearning Centre &nbsp;untuk mengenal flora dan fauna yang ada di Kutub.&nbsp; Sore hari Anda dapat berpartisipasi dalam kegiatan opsional atau bersantai dan menikmati pemandangan di salah satu taman nasional Amerika yang paling luar biasa.&nbsp;<img alt=\"\" src=\"/mms/userfiles/images/Fairbank-43.jpg\" style=\"float:right; height:166px; width:250px\" /></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 09, Rabu, 02&nbsp; Aug. 17:&nbsp; DENALI NATIONAL PARK &ndash; TALKEETNA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini kita akan mempunyai&nbsp; pengalaman yang berbeda menuju &nbsp;sub-Arktik,pemandangan luar biasa, kita akan melihat dan foto satwa liar seperti Dall domba, rusa, karibu, serigala, dan beruang grizzly dan satwa liar lainnya. &nbsp;Sore hari kita akan meninggalkan Denali National Park &nbsp;melanjutkan perjalanan ke Talkeetna, distrik kecil di Negara Bagian Alaska, Amerika Serikat, Wilayah seluas 107,74 kilometer persegi yang biasanya sepi senyap ini memang mendadak menjadi ramai saat musim panas tiba. Wisatawan dari berbagai pelosok AS, bahkan penjuru dunia, menghampiri Talkeetna untuk berlibur, mulai dari sekadar jalan-jalan, berkemah, memancing, arung jeram, bermain ski, keliling naik pesawat, sampai mendaki gunung.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 10, Kamis 03&nbsp; Aug.17&nbsp; : TALKEETNA-ANCHORAGE </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Nikmati sarapan di Foraker Dining Room sebelum memulai perjalanan Anda ke Anchorage. &nbsp;. Mendekati Anchorage, Anda akan berhenti di Historical Park Eklutna di mana Anda akan mengunji Gereja Ortodoks Rusia, belajar tentang sejarah, budaya, dan adat istiadat Athabascans Dena&rsquo;ina dalam kombinasi dengan tradisi Ortodoks Rusia. &nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 11,&nbsp; Jum&rsquo;at ,&nbsp; 04&nbsp; Aug. 17: </strong><strong>ANCHORAGE &ndash; SEWARD ( CRUISE) </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari kita akan menuju pelabuhan untuk memulai&nbsp; pelayaran menjelajahi Alaska dengan kapal Celebrity Cruises.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 12, Sabtu ,&nbsp; 05 Aug.17&nbsp; :</strong><strong> HUBBARD GLACIER ( CRUISING )</strong>&nbsp; &nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">Kita akan berlayar ke Hubbard Glacier adalah gletser terpanjang Tidewater di Alaska membentang 76 km dari sumbernya di Gunung. Logan in the Yukon.The cliff face you sail along is over six miles wide, 300 to 400 feet from the top to sea level and 300 feet from sea level to the bottom. Kita akan berlayar di Tebing Glacier lebih dari enam mil lebarnya, 300 sampai 400 meter dari atas ke permukaan laut.As Hubbard is advancing, it creaks and groans as it moves and is a very actively calving glacier. Seperti pada saat kapal melalui Hubbard, derit &nbsp;&nbsp;saat bergerak merupakan&nbsp; This makes for some exciting moments when the huge chunks of ice crash into the Bay creating a wonderful sound called &lsquo;white thunder&rsquo; by the Tlingit people. Momen seru yang tak terlupakan ketika potongan besar &nbsp;es ke Teluk menciptakan suara indah yang disebut &lsquo;guntur putih&rsquo; oleh orang-orang Tlingit. &nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 13, </strong><strong>Minggu</strong><strong>,&nbsp; 06&nbsp; Aug.17&nbsp; </strong><strong>JUNEAU, ALASKA </strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;Setibanya di kota Juneau yang merupakan ibukota Alaska, kita dapat mengikuti acara tour tambahan seperti : Dog Sledding (tergantung cuaca), Helicopter Glacier Excursion, Whale Watching atau berkesempatan menyantap Alaskan King Crab.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 14,</strong><strong> Senin</strong><strong> &nbsp;07 Aug.17 </strong>&nbsp;<strong>SKAGWAY, ALASKA<img alt=\"\" src=\"/mms/userfiles/images/CaribouDenali.jpg\" style=\"float:right; height:150px; width:300px\" /> </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setibanya di kota Skagway yang merupakan kota sejarah tambang emas Klondike, Anda dapat mengikuti acara tour tambahan seperti : White Pass Scenic Train untuk menikmati pemandangan alam kota Skagway dan Dog Sledding (tergantung cuaca) apabila Anda tidak berkesempatan mencoba di kota Juneau.</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 15,&nbsp; Selasa 08 Aug.17&nbsp; </strong><strong>&nbsp;ICY STRAIT POINT&ndash; ALASKA</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Selat Icy menawarkan wisata berjalan di hutan, mengetahui lebih dalam mengenai&nbsp; sejarah Tlingit dan budaya, kembali ke alam petualangan . melihat Upmarket craft shops feature artisan crafts and locally made goods like woodland berry jam and confectionery, rather than the &ldquo;made in Taiwan&rdquo; good so prevalent in, say, Juneau. Toko kerajinan&nbsp; dan barang buatan egar seperti selai berry hutan dan gula-gula.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 16,</strong><strong> Rabu</strong><strong>&nbsp; 09 &nbsp;Aug.17&nbsp; </strong><strong>KETCHIKAN, ALASKA </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari setibanya di kota Ketchikan, Alaska yang dikenal sebagai &ldquo;Salmon Capital of the World&rdquo;, Anda dapat mengikuti acara tour tambahan untuk melihat secara langsung Alaskan Bear, menikmati Fjord Floatplane Adventure, melakukan Salmon Fishing serta menonton pertunjukan traditional Lumberjack Show atau sekedar menikmati keindahan kota Ketchikan</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 17,</strong><strong> Kamis 10</strong><strong> &nbsp;&nbsp;Aug.17 :: Inside Passage (Cruising)</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Inside Passage (Di dalam Cruise) Sehari penuh Anda berada di dalam kapal pesiar untuk menikmati berbagai fasilitas kapal sambil menikmati pemandangan alam, semetara cruise melanjutakan pelayaran meuju &nbsp;&nbsp;Vancouver</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 18, Jum&rsquo;at 11 &nbsp;Aug.17: Vancouver, British Columbia </strong></p>\r\n\r\n<p style=\"text-align: justify;\">Hari ini berakhirlah pelayaran kita di Alaska, kembali ke Vancouver, kemudian &nbsp;kita akan&nbsp; mengunjungi&nbsp; Queen Elizabeth Park, Stanley Park, Gas Town (tempat pemukiman tertua orang kulit putih di Vancouver), dan&nbsp; Steam Clock . Melewati&nbsp; Science World dan Sholat di Islamic Center , Vancouver.&nbsp; Kemudian meninggalkan egara&nbsp; Canada&nbsp; untuk kembali ke Tanah air</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 19.</strong><strong> Sabtu 12</strong><strong>&nbsp; Aug.17</strong><strong>: Vancouver &ndash; Jakarta</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Dini hari penerbangan dari Vancouver ke Jakarta</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 20, Minggu 13 Aug.17&nbsp;&nbsp; : Jakarta</strong></p>\r\n\r\n<p style=\"text-align: justify;\">InsyaAllah tiba di Jakarta dengan pengalaman, pengetahuan dan kenangan yang tak terlupakan.</p>\r\n'),
(12, '', 'September 2018', '2018-09-08', '4', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '9 ', '0', '0', '', '<p style=\"text-align: justify;\"><strong>Hari 1, </strong><strong>8 Sep</strong><strong> : JAKARTA &ndash; NEW DELHI</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Berkumpul dan berangkat dari bandara Internasional Soekarno Hatta. Tiba di New Delhi, kota dengan sejarah ribuan &nbsp;tahun yang unik&nbsp; nan indah siap menyambut kunjungan Anda. Check &nbsp;&nbsp;in hotel. &nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 2 </strong><strong>, </strong><strong>9 Sep</strong> <strong>: New Delhi - Jaipur</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setelah santap pagi, chek out hotel.&nbsp; Melanjutkan perjalanan ke Jaipur. Tiba di Jaipur langsung chek in hotel, dan pada malam hari menyaksikan Culture Dance di sebuah desa yang Menyenagkan, penuh dengan tari dan musik. Anda dapat berfoto dengan kostum khas India, mencoba ramalanramalan gaya india bahkan ber tattoo ala India &nbsp;(mehendi)</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>&nbsp;Hari 3</strong><strong>, 10 Sep</strong><strong> &nbsp;: Jaipur</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Santap pagi di hotel. Mengunjungi Benteng &nbsp;Amer, terletak di puncak amber dan berfoto di Hawa Mahal &nbsp;yang terkenal. Mengunjungi &nbsp;City Palace (tempat tinggal Raja) dengan gaya arsitektur yang sangat menarik. Kita&nbsp; juga akan mengunjungi Jantar Mantar, Observatori yang terbuat dari batu pada abad 18.&nbsp; Jika waktu memungkinkan mengunjungi industri karpet &amp; textile dari kerajinan tangan.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>&nbsp;Hari 4</strong><strong>, 11 Sep</strong><strong> &nbsp;: Jaipur - Ag</strong><strong>ra&nbsp; </strong></p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;Santap pagi langsung chek out hotel, Melanjutkan perjalanan ke Agra. Tiba di Agra langsung mengunjungi Taj Mahal, satu dari 7 keajaiban dunia, setelah&nbsp; puas dilanjutkan menuju Benteng Agra&nbsp; yang dibangun zaman kebesaran Mughal, tahun 1569 di tepi sungai Yamuna. Jika waktu memungkin &nbsp;kan, mengunjungi industri marmer yang indah.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 5 . 12 Sep : Agra - Delhi - Kalka</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Santap pagi, chek out hotel. Menuju Delhi. Melintasi India Gate (Gerbang Memoril &nbsp;prajurit India perang dunia I); Rastrapati Bhawan (tempat tinggal Raja Muda); Gedung Parlemen dan Qutab Minar. Tranfer ke stasiun kereta api untuk melanjutkan perjalanan keKalka. Bermalam di kereta api. (B,L,D)</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 6 . 13 Sep : Kalka - Shimla</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Pagi hari tiba di Kalka dan melanjutkan&nbsp; perjalanan dengan Kalka-Shimla Shivalik Express (toy train). Tiba di Shimla, chek in.Tour di Shimla dengan berjalan kaki menuju jalan utama, mall road dengan aneka kuliner yang sangat menarik.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 7. 14 Sep &nbsp;: Shimla -Kufri - Shimla</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Setelah santap pagi menuju Kufri dan tour&nbsp; di daerah ski resort (musim dingin) dan Pony(musim panas) dan meng- unjungi Kebun Bintang Himalayan. Kembali ke Simla.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 8 .15 Sep : Shimla-Kalka-Delhi-Airport</strong></p>\r\n\r\n<p style=\"text-align: justify;\">Chek out hotel menuju Kalka dilanjutkan ke Delhi dan transfer ke airport untuk kembali ke Jakarta. Penerbangan ke Jakarta.</p>\r\n\r\n<p style=\"text-align: justify;\">&nbsp;</p>\r\n\r\n<p style=\"text-align: justify;\"><strong>Hari 9, 16 Sep : Jakarta</strong></p>\r\n\r\n<p style=\"text-align: justify;\">InsyaAllah tiba dibandara Soekarno-Hatta, dengan kenangan yang ak terlupakan</p>\r\n'),
(13, '', 'Agustus 2017', '2017-08-01', '4', '0', '0', '0', '00', '0', '0', '', '0', '0', '0', '0', '4 ', '0', '0', '', '<p style=\"text-align:justify\">Hari1: BANGKOK (D)</p>\r\n\r\n<p style=\"text-align:justify\">* Tiba di Bangkok, Airport Greetings with Flower Garland&quot;</p>\r\n\r\n<p style=\"text-align:justify\">* Transfer ke Hotel untuk Check in, Bermalam di Bangkok</p>\r\n\r\n<p style=\"text-align:justify\">* Makan malam di Rasa Khas Indo Resto (Sertifikat Halal) Berbelanja di Pasar Malam Asiatique</p>\r\n\r\n<p style=\"text-align:justify\">* Doa akan berhenti di masjid selama waktu sholat</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">Hari2: BANGKOK - PATTAYA (B / L / D) * Makan pagi di hotel, Half Day Bangkok City Tour sungai chaopraya dengan Wat Arun Temple</p>\r\n\r\n<p style=\"text-align:justify\">* Kunjungi Masjid Bang Luang dengan arsitektur fusi Thailand &amp; Islam</p>\r\n\r\n<p style=\"text-align:justify\">* Makan siang di Sophia / Al Hilal Rest (Sertifikat Halal)</p>\r\n\r\n<p style=\"text-align:justify\">* Lanjutkan ke Pattaya, kunjungi Pasar Terapung Pattaya Kunjungi Masjid Darulaubaror, Hard Rock Store</p>\r\n\r\n<p style=\"text-align:justify\">* Makan malam di Hotel Royal A-One (Sertifikat Halal), diantar ke hotel untuk bermalam di Pattaya</p>\r\n\r\n<p style=\"text-align:justify\">* Doa akan berhenti di masjid selama waktu sholat</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">Hari3: PATTAYA - BANGKOK (B / L / D) * Makan pagi di hotel, wisata Pattaya</p>\r\n\r\n<p style=\"text-align:justify\">* Mengunjungi Bukit Pattaya, Mimosa City of Love Kunjungi Gems Gallery, Honey Shop &amp; Makanan Kering</p>\r\n\r\n<p style=\"text-align:justify\">* Lanjutkan ke Bangkok, Makan Siang di Sophia / Amir Rest (Sertifikat Halal)</p>\r\n\r\n<p style=\"text-align:justify\">* Kunjungi Masjid Yawa (Mesjid Jawa), Shopping Program di MBK Mall</p>\r\n\r\n<p style=\"text-align:justify\">* Makan malam di Coffee Shop Baiyoke Suite (Sertifikat Halal), transfer ke hotel, Bermalam di Bangkok</p>\r\n\r\n<p style=\"text-align:justify\">* Doa akan berhenti di masjid selama waktu sholat</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">Hari4: BANGKOK -JAKARTA (B)</p>\r\n\r\n<p style=\"text-align:justify\">* Sarapan pagi di hotel, gratis di program leisure / shopping</p>\r\n\r\n<p style=\"text-align:justify\">* Transfer ke Bandara, Akhir pelayanan</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `judulgallery`
--

CREATE TABLE `judulgallery` (
  `no` int(2) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `foto` varchar(230) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `no` int(1) NOT NULL,
  `foto` varchar(250) NOT NULL,
  `kode` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`no`, `foto`, `kode`) VALUES
(1, '87IMG-20170210-WA0011.jpg', '3'),
(4, '16CA12BC51-8459-428F-93CC-653B179AA44A.jpeg', '1'),
(12, '63avanza.jpg', '2'),
(14, '31test.jpeg', '4'),
(15, '149883_125.jpg', '5');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(6) NOT NULL,
  `username` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `alamat` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `kota` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `hp` varchar(25) COLLATE latin1_general_ci DEFAULT NULL,
  `ipaddress` varchar(50) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `username`, `nama`, `alamat`, `kota`, `hp`, `ipaddress`) VALUES
(1, 'AMH00001', 'Aminah Tour', 'Ruko puri', 'Surabaya', '0318281956', ''),
(197, 'AMH00002', 'ADI SUSENO', 'Ruko Puri Kencana Karah ', 'Surabaya', '081234188899', ''),
(198, 'AMH00003', 'AMIRUL', 'Ruko Puri Kencana Karah ', 'Surabaya', '0318281956', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `menutype` varchar(75) COLLATE latin1_general_ci DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `alias` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `link` text COLLATE latin1_general_ci,
  `type` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `componentid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `no` int(2) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `ket` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`no`, `jenis`, `nama`, `ket`) VALUES
(7, '1', 'UMROH MILAD 16 Hari', 'Paket 16 Hari\r\n4 Madinah\r\n10 Makkah'),
(8, '1', 'UMROH  MILAD 13 Hari', 'Paket 13 Hari\r\n3 Madinah\r\n8 Makkah');

-- --------------------------------------------------------

--
-- Table structure for table `pakettour`
--

CREATE TABLE `pakettour` (
  `no` int(2) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `ket` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pakettour`
--

INSERT INTO `pakettour` (`no`, `jenis`, `nama`, `ket`) VALUES
(1, '1', 'Domestik', ''),
(4, '1', ' Internasional', '');

-- --------------------------------------------------------

--
-- Table structure for table `testimoni`
--

CREATE TABLE `testimoni` (
  `no` int(5) UNSIGNED NOT NULL,
  `hp` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `userid` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `kota` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `judul` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `testimoni` text COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `tgl` date NOT NULL DEFAULT '0000-00-00',
  `published` varchar(5) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `testimoni`
--

INSERT INTO `testimoni` (`no`, `hp`, `userid`, `nama`, `kota`, `judul`, `testimoni`, `foto`, `tgl`, `published`) VALUES
(2, '02222', '', 'Hj Mirna', 'Surabaya', 'AMINAH YESS YESS YESS', '<p>Pelayanan&nbsp;memuaskan,&nbsp;paket&nbsp;umrohnya&nbsp;murah,</p><p>&nbsp;sesuai&nbsp;dengan&nbsp;jadwal.</p>', '', '0000-00-00', ''),
(3, '02222', '', 'Rani', 'Kediri', 'Sempurna', '<p>Alhamdulillah&nbsp;pelayanannya&nbsp;baik,&nbsp;panduan&nbsp;dan&nbsp;pembimbingnya&nbsp;ramah&nbsp;tamah&nbsp;dan&nbsp;jelas.</p><p>Aminah&nbsp;Tour&nbsp;okee</p>', '', '0000-00-00', ''),
(4, '02222', '', 'Lyra ', 'malang', 'Aminah Tour lancar', '<p>Alhamdulillah&nbsp;kami&nbsp;sekeluarga&nbsp;diberi&nbsp;kemudahan&nbsp;</p><p>dan&nbsp;kelancaran&nbsp;ibadah&nbsp;umroh&nbsp;bersama&nbsp;Aminah&nbsp;Tour</p><p>Semua&nbsp;sesuai&nbsp;harapan&nbsp;dan&nbsp;berjalan&nbsp;lancar&nbsp;</p>', '', '0000-00-00', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `bayar`
--
ALTER TABLE `bayar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `bulan`
--
ALTER TABLE `bulan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `bulantour`
--
ALTER TABLE `bulantour`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cat_idx` (`section`,`published`);

--
-- Indexes for table `configuration`
--
ALTER TABLE `configuration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_section` (`sectionid`),
  ADD KEY `idx_access` (`access`),
  ADD KEY `idx_checkout` (`checked_out`),
  ADD KEY `idx_state` (`state`),
  ADD KEY `idx_catid` (`catid`),
  ADD KEY `idx_createdby` (`created_by`);

--
-- Indexes for table `depan`
--
ALTER TABLE `depan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `dokumen`
--
ALTER TABLE `dokumen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fotogallery`
--
ALTER TABLE `fotogallery`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `haji`
--
ALTER TABLE `haji`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `jadwaltour`
--
ALTER TABLE `jadwaltour`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `judulgallery`
--
ALTER TABLE `judulgallery`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `componentid` (`componentid`,`menutype`,`published`),
  ADD KEY `menutype` (`menutype`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `pakettour`
--
ALTER TABLE `pakettour`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `testimoni`
--
ALTER TABLE `testimoni`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `no` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bayar`
--
ALTER TABLE `bayar`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `no` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bulan`
--
ALTER TABLE `bulan`
  MODIFY `no` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `bulantour`
--
ALTER TABLE `bulantour`
  MODIFY `no` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `configuration`
--
ALTER TABLE `configuration`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `depan`
--
ALTER TABLE `depan`
  MODIFY `no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dokumen`
--
ALTER TABLE `dokumen`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fotogallery`
--
ALTER TABLE `fotogallery`
  MODIFY `no` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `haji`
--
ALTER TABLE `haji`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
  MODIFY `no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `jadwaltour`
--
ALTER TABLE `jadwaltour`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `judulgallery`
--
ALTER TABLE `judulgallery`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `no` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=199;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pakettour`
--
ALTER TABLE `pakettour`
  MODIFY `no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `testimoni`
--
ALTER TABLE `testimoni`
  MODIFY `no` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
