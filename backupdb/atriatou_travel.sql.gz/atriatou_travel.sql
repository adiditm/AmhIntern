-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: atriatou_travel
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `uraian` longtext NOT NULL,
  `foto` varchar(150) NOT NULL,
  `fb` varchar(200) NOT NULL,
  `tw` varchar(200) NOT NULL,
  `ig` varchar(200) NOT NULL,
  `youtube` varchar(200) NOT NULL,
  `perusahaan` varchar(255) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(100) NOT NULL,
  `propinsi` varchar(50) NOT NULL,
  `kodepos` int(5) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `gmap` text NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'Tentang Kami','PT. Andromeda Atria Wisata / Atria Tour &amp; Travel sebagai Biro Perjalanan Wisata','assets/images/clients/nabawi2.jpg','https://facebook.com/username','http://twitter.com/username','https://instagram.com/username','https://www.youtube.com/channel/UC3M-gfd_4wFaeu-uJse-ptg','PT. Andromeda Atria Wisata','“ Melayani Tamu Allah adalah Pengabdian Kepada Allah ”','Jl. Raya Kupang Jaya 1 Kav. 6','SURABAYA','JAWA TIMUR',60189,'travelatriatours@gmail.com','082144444444','031-7310374 ext. 105/114','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.691374033051!2d112.70330551487565!3d-7.275915473519528!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fc04fab16a5d%3A0xd2cbed829fd63130!2sPT.%20Andromeda%20Atria%20Wisata!5e0!3m2!1sid!2sid!4v1634965413837!5m2!1sid!2sid\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>','Tampil');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `about_home`
--

DROP TABLE IF EXISTS `about_home`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about_home` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `tema` varchar(100) NOT NULL,
  `judul_about` varchar(150) NOT NULL,
  `about_singkat` varchar(250) NOT NULL,
  `slogan1` varchar(150) NOT NULL,
  `slogan2` varchar(150) NOT NULL,
  `slogan3` varchar(150) NOT NULL,
  `slogan4` varchar(150) NOT NULL,
  `judul_lebih` varchar(150) NOT NULL,
  `singkat_lebih` varchar(200) NOT NULL,
  `lebih1` varchar(100) NOT NULL,
  `keterangan1` varchar(200) NOT NULL,
  `lebih2` varchar(100) NOT NULL,
  `keterangan2` varchar(200) NOT NULL,
  `lebih3` varchar(100) NOT NULL,
  `keterangan3` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_home`
--

LOCK TABLES `about_home` WRITE;
/*!40000 ALTER TABLE `about_home` DISABLE KEYS */;
INSERT INTO `about_home` VALUES (1,'5616d09f764c7e556fa755ffadc38f265cf8bfa1','','TENTANG KAMI','IZIN KEMENTRIAN AGAMA SEJAK TAHUN 1999 DAN HAJI KHUSUS TAHUN 2000','PT. Andromeda Atria Wisata adalah Biro Resmi Penyelenggara Perjalanan Ibadah Umrah dan Haji Khusus yang berdiri sejak tahun 1997. Karakter kami adalah menjunjung tinggi nilai kejujuran dan transparansi, Pelayanan excellent, dan menjamin 5 Pasti. Kami','HAJI KHUSUS & MUJAMALAH','UMROH CANTIK ,CERIA DAN CERDAS','UMROH PRIVAT, REQUEST & PLUS','TOUR INBOUND & OUTBOUND','Kelebihan Kami','Kemandirian dalam pelayanan menuju kenyamanan beribadah','Aman','Perjalanan dalam kondisi aman','Nyaman','Kenyamanan anda menjadi pelayanan kami nomor 1','Tenang','Kami selalu mengutamakan ketepatan waktu');
/*!40000 ALTER TABLE `about_home` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `lupapassword` varchar(200) NOT NULL,
  `singkat` varchar(150) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `hp` varchar(16) NOT NULL,
  `gmap` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','$2y$10$TcvXrMQRKNt8iJXKdqJQEOEkd8SgtnuLusxz.6.fvndUIv6q.WTcy','kokbisalupa','HOTEL DEKAT, HARGA HEMAT, IBADAH NIKMAT','Trillium Office and Residence brJl. Pemuda 108 - 116 Lt. I No. 07','Surabaya','travelatriatours@gmail.com','+6231 5116900','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.778945994214!2d112.74673651466809!3d-7.2659789947552875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7f962bc2c8d51%3A0x984f49879deb4e25!2sPT%20SAFARI%20GLOBAL%20PERKASA%20-%20Surabaya!5e0!3m2!1sid!2sid!4v1595148116942!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','assets/images/about/3D-Abstract-Background-Wallpapers-Part-2-3-300x187.jpg',1,'2020-04-01 00:00:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artikel`
--

DROP TABLE IF EXISTS `artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` int(11) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `diskripsi` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `urut` int(5) NOT NULL,
  `baca` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikel`
--

LOCK TABLES `artikel` WRITE;
/*!40000 ALTER TABLE `artikel` DISABLE KEYS */;
/*!40000 ALTER TABLE `artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `award` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tampil` varchar(10) NOT NULL,
  `data1` varchar(25) NOT NULL,
  `angka1` int(5) NOT NULL,
  `data2` varchar(25) NOT NULL,
  `angka2` int(5) NOT NULL,
  `data3` varchar(25) NOT NULL,
  `angka3` int(5) NOT NULL,
  `data4` varchar(25) NOT NULL,
  `angka4` int(5) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(150) NOT NULL,
  `foto` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award`
--

LOCK TABLES `award` WRITE;
/*!40000 ALTER TABLE `award` DISABLE KEYS */;
INSERT INTO `award` VALUES (1,'Tampil','Total Umroh',1230,'Total Haji Khusus',120,'Happy Customers',1200,'Cups of coffee',590,'Kami <span>MEMBANTU</span> masalah hukum anda','A small river named Duden flows by their place and supplies it with the necessary regelialia.','assets/images/foto/al-aqsa-mosque.jpg');
/*!40000 ALTER TABLE `award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_web` varchar(50) NOT NULL,
  `th_web` varchar(4) NOT NULL,
  `titel_web` varchar(150) NOT NULL,
  `keyword_web` varchar(250) NOT NULL,
  `diskripsi_web` text NOT NULL,
  `judul_web` varchar(150) NOT NULL,
  `favicon` varchar(100) NOT NULL,
  `fontawesome` varchar(50) NOT NULL,
  `sessionadmin` varchar(255) NOT NULL,
  `sessionpassadmin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'travelatria.com','2020','Travelatria | Perjalanan Ibadah Umrah &amp; Haji Tenang, Nyaman dan Aman','umroh,umrah,haji,perjalanan,ibadah','Travelatria : Perjalanan Ibadah Umrah &amp; Haji Tenang, Nyaman dan Aman - PT.ANDROMEDA ATRIA WISATA dikenal dengan nama ATRIA adalah perusahaan Biro Perjalanan Wisata ( BPW ) , berdiri sejak tahun 1997, didukung oleh tenaga profesional dan berpengalaman menjadikan PT.Andromeda Atria Wisata sebagai perusahaan yang dipercaya oleh pemerintah sebagai penyelenggara Ibadah Umrah (PPIU) sejak tahun 1999 dan Haji Khusus sejak tahun 2000\">\r\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=5.0','TRAVEL ATRIA','assets/images/favicon.png','<i class=\"fas fa-user\"></i>','RajaAdmin','PasswordAdmin');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori_artikel`
--

DROP TABLE IF EXISTS `kategori_artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(10) NOT NULL,
  `nama_kategori` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori_artikel`
--

LOCK TABLES `kategori_artikel` WRITE;
/*!40000 ALTER TABLE `kategori_artikel` DISABLE KEYS */;
INSERT INTO `kategori_artikel` VALUES (1,'KTG001','HAJI'),(2,'KTG002','UMROH'),(3,'KTG003','TOUR HALAL INTERNASIONAL'),(4,'KTG004','TOUR DOMISTIK'),(5,'KTG005','KEBERANGKATAN 2024');
/*!40000 ALTER TABLE `kategori_artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategoriproduk`
--

DROP TABLE IF EXISTS `kategoriproduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategoriproduk` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `kodekategori` varchar(15) NOT NULL,
  `namakategori` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategoriproduk`
--

LOCK TABLES `kategoriproduk` WRITE;
/*!40000 ALTER TABLE `kategoriproduk` DISABLE KEYS */;
INSERT INTO `kategoriproduk` VALUES (1,'KTP001','UMROH'),(2,'KTP002','HAJI'),(3,'KTP003','Tour Internasional'),(4,'KTP004','Tour Domistik'),(5,'KTP005','Produk Barang'),(6,'KTP006','Produk Jasa');
/*!40000 ALTER TABLE `kategoriproduk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `wa` varchar(15) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(25) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,'64f043a855a7906a625702b0920aed2cb5156baa','JU-2020030001','travelatria','assets/images/member/logo_atria_terbaru_11.png','Atria Tour','081330894988','6281330894988','Surabaya','Surabaya',1),(5,'0ecab3d1e39015c4783813bf228ac61a497f2a0b','JU-2021010001','surabaya','','ZAINAL ABIDIN','08113084293','628113084293','SURABAYA','SURABAYA',1),(7,'ad8c5b4469211602327712c8d56ab1c21a36cf13','JU-2020090001','mudahajiumrah','assets/images/member/100478054-stock-vector-holy-kaaba-in-mecca-saudi-arabia-hand-drawn-sketch-vector-illustration-3.jpg','Eko Wahyudi','0817339090','62817339090','Baratajaya 1 no 11 Surabaya','Surabaya',1),(11,'fba6133ac5602498486a73e9f5be84d593a1f50d','JU-2020120001','faiqjombang','','MOH FAIQUL IKHSAN','0818323029','62818323029','Jombang','Jombang',1),(12,'cb4c820f91a480068413348bdf8574e7c51ab3ee','JU-2020120003','nisakediri','','NISA MUTIARA','081359054006','6281359054006','Kediri','Kediri',1),(13,'0e5c02e786f1d6d6f99370c41f76ff77b5f2be9c','JU-2021010002','junaedi','','ROEBERTUS DJOENEIDI','08123403816','628123403816','ponorogo','ponorogo',1),(14,'348d379c29fabf6f72d6a1ec1890977fff97fac6','JU-2020070002','anggisby','','Anggi prasita dewi','081233857811','6281233857811','Surabaya','Surabaya',1),(15,'6cf9dcf6f90ed14abd942f3872279504dcaa0f8d','JU-2021120002','tanmeihwa','assets/images/member/0508tan-mei-hwa_20150805_1215141.jpg','TAN MEI HWA','0811375745','62811375745','Surabaya','Surabaya',1),(16,'e89fb5c5d765036729d6216fa503bf0ae87ff6ee','JU-2022030003','silmi2022','','Silmi Fajarwatin','0818501186','62818501186','Surabaya','Surabaya',1),(17,'d22808c2ba08a25fd950960609aaf16b22e0efaa','JU-2020100003','anugrah2022','','Anugrah Robby','082233142244','6282233142244','Surabaya','Surabaya',1),(18,'df2a579b255ad1c1e2183864e7a711b17c21919f','JU-2020100008','irfan2022','','Irfan Harijadie','081233780080','6281233780080','Surabaya','Surabaya',1),(19,'a62363fcdea8e2d5e61432a522f3cb7ae2fad0ba','JU-2022030001','alaydrus2022','','Muhammad Alaydrus','0895324504512','62895324504512','Surabaya','Surabaya',1),(20,'008293ca52b9485ef3af2e72eb41fb89d17d5170','JU-2022030005','ustchodri2022','','Chodri Ramli','082244651950','6282244651950','Surabaya','Surabaya',1),(21,'bc14f2335ef8c5530984c4240f7731acbe4803f8','JU-2022030006','wardatul2022','','Wardatul Badiah','087851118877','6287851118877','Surabaya','Surabaya',1),(22,'9db628bccd0d9c4edca844de5da48433f3e7cc43','JU-2022030009','hamsiati2022','','Hamsiati','085104470947','6285104470947','Gresik','Gresik',1),(23,'65bdb0383a7b04ad229b1430539d74c83c5d66ba','JU-2022030002','hermanto2022','','Hermanto','081217770939','6281217770939','Gresik','Gresik',1),(24,'e3fa166fb2c26ba0aada06e11b8b05eab039fb31','JU-2022030013','umam2022','','Umam','087890555550','6287890555550','Bangkalan','Bangkalan',1),(25,'fae84348cc287f12b2f7213fc9d8766dd8f761d4','JU-2022030012','muhdori2022','','Muhdori','087851759222','6287851759222','Bangkalan','Bangkalan',1),(26,'0e5c96c8ba719b64beb0b77b1b372d6c58742c13','JU-2022030010','soeoed2022','','Soeoed','082332616263','6282332616263','Bangkalan','Bangkalan',1),(27,'4a8931a8eb4486ce900028e6864e8799cf3d2e4e','JU-2020120004','gussyafii2022','','Gus Syafii','08124906932','628124906932','Banyuwangi','Banyuwangi',1),(28,'0d82c6d4171307095572837259e312e614334c2e','JU-2022020002','ahmad2022','','AHMAD MUHAMMAD ABDUL MALIK','082334351789','6282334351789','Banyuwangi','Banyuwangi',1),(29,'721ee315390d02da1ef73e12deccfe23cea73014','JU-2022020003','nasrul2022','','Nasrul Mustaan','081336819494','6281336819494','Bondowoso','Bondowoso',1),(30,'68781ff67e192663ec583b2f88fd536ca6ae9f6d','JU-2020100006','utomo2022','','Utomo','081521685454','6281521685454','Jombang','Malang',1),(31,'b84fe65e72cd7f300104a9ee07764e51ec8c91fb','JU-2022030008','habibali2022','','Habib Ali','08133495600','628133495600','Malang','Malang',1),(32,'55c33cf1d04afe0087610d51c0ba1088079375d3','JU-2020100007','wibowo2022','','Andri Wibowo','000000000000000','628100008000','Mojokerto','Mojokerto',1),(33,'d905d6d1b4a800542db33fa7e68e7ae1572a6ff3','JU-2022030014','adam2022','','Adam','081359155618','6281359155618','Pasuruan','Pasuruan',1),(34,'2d924dea69648033b27bf67950c8adebcc212e6c','JU-2022030016','zainularifin2022','','Zainul Arifin','085100279267','6285100279267','Pasuruan','Pasuruan',1),(35,'878a7de49239e6367b886063c162bc554e44f18e','JU-2022030007','musayyib2022','','Musayyib','082135661757','6282135661757','Probolinggo','Probolinggo',1),(36,'31e69795e42a47cc30341a8e71696ce7b784ebc8','JU-2022010001','reno2022','','Reno Handoko','082381667700','6282381667700','Probolinggo','Probolinggo',1),(37,'0716db5effa5f8dbcf722f439ed275f65288c341','JU-2022020001','tamim2022','','GusTamim','085230644458','6285230644458','Tuban','Tuban',1),(38,'304979f220537b08872be5a2a22923979b3e14a1','JU-2022030017','susmiatun2022','','Susmiatun','081234239595','6281234239595','Tuban','Tuban',1),(39,'13dbae7e9e0864afdc95824f12899b1286bf707d','JU-2022030015','doddy2022','','Doddy','08113308587','628113308587','Tuban','Tuban',1),(40,'3d5f170c3d08b96e8db8008dce898427782cad67','JU-2022030004','muksin2022','','Muksin','088805724241','6288805724241','Tulungagung','Tulungagung',1),(41,'2d9a865c1632d755c45607ab05abca16a18fad08','JU-2026040001','akusaya','','Aku','112345678','6212345678','Wqigina timur no. 6','Surabaya',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengumuman`
--

DROP TABLE IF EXISTS `pengumuman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengumuman` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `tombol` varchar(20) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengumuman`
--

LOCK TABLES `pengumuman` WRITE;
/*!40000 ALTER TABLE `pengumuman` DISABLE KEYS */;
INSERT INTO `pengumuman` VALUES (18,'95d4edeb0c10b6b1881066e5747844c2e7110884','Close','assets/home/assets/img/pengumuman/peringatan.jpg','TRAVEL ATRIA','<h3><b style=\"\"><font color=\"#ff0000\"><span style=\"font-family: Verdana;\"><u>PERHATIAN</u></span></font></b></h3><p><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">PEMBAYARAN diakui SAH jika dibayarkan tunai di kantor pusat atau disetor/transfer ke rekening perusahaan&nbsp;</span><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">&nbsp;:</span></p><h4><br></h4>','2020-05-11 14:07:07','Tampil');
/*!40000 ALTER TABLE `pengumuman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produk`
--

DROP TABLE IF EXISTS `produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produk` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `paketproduk` varchar(25) NOT NULL,
  `jenisproduk` varchar(25) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `judul` text NOT NULL,
  `foto` varchar(150) NOT NULL,
  `harga` varchar(25) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `diskripsi` longtext NOT NULL,
  `urut` int(2) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `kamar` int(1) NOT NULL,
  `hotelmadinah` varchar(50) NOT NULL,
  `bintangmadinah` int(1) NOT NULL,
  `hotelmekkah` varchar(50) NOT NULL,
  `bintangmekkah` int(1) NOT NULL,
  `pesawat` varchar(50) NOT NULL,
  `lama` int(2) NOT NULL,
  `baca` int(5) NOT NULL,
  `aman` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produk`
--

LOCK TABLES `produk` WRITE;
/*!40000 ALTER TABLE `produk` DISABLE KEYS */;
/*!40000 ALTER TABLE `produk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prosedur`
--

DROP TABLE IF EXISTS `prosedur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prosedur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `jenis` varchar(15) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `tagline` varchar(200) NOT NULL,
  `diskripsi` longtext NOT NULL,
  `foto` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prosedur`
--

LOCK TABLES `prosedur` WRITE;
/*!40000 ALTER TABLE `prosedur` DISABLE KEYS */;
INSERT INTO `prosedur` VALUES (1,'prosedur','Syarat dan Ketentuan','“ Melayani Tamu Allah adalah Pengabdian Kepada Allah ”','<p>Persyaratan Umrah :</p>\r\n\r\n<ol>\r\n	<li>Mengisi formulir pendaftaran</li>\r\n	<li>Paspor 3 kata yang masih berlaku 7 bulan saat keberangkatan</li>\r\n	<li>Vaksin Meningitis dan Influenza</li>\r\n	<li>Surat Mahram bagi perempuan <45 tahun, umrah sendiri tanpa suami / saudara laki-laki / bapak kandung</li>\r\n	<li>Foto berwarna background putih tampak wajah 80%  3x4 dan 4x6 masing-masing 4 lembar</li>\r\n	<li>Surat nikah asli bagi suami-istri <45 tahun</li>\r\n	<li>Foto copy Akte lahir bagi Anak <17 tahun</li>\r\n	<li>Foto copy Akte lahir bagi perempuan <45 tahun yang berangkat bersama orang tua</li>\r\n</ol>\r\n\r\n<p>Biaya belum termasuk :</p>\r\n\r\n<ol>\r\n	<li>Pengurusan Paspor dan tambah nama.</li>\r\n	<li>Dokumen tambahan untuk perempuan <45 tahun umroh sendiri tanpa suami/saudara laki-laki/bapak kandung atau jamaah yang tidak lengkap dokumennya.</li>\r\n	<li>Pengeluaran pribadi : laundry, telepon hotel, kelebihan bagasi, dsb.</li>\r\n	<li>Biaya kesehatan dan vaksin meningitis.</li>\r\n	<li>Biaya Regulasi, jika ada seperti kenaikkan PPN Saudi, Vaksin covid 19 (PCR) dan biaya tiket akibat social distancing</li>\r\n	<li>Pengurusan Visa di luar Saudi Arabia dan asuransi </li>\r\n</ol>\r\n\r\n<p>Pembatalan</p>\r\n\r\n<p>Pembatalan yang dilakukan satu bulan sebelum pemberangkatan dikenakan pemotongan 75%, dan < satu bulan sebelum pemberangkatan dikenakan biaya full/Hangus</p>','assets/images/clients/nabawi2.jpg'),(2,'mitrabisnis','MItra Bisnis','“ Melayani Tamu Allah adalah Pengabdian Kepada Allah ”','<p style=\"text-align: center; \"><iframe frameborder=\"0\" src=\"//www.youtube.com/embed/MHkudIPZX48?start=38\" width=\"640\" height=\"360\" class=\"note-video-clip\"></iframe></p><p><br></p><p><b><span style=\"font-family: \" arial=\"\" black\";\"=\"\">Kemudahan menjadi Mitra Bisnis Atria</span></b></p><p><b>Beberapa kemudahan untuk menjadi Mitra Bisnis Atria (MBA) :</b></p><ol><li>Anda TIDAK PERLU MODAL ketika mendaftar</li><li>Anda TIDAK PERLU bekerja di kantor, cukup di RUMAH saja</li><li>WAKTU anda yang menentukan ketika mencari jamaan</li><li>TEAM ATRIA siap membantu untul CLOSING Jamaah ketika dibutuhkan dan BONUS SEUTUHNYA milik anda</li><li>Media PROMOSI disediakan OLEH ATRIA TOUR melalui Media INSTAGRAM dan LINK yang bisa diakses dan didownload langsung</li></ol><p><br></p><p><span style=\"background-color: rgb(255, 255, 0);\"><b>BANTUAN SUPPORT CLOSING</b></span></p><p>Customer Service : 08113311808</p><p><span style=\"background-color: rgb(255, 255, 0);\">Download Link Paket dan Pelayanan</span></p><p>Instagram : Atria Tour and Travel</p><p>Facebook : Atria Tour & Travel</p><p style=\"text-align: center; \"><span style=\"font-family: \" arial=\"\" black\";\"=\"\"><b>Keuntungan Financial</b></span></p><p style=\"text-align: center;\"><span style=\"font-family: Arial;\"><b>Estimasi jika Bonus Rp. 3.000.000 per paket</b></span></p><table class=\"table table-bordered\"><tbody><tr><td>No.</td><td>Jumlah Pendaftar</td><td>Bonus Per Jamaah</td><td>Perhitungan</td><td>Keuntungan</td></tr><tr><td>1</td><td>1 Jamaah</td><td>Rp. 3.000.000</td><td>1 x 3.000.000</td><td>Rp. 3.000.000</td></tr><tr><td>2</td><td>2 Jamaah</td><td>Rp. 3.000.000</td><td>2 x 3.000.000</td><td>Rp. 6.000.000</td></tr><tr><td>3</td><td>3 Jamaah</td><td>Rp. 3.000.000</td><td>3 x 3.000.000</td><td>Rp. 9.000.000</td></tr><tr><td>4</td><td>4 Jamaah</td><td>Rp. 3.000.000</td><td>4 x 3.000.000</td><td>Rp. 12.000.000</td></tr><tr><td>5</td><td>5 Jamaah</td><td>Rp. 3.000.000</td><td>5 x 3.000.000</td><td>Rp. 15.000.000</td></tr><tr><td>6</td><td>6 Jamaah</td><td>Rp. 3.000.000</td><td>6 x 3.000.000</td><td>Rp. 18.000.000</td></tr><tr><td>7</td><td>7 Jamaah</td><td>Rp. 3.000.000</td><td>7 x 3.000.000</td><td>Rp. 21.000.000</td></tr><tr><td>8</td><td>8 Jamaah</td><td>Rp. 3.000.000</td><td>8 x 3.000.000</td><td>Rp. 24.000.000</td></tr><tr><td>9</td><td>9 Jamaah</td><td>Rp. 3.000.000</td><td>9 x 3.000.000</td><td>Rp. 27.000.000</td></tr><tr><td>10</td><td>10 Jamaah</td><td>Rp. 3.000.000</td><td>10 x 3.000.000</td><td>Rp. 30.000.000</td></tr></tbody></table><p><span style=\"font-family: Arial;\"><br></span></p><p><br></p>','assets/home/assets/img/prosedur/mitra.png');
/*!40000 ALTER TABLE `prosedur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `foto` varchar(200) NOT NULL,
  `heading` varchar(250) NOT NULL,
  `baris1` varchar(250) NOT NULL,
  `baris2` varchar(250) NOT NULL,
  `urut` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` VALUES (1,'assets/images/slider-main/slider_depan.jpg','Ayo Maju Terus kawan','“Mengerjakan haji adalah kewajiban manusia terhadap Allah, yaitu (bagi) orang yang sanggup mengadakan perjalanan ke Baitullah, Barangsiapa mengingkari (kewajiban haji), maka sesungguhnya Allah Maha Kaya (tidak memerlukan sesuatu) dari semesta alam”','~ QS. Ali Imran: 97',2),(4,'assets/images/slider-main/FOTO_HAJI.jpg','Ayo Maju Terus Kawan','“Rasulullah SAW bersabda, Sesungguhnya umrah di bulan Ramadhan seperti berhaji bersamaku”','(HR. Bukhari no. 1863)',1);
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spesialis`
--

DROP TABLE IF EXISTS `spesialis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spesialis` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `tema` varchar(100) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `gbr_tengah` varchar(255) NOT NULL,
  `foto1` varchar(255) NOT NULL,
  `judul1` varchar(150) NOT NULL,
  `isi1` varchar(255) NOT NULL,
  `foto2` varchar(255) NOT NULL,
  `judul2` varchar(150) NOT NULL,
  `isi2` varchar(255) NOT NULL,
  `foto3` varchar(255) NOT NULL,
  `judul3` varchar(150) NOT NULL,
  `isi3` varchar(255) NOT NULL,
  `foto4` varchar(255) NOT NULL,
  `judul4` varchar(150) NOT NULL,
  `isi4` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spesialis`
--

LOCK TABLES `spesialis` WRITE;
/*!40000 ALTER TABLE `spesialis` DISABLE KEYS */;
INSERT INTO `spesialis` VALUES (1,'','SPESIALISASI KERJA','UMROH DAN HAJI','assets/images/services/mekkah.png','assets/images/icon-image/best-service.png','Best Service','Kami selalu berusaha memberikan pelayanan terbaik, terbukti selama beberapa tahun Kepercayaan Jamaah semakin meningkat dalam Pemberangkatan Haji & Umrah.','assets/images/icon-image/rasional-cost.png','Rasional Cost','Biaya atau cost sangat Rasional artinya tidak dibawah harga minimal yang ditetapkan pemerintah. Kenyamanan dan keamanan dalam pemberangkatan jadi Prioritas Utama.','assets/images/icon-image/on-time-schedule.png','On Time Schedule','Sangat menjamin kepastian jadwal,Terbang,Hotel,Visa,Harga,Hotel dan Komitmenya ( Semua sesuai dan tertulis dalam perjanjian )','assets/images/icon-image/people-trust.png','People Trust !','Alhamdulillah, dipercaya oleh masyarakat hingga Pemerintahan dalam mendampingi ke Baitullah karena kami\r\nselalu mengedepankan \" Jujur Itu Wajib \" dalam setiap pelayanan kami kepada Jamaah.');
/*!40000 ALTER TABLE `spesialis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimoni`
--

DROP TABLE IF EXISTS `testimoni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimoni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `posisi` varchar(150) NOT NULL,
  `isi` text NOT NULL,
  `foto` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `tampil` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimoni`
--

LOCK TABLES `testimoni` WRITE;
/*!40000 ALTER TABLE `testimoni` DISABLE KEYS */;
INSERT INTO `testimoni` VALUES (4,'138c6dc698e35b63135333fbb7d6c1fa2642cd74','Alea Lely Azzam (Marwah Azam)','Malang','Atria Tour & Travel patut dibanggakan','assets/images/testimoni/favicon.png','2021-10-30',1),(5,'5f7b59c54ace86502e0620442efb9c3f8a862061','Hilmy Ihwan Syam','Surabaya','Amanah dan terpercaya','assets/images/testimoni/favicon1.png','2021-10-30',1);
/*!40000 ALTER TABLE `testimoni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `namavideo` varchar(150) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `urut` int(2) NOT NULL,
  `tampil` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (6,'6631271b9c1f52fd0d7bdd20d916bdc4969a6654','youtube','oZwKQON9Q_I','Detik-detik Terbukanya Payung ','Detik-detik Terbukanya Payung Di Halaman Masjid Rasulullah, Semoga Terbuka Juga Hidayah Untuk Kita! ',1,1),(17,'a5f201cb2ddfdbd4b7a9cbc2221d2003b331731b','youtube','EmePRh918Tw','222222222','bbbbbbbbb',7,1),(23,'a5f201cb2ddfdbd4b7a9cbc2221d2003b331731b','youtube','7ETp5amrbw4','222222222','bbbbbbbbb',7,1),(24,'5414b52faacbbf24bc715ef9b3a8de3dd1f9627d','youtube','4X7HXvfePmE','Sisa Cerita dari Tanah Suci: Tak Ada Tawakalna, Tawakaltu (Alallah) Pun Jadi','Tawakkalna Jamaah Umrah Indonesia Belum Berfungsi!? Mengapa?   #umrahdimasapandemi #umrah2022 #tawakkalna',8,1);
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'atriatou_travel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07  5:47:30
