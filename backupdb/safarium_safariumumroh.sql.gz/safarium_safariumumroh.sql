-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: safarium_safariumumroh
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `uraian` mediumtext NOT NULL,
  `foto` varchar(150) NOT NULL,
  `fb` varchar(200) NOT NULL,
  `tw` varchar(200) NOT NULL,
  `ig` varchar(200) NOT NULL,
  `perusahaan` varchar(255) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `gmap` text NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'Tentang Kami','<div>Berawal dari kepedulian terhadap anak yatim dan kaum dhuafa yang kurang <span style=\"font-size: 1rem;\">mendapatkan pendidikan yang layak dan memadai, beberapa dosen dari Universitas </span><span style=\"font-size: 1rem;\">Airlangga dan Universitas Islam Negeri Surabaya (IAIN Sunan Ampel) tergerak hatinya </span><span style=\"font-size: 1rem;\">untuk mendirikan usaha yang profitnya di darmabaktikan untuk membiayai pendidikan </span><span style=\"font-size: 1rem;\">anak yatim dan kaum dhuafa. </span><span style=\"font-size: 1rem;\">Gagasan dan cita-cita yang mulia tersebut diikrarkan </span><span style=\"font-size: 1rem;\">di depan Ka\'bah (Baitullah) saat mereka menunaikan </span><span style=\"font-size: 1rem;\">ibadah Haji.</span></div><div><span style=\"font-size: 1rem;\"><br></span></div><div><span style=\"font-size: 1rem;\">Akhirnya pada tahun 2008, gagasan dan </span><span style=\"font-size: 1rem;\">cita-cita mulia tersebut oleh Bapak Muhammad Asfar </span><span style=\"font-size: 1rem;\">selaku penggagas utama diwujudkan dalam bentuk </span><span style=\"font-size: 1rem;\">konkrit berupa pendirian PT. </span><span style=\"font-size: 1rem;\">Safari Global Perkasa </span><span style=\"font-size: 1rem;\">yang bergerak dalam bidang </span><span style=\"font-size: 1rem;\">pelayanan Umrah dan Haji Khusus dengan brand \"</span><span style=\"font-size: 1rem;\">Safari Umrah & Haji\".</span></div><div><span style=\"font-size: 1rem;\"><br></span></div><div><div>Keuntungan perusahaan ini sepenuhnya diinfaqkan untuk Pondok Pesantren <span style=\"font-size: 1rem;\">Idhotun Nasyi\'in di Desa Sugihwaras, Kalitengah Lamongan Jawa Timur, sehingga dapat </span><span style=\"font-size: 1rem;\">memberikan pendidikan gratis kepada para anak yatim dan kaum dhuafa, mulai dari </span><span style=\"font-size: 1rem;\">sekolah Dasar, SMP dan SMA.</span></div><div><span style=\"font-size: 1rem;\">Dalam perjalanannya Safari Umrah & Haji yang bermotokan \"<span style=\"font-weight: bolder;\">Umrah Sekaligus </span></span><span style=\"font-size: 1rem;\"><span style=\"font-weight: bolder;\">Bersedekah</span>\" mendapatkan kepercayaan dari masyarakat sehingga mulai tahun 2010 </span><span style=\"font-size: 1rem;\">memberangkatkan jama\'ah umrah dan haji khusus.</span></div><div><span style=\"font-size: 1rem;\"><br></span></div><div><span style=\"font-size: 1rem;\">Kepercayaan ini akan senantiasa dijaga </span><span style=\"font-size: 1rem;\">dengan pelayanan terbaik bagi jama\'ah umrah/haji  khusus karena mereka adalah tamu-tamu </span><span style=\"font-size: 1rem;\">Allah SWT, sekaligus menjaga komitmen perusahaan untuk mengentas kemiskinan </span><span style=\"font-size: 1rem;\">berupa sumbangsih dalam pendidikan anak yatim dan kaum dhuafa.</span></div><div><br></div><div><span style=\"font-size: 1rem;\"><span style=\"font-weight: bolder;\">Visi :</span></span></div><div> \" Menjadi Penyedia Layanan Umrah & Haji yang Amanah dan Profesional \"</div><div><br></div><div><span style=\"font-weight: bolder;\">Misi :</span></div><div><ol><li>Menyelenggarakan perjalanan ibadah Umrah-Haji dengan kualitas layanan prima untuk mencapai kemabruran.</li><li>Mengembangkan Pengelolaan perusahaan yang baik untuk mewujudkan kesejahteraan bagi anak yatim dan kaum dhuafa khususnya dalam bidang pendidikan.</li><li>Mengembangkan kreatifitas guna mendukung dan memberikan kontribusi yang sebesar-besarnya untuk masyarakat, bangsa dan agama.</li></ol><p>Mengapa harus Safari Umrah & Haji?</p><ol><li>InsyaAllah Umrah & Haji anda semakin berkah karena secara tidak langsung berinfaq kepada yatim piatu dan fakir miskin di Ponpes Idhotun Nasyi\'in, Sugihwaras, Kalitengah, Lamongan.</li><li>Berijin resmi Kementerian Agama RI.</li><li>Pembimbing yang amanah dan profesional.</li><li>Pembekalan tata cara ibadah yang komplit baik teori maupun praktek untuk memastikan jamaah umrah melaksanakan ibadah dengan sempurna.</li><li>Kepastian harga, tidak ada tambahan biaya lagi selain yang sudah tercantum di daftar harga brosur/pamflet.</li><li>Melayani dengan sepenuh hati, dengan motto : “ Melayani Tamu Allah adalah Pengabdian Kepada Allah”.</li></ol></div></div>','assets/home/assets/img/about/Safari-tour-tentang-kami.jpg','https://www.facebook.com/safari.umrahhaji.9/','http://twitter.com/username','https://www.instagram.com/safariumrahhaji/','PT. Safari Global Perkasa','“ Langkah Pasti Menuju Baitullah ”','Trillium Office and Residence<br> Jl. Pemuda 108 - 116 Lt. 1 No. 07','SURABAYA','safariglobalperkasa.pt@gmail.com','081232324112','+6231 51169000','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.7789928603006!2d112.74673651487565!3d-7.265973673408765!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7f9e1b0c6985f%3A0xf5f2248793d3a63d!2sPT.%20Safari%20Global%20Perkasa!5e0!3m2!1sid!2sid!4v1595151888643!5m2!1sid!2sid\" width=\"1600\" height=\"600\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','Tidak');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `lupapassword` varchar(200) NOT NULL,
  `singkat` varchar(150) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `hp` varchar(16) NOT NULL,
  `gmap` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','$2y$10$.fN..g1xyTEa5Gqsn9uwHuWiBR1QjLNG175tn0jGp1FwLEV0dhdvW','kokbisalupa','HOTEL DEKAT, HARGA HEMAT, IBADAH NIKMAT','Trillium Office and Residence brJl. Pemuda 108 - 116 Lt. I No. 07','Surabaya','safariglobalperkasa.pt@gmail.com','+6231 5116900','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.778945994214!2d112.74673651466809!3d-7.2659789947552875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7f962bc2c8d51%3A0x984f49879deb4e25!2sPT%20SAFARI%20GLOBAL%20PERKASA%20-%20Surabaya!5e0!3m2!1sid!2sid!4v1595148116942!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','assets/images/about/3D-Abstract-Background-Wallpapers-Part-2-3-300x187.jpg',1,'2020-04-01 00:00:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artikel`
--

DROP TABLE IF EXISTS `artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(150) NOT NULL,
  `diskripsi` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `urut` int(5) NOT NULL,
  `baca` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikel`
--

LOCK TABLES `artikel` WRITE;
/*!40000 ALTER TABLE `artikel` DISABLE KEYS */;
INSERT INTO `artikel` VALUES (5,'UMROH PENUH HIKMAT','Umroh bersama SAFARI TOUR & TRAVEL penuh kenyamanan dan hikmat','assets/home/assets/img/artikel/IMG-20180310-WA0013.jpg','2020-04-19','KTG002',4,1557),(6,'Miqot.','Saat jamaah melakukan umroh dg pengambilan Miqot','assets/home/assets/img/artikel/IMG-20181129-WA0042.jpg','2020-04-19','KTG001',5,1511),(7,'Jabal Rahmah','<p>Dalam Alquran surah Thaha disebutkan, Adam dan Hawa diusir dari surga karena telah melanggar ketentuan Allah, yakni jangan memakan buah khuldi.Tindakan Adam dan Hawa itu pun akibat keduanya terpedaya bujuk rayu iblis. Makhluk terkutuk itu telah membisikkan pikiran jahat kepada mereka dengan berkata, \"Hai Adam, maukah saya tunjukkan padau pohon khuldi dan kerajaan yang tidak akan binasa?” (QS Thaha ayat 120).</p><p><span style=\"font-size: 1rem;\">Dalam An-Nihayah fi Gharib Al-Hadit karya Abu Sa’adat Ibnul Atsir disebutkan, Adam awalnya menolak mengikuti bujukan Iblis. Namun, ada desakan dari Hawa sehingga manusia pertama itu pun akhirnya ikut memakan buah tersebut.</span><br></p><p><span style=\"font-size: 1rem;\">Bertemu di Jabal Rahmah</span><br></p><p><span style=\"font-size: 1rem;\">Apa yang terjadi setelah keduanya terusir dari surga? Yang jelas, mereka akhirnya diturunkan ke bumi.</span><br></p><p><span style=\"font-size: 1rem;\">Namun, di manakah lokasi persisnya mereka diturunkan hingga bertemu kembali? Soal itu tidak dijelaskan dalam Alquran maupun hadis.</span><br></p><p><span style=\"font-size: 1rem;\">Namun, sebagian ulama sepakat, keduanya setelah diturunkan secara terpisah dari Surga kemudian bertemu di Jabal Rahmah, Arafah, Jazirah Arab.</span><br></p><p><span style=\"font-size: 1rem;\">Al-Imam At-Thabari dalam Tarikh-nya menjelaskan keterangan dari Abdullah bin Abbas bin Abdul Mutthalib. Ia mengatakan, \"Adam diturunkan dari surga ke bumi di negeri India.”</span><br></p><p><span style=\"font-size: 1rem;\">Abu Shaleh meriwayatkan juga dari Ibnu Abbas, Hawa diturunkan di Jeddah--yang masih bagian dari Hijaz. Kata Jeddah itu sendiri berasal dari bahasa Arab yang berarti \'perempuan tua.\'</span><br></p><p><span style=\"font-size: 1rem;\">Riwayat lain menyebutkan, Adam diturunkan di Bukit Shafa, sedangkan Hawa di Bukit Marwah. Ada pula yang menyebutkan, Adam diturunkan di antara Makkah dan Thaif. Ada pula yang berpendapat, Adam diturunkan di India, sementara Hawa di Irak.</span><br></p><p><span style=\"font-size: 1rem;\">Betapapun sebagian ulama berselisih pendapat tentang lokasi diturunkannya Adam dan Hawa, kebanyakan mereka bersepakat: kedua insan pertama itu akhirnya bertemu kembali di Jabal Rahmah. Sebelumnya, mereka terpisah ratusan tahun lamanya sejak diturunkan dari surga ke bumi.</span><br></p><p><span style=\"font-size: 1rem;\">Bagi umat Islam, Jabal Rahmah juga memiliki nilai sejarah penting. Sebab, di sinilah Nabi Muhammad SAW menerima wahyu terakhir. Yakni, pada saat beliau menunaikan Haji Wada, atau ibadah haji terakhir.</span><br></p><p><span style=\"font-size: 1rem;\">Wahyu itu adalah surah al-Maidah ayat 3, yang artinya, \"Pada hari ini orang-orang kafir telah putus asa untuk (mengalahkan) agamamu, sebab itu janganlah kamu takut kepada mereka, tetapi takutlah kepada-Ku. Pada hari ini telah Aku sempurnakan agamamu untukmu, dan telah Aku cukupkan nikmat-Ku bagimu, dan telah Aku ridai Islam sebagai agamamu. Tetapi barangsiapa terpaksa karena lapar, bukan karena ingin berbuat dosa, maka sungguh, Allah Maha Pengampun, Maha Penyayang.\"</span><br></p><p style=\"text-align: right; \"><span style=\"font-size: 1rem;\">sumber : Pusat Data Republika</span><br></p>','assets/home/assets/img/artikel/IMG-20180424-WA0031.jpg','2020-04-19','KTG003',6,1538),(9,'HALAL BIHALAL RAJUT PERSAUDARAAN','<p>Barangsiapa yang ingin dilapangkan rezekinya dan dipanjangkan umurnya maka hubungkan silaturahmi (HR Bukhori-Muslim).</p><p><span style=\"font-size: 1rem;\">Silaturahim adalah sebuah kata yang sudah sering digunakan. Berasal dari dua kata, yaitu silah yang artinya tali atau hubungan dan rahim yang artinya kasih sayang.&nbsp;</span><span style=\"font-size: 1rem;\">Dari dua kata itu, silaturahim sering diartikan sebagai \'menyambung tali kasih sayang atau tali persaudaraan.\'&nbsp;</span><span style=\"font-size: 1rem;\">Istilah ini sudah sering dipakai untuk saling mengunjungi keluarga, relasi, tetangga, serta teman yang dekat maupun jauh.</span></p><p><span style=\"font-size: 1rem;\">Di negara-negara Arab, budaya silaturahmi saat Idul Fitri seperti yang ada di Indonesia ini tidak pernah ada.&nbsp;</span><span style=\"font-size: 1rem;\">Nabi Muhammad sendiri tidak pernah mencontohkannya secara khusus untuk saling mengunjungi saat Idul Fitri. Nabi saw hanya memberikan contoh dengan selalu berangkat dan pulang shalat Id melalui dua jalan yang berbeda agar bisa bertemu banyak orang yang bergantian dapat bersilaturahmi.&nbsp;</span><span style=\"font-size: 1rem;\">Silaturahim yang dilakukan Nabi saw pun setiap saat, tidak hanya terbatas saat Idul Fitri. Di Indonesia silaturahmi ini sudah lazim dilakukan terutama saat Idul Fitri tiba. Idul Fitri memang saat yang tepat untuk bersilaturahim.</span></p><p><span style=\"font-size: 1rem;\">Menyambung persaudaraan atau bersilaturahim adalah suatu kewajiban bagi setiap Muslim. Allah telah menjanjikan kepada orang yang menjalin silaturahmi dengan balasan surga. Dalam sebuah hadis dari Al Ayyub Al Anshary bahwa Rasulullah pernah suatu kali ditanya oleh seorang laki-laki, \'\'Ya Rasulullah, beritahukan kepadaku suatu perkara yang bisa mengantarkanku ke surga!\'\' Rasulullah menjawab, \'\'Menyembah Allah tanpa mempersekutukan-Nya dengan sesuatu, mendirikan shalat, mengeluarkan zakat, dan bersilaturahmi.\'\'</span><br></p><p><span style=\"font-size: 1rem;\">Allah juga sangat mengecam siapa saja yang memutuskan silaturahim. Hal ini ditunjukkan dengan adanya ancaman dari Allah bagi siapa saja yang memutuskan tali persaudaraan sesama Muslim seperti ditunjukkan dalam sebuah hadis bahwa Rasulullah saw bersabda, \'\'Tidak akan masuk surga orang yang memutuskan silaturahim,\'\' (HR Bukhori-Muslim).</span><br></p><p><span style=\"font-size: 1rem;\">Selain merupakan kewajiban, ternyata silaturahmi banyak sekali manfaatnya. Dengan bersilaturahmi, keluarga yang jauh akan terasa dekat kembali, saudara dan kawan lama bisa berkumpul, bahkan orang yang berseteru bisa rukun kembali.&nbsp;</span><span style=\"font-size: 1rem;\">Dengan saling berkumpulnya saudara dan teman yang selama ini terpisah serta rukunnya kembali orang yang sebelumnya berseteru, insya Allah akan dapat disatukan kembali hubungan persaudaraan. Diharapkan dengan terjalinnya kembali persaudaraan, umat Islam yang bersatu dan bersaudara akan terwujud kembali seperti ketika Rasulullah mempersaudarakan kaum Muhajir dan Anshar di Madinah.</span></p><p><span style=\"font-size: 1rem;\">Silaturahim seharusnya tidak hanya dilaksanakan saat Idul Fitri, tetapi sedapat mungkin setiap ada kesempatan. Semoga niat baik kita untuk menjalin kembali persaudaraan ini diridhoi Allah. Amin.</span><br></p>','assets/home/assets/img/artikel/IMG-20200813-WA0036.jpg','2020-04-19','KTG002',7,3055),(10,'Fasilitas Terjamin','<p>Kenyamanan &amp; keamanan saat di tanah suci menjadi tanggung jawab Safari Umrah &amp; Haji</p>','assets/home/assets/img/artikel/IMG-20181130-WA0029.jpg','2020-05-01','KTG001',8,3120),(12,'Kesabaran & Kesadaran Sebagai Tamu Allah adalah Awal Mencapai Kemabruran','<div><br></div><div><div>Salah satu tips utama yang harus dimiliki setiap orang yang berumrah adalah sabar. Kesabaran ini harus dimiliki ketika di perjalanan, saat menunaikan umrah dan ketika balik ke tanah air.</div><div><br></div><div>Dalam ayat suci Al Qur’an disebutkan firman Allah,</div><div><br></div><div><span style=\"font-size: 1rem;\">“(Musim) haji adalah beberapa bulan yang dimaklumi, barangsiapa yang menetapkan niatnya dalam bulan itu akan mengerjakan haji, maka tidak boleh rafats (berkata kotor)\", berbuat fasik dan berbantah-bantahan di dalam masa mengerjakan haji.” (QS. Al Baqarah: 197).</span><br></div><div><br></div><div>Lihatlah Allah memerintahkan bagi yang berhaji untuk sabar. Demikian pula umrah semisal itu. Allah memerintahkan untuk menghindari jidal, yaitu beradu argumen. Karena memamg saat haji atau umrah, kita akan bertemu dengan berbagai macam orang yang punya watak yang berbeda-beda. Ada yang punya cara berbicara yang keras dan ada yang punya watak yang lain karena datang dari berbagai penjuru negeri.</div><div><br></div><div>Coba lihat saja saat berangkat umrah, kita sudah merasakan susahnya safar. Perjalanan yang lama hingga 24 jam di perjalanan dan tentu melelahkan.</div><div><br></div><div>Dari Abu Hurairah, dari Nabi shallallahu ‘alaihi wa sallam, beliau bersabda,</div><div><br></div><div><span style=\"font-size: 1rem;\">“Safar adalah bagian dari adzab (siksa). Ketika safar salah seorang dari kalian akan sulit makan, minum dan tidur. Jika urusannya telah selesai, bersegeralah kembali kepada keluarganya.” (HR. Bukhari no. 1804 dan Muslim no. 1927). Yang dimaksud adzab dalam hadits di atas adalah rasa sakit yang timbul dari kesulitan yang dihadapi ketika berkendaraan dan berjalan sampai harus meninggalkan hal-hal yang disukai. (Fathul Bari, Ibnu Hajar)</span><br></div><div><br></div><div>Saat sampai di Jeddah, coba lihat saja sebagian kita harus mengantri di imigrasi berjam-jam, itu tentu butuh kesabaran.</div><div><br></div><div>Ketika pelaksanaan umrah juga harus sabar. Saat thawaf, kita akan bertemu dengan watak yang suka dorong-dorongan. Ada juga yang mengelilingi thawaf sambil mengeraskan suara hingga memekakkan telinga yang lain. Padahal thawaf cukup dengan suara lirih tanpa mengganggu yang lain. Dan juga ibadah tersebut cukup dilakukan sendiri-sendiri tanpa mesti dikomandoi seorang imam saat mengelilingi Baitullah Al Haram.</div><div><br></div><div>Saat pulang pun akan mengalami kesulitan di perjalanan sama seperti saat beangkat.</div><div><br></div><div>Ketika pergi dan pulang, niat kita juga harus dijaga ikhlas karena Allah. Karena kadang di awal sudah ingin cari pujian, di tengah dan saat mau berakhir pun demikian. Jadi perlu kesabaran menjaga niat yang ikhlas.</div><div><br></div><div>Begitu pula saat pulang akan merasakan kecapekan. Itu tentu butuh kesabaran yang ekstra.</div><div><br></div><div>Kita pun akan merasakan susahnya antri di kamar mandi dan pemeriksaan, sehingga semuanya butuh kesabaran.</div><div><br></div><div>Kalau kita terus bersabar, maka kita bisa mewujudkan yang disebut dalam ayat: “tidak boleh rafats (berkata kotor), berbuat fasik dan berbantah-bantahan di dalam masa mengerjakan haji.”</div><div><br></div><div>Pahala orang yang sabar disebutkan dalam ayat,</div><div><br></div><div><span style=\"font-size: 1rem;\">“Sesungguhnya orang-orang yang bersabar, ganjaran bagi mereka adalah tanpa hisab (tak terhingga).” (QS. Az Zumar: 10). As Sudi mengatakan bahwa balasan bagi orang yang bersabar adalah surga. (Tafsir Al Qur’an Al ‘Azhim karya Ibnu Katsir, 7: 89)</span><br></div><div><br></div><div><span style=\"font-size: 1rem;\">Dari Abu Hurairah radhiyallahu ‘anhu, ia berkata bahwa Rasulullah shallallahu ‘alaihi wa sallam bersabda,</span><br></div><div><br></div><div><span style=\"font-size: 1rem;\">“Di antara umrah yang satu dan umrah lainnya akan menghapuskan dosa di antara keduanya dan haji mabrur tidak ada bahasannya kecuali surga.” (HR. Bukhari no. 1773 dan Muslim no. 1349).</span><br></div><div><br></div><div>Dari Abdullah, Rasulullah shallallahu ‘alaihi wa sallam bersabda,</div><div><br></div><div><span style=\"font-size: 1rem;\">“Ikutkanlah umrah kepada haji, karena keduanya menghilangkan kemiskinan dan dosa-dosa sebagaimana pembakaran menghilangkan karat pada besi, emas, dan perak. Sementara tidak ada pahala bagi haji yang mabrur kecuali surga.” (HR. An Nasai no. 2631, Tirmidzi no. 810, Ahmad 1/387. Kata Syaikh Al Albani hadits ini hasan shahih)</span><br></div><div><br></div><div>Dan ingatlah umrah pun termasuk jihad sehingga harus memiliki kesabaran yang tinggi.</div><div><br></div><div>‘Aisyah RA berkata,</div><div><br></div><div><span style=\"font-size: 1rem;\">“Wahai Rasulullah, apakah wanita juga wajib berjihad?” Beliau shallallahu ‘alaihi wa sallam menjawab, “Iya. Dia wajib berjihad tanpa ada peperangan di dalamnya, yaitu dengan haji dan ‘umroh.” (HR. Ibnu Majah no. 2901, hadits ini shahih sebagaimana kata Syaikh Al Albani).</span><br></div><div><br></div><div>Hanya Allah yang memberi taufik.</div><div><br></div><div><br></div><div><span style=\"font-size: 1rem;\">disadur dari muslim.or.id</span><br></div></div>','assets/home/assets/img/artikel/WhatsApp_Image_2019-01-20_at_15_01_35.jpeg','2020-05-11','KTG002',9,3273);
/*!40000 ALTER TABLE `artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artikel_tampil`
--

DROP TABLE IF EXISTS `artikel_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artikel_tampil` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikel_tampil`
--

LOCK TABLES `artikel_tampil` WRITE;
/*!40000 ALTER TABLE `artikel_tampil` DISABLE KEYS */;
INSERT INTO `artikel_tampil` VALUES (1,'Berita','Umroh  Haji Sesuai Sunnah','Penyelenggara Haji Khusus dan Umrah dengan pelayanan berkualitas','assets/images/fotoservice/nabawi2.jpg','Tampil');
/*!40000 ALTER TABLE `artikel_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `award` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tampil` varchar(10) NOT NULL,
  `data1` varchar(25) NOT NULL,
  `angka1` int(5) NOT NULL,
  `data2` varchar(25) NOT NULL,
  `angka2` int(5) NOT NULL,
  `data3` varchar(25) NOT NULL,
  `angka3` int(5) NOT NULL,
  `data4` varchar(25) NOT NULL,
  `angka4` int(5) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(150) NOT NULL,
  `foto` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award`
--

LOCK TABLES `award` WRITE;
/*!40000 ALTER TABLE `award` DISABLE KEYS */;
INSERT INTO `award` VALUES (1,'Tampil','Rejekiku',100,'Luar Biasa',1200,'Happy Customers',1200,'Cups of coffee',590,'Kami <span>MEMBANTU</span> masalah hukum anda','A small river named Duden flows by their place and supplies it with the necessary regelialia.','assets/images/foto/al-aqsa-mosque.jpg');
/*!40000 ALTER TABLE `award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(150) NOT NULL,
  `foto` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (1,'Blog Single Post','Mewarnai hidup lebih baik BOSKU SAYANG','assets/images/foto/2zppjpz.jpg');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_web` varchar(50) NOT NULL,
  `th_web` varchar(4) NOT NULL,
  `titel_web` varchar(150) NOT NULL,
  `keyword_web` varchar(250) NOT NULL,
  `diskripsi_web` varchar(250) NOT NULL,
  `judul_web` varchar(150) NOT NULL,
  `favicon` varchar(100) NOT NULL,
  `fontawesome` varchar(50) NOT NULL,
  `sessionadmin` varchar(255) NOT NULL,
  `sessionpassadmin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'safariumrohhaji.com','2020','Safari Umrah  Haji | Langkah Pasti Menuju Baitullah','umroh,umrah,haji,perjalanan,ibadah,umroh murah,umrah murah,umroh terbaik,umroh terbaik,umroh surabaya,umrah surabaya,haji terbaik,haji murah,haji surabaya','Website Promosi','SAFARI UMRAH HAJI','assets/images/favicon.ico','<i class=\"fas fa-user\"></i>','Admin','PasswordAdmin');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori_artikel`
--

DROP TABLE IF EXISTS `kategori_artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(10) NOT NULL,
  `nama_kategori` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori_artikel`
--

LOCK TABLES `kategori_artikel` WRITE;
/*!40000 ALTER TABLE `kategori_artikel` DISABLE KEYS */;
INSERT INTO `kategori_artikel` VALUES (1,'KTG001','SAUDI'),(2,'KTG002','UMROH'),(3,'KTG003','TOUR INTERNASIONAL'),(4,'KTG004','HAJI');
/*!40000 ALTER TABLE `kategori_artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `wa` varchar(15) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(25) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (22,'MA-RKET02','market02','Muhammad Asyhar','081252397285','6281252397285','Jl Karah 83 RT 1RW 06 Karah Jambangan','Surabaya',1),(23,'MA-RKET03','market03','Muhamad Arifin','081234044195','6281234044195','Jl Saidani Tambak Sumur Waru','Sidoarjo',1),(24,'MA-RKET04','market04','Novia Eka Agustin','081259424480','6281259424480','Perum Bumi Cabean Asri E32 Candi','Sidoarjo',1),(25,'MA-RKET05','market05','Abdul Hadi','082244556209','6282244556209','JL Ayelir 42, Tulungrejo, Pare','Kediri',1),(26,'MA-RKET06','market06','Abdullah Wahib','081232324112','6281232324112','Ngeni Permai Gang 212, Waru','Sidoarjo',1),(27,'MA-RKET07','market07','Erna Siswati','081295741965','6281295741965','Ngeni Permai Gang 212, Waru','Sidoarjo',1),(31,'MI-TRA0001','mitra0001','Agus Turmudzi','081554085324','6281554085324','Trosobo Taman','Sidoarjo',1),(32,'MI-TRA0002','mitra0002','Hari Seputro','081233621779','6281233621779','Taman Pondok Jati P 21','Sidoarjo',1),(33,'MI-TRA0003','mitra0003','Masud','082232196304','6282232196304','Kejawan Putih Tambak Baru 25-A Mulyorejo','Surabaya',1),(34,'MI-TRA0004','mitra0004','Indah Suyanti','087701386629','6287701386629','Barata Jaya 379 Gubeng','Surabaya',1),(35,'MI-TRA0005','mitra0005','Andi Widiyanto','085100848121','6285100848121','Bagong Ginayan 4-A4 Wonokromo','Surabaya',1),(36,'MI-TRA0006','mitra0006','Didit Soeprijanto','082233445566','6282233445566','Perum Mega Asri B-45, Candi','Sidoarjo',1),(37,'MI-TRA0007','mitra0007','Irma Uswatun Hasanah','08155090595','628155090595','Anggur RT 002 RW 003 Tunjung Mekar Kalitengah','Lamongan',1),(38,'MI-TRA0008','mitra0008','Setyawan Suwanto','082331251001','6282331251001','Perum Citra Harmoni A612 Taman','Sidoarjo',1),(39,'MI-TRA0009','mitra0009','Sawitri','082257272128','6282257272128','JL Ayelir 42, Tulungrejo, Pare','Kediri',1),(40,'MI-TRA0010','mitra0010','Umi Khofsah S.Pd.I','085731644099','6285731644099','Puri Aloha DD7 Suko Sukodono','Sidoarjo',1),(41,'MI-TRA0011','mitra0011','Al Falah Adan Adan Kediri','085335404691','6285335404691','Asemrowo IV No 3 Asemrowo','SURABAYA',1),(42,'MI-TRA0012','mitra0012','Udik Ariyanto','081331740797','6281331740797','Perum Bumi Cabean Asri E32 Candi','Sidoarjo',1),(43,'MI-TRA0013','mitra0013','Alfiah','08123590141','628123590141','Taman Suko Asri H07 Sukodono','Sidoarjo',1),(44,'MI-TRA0014','mitra0014','Soegeng Iman Wicaksono','085730077121','6285730077121','Bratang Gede 3H3 Ngagel Rejo Wonokromo','Surabaya',1),(45,'MI-TRA0015','mitra0015','Nurul Fahmi','082140615599','6282140615599','Jl Duku R9 Kepanjen  Jombang','Jombang',1),(46,'MI-TRA0016','mitra0016','Nur Faisah','085257320547','6285257320547','Kedungturi Permai 1 Blok C7 Kedungturi Taman','Sidoarjo',1),(47,'MI-TRA0017','mitra0017','Nur Cholis','085230000597','6285230000597','Dukuh Kupang Gg Sumber No 4 Dukuh Pakis','Surabaya',1),(48,'MI-TRA0018','mitra0018','Margono','081234532187','6281234532187','Buran Babat Jerawat Pakal','Surabaya',1),(49,'MI-TRA0020','mitra0020','Mohammad Amin','6285731480606','6285731480606','Sawah Pulo, Ujung,  Semampir, Surabaya','Surabaya',1),(50,'MI-TRA0019','mitra0019','BAHRON','081944946827','6281944946827','DSN BANDARAN RT.001, RW.002, KEL.MANCILAN, KEC. MOJOAGUNG','JOMBANG',1),(51,'MI-TRA0021','mitra0021','ARBY TOUR','089697505225','6289697505225','Mandiri Residence cluster Jasmine Blok F68, Jeruk, Gamping, Krian','Sidoarjo',1),(52,'MI-Tra0023','mitra0023','ISMAIL HAMID','085732034369','6285732034369','NGINDEN 3-E6 SUKOLILO','surabaya',1),(53,'MI-Tra0022','mitra0022','YUNI ASTUTININGSIH','082233072025','6282233072025','WONOREJO I4 KEL. WONOREJO','surabaya',1),(54,'MI-Tra0024','mitra0024','IWAN SUBEKTI','088217097427','6288217097427','TEMPEL SUKOREJO I131','surabaya',1),(55,'MI-Tra0025','mitra0025','GILANG IZZUDDIN AMRULLAH','081235908575','6281235908575','TEMPEL SUKOREJO I131 A','surabaya',1),(56,'MARK-ET01','market01','CSO SAFARI TOUR  TRAVEL','03151169000','6282330377729','Trillium Office  Residence Lt.1, No.7, Jl. Pemuda 108-116','Surabaya',1),(57,'MI-Tra0026','mitra0026','HADI WIBOWO','085853402305','6285853402305','NGENI PERMAI II7','SIDOARJO',1),(58,'MI-Tra0027','mitra0027','WAHYUNINGSIH','081334366920','6281334366920','JL. HAYAM WURUK 41 SAWOTRATAP','SIDOARJO',1),(59,'MI-Tra0028','mitra0028','NADIYA NUR ROSYIDAH','81334366920','6281334366920','JL. HAYAM WURUK 41 SAWOTRATAP','SIDOARJO',1),(60,'MI-Tra0030','mitra0030','DILA APRINA NIRLINASARI','081654913942','6281654913942','DSN SUREN RT003RW012 DESA JAMBU KEC. KAYEN KIDUL','KEDIRI',1),(61,'MI-Tra0031','mitra0031','PARJIANTO BIN HARJO S','82113068340','6282113068340','KRANGGAN PASAR RT002RT004 JATISAMPURNA','BEKASI',1),(62,'MI-Tra0032','mitra0032','ENI INDAYANI','082244404027','6282244404027','WISMA TROPODO NUSA INDAH G-3 TROPODO','SIDOARJO',1),(63,'MI-Tra0033','mitra0033','ERWIN SARWONO','082333060060','6282333060060','DUSUN KOPEN RT 02 RW 02 GENTENG KULON','BANYUWANGI',1),(64,'MI-Tra0034','mitra0034','HUSNUN','082139633212','6282139633212','GG.SWADAYA DSN BOHAR BALUN','SIDOARJO',1),(65,'MI-Tra0035','mitra0035','YUNI SUDIARSIH','085101205551','6285101205551','JL.LAMONGAM NO.11','SURABAYA',1),(66,'MI-TRA0029','mitra0029','M. YUNAN MUZAKKI','085230648237','6285230648237','JL. DSN KEMBANGAN RT003 RW.004 KEL.KEMBANGRINGGIT, Kec. Pungging','MOJOKERTO',1),(67,'MI-TRA0036','mitra0036','BENY ANDRIYAN','085733019903','6285733019903','JL.KEDUNG RUKEM III47-B KEL.KEDUNGDORO, Kec. Tegalsari','SURABAYA',1),(68,'MI-TRA0037','mitra0037','SYAMSUL AMAN','082257227497','6282257227497','DSN RUJING RT.001 RW.002 KEL.SUNGAI TELUK, Kec. Sangkapura','GRESIK',1),(69,'MI-Tra0038','mitra0038','RETNO AYU RUSTIAYATI','082140970808','6282140970808','BRATANG GEDE 6C34 NGAGELREJO,','SURABAYA',1),(70,'MI-Tra0039','mitra0039','RIAWAN','0882117433431','62882117433431','DARMOREJO 32 DARMO','SURABAYA',1),(71,'MI-Tra0040','mitra0040','SUGENG ALFIKRI EENG','081247058265','6281247058265','BENDULMERISI BESAR SELATAN 65J','SURABAYA',1),(72,'MI-Tra0041','mitra0041','R FEBRANTA YUDHI WULANDARU','0818522616','62818522616','NGENI PERMAI 34 KEPUHKIRIMAN WARU','SIDOARJO',1),(73,'MI-Tra0042','mitra0042','SYARIFATUL AISYAH','081330355842','6281330355842','Botoh putih 157 A Simolawang','SURABAYA',1),(74,'MI-Tra0043','mitra0043','ZAMRONI','081332081478','6281332081478','Sidotopo 4195-B','SURABAYA',1),(75,'MI-Tra0044','mitra0044','Dra. LIANA SRI WULANDARI','081249015275','6281249015275','JAJARTUNGGAL UTARA 5-T7','SURABAYA',1),(76,'MI-Tra0045','mitra0045','MOCH ASRUSSANI','085645099629','6285645099629','JEMURWONOSARI SEKOLAHAN NO.2 JEMURWONOSARI','SURABAYA',1),(77,'MI-Tra0046','mitra0046','SYAMSUDIN','085102669074','6285102669074','GRIYOKENCANA SEKTOR 1W.62 RT01RW6 MOJOSARIREJO DRIYOREJO, Kec. Driyorejo','GRESIK',1),(78,'MI-Tra0047','mitra0047','AHMAD ARIADI AL AMIN','085730065005','6285730065005','JL.RAJAWALI C77 WAP PANGERANAN , Kec. Bangkalan','BANGKALAN',1),(79,'MI-Tra0048','mitra0048','BAMBANG SUDARJONO','082335082297','6282335082297','MERBABU H-22 KEPUH KIRIMAN','SIDOARJO',1),(80,'MI-Tra0049','mitra0049','SULTANI S.Ag.','081357010899','6281357010899','KARANG MENJANGAN 3-C16 MOJO','SURABAYA',1),(81,'MI-Tra0050','mitra0050','NUNUK WARSIYAH','081272353117','6281272353117','Semampirtengah IXA dalam no.3 medokan semampir','SURABAYA',1),(82,'MI-Tra0051','mitra0051','Nurul Fatimah','081313797784','6281313797784','Gembong 328, rt.003, rw.004, Kel.Kapasan, Kec. Simokerto','Surabaya',1),(83,'MI-TRA0052','mitra0052','SITI FATIMAH','085748275997','6285748275997','BRATANG GEDE 3-H3, Rt.12, Rw.07, Kel. Ngagelrejo, Kec. Wonokromo','Surabaya',1),(84,'MI-TRA0053','mitra0053','NADIA EKA SEPTIANA','085732347692','6285732347692','Tempurejo 51, Rt. 04, Rw.03, Dukuh Sutorejo, Mulyorejo','Surabaya',1),(85,'MI-TRA0054','mitra0054','ACHMAD HADIYANTO','081332066630','6281332066630','Keplak, Rt.09, Rw.01, Keplaksari, Peterongan','JOMBANG',1),(86,'MI-Tra0055','mitra0055','ZIAUL HAQ','082331907771','6282331907771','Kedung Turi Permai 1, N14, Rt.34, Rw.11, Kel. Kedung Turi, Taman','Sidoarjo',1),(87,'MI-Tra0056','mitra0056','LISA YULIARTINING PUTRI','081556616707','6281556616707','Ds. Slempit 012003, Slempit, Kedamean','GRESIK',1),(88,'MI-Tra0057','mitra0057','yunanda sentia rizki samudra','08994809463','628994809463','jl.surowongso no188','surabaya',1),(89,'MI-0058','mitra0058','WILLY JUNAIDI','085708010987','6285708010987','KERTAJAYA INDAH TIMUR 144P-245','surabaya',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengumuman`
--

DROP TABLE IF EXISTS `pengumuman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengumuman` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tombol` varchar(20) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengumuman`
--

LOCK TABLES `pengumuman` WRITE;
/*!40000 ALTER TABLE `pengumuman` DISABLE KEYS */;
INSERT INTO `pengumuman` VALUES (18,'Tutup','assets/home/assets/img/pengumuman/Brosur-Safari-Al-mukhlisin-.jpg','Safari Tour Mengucapkan Selamat Hari Raya Idul Fitri 1443 H','<h3><b style=\"\"><font color=\"#ff0000\"><span style=\"font-family: Verdana;\"><u>PERHATIAN</u></span></font></b></h3><p><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">Pembayaran diakui sah jika dibayarkan tunai di kantor pusat atau disetor/transfer ke rekening perusahaan </span><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\"> :</span></p><h4><b style=\"font-size: 1rem;\"><span style=\"font-family: \" times=\"\" new=\"\" roman\";\"=\"\" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">PT SAFARI GLOBAL PERKASA</span></b></h4><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><u><br></u></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><u><span style=\"font-family: \" tahoma\";\"=\"\">BANK SYARIAH MANDIRI </span></u><br></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \">No Rek :   716 117 161 6  (IDR)</span></b></span></b></h6><h6><span style=\"font-weight: bolder; font-size: 1rem;\"><span source=\"\" sans=\"\" pro\";\"=\"\">No Rek :   716 116 611 6 (US</span></span><span style=\"font-weight: bolder; font-size: 1rem;\"><span source=\"\" sans=\"\" pro\";\"=\"\">D)</span></span><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><br></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u><br></u></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u>BANK</u></span></b><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u> BCA </u>                                </span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\">No Rek :   152 039 523 3  (IDR)</span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u><br></u></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u>BANK MANDIRI </u>                    </span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\">No Rek :   142 002 233 445 1 (IDR)</span></b></h6><h6><br></h6><p><b>            </b></p>','2020-05-11 14:07:07','Tampil');
/*!40000 ALTER TABLE `pengumuman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` date NOT NULL,
  `urut` int(5) NOT NULL,
  `baca` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (3,'assets/home/assets/img/testimoni/WhatsApp_Image_2019-01-20_at_14_36_32.jpeg','Miqot Umrah Pertama','<p>Pengambilan Miqot untuk umrah Pertama di Masjid Bier \'Ali</p>','2020-08-10',3,19),(4,'assets/home/assets/img/testimoni/Pembekalan-Sebelum-Keberang.jpg','Pembekalan','<p>Sebelum Keberangkatan Jamaah akan diberi pembekalan berupa breafing tentang keadaan dan kondisi di Arab Saudi.</p>','2020-08-05',4,17),(5,'assets/home/assets/img/testimoni/Manasik-Safari-Tour.jpg','Proses Manasik','<p>Manasik Safari dilakukan secara Teori dan Praktek</p>','2020-08-05',5,0),(6,'assets/home/assets/img/testimoni/Proses-Bagasi.jpg','Proses Bagasi di Bandara','<p>Proses Bagasi yang rapi dan aman</p>','2020-09-21',6,0),(7,'assets/home/assets/img/testimoni/WhatsApp_Image_2019-04-02_at_17_47_22.jpeg','PETERNAKAN UNTA','<p><br></p>','2020-09-21',7,0);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_tampil`
--

DROP TABLE IF EXISTS `project_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_tampil` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tampil` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_tampil`
--

LOCK TABLES `project_tampil` WRITE;
/*!40000 ALTER TABLE `project_tampil` DISABLE KEYS */;
INSERT INTO `project_tampil` VALUES (1,'Testimoni','Umrah Haji Dambaan Umat','Umrah dan Haji dengan Aman dan Nyaman','','Tampil');
/*!40000 ALTER TABLE `project_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prosedur`
--

DROP TABLE IF EXISTS `prosedur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prosedur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `tagline` varchar(200) NOT NULL,
  `diskripsi` longtext NOT NULL,
  `foto` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prosedur`
--

LOCK TABLES `prosedur` WRITE;
/*!40000 ALTER TABLE `prosedur` DISABLE KEYS */;
INSERT INTO `prosedur` VALUES (1,'Syarat dan Ketentuan','“ Langkah Pasti Menuju Baitullah ”','<p style=\"color: rgb(77, 70, 67); font-family: \" open=\"\" sans\",=\"\" sans-serif;\"=\"\"><span style=\"font-size: 1rem;\"><span style=\"font-weight: bolder;\">Persyaratan Umrah :</span></span><br></p><ol style=\"color: rgb(77, 70, 67); font-family: \" open=\"\" sans\",=\"\" sans-serif;\"=\"\"><li>Mengisi formulir pendaftaran</li><li>Paspor yang masih berlaku 7 bulan saat keberangkatan (nama minimal 2 suku kata)&nbsp;</li><li>Vaksin meningitis dan atau sesuai ketentuan yang berlaku</li><li>Surat mahram bagi perempuan &lt;45 tahun, umrah sendiri tanpa suami/ saudara laki-laki/ bapak kandung</li><li>Foto berwarna background putih tampak wajah 80%&nbsp; 3x4 dan 4x6 masing-masing 6 lembar</li><li>Surat nikah asli bagi suami-istri &lt;45 tahun</li><li>Fotocopy akte lahir bagi anak &lt;17 tahun</li><li>Fotocopy akte lahir bagi perempuan &lt;45 tahun yang berangkat&nbsp;<span style=\"font-size: 1rem;\">bersama orang tua</span></li></ol><p style=\"color: rgb(77, 70, 67); font-family: \" open=\"\" sans\",=\"\" sans-serif;\"=\"\"><span style=\"font-weight: bolder;\">Biaya belum termasuk :</span></p><ol style=\"color: rgb(77, 70, 67); font-family: \" open=\"\" sans\",=\"\" sans-serif;\"=\"\"><li>Pengurusan paspor dan tambah nama.</li><li>Dokumen tambahan untuk perempuan &lt;45 tahun umroh sendiri tanpa suami/saudara laki-laki/bapak kandung atau jamaah yang tidak lengkap dokumennya.</li><li>Pengeluaran pribadi : laundry, telepon hotel, kelebihan bagasi, dsb.</li><li>Vaksin meningitis dan atau biaya kesehatan lainnya.</li><li>Pengurusan visa di luar Saudi Arabia dan asuransi (untuk paket Eropa)</li><li>Tambahan biaya yang berkaitan dengan pandemi Covid-19</li></ol><p style=\"color: rgb(77, 70, 67); font-family: \" open=\"\" sans\",=\"\" sans-serif;\"=\"\"><span style=\"font-weight: bolder;\">Pembatalan</span><br></p><ol><li style=\"color: rgb(77, 70, 67);\">Pembatalan 45 hari sebelum keberangkatan atau setelah issued ticket dibebankan biaya 75% dari harga paket</li><li style=\"color: rgb(77, 70, 67);\">Pembatalan 14 hari sebelum keberangkatan dibebankan biaya 100% dari harga paket</li></ol>','assets/home/assets/img/prosedur/IMG_20181124_0634471.jpg');
/*!40000 ALTER TABLE `prosedur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume`
--

DROP TABLE IF EXISTS `resume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(15) NOT NULL,
  `kerja` varchar(50) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `urut` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume`
--

LOCK TABLES `resume` WRITE;
/*!40000 ALTER TABLE `resume` DISABLE KEYS */;
INSERT INTO `resume` VALUES (4,'1999 -2005','Indonesiaku Oke','Internship','indah nya berbagi',4),(5,'1970 - 1980','SMPN','Direktur','Ini saatnya yang bagus',2),(6,'2015 - 2017','Angkasa Pura','Marketing','Makkkkkkkk',3);
/*!40000 ALTER TABLE `resume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume_tampil`
--

DROP TABLE IF EXISTS `resume_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume_tampil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume_tampil`
--

LOCK TABLES `resume_tampil` WRITE;
/*!40000 ALTER TABLE `resume_tampil` DISABLE KEYS */;
INSERT INTO `resume_tampil` VALUES (1,'Resume','Resume yang berbagi','Tampil','Ini plkayanan kami yang luar biasa');
/*!40000 ALTER TABLE `resume_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `prakode` varchar(100) NOT NULL,
  `kode` varchar(100) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `harga` varchar(25) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `diskripsi` text NOT NULL,
  `urut` int(2) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (16,'SHJ-01 | PAKET HAJI ARBAIN','SHJ-01','PAKET HAJI ARBAIN','assets/home/assets/img/produk/Haji_Arbain.jpg','4.500 USD','DZULHIJAH','Nikmati perjalanan ibadah rukun islam yang ke-5 dengan nyaman ',10,'Tampil'),(17,'SHJ-03 | PAKET BADAL HAJI','SHJ-03','PAKET BADAL HAJI','assets/home/assets/img/produk/Badal-Haji.jpg','Rp. 7.500.000','Bulan Dhulhijjah Setiap Tahun','<p>Haji Amanah, Untuk orang orang tercinta</p>',9,'Tampil'),(18,'SHJ-02 | PAKET HAJI FURODA/MUJAMALAH','SHJ-02','PAKET HAJI FURODA/MUJAMAL','assets/home/assets/img/produk/Brosur-Haji-Furoda1.jpg','14.500 USD','DZULHIJAH','<p>HAJI FURODA</p>',11,'Tampil'),(20,'SUM-01 | PAKET MILAD','SUM-01','PAKET MILAD','assets/home/assets/img/produk/Umrah-Milad-14th1.jpg','Rp 25.500.000,-','OKTOBER 2022','<p>PAKET 10 HARI UMRAH MILAD MAULID</p>',19,'Tampil'),(22,'SUM-02 | PAKET REGULER','SUM-02','PAKET REGULER','assets/home/assets/img/produk/Umrah-Berkah-Agustus1.jpg','Rp 27.600.000,-','AGUSTUS 2022','<p>PAKET 13 HARI UMRAH BERKAH</p>',21,'Tampil');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_tampil`
--

DROP TABLE IF EXISTS `service_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_tampil` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `jumlah` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_tampil`
--

LOCK TABLES `service_tampil` WRITE;
/*!40000 ALTER TABLE `service_tampil` DISABLE KEYS */;
INSERT INTO `service_tampil` VALUES (1,'Produk','Produk','MUDAH | NYAMAN | PASTI','Tidak',5);
/*!40000 ALTER TABLE `service_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `skill` varchar(25) NOT NULL,
  `prosen` int(3) NOT NULL,
  `urut` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES (1,'Pramuka',30,2),(2,'Demontrasi',25,1),(3,'Motivasi',80,3);
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill_tampil`
--

DROP TABLE IF EXISTS `skill_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_tampil` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill_tampil`
--

LOCK TABLES `skill_tampil` WRITE;
/*!40000 ALTER TABLE `skill_tampil` DISABLE KEYS */;
INSERT INTO `skill_tampil` VALUES (1,'Skill','Pengalaman yang luas','Kealhlian yang sangat luarbiasa','Tampil');
/*!40000 ALTER TABLE `skill_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `foto` varchar(200) NOT NULL,
  `heading` varchar(250) NOT NULL,
  `baris1` varchar(250) NOT NULL,
  `baris2` varchar(250) NOT NULL,
  `urut` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` VALUES (1,'assets/home/assets/img/slide/WhatsApp_Image_2018-03-13_at_12_36_24.jpeg','Ayo Maju Terus kawan','“Mengerjakan haji adalah kewajiban manusia terhadap Allah, yaitu (bagi) orang yang sanggup mengadakan perjalanan ke Baitullah, Barangsiapa mengingkari (kewajiban haji), maka sesungguhnya Allah Maha Kaya (tidak memerlukan sesuatu) dari semesta alam”','~ QS. Ali Imran: 97',3),(2,'assets/home/assets/img/slide/IMG-20181129-WA0047.jpg','Saya sedang mencoba','Rasulullah SAW bersabda :  “Naungan bagi seorang mukmin pada hari kiamat adalah shodaqohnya.”','~ HR. Ahmad',4),(3,'assets/home/assets/img/slide/IMG-20180423-WA0004.jpg','Ayo Maju Terus Kawan','“Umrah satu ke Umrah lainnya adalah penebus dosa antara keduanya, dan haji yang mabrur tidak ada pahala baginya selain surga.”','~ HR. Bukhari & Muslim',2);
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'safarium_safariumumroh'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07  5:47:33
