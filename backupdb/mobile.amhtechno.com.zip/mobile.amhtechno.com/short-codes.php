
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>

<html lang="en">
<head>
<title>Travel Hunt App A Mobile App Flat Bootstrap Responsive Website Template | Short Codes :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Travel Hunt App Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() {setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<meta charset utf="8">
<!--font-awsome-css-->
     <link rel="stylesheet" href="css/font-awesome.min.css"> 
<!--bootstrap-->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<!--custom css-->
	<link href="css/style.css" rel="stylesheet" type="text/css"/>
<!--component-css-->
   <script src="js/jquery-2.1.4.min.js"></script>
<!--script-->
	<script src="js/modernizr.custom.js"></script>
    <script src="js/bigSlide.js"></script>
           <script>
				$(document).ready(function() {
				$('.menu-link').bigSlide();
				});
     </script>
<!-- web-fonts -->  
  <link href='//fonts.googleapis.com/css?family=Abril+Fatface' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //web-fonts -->
</head>
<body>
<div class="body-back">
	<div class="masthead pdng-stn1">
		<div id="menu" class="panel" role="navigation">
			<div class="wrap-content">
				<div class="profile-menu text-center">
					<img class="border-effect" src="images/logo.png" alt=" ">
						<h3>MENU</h3>

						<div class="pro-menu">
							<div class="logo">
								<li><a class=" link link--yaku" href="index.php"><span>H</span><span>o</span><span>m</span><span>e</span></a></li>
								<li><a class=" link link--yaku" href="about.php"><span>A</span><span>b</span><span>o</span><span>u</span><span>t</span></a></li>
								<li><a class=" link link--yaku active" href="short-codes.php"><span>S</span><span>e</span><span>r</span><span>v</span><span>i</span><span>c</span><span>e</span><span>s</span></a></li>
								<li><a class=" link link--yaku" href="destination.php"><span>D</span><span>e</span><span>s</span><span>t</span><span>i</span><span>n</span><span>a</span><span>t</span><span>i</span><span>o</span><span>n</span><span>s</span></a></li>
								<li><a class=" link link--yaku" href="contact.php"><span>C</span><span>o</span><span>n</span><span>t</span><span>a</span><span>c</span><span>t</span></a></li>
							</div>
				

						</div>
				</div>
			</div>
		</div>
		<div class="phone-box wrap push" id="home">
			<div class="menu-notify">
				<div class="profile-left">
					<a href="#menu" class="menu-link"><i class="fa fa-list-ul"></i></a>
				</div>
				<div class="Profile-mid">
					<h5 class="pro-link"><a href="main.php">Travel Hunt</a></h5>
				</div>
				<div class="Profile-right">
					<a href="#small-dialog" class="sign-in popup-top-anim"> <i class="fa fa-user"></i></a> 
					<!-- modal -->
					<div id="small-dialog" class="mfp-hide">
						<div class="login-modal"> 	
							<div class="booking-info">
							   <h3><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
								
							</div>
							<div class="login-form">
								<form action="#" method="post">
									<p>Your Name </p>
									<input type="text" name="Name" required=""/>
									<p>Your Password</p>
									<input type="password" name="Password" required=""/>	 
									<div class="wthree-text"> 
										<ul> 
											<li>
												<input type="checkbox" id="brand" value="">
												<label for="brand"><span></span> Remember me ?</label>  
											</li>
											<li> <a href="#">Forgot password?</a> </li>
										</ul>
										<div class="clear"> </div>
									</div> 
									<input type="submit" value="Sign In">		
								</form>
								<p>Don’t have an account ?<a href="#small-dialog1" class="sign-in popup-top-anim"> Sign Up</a></p>
							</div> 
						</div>
					</div>
					<!-- //modal --> 
					<!-- modal-two -->
					<div id="small-dialog1" class="mfp-hide">
						<div class="login-modal">  
							<div class="booking-info">
							   <h3><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
								
							</div>
							<div class="login-form signup-form">
								<form action="#" method="post">
									<p>User Name </p>
									<input type="text" name="Name"  required=""/>
									<p>User Email </p>
									<input type="text" name="Email"  required=""/>
									<p>User Password</p>
									<input type="password" name="Password" placeholder="" required=""/>	
									<div class="wthree-text"> 
										<input type="checkbox" id="brand1" value="">
										<label for="brand1"><span></span>I accept the terms of use</label> 
									</div>
									<input type="submit" value="Sign Up">		
								</form> 
							</div> 
						</div>
					</div>
					<!-- //modal-two --> 
					
				</div>
				<div class="clearfix"></div>
			</div> 
<!-- banner -->
<div class="details-grid">
				<div class="details-shade">
						<div class="details-right">
							<img src="images/logo.png" alt=" ">
							<h3>Welcome To</h3>
							<h4>You’re going to like us.</h4>
								
							
						</div>
						<div class="banner_search">
								<form>
									<input type="search" name="search" value="Where to go ?" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Where to go ?';}" required="">
									<input type="submit" value=" ">
								</form>
						</div> 

				
				</div>
			</div>
		<div class="w3agile banner-bottom">
			     <ul>
				    <li><a href="flight.php" class="hvr-radial-out"><i class="fa fa-plane" aria-hidden="true"></i></a><h6>Flight</h6></li>
					<li><a href="train.php" class="hvr-radial-out"><i class="fa fa-train" aria-hidden="true"></i></a><h6>Train</h6></li>
					<li><a href="bus.php" class="hvr-radial-out"><i class="fa fa-bus" aria-hidden="true"></i></a><h6>Bus</h6></li>
					<li><a href="hotel.php" class="hvr-radial-out"><i class="fa fa-bed" aria-hidden="true"></i></a><h6>Hotels</h6></li>
				</ul>
			</div>
	<!-- //banner -->
	<!-- /short-codes --> 
         <div class="w3agile about"> 
					<h3 class="w3ls-title">Short Codes</h3> 
					<div class="grid_3 grid_5 ">
						<h3 class="hdg">Buttons</h3>
						<h1>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h1>
						<h2>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h2>
						<h3>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h3>
						<h4>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h4>
						<h5>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h5>
						<h6>
							<a href="#"><span class="label label-default">Default</span></a>
							<a href="#"><span class="label label-primary">Primary</span></a>
							<a href="#"><span class="label label-success">Success</span></a>
							<a href="#"><span class="label label-info">Info</span></a>
							<a href="#"><span class="label label-warning">Warning</span></a>
							<a href="#"><span class="label label-danger">Danger</span></a>
						</h6>
					</div>	
					<div class="grid_3 grid_4 ">
						<h3 class="hdg">Headings</h3>
						<div class="bs-example">
							<table class="table">
								<tbody>
									<tr>
										<td><h1 id="h1.-bootstrap-heading">h1. Bootstrap heading<a class="anchorjs-link" href="#h1.-bootstrap-heading"><span class="anchorjs-icon"></span></a></h1></td>
										<td class="type-info">Semibold 36px</td>
									</tr>
									<tr>
										<td><h2 id="h2.-bootstrap-heading">h2. Bootstrap heading<a class="anchorjs-link" href="#h2.-bootstrap-heading"><span class="anchorjs-icon"></span></a></h2></td>
										<td class="type-info">Semibold 30px</td>
									</tr>
									<tr>
										<td><h3 id="h3.-bootstrap-heading">h3. Bootstrap heading<a class="anchorjs-link" href="#h3.-bootstrap-heading"><span class="anchorjs-icon"></span></a></h3></td>
										<td class="type-info">Semibold 24px</td>
									</tr>
									<tr>
										<td><h4 id="h4.-bootstrap-heading">h4. Bootstrap heading<a class="anchorjs-link" href="#h4.-bootstrap-heading"><span class="anchorjs-icon"></span></a></h4></td>
										<td class="type-info">Semibold 18px</td>
									</tr>
									<tr>
										<td><h5 id="h5.-bootstrap-heading">h5. Bootstrap heading<a class="anchorjs-link" href="#h5.-bootstrap-heading"><span class="anchorjs-icon"></span></a></h5></td>
										<td class="type-info">Semibold 14px</td>
									</tr>
									<tr>
										<td><h6>h6. Bootstrap heading</h6></td>
										<td class="type-info">Semibold 12px</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<div class="grid_3 grid_5 ">
						<h3 class="hdg">Progress Bars</h3>
						<div class="tab-content">
							<div class="tab-pane active" id="domprogress">
								<div class="progress">    
									<div class="progress-bar progress-bar-primary" style="width: 20%"></div>
								</div>
								<p>Info with <code>progress-bar-info</code> class.</p>
								<div class="progress">    
									<div class="progress-bar progress-bar-info" style="width: 60%"></div>
								</div>
								<p>Success with <code>progress-bar-success</code> class.</p>
								<div class="progress">
									<div class="progress-bar progress-bar-success" style="width: 30%"></div>
								</div>
								<p>Warning with <code>progress-bar-warning</code> class.</p>
								<div class="progress">
									<div class="progress-bar progress-bar-warning" style="width: 70%"></div>
								</div>
								<p>Danger with <code>progress-bar-danger</code> class.</p>
								<div class="progress">
									<div class="progress-bar progress-bar-danger" style="width: 50%"></div>
								</div>
								<p>Inverse with <code>progress-bar-inverse</code> class.</p>
								<div class="progress">
									<div class="progress-bar progress-bar-inverse" style="width: 40%"></div>
								</div>
								<p>Inverse with <code>progress-bar-inverse</code> class.</p>
								<div class="progress">
									<div class="progress-bar progress-bar-success" style="width: 35%"><span class="sr-only">35% Complete (success)</span></div>
									<div class="progress-bar progress-bar-warning" style="width: 20%"><span class="sr-only">20% Complete (warning)</span></div>
									<div class="progress-bar progress-bar-danger" style="width: 10%"><span class="sr-only">10% Complete (danger)</span></div>
								</div>
							</div>
						</div>
					</div>
					<h3 class="hdg">Forms</h3>
					<div class="input-group ">
						<span class="input-group-addon" id="basic-addon1">@</span>
						<input type="text" class="form-control" placeholder="Username" aria-describedby="basic-addon1">
					</div>
					<div class="input-group ">
						<input type="text" class="form-control" placeholder="Recipient's username" aria-describedby="basic-addon2">
						<span class="input-group-addon" id="basic-addon2">@example.com</span>
					</div>
					<div class="input-group ">
						<span class="input-group-addon">$</span>
							<input type="text" class="form-control" aria-label="Amount (to the nearest dollar)">
						<span class="input-group-addon">.00</span>
					</div>
					<div class="input-group input-group-lg ">
						<span class="input-group-addon" id="sizing-addon1">@</span>
						<input type="text" class="form-control" placeholder="Username" aria-describedby="sizing-addon1">
					</div>
					<div class="input-group ">
						<span class="input-group-addon" id="sizing-addon2">@</span>
						<input type="text" class="form-control" placeholder="Username" aria-describedby="sizing-addon2">
					</div>
					<div class="input-group input-group-sm ">
						<span class="input-group-addon" id="sizing-addon3">@</span>
						<input type="text" class="form-control" placeholder="Username" aria-describedby="sizing-addon3">
					</div>
					<div class="row ">
						<div class="col-lg-6 in-gp-tl">
							<div class="input-group">
								<span class="input-group-addon">
									<input type="checkbox" aria-label="...">
								</span>
								<input type="text" class="form-control" aria-label="...">
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
						<div class="col-lg-6 in-gp-tb">
							<div class="input-group">
								<span class="input-group-addon">
									<input type="radio" aria-label="...">
								</span>
								<input type="text" class="form-control" aria-label="...">
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
					</div><!-- /.row -->
					<div class="row ">
						<div class="col-lg-6 in-gp-tl">
							<div class="input-group">
								<span class="input-group-btn">
									<button class="btn btn-default" type="button">Go!</button>
								</span>
								<input type="text" class="form-control" placeholder="Search for...">
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
						<div class="col-lg-6 in-gp-tb">
							<div class="input-group">
								<input type="text" class="form-control" placeholder="Search for...">
								<span class="input-group-btn">
									<button class="btn btn-default" type="button">Go!</button>
								</span>
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
					</div><!-- /.row -->
					<div class="row ">
						<div class="col-lg-6 in-gp-tl">
							<div class="input-group">
								<div class="input-group-btn">
									<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action <span class="caret"></span></button>
									<ul class="dropdown-menu">
										<li><a href="#">Action</a></li>
										<li><a href="#">Another action</a></li>
										<li><a href="#">Something else here</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#">Separated link</a></li>
									</ul>
								</div><!-- /btn-group -->
								<input type="text" class="form-control" aria-label="...">
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
						<div class="col-lg-6 in-gp-tb">
							<div class="input-group">
								<input type="text" class="form-control" aria-label="...">
								<div class="input-group-btn">
									<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action <span class="caret"></span></button>
									<ul class="dropdown-menu dropdown-menu-right">
										<li><a href="#">Action</a></li>
										<li><a href="#">Another action</a></li>
										<li><a href="#">Something else here</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#">Separated link</a></li>
									</ul>
								</div><!-- /btn-group -->
							</div><!-- /input-group -->
						</div><!-- /.col-lg-6 -->
					</div><!-- /.row --> 
				</div>
	<!-- //short-codes -->  
    <!--/footer-->
    <div class="w3agile footer">
			<div class="col-md-3 w3agile_footer_grid">
				<h3>About Us</h3>
				<p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
					voluptatibus.</p>
				<h3 class="logo"><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
			</div>
			<div class="col-md-2 w3agile_footer_grid">	
				<h3>Links</h3>
				<ul>
					<li><a href="main.php">Home</a></li>
					<li><a href="short-codes.php">Services</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Mail Us</a></li>
				</ul>
			</div>
			<div class="col-md-4 w3agile_footer_grid">
				<h3>Twitter Posts</h3>
				<ul class="w3agile_footer_grid_list">
					<li>Ut aut reiciendis voluptatibus maiores alias, ut aut reiciendis.
						<span><i class="fa fa-twitter" aria-hidden="true"></i> 02 days ago</span></li>
					<li>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
						voluptatibus.<span><i class="fa fa-twitter" aria-hidden="true"></i> 03 days ago</span></li>
				</ul>
			</div>
			<div class="col-md-3 w3agile_footer_grid">
				<h3>Newsletter</h3>
				<p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus.</p>
				<ul class="social">
					<form action="#" method="post">			 
					  <input type="text" name="Email" placeholder="Enter Email..." required="">

					 <input type="submit" value="Submit">
					 <div class="clearfix"></div>
				 </form>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="w3agile agileinfo_copy_right">
			<div class="agileinfo_copy_right_left">
				<p>© 2016 Travel Hunt. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
			</div>
			<div class="agileinfo_copy_right_right">
				<ul class="social">
					<li><a class="social-linkedin" href="#">
						<i></i>
						<div class="tooltip"><span>Facebook</span></div>
						</a></li>
					<li><a class="social-twitter" href="#">
						<i></i>
						<div class="tooltip"><span>Twitter</span></div>
						</a></li>
					<li><a class="social-google" href="#">
						<i></i>
						<div class="tooltip"><span>Google+</span></div>
						</a></li>
					<li><a class="social-facebook" href="#">
						<i></i>
						<div class="tooltip"><span>Pinterest</span></div>
						</a></li>
					<li><a class="social-instagram" href="#">
						<i></i>
						<div class="tooltip"><span>Instagram</span></div>
						</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
	</div>
	<!--/footer-->
	</div>
</div>

	<!-- pop-up-box -->
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	    <script>
			$(document).ready(function() {
				$('.popup-top-anim').magnificPopup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
				});																							
			}); 
		</script>
<!--//pop-up-box -->
 <script src="js/bootstrap.min.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>