
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>

<html lang="en">
<head>
<title>Travel Hunt App A Mobile App Flat Bootstrap Responsive Website Template | Hotel-Single :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Travel Hunt App Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android  Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() {setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<meta charset utf="8">
<!--font-awsome-css-->
     <link rel="stylesheet" href="css/font-awesome.min.css"> 
<!--bootstrap-->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<!--custom css-->
	<link href="css/style.css" rel="stylesheet" type="text/css"/>
<!--component-css-->
   <script src="js/jquery-2.1.4.min.js"></script>
<!--script-->
	<script src="js/modernizr.custom.js"></script>
    <script src="js/bigSlide.js"></script>
           <script>
				$(document).ready(function() {
				$('.menu-link').bigSlide();
				});
     </script>
<!-- web-fonts -->  
  <link href='//fonts.googleapis.com/css?family=Abril+Fatface' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //web-fonts -->
<script src="js/jquery.seat-charts.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.seat-charts.css">

    </head>
	 <div class="modal fade" id="myModalbook" role="dialog">
			<div class="modal-dialog">
			<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-header">
					      
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
					<h3 class="w3ls-title book">HOTEL CHECKOUT FORM</h3>
					<div class="main-booking">
						 <div class="hotel-right  vlcone">
									<div class="hotel-form">
										<h3>Receipt Form</h3>
										<ul class="list_ins1">
													<li>Room No.</li>
													<li>Room Charges</li>
													<li>Services Charges</li>
													<li>Vat</li>
													<li>Total</li>
										</ul>
										<ul class="list_ins2">
													<li>: 201</li>
													<li>: $500.00</li>
													<li>: $10.00</li>
													<li>: $0.00</li>
													<li>: $510.00</li>
										</ul>
										<div class="clearfix"></div>
									</div>
									<div class="pay-form">
									<form action="#" method="post">
											<h3>Payment Information</h3>
											<h5>Name On Credit Card</h5>
											<input type="text" value="James Thompson" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'James Thompson';}" required="">

											<h5>Credit Card Number</h5>
											<input class="card_logo" type="text" value="2525 2525 2525 2525" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '2525 2525 2525 2525';}" required="">

											<h5>Expires On</h5>
											<select id="country3" onchange="change_country(this.value)" class="frm-field required">
												<option value="null">January</option>
												<option value="null">February</option>         
												<option value="AX">March</option>
												<option value="AX">April</option>
												<option value="AX">May</option>
												<option value="AX">June</option>
												<option value="AX">July</option>
												<option value="AX">August</option>
												<option value="AX">September</option>
												<option value="AX">October</option>
												<option value="AX">November</option>
												<option value="AX">December</option>
											</select>
											<ul>
												<li>
													<input type="number" name="number" class="text_box" value="1988" min="1">	
												</li>
											</ul>
											<div class="clearfix"></div>
											<h5>CVC</h5>
											<input type="text"  value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '';}" required="">

											<input type="submit" value="BOOK SECURELY">
										</form>
										<p><span></span>Your credit card information is encrypted.</p>
									</div>
								</div>
					</div>
				</div>
			</div>
		</div>
	   </div>

<body>
<div class="body-back">
	<div class="masthead pdng-stn1">
		<div id="menu" class="panel" role="navigation">
			<div class="wrap-content">
				<div class="profile-menu text-center">
					<img class="border-effect" src="images/logo.png" alt=" ">
						<h3>MENU</h3>

						<div class="pro-menu">
							<div class="logo">
								<li><a class=" link link--yaku  active" href="main.php"><span>H</span><span>o</span><span>m</span><span>e</span></a></li>
								<li><a class=" link link--yaku" href="about.php"><span>A</span><span>b</span><span>o</span><span>u</span><span>t</span></a></li>
								<li><a class=" link link--yaku" href="short-codes.php"><span>S</span><span>e</span><span>r</span><span>v</span><span>i</span><span>c</span><span>e</span><span>s</span></a></li>
								<li><a class=" link link--yaku" href="destination.php"><span>D</span><span>e</span><span>s</span><span>t</span><span>i</span><span>n</span><span>a</span><span>t</span><span>i</span><span>o</span><span>n</span><span>s</span></a></li>
								<li><a class=" link link--yaku" href="contact.php"><span>C</span><span>o</span><span>n</span><span>t</span><span>a</span><span>c</span><span>t</span></a></li>
							</div>
				

						</div>
				</div>
			</div>
		</div>
		<div class="phone-box wrap push" id="home">
			<div class="menu-notify">
				<div class="profile-left">
					<a href="#menu" class="menu-link"><i class="fa fa-list-ul"></i></a>
				</div>
				<div class="Profile-mid">
					<h5 class="pro-link"><a href="main.php">Travel Hunt</a></h5>
				</div>
				<div class="Profile-right">
					<a href="#small-dialog" class="sign-in popup-top-anim"> <i class="fa fa-user"></i></a> 
					<!-- modal -->
					<div id="small-dialog" class="mfp-hide">
						<div class="login-modal"> 	
							<div class="booking-info">
							   <h3><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
								
							</div>
							<div class="login-form">
								<form action="#" method="post">
									<p>User Name </p>
									<input type="text" name="Name" required=""/>
									<p>User Password</p>
									<input type="password" name="Password" required=""/>	 
									<div class="wthree-text"> 
										<ul> 
											<li>
												<input type="checkbox" id="brand" value="">
												<label for="brand"><span></span> Remember me ?</label>  
											</li>
											<li> <a href="#">Forgot password?</a> </li>
										</ul>
										<div class="clear"> </div>
									</div> 
									<input type="submit" value="Sign In">		
								</form>
								<p>Don’t have an account ?<a href="#small-dialog1" class="sign-in popup-top-anim"> Sign Up</a></p>
							</div> 
						</div>
					</div>
					<!-- //modal --> 
					<!-- modal-two -->
					<div id="small-dialog1" class="mfp-hide">
						<div class="login-modal">  
							<div class="booking-info">
							   <h3><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
								
							</div>
							<div class="login-form signup-form">
								<form action="#" method="post">
									<p>User Name </p>
									<input type="text" name="Name"  required=""/>
									<p>User Email </p>
									<input type="text" name="Email"  required=""/>
									<p>User Password</p>
									<input type="password" name="Password" placeholder="" required=""/>	
									<div class="wthree-text"> 
										<input type="checkbox" id="brand1" value="">
										<label for="brand1"><span></span>I accept the terms of use</label> 
									</div>
									<input type="submit" value="Sign Up">		
								</form> 
							</div> 
						</div>
					</div>
					<!-- //modal-two --> 
					
				</div>
				<div class="clearfix"></div>
			</div> 
<!-- banner -->
  <div class="details-grid ht">
				<div class="details-shade ">
						<div class="details-right">
							<img src="images/logo.png" alt=" ">
							<h3>Book A Room</h3>
							<h4>You’re going to like us.</h4>
								
							
						</div>
						<div class="banner_search">
								<form action="#" method="post">
									<input type="search" name="search" value="Where to go ?" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Where to go ?';}" required="">
									<input type="submit" value=" ">
								</form>
						</div> 

				
				</div>
			</div>
		<div class="w3agile banner-bottom">
			   <ul>
				    <li><a href="flight.php" class="hvr-radial-out"><i class="fa fa-plane" aria-hidden="true"></i></a><h6>Flight</h6></li>
					<li><a href="train.php" class="hvr-radial-out"><i class="fa fa-train" aria-hidden="true"></i></a><h6>Train</h6></li>
					<li><a href="bus.php" class="hvr-radial-out"><i class="fa fa-bus" aria-hidden="true"></i></a><h6>Bus</h6></li>
					<li class="active"><a href="hotel.php" class="hvr-radial-out"><i class="fa fa-bed" aria-hidden="true"></i></a><h6>Hotels</h6></li>
				</ul>
			</div>
	<!-- //banner -->
	<!--hotel-single --> 
          <div class="w3agile single-hotel">
		  <!--/rooms-->
		  	<!--/room1-->
		     <div class="hotel-rooms">
					<div class="hotel-left">
						<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-bed" aria-hidden="true"></span>Grand Park Hyatt <img src="images/star1.png" alt=""></a>
						<p>Jl. Pahlawan VII No.247-D Sidoarjo-Surabaya-Indonesia</p>
						<div class="hotel-left-grids">
							<div class="hotel-left-one">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><img src="images/h1.jpg" alt=""></a>
								<span class="sale-box">
								  <span class="sale-label">Rooms</span>
								</span>
							</div>
							<div class="hotel-left-two">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Diamond Street</a>
								<p>2.5 km to Sed ut perspiciatis <span> 2.6 km to sit voluptatem</span></p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="hotel-right text-right">
						<h4><span>$8,750</span> $4,850</h4>
						<p>Best price</p>
						  <a href="#" data-toggle="modal" data-target="#myModalbook" class="seat-button hotel">Continue</a>
					</div>
					<div class="clearfix"></div>
				</div>
				<!--//room1-->
				<!--/room2-->
		     <div class="hotel-rooms">
					<div class="hotel-left">
						<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-bed" aria-hidden="true"></span>Royal Park Hyatt <img src="images/star1.png" alt=""></a>
						<p>Jl. Pahlawan VII No.247-D Sidoarjo-Surabaya-Indonesia</p>
						<div class="hotel-left-grids">
							<div class="hotel-left-one">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><img src="images/h2.jpg" alt=""></a>
								<span class="sale-box">
								  <span class="sale-label">Rooms</span>
								</span>
							</div>
							<div class="hotel-left-two">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Diamond Street</a>
								<p>2.5 km to Sed ut perspiciatis <span> 2.6 km to sit voluptatem</span></p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="hotel-right text-right">
						<h4><span>$8,750</span> $4,850</h4>
						<p>Best price</p>
						<a href="#" data-toggle="modal" data-target="#myModalbook" class="seat-button hotel">Continue</a>
					</div>
					<div class="clearfix"></div>
				</div>
				<!--//room2-->
			    <!--/room3-->
		         <div class="hotel-rooms">
					<div class="hotel-left">
						<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-bed" aria-hidden="true"></span>Crowne Plaza<img src="images/star2.png" alt=""></a>
						<p>Jl. Pahlawan VII No.247-D Sidoarjo-Surabaya-Indonesia</p>
						<div class="hotel-left-grids">
							<div class="hotel-left-one">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><img src="images/h3.jpg" alt=""></a>
								<span class="sale-box">
								  <span class="sale-label">Rooms</span>
								</span>
							</div>
							<div class="hotel-left-two">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Diamond Street</a>
								<p>2.5 km to Sed ut perspiciatis <span> 2.6 km to sit voluptatem</span></p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="hotel-right text-right">
						<h4><span>$8,750</span> $4,850</h4>
						<p>Best price</p>
						<a href="#" data-toggle="modal" data-target="#myModalbook" class="seat-button hotel">Continue</a>
					</div>
					<div class="clearfix"></div>
				</div>
				<!--//room3-->
				  <!--/room4-->
		         <div class="hotel-rooms">
					<div class="hotel-left">
						<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-bed" aria-hidden="true"></span>Modern Hilton Park<img src="images/star2.png" alt=""></a>
						<p>Jl. Pahlawan VII No.247-D Sidoarjo-Surabaya-Indonesia</p>
						<div class="hotel-left-grids">
							<div class="hotel-left-one">
								<a href="#" data-toggle="modal" data-target="#myModalbook"><img src="images/h4.jpg" alt=""></a>
								<span class="sale-box">
								  <span class="sale-label">Rooms</span>
								</span>
							</div>
							<div class="hotel-left-two">
								
								<a href="#" data-toggle="modal" data-target="#myModalbook"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Diamond Street</a>
								<p>2.5 km to Sed ut perspiciatis <span> 2.6 km to sit voluptatem</span></p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="hotel-right text-right">
						<h4><span>$8,750</span> $4,850</h4>
						<p>Best price</p>
						<a href="#" data-toggle="modal" data-target="#myModalbook" class="seat-button hotel">Continue</a>
					</div>
					<div class="clearfix"></div>
				</div>
				<!--//room4-->
		  <!--//rooms-->
			
          </div>
	<!-- /hotel-single-->
    <!--/footer-->
    <div class="w3agile footer">
			<div class="col-md-3 w3agile_footer_grid">
				<h3>About Us</h3>
				<p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
					voluptatibus.</p>
				<h3 class="logo"><a href="main.php">T<span>r</span>a<span>v</span>e<span>l</span> <span>H</span>u<span>n</span>t</a></h3>
			</div>
			<div class="col-md-2 w3agile_footer_grid">	
				<h3>Links</h3>
				<ul>
					<li><a href="main.php">Home</a></li>
					<li><a href="short-codes.php">Services</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contact.php">Mail Us</a></li>
				</ul>
			</div>
			<div class="col-md-4 w3agile_footer_grid">
				<h3>Twitter Posts</h3>
				  <ul class="w3agile_footer_grid_list">
					  <li>Ut aut reiciendis voluptatibus maiores alias, ut aut reiciendis.
						<span><i class="fa fa-twitter" aria-hidden="true"></i> 02 days ago</span></li>
					  <li>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis 
						voluptatibus.<span><i class="fa fa-twitter" aria-hidden="true"></i> 03 days ago</span></li>
				  </ul>
			</div>
			<div class="col-md-3 w3agile_footer_grid">
				<h3>Newsletter</h3>
				<p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus.</p>
				<ul class="social">
					<form action="#" method="post">			 
					  <input type="text" name="Email" placeholder="Enter Email..." required="">

					 <input type="submit" value="Submit">
					 <div class="clearfix"></div>
				 </form>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="w3agile agileinfo_copy_right">
			<div class="agileinfo_copy_right_left">
				<p>© 2016 Travel Hunt. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
			</div>
			<div class="agileinfo_copy_right_right">
				<ul class="social">
					<li><a class="social-linkedin" href="#">
						<i></i>
						<div class="tooltip"><span>Facebook</span></div>
						</a></li>
					<li><a class="social-twitter" href="#">
						<i></i>
						<div class="tooltip"><span>Twitter</span></div>
						</a></li>
					<li><a class="social-google" href="#">
						<i></i>
						<div class="tooltip"><span>Google+</span></div>
						</a></li>
					<li><a class="social-facebook" href="#">
						<i></i>
						<div class="tooltip"><span>Pinterest</span></div>
						</a></li>
					<li><a class="social-instagram" href="#">
						<i></i>
						<div class="tooltip"><span>Instagram</span></div>
						</a></li>
				</ul>
			</div>
			<div class="clearfix"> </div>
	</div>
	<!--/footer-->
	</div>
</div>

	<!-- pop-up-box -->
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	    <script>
			$(document).ready(function() {
				$('.popup-top-anim').magnificPopup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
				});																							
			}); 
		</script>
<!--//pop-up-box -->
 <script src="js/bootstrap.min.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>