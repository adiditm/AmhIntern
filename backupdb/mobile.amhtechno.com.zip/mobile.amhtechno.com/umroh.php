<? include_once('header.php')?>
<!-- banner -->
   
		
	<!-- //banner -->
	<!-- about --> 
            
	<!-- //about --> 
	<!-- //who we are -->

<!-- experts -->
<div class="w3agile experts">
<h3 class="w3ls-title">15 Oktober 2019</h3>
  <div class="team-inner">
 <img src="https://www.aminahtour.co.id/images/52DE9704BD-BCFD-49FB-8BF5-9BC4AC1AF69F.jpeg"> 
 <label>
Hotel Kamar 4 Orang : <b>Rp. 24,250,000</b>
Hotel Kamar 3 Orang : <b>Rp. 0</b>
Hotel Kamar 2 Orang : <b>Rp. 0</b>
Hotel Kamar Sendiri : <b>0</b>
Lama : <b>13 Hari</b>
Pesawat : <b>Saudi Airline</b>
Hotel Madinah :<b> Luluk Mubarok</b>
Hotel Makkah : <b>Karam Al Dhiafa</b>
Kapasitas :<b> 45</b>
Terpenuhi :<b> 0</b>
Pembimbing :<b> Amir Fatah</b>
</label>
<br> <br><br><br><br><br><br><br><br>
	</div>
</div>
<!-- //experts -->
    <!--/footer-->
   
	<? include_once('footer.php');?>