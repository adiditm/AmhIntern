<? include_once('header.php');?>
<!-- banner -->
   <div class="details-grid">
				<div class="details-shade">
						<div class="details-right">
							<img src="images/logoaminah.png" alt=" ">
							<h3>Selamat datang di</h3>
							<h3 style="color:#0f0;font-size:36px">Aminah Tour</h3>
								
                                
							
						</div>
						<div class="banner_search hide">
								<form action="#" method="post">
									<input type="search" name="search" value="Where to go ?" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Where to go ?';}" required="">
									<input type="submit" value=" ">
								</form>
						</div> 

				
				</div>
			</div>
		<div class="w3agile banner-bottom">
				<ul>
				    <li><a href="#" class="hvr-radial-out" data-toggle="modal" data-target="#theModal" onClick=" showLayan();"><i class="fa fa-cogs" aria-hidden="true"></i></a><h6 style="font-size:10px">Pelayanan</h6></li>
					<li><a href="#" class="hvr-radial-out" data-toggle="modal" data-target="#theModal" onClick="showTL()"><i class="fa fa-male" aria-hidden="true"></i></a><h6 style="font-size:10px">Tour Leader</h6></li>
					<li><a href="#" class="hvr-radial-out" data-toggle="modal" data-target="#theModal" onClick="showFeat()"><i class="fa fa-building" aria-hidden="true"></i></a><h6 style="font-size:10px">Fasilitas</h6></li>
					<li><a href="#" class="hvr-radial-out" data-toggle="modal" data-target="#theModal" onClick="showLengkap()"><i class="fa fa-thumbs-up" aria-hidden="true"></i></a><h6 style="font-size:10px">Perlengkapan</h6></li>
				</ul>
			</div>
   <!-- //banner -->
   <!--/welcome-->
		        <div class="w3agile welcome"> 
					<h3 class="w3ls-title">ALASAN UTAMA
KENAPA MEMILIH KAMI ?</h3> 
					<div class="b-bottom">
			<div class="col-md-6 banner_bottom_left">
				<h3>KAMI PELAYAN TAMU ALLOH</h3>
				
				
			</div>
			
			<div class="clearfix"> </div>
		</div>	
				</div>
		<!--//welcome-->
		<!--/footer-->
    
<? include_once('footer.php');?>