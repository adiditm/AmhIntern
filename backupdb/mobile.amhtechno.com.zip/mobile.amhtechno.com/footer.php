		<div class="w3agile agileinfo_copy_right">
			<div class="agileinfo_copy_right_left">
				<p>© 2014 - 2019 <a href="http://www.aminahtour.co.id" target="_blank">www.aminahtour.co.id</a> </p>
			</div>
			<div class="agileinfo_copy_right_right">
				
			</div>
			<div class="clearfix"> </div>
	</div>
	<!--/footer-->
	
</div>
</div>
	<!-- pop-up-box -->
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	    <script>
			$(document).ready(function() {
				$('.popup-top-anim').magnificPopup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
				});																							
			}); 
		</script>
<!--//pop-up-box -->

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>