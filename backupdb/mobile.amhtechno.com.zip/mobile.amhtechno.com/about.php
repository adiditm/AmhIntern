<? include_once('header.php')?>
<!-- banner -->
   
		
	<!-- //banner -->
	<!-- about --> 
            
	<!-- //about --> 
	<!-- //who we are -->

<!-- experts -->
<div class="w3agile experts">
<h3 class="w3ls-title">Tentang Kami</h3>
  <div class="team-inner">
  
  <div class="row"><div class="col-lg-12 " style="text-align:justify">Aminah Tour adalah Divisi Umroh dari PT. Aminah yang bergerak sebagai sebuah Perusahaan Penyelenggara Perjalanan Ziarah Muslim Internasional yang menjembatani anda mudah menuju ke Baitulloh dan telah memiliki izin resmi berupa :</div></div>

<br><br>

<label>SURAT KETERANGAN :</label>

<div class="row"><div class="col-lg-2">&#9679; TDP   </div><div class="col-lg-4">  No. 503/10380.D/436.6.11/2013</div></div>
<div class="row"><div class="col-lg-2">&#9679; DISPARTA </div><div class="col-lg-4">  No. 503.08/083/436.6.14/2014</div></div>
<div class="row"><div class="col-lg-2">&#9679; IZIN UMROH </div><div class="col-lg-4">PPIU. No. 819 tahun 2016</div></div>
<br><br>
<div class="row"><div class="col-lg-12" style="text-align:justify">Kami menyadari bahwa dalam memenuhi kebutuhannya antara jamaah satu dengan yang lainnya berbeda. Namun kami juga yakin yang diidamkan dalam sebuah perjalanan adalah rasa nyaman (Comfort). &nbsp;Ukuran rasa nyaman yang dirasakan seseorang amatlah subjektive dan relative dan tidak dapat diseragamkan atau digantikan dan diukur dengan materi,untuk itu kami dengan sumberdaya manusia berpengalaman serta dukungan jaringan akomodasi dan transportasi yang telah terjalin cukup lama, baik di Saudi Arabia maupun kota-kota lain akan memfasilitasi kebutuhan akan rasa nyaman para jamaah, sehingga Kekhusyuan dalam melakukan Ibadah Umroh dan Haji serta perjalanan Ziarah Muslim dapat utuh dirasakan.</div></div>

<br><br>

<label>MOTTO</label><br><br>
<div class="row"><div class="col-lg-2">&#9679; Aman</div></div>
<div class="row"><div class="col-lg-2">&#9679; Nyaman</div></div>
<div class="row"><div class="col-lg-2">&#9679; Amanah</div></div>
<br><br>
<label>VISI MISI</label>
<div class="row"><div class="col-lg-2">&#9679; Beribadah</div></div>
<div class="row"><div class="col-lg-2">&#9679; Berniaga</div></div>
<div class="row"><div class="col-lg-2">&#9679; Melayani dengan baik</div></div>
<br><br>
<label>Produk</label>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh 9 Hari</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh Reguler 12 hari</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh Reguler 15 hari</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh VIP</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh Bulan Ramadhan</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Umroh Plus</div></div>
<div class="row"><div class="col-lg-2">&#9679; Paket Haji Khusus</div></div>

	</div>
</div>
<!-- //experts -->
    <!--/footer-->
    
	<? include_once('footer.php');?>