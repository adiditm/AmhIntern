-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: aminahto_aminaht
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `singkat` varchar(255) NOT NULL,
  `uraian` text NOT NULL,
  `visimisi` text NOT NULL,
  `foto` varchar(150) NOT NULL,
  `fotodetail` varchar(150) NOT NULL,
  `fb` varchar(200) NOT NULL,
  `tw` varchar(200) NOT NULL,
  `ig` varchar(200) NOT NULL,
  `youtube` varchar(200) NOT NULL,
  `fotomap` varchar(200) NOT NULL,
  `googlemap` mediumtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `wa` varchar(20) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `alamat` tinytext NOT NULL,
  `kota` varchar(25) NOT NULL,
  `motto` mediumtext NOT NULL,
  `resume` text NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` (`id`, `judul`, `singkat`, `uraian`, `visimisi`, `foto`, `fotodetail`, `fb`, `tw`, `ig`, `youtube`, `fotomap`, `googlemap`, `email`, `hp`, `wa`, `telp`, `alamat`, `kota`, `motto`, `resume`, `tampil`) VALUES (1,'Tentang Kami','<p>PT. AMINAH \r\nBERGERAK DIBIDANG JASA, TOUR INTERNASIONAL, DOMISTIK, UMROH. DAPAT DIPERCAYA DAN AMANAH.\r\nIzin Kemenag No. 927 Tahun 2019</p><p>VISI</p><p>Ber-Ibadah, Ber-Niaga, Melayani dengan Hati yang Tulus.</p><p>MISI</p><p>Bergerak dan menggerakkan</','<p>PT. AMINAH \r\nBERGERAK DIBIDANG JASA, TOUR INTERNASIONAL, DOMISTIK, UMROH, DAPAT DIPERCAYA DAN AMANAH.\r\nIzin Kemenag No. 927 Tahun 2019</p><p>VISI</p><p>Ber-Ibadah, Ber-Niaga, Melayani dengan Hati yang Tulus.</p><p>MISI</p><p>Hidup dan Menghidupi</p><p>Bergerak dan Menggerakkan</p><p>Berjuang dan Memperjuangkan</p><p><br></p><p><br></p><p><br></p>','<p>visi & misi</p><p>VISI</p><p>Ber-Ibadah, Ber-Niaga, Melayani dengan Hati yang Tulus.</p><p>MISI</p><p>Hidup dan Menghidupi</p><p>Bergerak dan Menggerakkan</p><p>Berjuang dan Memperjuangkan</p><p><br></p>','assets/images/about/aminahtourkantor.jpeg','assets/images/about/aminahtourkantor.jpeg','https://facebook.com/username','http://twitter.com/username','https://www.instagram.com/aminah_tour','https://youtube.com/channel/aminahtour','assets/images/about/kantor_aminah.jpeg','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.145775171068!2d112.79943651402381!3d-7.3375211947048005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7faae58751c03%3A0x12c124a28c02bc3c!2sJl.%20Raya%20Wiguna%20Timur%20No.48%2C%20Gn.%20Anyar%20Tambak%2C%20Kec.%20Gn.%20Anyar%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060294!5e0!3m2!1sid!2sid!4v1589299438199!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','aminah_a54@yahoo.com','087739872922','6287739872922','(031)87854771','Jl. Raya Wiguna Timur 48A','Surabaya','Jadilah Manusia Yang Mempunyai Manfaat Untuk Orang Lain.','Saya Alumni Universitas Airlangga Surabaya pada tahun 1991, telah berkecimpung dalam banyak hal yang berhubungan dengan masalah perdata dan pidana','Tampil');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `lupapassword` varchar(200) NOT NULL,
  `singkat` varchar(150) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `hp` varchar(16) NOT NULL,
  `gmap` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`, `lupapassword`, `singkat`, `alamat`, `kota`, `email`, `hp`, `gmap`, `foto`, `level`, `created`) VALUES (1,'admin','$2y$10$ARmjW8M.68e8./SRDZtee.bg5pIQfI8YmIm74recisxWeb4imG48y','akulupakamu','PT. AMINAH \r\nBERGERAK DIBIDANG JASA, TOUR INTERNASIONAL, DOMISTIK, UMROH  HAJI KHUSUS. DAPAT DIPERCAYA DAN AMANAH.\r\nIzin Kemenag No. 927 Tahun 2019','Jl. Raya Wiguna Timur 48A','Surabaya','aminah_a54@yahoo.com','082131973557','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.145775171068!2d112.79943651402381!3d-7.3375211947048005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7faae58751c03%3A0x12c124a28c02bc3c!2sJl.%20Raya%20Wiguna%20Timur%20No.48%2C%20Gn.%20Anyar%20Tambak%2C%20Kec.%20Gn.%20Anyar%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060294!5e0!3m2!1sid!2sid!4v1589299438199!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>>>>>','assets/images/about/kantor_aminah.jpeg',1,'2020-04-01 00:00:00'),(2,'admin170845','$2y$10$9so3eqgUaK2rX0kOHyGx3eO47nZWhjCXCjDZsxVMzGlpQ6AOQIqs2','akulupakamu','PT. AMINAH \r\nBERGERAK DIBIDANG JASA, TOUR INTERNASIONAL, DOMISTIK, UMROH  HAJI KHUSUS. DAPAT DIPERCAYA DAN AMANAH.\r\nIzin Kemenag No. 927 Tahun 2019','Jl. Raya Wiguna Timur 48A','Surabaya','aminah_a54@yahoo.com','082131973557','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.145775171068!2d112.79943651402381!3d-7.3375211947048005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7faae58751c03%3A0x12c124a28c02bc3c!2sJl.%20Raya%20Wiguna%20Timur%20No.48%2C%20Gn.%20Anyar%20Tambak%2C%20Kec.%20Gn.%20Anyar%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060294!5e0!3m2!1sid!2sid!4v1589299438199!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>>>>>','assets/images/about/kantor_aminah.jpeg',1,'2020-04-01 00:00:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artikel`
--

DROP TABLE IF EXISTS `artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `diskripsi` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `kategori` varchar(25) NOT NULL,
  `urut` int(5) NOT NULL,
  `baca` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikel`
--

LOCK TABLES `artikel` WRITE;
/*!40000 ALTER TABLE `artikel` DISABLE KEYS */;
INSERT INTO `artikel` (`id`, `aman`, `judul`, `diskripsi`, `foto`, `tanggal`, `kategori`, `urut`, `baca`) VALUES (9,'','Imbas CoronaArab Saudi Tutup Mekkah dan Madinah','<p>Pemerintah Arab Saudi mengumumkan bahwa Masjidil Haram Makkah akan ditutup sementara dan dibuka kembali satu jam sebelum salat Jumat saat pihak berwenang Arab Saudi membersihkan situs suci umat Islam.</p>\r\n\r\n<p>Area sekitar Ka’bah itu dikosongkan untuk dibersihkan dan disterilisasi sebagai bagian pencegahan virus corona. Selain itu, upaya pembersihan juga untuk memastikan keselamatan para jemaah.</p>\r\n\r\n<p>“Penutupan sementara akan dimulai satu jam setelah salat pada Kamis malam berakhir dan akan berlangsung hingga satu jam sebelum salat subuh pada hari Jumat,” menurut pernyataan dari Presidensi Umum untuk urusan Masjidil Haram dan Masjid Nabawi seperti disitir dari Al Arabiya, Jumat (6/3/2020).</p>\r\n\r\n<p>Secara khusus, halaman di sekitar Ka’bah, yang dikenal sebagai mataf, dan jalur antara al-Safa dan al-Marwah akan ditutup selama durasi penutupan sementara. Pihak berwenang mengatakan salat hanya akan diizinkan dari dalam masjid.</p>\r\n\r\n<p>Di media sosial, beredar gambar dan video yang menunjukkan daerah terdekat di sekitar situs tersuci umat Islam, Ka’bah, dikosongkan ketika otoritas kesehatan membersihkan daerah tersebut.</p>','assets/images/fotoartikel/berita2.jpg','2020-04-19','KTG004',7,1831),(10,'','Arab Saudi Buka Mekkah dan Madinah','<p>Dalam Upaya penanggulangan covid 19 di Saudi Arabia&nbsp;<span style=\"font-size: 1rem;\">melanjutkan aturan-aturan sebelumnya yakni menghentikan penerbangan internasional, menangguhkan umrah sepanjang tahun, menutup sebagian besar tempat umum, dan sangat membatasi pergerakan warga. Dilansir dari Aljazeera, pada Selasa (31/3/2020) Menteri Haji dan Umrah Mohammed Saleh Benten, meminta umat Islam untuk menunggu.</span></p><p><span style=\"font-size: 1rem;\">Alhamdulillah, umrah telah diperbolehkan lagi, dengan ketentuan2 yang telah ditetapkan Pemerintah Saudi Arabia.</span></p><p><span style=\"font-size: 1rem;\"> pengumuman&nbsp; ini,&nbsp; tentang ibadah haji dan umrah diumumkan pada 1 Muharam 1443 H yang bertepatan dengan tanggal 10 Agustus 2021.&nbsp; </span></p><p><br></p><p>\r\n&nbsp;</p>','assets/images/fotoartikel/berita1.jpg','2020-05-01','KTG004',8,2743),(12,'','Saudi Telah Membuka Masjid Masjidil Haram dan Nabawi Untuk Indonesia','<p>Pemerintah kerajaan Arab Saudi telah&nbsp; membuka Masjid Masjidil Haram dan Masjid Nabawi untuk&nbsp; Indonesia Mulai 1 Muharram 1443 H bertepatan tanggal 10 Agustus 2021, dengan ketentuan yang telah ditetapkan Pemerintah Saudi Arabia Sehubungan Prokes Covid 19.</p><p>Pemerintah Indonesia dalam hal ini, sedang menyesuaikan ketentuan2 yang disyaratkan Pemerintah Saudi Arabia. Dengan tujuan jamaah Indonesia dapat beribadah dengan aman &amp; nyaman. Diantara ketentuan- ketentuan tersebut adalah :</p><p>1. Jamaah wajib sudah vaksin 2x + booster (sinovac, sinoporhn), selain tersebut cukup 2x (astrasineca, moderna, johson &amp; johson dan pisher)</p><p>2. Telah terkoneksi dengan Apkikasi TAWAKALNA ( Indonesia membangun PEDULILINDUNGI yg terkoneksi dengan TAWAKALNA)</p><p>3. Batasan umur mulai 18 tahun keatas yang telah vaksin lengkap dengan batasan minimal setelah 14 hari vaksin terakhir.</p><p>4. Dilakukan test PCR oleh Pemerintah Indonesia.</p><p>5. Dilakukan Karantina keberangkatan dan kepulangan.</p><p>6. Jamaah mematuhi Prokes yang ditentukan Pemerintah Indonesia dengan biaya mandiri.</p><p><br></p><p><br></p>\r\n\r\n<p><br></p>\r\n\r\n<p>&nbsp;</p>','assets/images/fotoartikel/berita3.jpg','2020-05-11','KTG001',9,4329);
/*!40000 ALTER TABLE `artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artikel_tampil`
--

DROP TABLE IF EXISTS `artikel_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artikel_tampil` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikel_tampil`
--

LOCK TABLES `artikel_tampil` WRITE;
/*!40000 ALTER TABLE `artikel_tampil` DISABLE KEYS */;
INSERT INTO `artikel_tampil` (`id`, `navbar`, `judul`, `diskripsi`, `foto`, `tampil`) VALUES (1,'Berita','Umroh Sesuai Sunnah Rosul','Penyelenggara Umrah dengan pelayanan berkualitas','assets/images/fotoservice/nabawi2.jpg','Tidak');
/*!40000 ALTER TABLE `artikel_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award`
--

DROP TABLE IF EXISTS `award`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `award` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tampil` varchar(10) NOT NULL,
  `data1` varchar(25) NOT NULL,
  `angka1` int(5) NOT NULL,
  `data2` varchar(25) NOT NULL,
  `angka2` int(5) NOT NULL,
  `data3` varchar(25) NOT NULL,
  `angka3` int(5) NOT NULL,
  `data4` varchar(25) NOT NULL,
  `angka4` int(5) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(150) NOT NULL,
  `foto` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award`
--

LOCK TABLES `award` WRITE;
/*!40000 ALTER TABLE `award` DISABLE KEYS */;
INSERT INTO `award` (`id`, `tampil`, `data1`, `angka1`, `data2`, `angka2`, `data3`, `angka3`, `data4`, `angka4`, `judul`, `diskripsi`, `foto`) VALUES (1,'Tidak','Total Umroh',5500,'-',0,'Umroh Tahun Kemarin',1508,'-',0,'Kami <span>melayani </span> Anda','Pengalaman kami yang berlangsung lama akan manjadi kepercayaan Anda','assets/images/foto/al-aqsa-mosque.jpg');
/*!40000 ALTER TABLE `award` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `bank` varchar(25) NOT NULL,
  `rekening` varchar(25) NOT NULL,
  `pemilik` varchar(25) NOT NULL,
  `matauang` varchar(25) NOT NULL,
  `urut` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` (`id`, `bank`, `rekening`, `pemilik`, `matauang`, `urut`) VALUES (1,'MANDIRI','1420013662985','PT. AMINAH','3',1),(3,'BNI','8888881455','PT. AMINAH','3',2);
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(150) NOT NULL,
  `foto` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` (`id`, `judul`, `diskripsi`, `foto`) VALUES (1,'Blog Single Post','Mewarnai hidup lebih baik BOSKU SAYANG','assets/images/foto/2zppjpz.jpg');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url_web` varchar(50) NOT NULL,
  `th_web` varchar(4) NOT NULL,
  `titel_web` varchar(150) NOT NULL,
  `keyword_web` varchar(250) NOT NULL,
  `diskripsi_web` varchar(250) NOT NULL,
  `judul_web` varchar(150) NOT NULL,
  `favicon` varchar(100) NOT NULL,
  `fontawesome` varchar(50) NOT NULL,
  `sessionadmin` varchar(50) NOT NULL,
  `sessionpassadmin` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`id`, `url_web`, `th_web`, `titel_web`, `keyword_web`, `diskripsi_web`, `judul_web`, `favicon`, `fontawesome`, `sessionadmin`, `sessionpassadmin`) VALUES (1,'aminahtour.co.id','2020','PT. Aminah Go Digital','Ingin Punya Bisnis Tour ','ini website yang luar biasa','PT. AMINAH','assets/images/favicon.ico','<i class=\"fas fa-user\"></i>','AdminJoss','JossPassword');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategori_artikel`
--

DROP TABLE IF EXISTS `kategori_artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategori_artikel` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kode_kategori` varchar(10) NOT NULL,
  `nama_kategori` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategori_artikel`
--

LOCK TABLES `kategori_artikel` WRITE;
/*!40000 ALTER TABLE `kategori_artikel` DISABLE KEYS */;
INSERT INTO `kategori_artikel` (`id`, `kode_kategori`, `nama_kategori`) VALUES (1,'KTG001','IBADAH UMROH'),(2,'KTG002','IBADAH HAJI'),(3,'KTG003','MANASIK'),(4,'KTG004','ARAB SAUDI'),(5,'KTG00005','TUTORIAL');
/*!40000 ALTER TABLE `kategori_artikel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategoriproduk`
--

DROP TABLE IF EXISTS `kategoriproduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kategoriproduk` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `kodekategori` varchar(15) NOT NULL,
  `namakategori` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategoriproduk`
--

LOCK TABLES `kategoriproduk` WRITE;
/*!40000 ALTER TABLE `kategoriproduk` DISABLE KEYS */;
INSERT INTO `kategoriproduk` (`id`, `kodekategori`, `namakategori`) VALUES (1,'KTP001','UMROH'),(2,'KTP002','HAJI'),(3,'KTP003','Tour Internasional'),(4,'KTP004','Tour Domistik'),(5,'KTP005','Produk Barang'),(6,'KTP006','Produk Jasa');
/*!40000 ALTER TABLE `kategoriproduk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `wa` varchar(15) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(25) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=660 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`id`, `foto`, `user_id`, `username`, `nama`, `hp`, `wa`, `alamat`, `kota`, `status`) VALUES (1,'','1401-0000-0001','aminahtour','DIMAS AULIA','087739872922','6287739872922','Raya Wiguna Timur 48A','Surabaya',1),(5,'','2002-0000-1452','sukmawati1','Sukmawati','082331890655','6282331890655','Dsn jambe 005002 ds sukodadi kec. Candi','Sidoarjo',1),(6,'','2002-0000-1453','ahmadsyamsudin1','Ahmad Syamsudin','085648250836','6285648250836','Candi sayang 001001','Sidoarjo',1),(7,'','2002-0000-1454','endangumriyah1','Endang Umriyah','081230625553','6281230625553','Dsn rawan 014007 kec. krembung','Sidoarjo',1),(8,'','2002-0000-1455','akhmadrifai5','Akhmad Rifai','085604034445','6285604034445','Gempol','Pasuruan',1),(9,'','2002-0000-1456','zaini1','Muhmmad Zaini','081555656999','6281555656999','Gempol','Pasuruan',1),(10,'','2002-0000-1457','fathoni01','Ahmad Fathoni','081334210168','6281334210168','jl. tumapel 100 005006 singosari','Malang',1),(11,'','2003-0000-1464','arilunarko1','Ari Lanarko','081331535721','6281331535721','karangsono 0102 kec.sukorejo','pasuruan',1),(12,'','2003-0000-1465','ilyakrisnana1','Ilya Krisnana','085648230221','6285648230221','jl. bambu 0201 kec. sukorejo','pasuruan',1),(13,'','2003-0000-1466','sriswarsiningsih1','Sri Swarsiningsih','085646450944','6285646450944','karangsono 0101 kec. sukorejo','pasuruan',1),(14,'','2003-0000-1467','bahronizuhar1','Bahroni Zuhar','085335405406','6285335405406','jl. locari 2603 kec. kepanjen','kab. malang',1),(15,'','2003-0000-1468','anisah1','Anisah','082232835050','6282232835050','jl. locari 026003 kec. kepanjen','kab. malang',1),(16,'','2003-0000-1469','ibnufajar1','Ibnu Fajar','085103044847','6285103044847','jl. sawahan II nggurungan 017003 kec. kepanjen','kab. malang',1),(17,'','2003-0000-1470','nurulfatimah1','Nurul Fatimah','081313797784','6281313797784','gembong 328 kec. simokerto','surabaya',1),(18,'','2003-0000-1471','aniswulansari1','Anis Wulansari','085655120904','6285655120904','dsn tawang 004001','magetan',1),(20,'','2003-0000-1473','tantinherawati1','Tantin Herawati','08123233141','628123233141','nginden kec. sukolilo','surabaya',1),(21,'','2003-0000-1475','nurcholis1','H. Nur Cholis Amin','088289972376','6288289972376','dsn menyanggong kec. taman','sidoarjo',1),(22,'','2003-0000-1476','mahbub1','Muhammad Mahbub Putra Fajar','6281232013982','6281232013982','Krajan 0203 kec. purwosari','pasuruan',1),(23,'','1412-0000-0014','adisuseno1','Adi Suseno AMH','081234188899','6281234188899','Lebak permai 3kv. 22','surabaya',1),(24,'','1412-0000-0008','sucipto1','Sucipto','085850425373','6285850425373','Rungkut menanggal harapan Y1','surabaya',1),(25,'assets/images/member/IMG-20211002-WA0000.jpeg','1505-0000-0076','ardiana1','Ardiana Ninik Susanti','082244147117','6282244147117','Margorukun 9184 003009 ds gundih','surabaya',1),(26,'','1511-0000-0302','mohtoifan1','Moh Toifan','085311424616','6285311424616','Jl. kenjeran VI A3','surabaya',1),(27,'','1702-0000-0541','illanoor1','Illa Noor Kumala','081367191511','6281367191511','Graha kota d614 suko','surabaya',1),(28,'','1702-0000-0547','suparti1','Suparti','089680760583','6289680760583','Kletek 010005 taman','sidoarjo',1),(29,'','1702-0000-0550','mulya01','Mulya Ulfah','082233313646','6282233313646','Jl. mawar no.23 009003 gedangan','sidoarjo',1),(30,'','1702-0000-0577','sulistiani1','sulistiani','085843792190','6285843792190','Jl. mawar no.23 009003 gedangan','sidoarjo',1),(31,'','1702-0000-0578','supriyanto1','Supriyanto','082331373879','6281357578965','Jl. mawar no.23 kec. porong','sidoarjo',1),(32,'','1704-0000-0719','dony01','Donny Agus Susanto','085258117272','6285258117272','Jl. semeru no.56 pepelegi','sidoarjo',1),(33,'','1705-0000-0737','arisuprapti1','Ari Suprapti','085101730633','6285101730633','Sidoarjo','Sidoarjo',1),(34,'','1705-0000-0738','djumanikah1','Djumanikah','085648178886','6285648178886','Ketengan 0402 tanggulangin','Sidoarjo',1),(35,'','1709-0000-0809','nuriyah1','Nuriyah','087752622900','6287752622900','Perum bluru permai JE-08 buduran','Sidoarjo',1),(36,'','1801-0000-0906','ekosupriyono1','EKO SUPRIYONO','08113448985','62895808775500','Jl. Bambu runcing RT02RW01- Dusun Karangsono, Desa Karangsono, Kecamatan. Sukorejo.','Pasuruan',1),(37,'','1801-0000-0909','aswandi1','Aswandi','08755157957','628755157957','Gubeng kertajaya 34','Surabaya',1),(38,'','1804-0000-1104','asmaul01','Asmaul Chusnah','085733707651','6285733707651','Banjarsari 010003 tanggulangin','Sidoarjo',1),(39,'','1804-0000-1109','agusamin1','Agus Amin Wahyudi','087754144575','6287754144575','Balong dowo 0801 candi','Sidoarjo',1),(40,'','1805-0000-1112','budipranoto1','Budi Pranoto','087752908131','6287752908131','Bluru permai JE no.8','Sidoarjo',1),(41,'','1703-0000-0590','sriwahyuni1','Sri Wahyuni','085707658379','6285707658379','Berat wetan 0604','Mojokerto',1),(42,'','1805-0000-1119','sulistriyanti1','Sulistriyanti Spd AUD','081615423270','6281615423270','Jl. jenggolo 1B-3','Sidoarjo',1),(43,'','1805-0000-1120','panijo1','Panijo','085851064070','6285851064070','Jl. jenggolo 1B-3','Sidoarjo',1),(44,'','1909-0000-1255','imamthohari1','Imam Thohari','0815535049121','62815535049121','Surabaya','Surabaya',1),(45,'','1907-0000-1216','srisuhartini1','Sri Suhartini','081233749694','6281233749694','Godek wetan 1106 gading krembung','Sidoarjo',1),(46,'','1907-0000-1262','mahfudz1','Mahfudz','0281331241413','6281331241413','Jl. masjid 24 singasari','Malang',1),(47,'','1909-0000-1256','fuad1','M. Fuad Al Rosyidi','081233566523','6281233566523','Kebon agung 0401 sukodono','Sidoarjo',1),(48,'','1910-0000-1362','nurmufidah1','Nur Mufidah','0851533725014','62851533725014','Tulangan','Sidoarjo',1),(49,'','2002-0000-1450','irfan1','Muhammad Irfan Saputra','081235962176','6281235962176','Jl. mawar no.23 kec. porong','Sidoarjo',1),(50,'','2002-0000-1451','supriati1','Supriati','081216908794','6281216908794','Perumtas III blok g-1 no.31 tulangan','Sidoarjo',1),(51,'','1604-0000-0351','herdita1','Herdita Bambang Nugroho','08121661017','628121661017','Grand Rose Regency b-25 Ds. Kemiri sidoarjo','Sidoarjo',1),(52,'','1909-0000-1298','farid','M Farid','082301550383','6282301550383','Jl. panca niaga 14 mindi porong','Sidoarjo',1),(53,'','1905-0000-1208','tutuk1','Tutuk Yuningsih','081333397114','6281333397114','Jl. Dusun Godeg Wetan RT 11RW 06, Desa Gading , Kec. Krembung Sidoarjo','Sidoarjo',1),(54,'','1701-0000-0532','abdularif1','Abdul Arif','085645349090','6285645349090','Jl. Penatar Sewu - Tanggulangin','Sidoarjo',1),(55,'','1501-0000-0037','galang01','Galang Ade Rambawana','081216168500','6281216168500','Lebak Permai 322','Surabaya',1),(56,'','2007-0000-1488','maya01','Maya Puspitasari','082231011355','6282231011355','Jl. Pepaya III2 Karangduak','Sumenep',1),(58,'','2007-0000-1483','lilik01','Lilik Soenarti','087854455364','6287854455364','taman wiguna timur regency','surabaya',1),(59,'','200700001484','afilia01','Afilia Dinda','082291333941','6282291333941','taman wiguna timur regency','surabaya',1),(60,'','150600000084','dimas01','Dimas Aulia','08773987922','6287739872922','taman wiguna timur regency','surabaya',1),(61,'','200700001485','amir01','Mochamad Amir','087855165559','6287855165559','margoruku 9','surabaya',1),(62,'','200700001486','ria01','Siti Churia','089699466938','6289699466938','kalibogor 5-29','surabaya',1),(63,'','2007-0000-1487','lina01','Nariyah Gayuh','089656232085','6289656232085','dukuh kupang timur 7-35','surabaya',1),(64,'','1810-0000-1145','imam01','Imam Thohari','081553504912','6281553504912','Kebun Agung RT04,RW01, Kec. Sukodono','Sidoarjo',1),(67,'','1805-0000-1113','yuni01','Sriwahyuni','081231651213','6281231651213','Perumahan Bluru Permai GA.25','Sidoarjo',1),(71,'','2003-0000-1472','syaifudin01','Muhammad Syaifudin','0822344440296','62822344440296','Perumahan Alam Mutiara RT 04 RW 04','Sidoarjo',1),(72,'','170200000578','supriyo01','Supriyo','081235962176','6281235962176','PERUMTAS BLOK A6 NO.43','Sidoarjo',1),(73,'','200200001450','irvan01','Muhammad Irvan Sauptra','085704549266','6285704549266','Perumtas 3 Blok A6 No.43','SIDOARJO',1),(74,'','2007-0000-1489','edy01','H. Edy Abraham. S, SE','082110757007','6282110757007','Tangerang','Tangerang',1),(75,'','2007-0000-1490','asyiq01','Asyiq','08385873308','628385873308','Tambar Jogoroto','Jombang',1),(79,'','2003-0000-1474','surya01','Surya Ramadhan Firmansyah','082231437646','6282231437646','DK BL Banteng Suropati 5C-12','Surabaya',1),(86,'','2007-0000-1482','bambang01','Bambang Supriyadi','081334686482','6281334686482','Jl. Saeru ds pakijangan wonorejo','Pasuruan',1),(87,'','2007-0000-1491','anini01','Anini Nuryati','081334631595','6281334631595','Jl. Saeru RT 02RW03, Desa Pakijangan, Kec. Wonorejo','Pasuruan',1),(88,'','1511-0000-0308','illa01','ILLA NOOR KUMALA','081280118393','6281280118393','Jl. Thamrin 4a. Sidokumpul RT: 27RW: 05','Sidoarjo',1),(89,'','2003-0000-1478','bunga01','Bunga windy antika','082231028319','6282231028319','Darmo kali 423 Darmo Wonokromo','Surabaya',1),(90,'','2003-0000-1479','atiqa_d','Atiqa Andini','0818398009','62818398009','Prada permai VII18 dukuh pakis','Surabaya',1),(91,'','2009-0000-1516','nuril01','Nuril Huda','085730248925','6285730248925','Jl. Kampung Baru Rt. 003Rw 007 Segoro tambak sedati','Sidoarjo',1),(92,'','2008-0000-1515','jamal01','Jamaludin','081230353612','6281230353612','Jl. Pasar 005002 Tambak Oso Waru','Sidoarjo',1),(93,'','2003-0000-1459','zaini01','Muhammad Zaini','082132692879','6282132692879','Dsn Krajan 005001 Dampit','Malang',1),(94,'','1706-0000-0748','zaenal01','Zaenal Arifin','081553663115','6281553663115','Mojowarno','Jombang',1),(95,'','2011-0000-1539','hadi01','Abd. Hadi','085100360467','6285100360467','Ngupil 002001 ds kanigoro kec.Pagelaran','Malang',1),(96,'','2012-0000-1541','muhari01','Muhari Abror','085851035993','6285851035993','Dsn. Slatri RT 02 RW 01 Ds. Paid Kec. Kasembon','Malang',1),(97,'','2003-0000-1480','yahya01','Yahya Ubaid','081231707437','6281231707437','Jl. A.Yani 165 Ds. Kemantren Kec. Jabung','Malang',1),(98,'','2012-0000-1542','mustaqim01','Drs. Mustaqim','085235201796','6285235201796','Jl. Kendedes RT 22 RW 3 Ds. Sumber pucung Kec. Sumber Pucung','Malang',1),(99,'','2012-0000-1543','iwan01','Ir. Iwan Hadi Pratikno','085257272005','6285257272005','Jl. Cempaka 6 RT 001 RW 001 Ds. Ketajen Kec. Gedangan','Sidoarjo',1),(100,'','2101-0000-1546','nuraini01','Ir. Nuraini','082124319213','6282124319213','Perum BSI Blok D1012 Duren Mekar Bojongsari','Depok',1),(101,'','2101-0000-1547','syaifudin1','Ir. Syaifudin','0811833077','62811833077','Perum  Duren Jaya Blok C no. 165 Duren Jaya bekasi timur','Bekasi',1),(102,'','2101-0000-1548','rusmini01','Sri Rusmini','6289636834630','6289636834630','Komplek Kodam Jaya K2130 Kalideres','Jakarta Barat',1),(103,'','2101-0000-1544','hadiono01','Hadiono','085104603100','6285104603100','Dsn. Tambaksari 015002 Jatisari pakis Aji','Malang',1),(104,'','2101-0000-1545','elin01','Elin Erna Febri Yanti','0895342337578','62895342337578','Relokasi mingi baru jl. Melati blok K-4 Kesambi Porong','Sidoarjo',1),(105,'','2101-0000-1549','septy01','STEFANNY SEPTY','081299343484','6281299343484','Jl. Pala no. 39 Lubang Buaya Cipayung','Jakarta Timur',1),(106,'','2101-0000-1550','matnawari01','Matnawari','085101191452','6285101191452','Jl. DsN Kaliasem 011002 Kalipare','Malang',1),(107,'','2101-0000-1551','muji01','MUJI RAHAYU','08973257922','628973257922','JL. MANGGA GG. IKAN MAS 004003 POGAR BANGIL','PASURUAN',1),(108,'','2102-0000-1552','maitsa01','MAITSA SALSABILA','6283148535874','6283148535874','KP SUKAMANDI 008006','KAB. SUBANG',1),(109,'','2012-0000-1540','mansyur01','MANSYUR ARIF','6282131427835','6282131427835','EMURAN 005002 SUKODADI WAGIR','KAB MALANG',1),(110,'','2102-0000-1553','noval01','Noval sya prahara A','6281310893462','6281310893462','Jln. Panca warga 29 no.12 RT.004RW.002 Cipinang besar Selatan Jatinegara','JAKARTA TIMUR  JAKARTA TI',1),(111,'','2102-0000-1554','herni01','Herni Diah Pitaloka','6287721562173','6287721562173','Jln. Tangguh V no.65 RT.009RW.002','JAKARTA UTARA',1),(112,'','2102-0000-1555','adang01','RD Adang Sudrajat Suprayoga','6281320707757','6281320707757','Jln. Taman Sari 1 RT.017RW.006 Pasir Kareumbi','SUBANG',1),(113,'','2102-0000-1556','ugeng01','UGENG SUJANARKO','6281357319000','6281357319000','BCF PALAZZO PARK BLOK C-5080 RT.022 RW.001 RANGKAH KIDUL SIDOARJO','SIDOARJO',1),(114,'','2102-0000-1557','suyitno01','Suyitno SH','6287875868618','6287885610636','Jln. Matraman dalam 2 no. 21 RT.008RW.008 Pegangsaan Menteng','JAKARTA PUSAT',1),(115,'','2103-0000-1559','saerofil01','MOH. SAIROFIL LAILI','6285815777445','6285815777445','JL. G. SALAK RT 01RW 17, Dusun JOMBANGAN Tertek Pare','KEDIRI',1),(116,'','2103-0000-1560','imam02','Imam Firmansyah','6283824756835','6283824756835','Dusun 3 RT 014003 Cikulak Waled','CIREBON',1),(117,'','2103-0000-1561','dian01','DIAN NURDIANSYAH','+6282217603347','6282217603347','Blok Kliwon 021005 CIPINANG, MAJALENGKA','Majalengka',1),(118,'','2103-0000-1562','tabiin01','TABIIN RIANTO','6282330470431','6282330470431','BOCOK 002004 PONDOKAGUNG KASEMBON','MALANG',1),(119,'','2103-0000-1563','dea01','DEA DWI DAMAYANTI','6282120773480','6282120773480','JL. MOCH. YUNUS PAV NO.4 002007 PASIR KALIKI CICENDO','BANDUNG',1),(120,'','2103-0000-1564','gunawan01','GUNAWAN SUSANTO','6281222246445','6281222246445','PERUM BSI BLOK D.1012 005005 DUREN MEKAR BOJONGSARI','DEPOK',1),(121,'','2103-0000-1565','suyatno01','SUYATNO','6282330538883','6282330538883','Mukuh RT. 006RW.002 Tempursari Wungu','Madiun',1),(122,'','2103-0000-1566','achmadmunif01','Achmad Munif','6285780526633','6285780526633','Kp. Cerewet no.50 RT.002016 Duren jaya Bekasi Timur','Bekasi',1),(123,'','2103-0000-1567','sofa01','SOFA DWI KUSETIOWATI','6281330538113','6281330538113','DSN KESAMBEN 024 004 WUNUT','PORONG',1),(124,'','2103-0000-1568','agussafrudin01','AGUS SAFRUDIN','6281574674669','6281574674669','DUREN JAYA BLOK A NO. 539  DUREN JAYA Bekasi Timur','BEKASI',1),(125,'','2103-0000-1569','mochandi01','Moch Andi Rachman','6285231715990','6285231715990','Jl tanjung GG 3 Gempol','PASURUAN',1),(126,'','2103-0000-1570','rahmtullah01','RAHMATULLAH AZHAR','6287755880654','6287755880654','DUSUN JENI 001008 Gumukmas','JEMBER',1),(127,'','2103-0000-1571','supardjo01','Supardjo','6281210793175','6281210793175','Jln. Karang satria no.21 RT.0308 Duren Jaya Bekasi Timur','BEKASI',1),(128,'','2104-0000-1572','wahyudi01','WAHYUDI PURNOMO','6287864003431','6287864003431','Kedamean 005002 kedamean','Gresik',1),(129,'','2104-0000-1573','jaelani01','Ahmad Jaelani','6281219545562','6281219545562','Karet psr baru barat 1 RT.001007 Karet tengsin Tanah Abang','JAKARTA PUSAT',1),(130,'','2104-0000-1574','denny01','Denny Yanuar','6281585846697','6281585846697','Jln. Penegak no.50 RT.002010 Loji Bogor Barat','BOGOR',1),(131,'','2104-0000-1575','suparlan01','SUPARLAN','6285200437814','6285200437814','PANGGISARI 003002 PANGGISARI Mandiraja','BANJARNEGARA',1),(132,'','2104-0000-1576','djandji01','DJANDJI LINDARWASKITO','6281230301239','6281230301239','JL. L.A SUCIPTO VIIB 23 RT.007 RW. 002 Blimbing','MALANG',1),(133,'','2104-0000-1577','zainal01','Zainal Abidin','6285776258930','6285776258930','Villa Bekasi Indah I Blok A1 No.5 Jejalenjaya Tambun Utara Tambun','Bekasi',1),(134,'','2104-0000-1578','yusufnur01','Yusuf Nur Alim','6281223112144','6281223112144','Komplek Mekarsari Endah Blok C28 Bale Endah','Bandung',1),(135,'','2104-0000-1579','adde01','Adde Karnafi','6285216440701','6285216440701','Bumi sani permai blok H253 setia mekar Tambun selatan','Kab Bekasi',1),(136,'','2104-0000-1580','nunung01','nunung','6285772972991','6285772972991','Kp. Utan Asem RT.00402 Jaya Bakti Cabangbungin','BEKASI',1),(137,'','2104-0000-1581','suryo01','Drs. Suryo Gutomo','6288996120196','6288996120196','Jln. Kayu Agung 11 no.12 RT.00704 Turangga Lengkong','KOTA BANDUNG',1),(138,'','2107-0000-1582','totokedi01','TOTOK EDY SUPRIHANTO','6282143710441','6282143710441','Jl. Dirgantara 4 B7-1','Malang',1),(139,'','2108-0000-1584','mahmuddin01','MAHMUDDIN','6281233041083','6281233041083','Sumberkreco 017006 Sidomulyo Jabung','Malang',1),(140,'','2108-0000-1583','ilham01','AHMAD ILHAM AZIZI','6282257421508','6282257421508','Jl. Kauman I44 Tumpang','Malang',1),(141,'','2108-0000-1585','amang01','AMANG FATHURROHMAN','+6285655567588','6285655567588','Bakalan 024006 Purwosari pasuruan','Pasuruan',1),(142,'','2108-0000-1587','sukiman01','SUKIMAN','6281271610753','6281271610753','Jln. Karang setra no. 25 RT. 003 RW. 008 Duren Jaya','BEKASI',1),(143,'','2109-0000-1587','cbsyahrul01','SYAHRUL NABAWI','6285730640951','6285730640951','pranti 001001 pranti Sedati','SIDOARJO',1),(144,'','2109-0000-1588','randi01','R. ANDI WIDYATMOKO','6285736566987','6285736566987','DUSUN. WONOREJO, RT 002 RW 001 SUMBERWONO BANGSAL','MOJOKERTO',1),(145,'','2109-0000-1589','asroji01','ASROJI','6285349694776','6285349694776','Sungai bemban 027008 Punggur kecil sungai kakap Lubuh raya','Kubuh raya kalbar',1),(146,'','2109-0000-1590','syamsuddin','SYAMSUDDIN','6281259050021','6281259050021','JL. CENDRAWASIH 15 MULYOASRI 003006 TULUNGREJO Pare','KEDIRI',1),(147,'','2109-0000-1591','andamarie01','ANDA MARIE','6285101399908','6285101399908','JL.SUMPIL II20AX PURWODADI BLIMBING','MALANG',1),(148,'','2109-0000-1592','bambang02','BAMBANG SUDIHARIYANTO','6282155581111','6282155581111','PERUM BINTANG ALAM D36 TELUK JAMBE Telukjambe Timur','KARAWANG',1),(149,'','2109-0000-1593','miftah01','MIFTAHUL FARUQ','628113661667','628113661667','JL. PURWOSARI VI TAMBAKREJO GAYAMSARI','SEMARANG',1),(150,'','2110-0000-1594','hadroh01','Hadroh','628558693816','628558693816','Babelan Indah blok C 542 RT.09RW.08 Kebalen','BEKASI JABAR',1),(151,'','2110-0000-1595','ferry01','Ferry Setia P','6285705849156','6285705849156','Jln. DI Panjaitan no. 83 RT.028RW.000 Sumber Rejo Balikpapan Kota','BALIKPAPAN',1),(152,'','2110-0000-1596','happy01','Happy Mulyati Ningsih','6281649588474','6281649588474','Jln. Karang  Jawa RT.006RW.000 Karang Jati Balikpapan Tengah','BALIKPAPAN',1),(153,'','2110-0000-1597','nidhom01','MUHAMMAD SYAFIUN NIDHOM','6287841021684','6287841021684','JL. KH. SUWAIFI BARAT KARANGANYAR SEDATI','SIDOARJO',1),(154,'','2110-0000-1598','umisaraswati01','UMI SARASWATI','6281336778085','6281336778085','JL. WISNU WARDANA 118 CANDIRENGGO SINGOSARI','KAB MALANG',1),(155,'','2110-0000-1599','kusniyah01','Kusniyah','081327569474','6281327569474','Blimbing Rw 005 Rt 001','Banjarnegara',1),(156,'','2110-0000-1600','kohar01','Abdul Kohar','081327569474','6281327569474','Blimbing Rw 004 Rt 001','Banjarnegara',1),(157,'','2110-0000-1601','suwarno01','SUWARNO','6289670196275','6289670196275','Candiwulan RT.04 02 Candiwulan Mandiraja','Banjarnegara',1),(158,'','2110-0000-1602','aminmaruf01','MOCHAMAD AMIN MARUF','6283132680300','6283132680300','JL PESANTREN 039005 KARANGKATES SUMBERPUCUNG','MALANG',1),(160,'','2111-0000-1604','lutfiyatul01','LUTFIYATUL ALIYAH','6283833242702','6283833242702','BRUKAN 020002 Kalisat Rembang','Pasuruan',1),(161,'','2111-0000-1605','robingah01','Robingah','6281347384816','6281347384816','Panggisari RT.00302 Desa. Panggisari Mandiraja','Banjarnegara',1),(162,'','2111-0000-1606','trastuti01','TRASTUTI IRIANTI','628129205062','628129205062','Cibubur Country LN. 5 no.16 Cikeas Udik Gunung Putri','BOGOR',1),(163,'','2111-0000-1607','ekowidjanto01','EKO WIDJANTO','6285100787468','6285100787468','Jl. Manunggal XVII no. 57 Lubang buaya Cipayung','Jakarta Timur',1),(164,'','2111-0000-1608','yayanyanuar01','Yayan Yanuar','6281298611284','6281298611284','Pangkalan Jati VII no. 11 Cipinang Melayu Makasar','Jakarta Timur',1),(165,'','2111-0000-1609','leilarufalda01','LEILA RUFALDA YUSUF','6287822136327','6287822136327','JL. ANTAPANI CITY I NO.10 ANTANI TENGAH ANTAPANI','BANDUNG',1),(166,'','2111-0000-1610','sumiyah01','Sumiyah','628293632391','628293632391','Candiwulan RT.00302 Desa Candiwulan Mandiraja','Banjarnegara',1),(167,'','2111-0000-1611','donikatari01','DONI KATARI','6281802061968','6281802061968','JL. MERANTI I BLOK C27 001010 DUREN JAYA BEKASI TIMUR','BEKASI',1),(168,'assets/images/member/WhatsApp_Image_2021-12-16_at_14_21_22.jpeg','2112-0000-1612','endangyusanti01','Endang Yusanti','6281281071609','6281281071609','Jln. Panca warga 29 no.12 RT.004002 Cipinang besar Selatan Jatinegara','JAKARTA TIMUR',1),(169,'assets/images/member/pp.jpg','2112-0000-1613','surabaya','Drs. Sutrisno','6285733050327','6285733050327','DS. KEBONAGUNG 029006 KEBONAGUNG PORONG','SIDOARJO',1),(170,'assets/images/member/WhatsApp_Image_2021-12-16_at_16_18_47.jpeg','2112-0000-1614','hasansaidi01','HASAN SAIDI ABU DZARRIN','6282143423669','6282143423669','BLAMBANGAN NO.25 DAMPIT','MALANG',1),(171,'assets/images/member/WhatsApp_Image_2021-12-16_at_16_25_33.jpeg','2112-0000-1615','nurulhuda01','NURUL HUDA','6282141274916','6282141274916','JL. POLOWIJEN II 69-B 004004 POLOWIJEN BLIMBING','MALANG',1),(172,'assets/images/member/IMG-20211216-WA0017.jpg','2112-0000-1616','lukmanamin01','Lukman Amin','6285105093938','6285105093938','Pesantren 004001 Mojosari Kepanjen','Malang',1),(173,'assets/images/member/IMG-20211216-WA0020.jpg','2112-0000-1617','farliani01','Farliani','6281380844161','6281380844161','Jl. Turi no.72 Lenteng Agung Jagakarsa','Jakarta Selatan',1),(174,'assets/images/member/IMG-20211217-WA0037.jpg','2112-0000-1618','hilmiawan01','Ahmad Rizki Ihsan Hilmiawan','6285859848362','6285859848362','Jl. Karangsono Sukorejo Pasuruan','Pasuruan',1),(175,'assets/images/member/IMG-20211217-WA0009.jpg','2112-0000-1619','sujianto01','Sujianto','6285100541143','6285100541143','Dsn Watusigar 028004 Srigonco Bantur','Malanh',1),(176,'','2112-0000-1620','rismayanti01','Risma Yanti','6288803060138','6288803060138','Dsn Tanjung 003006 Banjararum Singosari','Malang',1),(177,'assets/images/member/IMG-20211217-WA0007.jpg','2112-0000-1621','arihidayati01','Ari Hidayati','6281230042857','6281230042857','Jl. Trunojoyo 031004 Gondanglegi kulon Ganodanglegi','Malang',1),(178,'assets/images/member/IMG-20211217-WA0005.jpg','2112-0000-1622','sitiasiyah01','Siti Asiyah','62812337795486','62812337795486','Argotirto 001001 Argotirto Sumbermanjeng wetan','Malang',1),(179,'','2112-0000-1623','rinaraflina','Rina Raflina','6285778770446','6285778770446','JL. Ayub Gg. C no.21 pejaten barat pasarminggu','Jakarta Selatan',1),(180,'','2112-0000-1624','sofan','Sofan Arisandi','6281357674252','6281357674252','Kebon Harjo Jatirogo','Tuban',1),(181,'','2112-0000-1625','zuhdi','sholeh zuhdi','6287809618977','6287809618977','Buntet Pesantren Mertapadan Kulon Asta Jaya Pura','Cirebon',1),(182,'','2112-0000-1626','rusito','Rusito Edy P','6281310214658','6281310214658','Puri Asri Pratama Blok C2 No. 14 Telajung Cikarang Barat','Bekasi',1),(183,'','2112-0000-1627','mwahyu','Muhammad Wahyu Firmansyah','6281572153474','6281572153474','pulo gerbang permai blok C21 Pulo Gebang Cakung Jakarta Timur','Jakarta Timur',1),(184,'','2112-0000-1628','alya02','Alya Setyowatiningsih','6282141019310','6282141019310','Badal Pandean 003001 badal pandean Ngaduluwih','Kediri',1),(185,'','2112-0000-1629','hasan02','Hasan Babis','6285336825029','6285235202230','Panggung 008002  Panggung Barat','Magetan',1),(186,'','2112-0000-1630','marsid','Marsid','6282232942244','6282232942244','Watusigar 017 003 Srigonco Bantur','Malang',1),(187,'','2112-0000-1631','nisaul','Ninis Kusnawati','6285785290688','6285785290688','Dsn Gambar Mini Gambar Sumber gempol Tulung Agung','Tulung Agung',1),(188,'','2112-0000-1632','murniati','Murniati','628983713093','628983713093','Pondok Maharta blok H-1022 pondok kacang timur pondok aren Tangerang selatan','Banten',1),(189,'','2112-0000-1633','ernawati','Ernawati','628161924956','621861924956','komp. PLN G1 Petukangan pondok karya pondok aren Tangerang selatan','Banten',1),(190,'','2112-0000-1634','nenden','Nenden Mutia Chumariah','628174948891','628174948891','KP. Jemblongan no. 24 Pancoran mas','Depok',1),(191,'','2112-0000-1635','riyani','Riyani','6281291806291','6281291806291','Pancoran 29 no. 17 Cipinang besar Selatan jatinegara','Jakarta Timur',1),(192,'','2112-0000-1636','usepgumilar','Usep Gumilar','6281316006224','6281316006224','Jl. Pemuda 3 no. 15 Rawamangun Pulogadung Jaktim','Jakarta Timur',1),(193,'','2112-0000-1637','yanuardi','Yanuardi','6281384355545','6281384355545','Jl. Pancawarga 29 no.12 Cipinang Besar Selatan Jatinegara','Jakarta Timur',1),(194,'','2112-0000-1638','gunawan','M Rohman Gunawan','6281283335952','6281283335952','KP. Baeud 002001 Samuda Selawi Garut Jabar','Jakarta Barat',1),(195,'','2112-0000-1639','sulaiman','Sulaiman','6281381914346','6281381914346','Jl. Duren 3 blok A 579 Duren Jaya Bekasi','Jakarta Barat',1),(196,'','2112-0000-1640','fatimah','Nenden Fatimah','6287887800909','6287887800909','Jl. Poncol Jaya 013005 Kuningan barat Mampang Mampang Prapatan','Jakarta Selatan',1),(197,'','2112-0000-1641','saonah','Saonah','6282123330871','6282123330871','Dsn I 004001 cikulak Waled','Cirebon',1),(198,'','2112-0000-1642','alfin','Alfin Fahmi','6282143123963','6282143123963','Dsn Bere Lorong Sukolilo barat labang','Bangkalan',1),(199,'','2112-0000-1643','teguh','Teguh Santoso, Ir','6285729407007','6285729407007','Tegal Mulyo II No. 2 Pakuncen Wirobrajan','Yogyakarta',1),(200,'','2112-0000-1644','faizal','Faizal Al Bakir','6282111014572','6282111014572','Perum Duren Jaya Blok C No. 145 Duren Jaya Bekasi Timur','Bekasi',1),(201,'','2112-0000-1645','raihan','Drs H Nur Raihan, MA','6287880984597','6287880984597','Jl. Ridi No. 71 Ulujami pesanggrahan','Jakarta Selatan',1),(202,'','2112-0000-1646','umarrifai','Umar Rifai','628111685853','628111685853','Jl. Sirsak gang Udel no. 80 010007 Jagakarsa','Jakarta Selatan',1),(203,'','2112-0000-1647','rudia','Ridi Abaruddin','6285855850114','6285855850114','Buluagung Jawa 001008 sengonagung purwosari','Pasuruan',1),(204,'','2112-0000-1648','darussalam','Mochamad Darrusalam','6282230128280','6282230128280','Ngetrep 001001 Sedati Ngoro Mojokerto','MOJOKERTO',1),(205,'','2112-0000-1649','iskak','Iskak Yulianto','6285334548080','6285334548080','Jl. Pandean III 81 Kidul Dalem Bangil','pasuruan',1),(206,'','2112-0000-1650','syahruddin','Syahruddin','6281247472347','6281247472347','Jl. S Poso  79 no. 9 Larangbangi Makasar','Makasar',1),(207,'','2112-0000-1651','ahafi','Abdul Hafi','6282132720740','6282132720740','Jl. Tangkilsari 008002 Tajinan','Malang',1),(208,'','2112-0000-1652','yusron','yusron Choirudin','6281336464275','6281336464275','Perum Pondok Mutiara 002011 Dengkol singosari','Malang',1),(209,'','2112-0000-1653','ulfaubai','Ulfa Ubaidiyah','6281217137787','6281217137787','Jl. Tenun no. 30 panggung Rejo kepanjen','Malang',1),(210,'','2112-0000-1654','mashithoh','Dewi Masithoh','6282338328882','6282338328882','Jl. Sunan Malik Ibrahim 001001 Bulupitu Gondanglegi','Malang',1),(211,'','2112-0000-1655','badri','Sholeh Al Badri','6285804559536','6285804559536','Pandansari 001006 Pandansari poncokusumo','Malang',1),(212,'','2112-0000-1656','yulian','Yulian Puji Astutik','6281918330105','6281918330105','Jl. Sidomulyo no. 38 Pagentan Singosari','Malang',1),(213,'','2111-0000-1657','mfauzi','Mohamad Fauzi','6285103017753','6285103017753','Jl. Pesantren Krajan Barat RT003RW003 Randuagung Singosari','Malang',1),(214,'','2112-0000-1658','aszril','Azril Mochamad','6285798217895','6285798217895','KP. Beaud 002001 Samida Selaawi','Garut',1),(215,'','2112-0000-1659','fikri','Muhamad Fikri Abdul Haq','628568469717','628568469717','Duren Jaya Blok A no. 579 Duren Jaya Bekasi Timur','Bekasi',1),(216,'','2112-0000-1660','misbakhul','Mukhamad Misbakhul Munir','6285895768608','6285895768608','Dsn Mlaras 003001 Mlaras Sumobi','Jombang',1),(217,'','2112-0000-1661','fanani','Moh Fanani Saifudin','6285707948136','6285707948136','dusun Rawan 014007 Tanjekwagir Krembung','Krembung',1),(218,'','2112-0000-1662','isnaini','Isnaini','62821111060009','62821111060009','Talang  005002 wonosari gempol','Pasuruan',1),(219,'','2112-0000-1663','wiwit','Wiwit Sugiharto','6282132329811','6282132329811','Bulaksari 633 wonokusumo Semampir','Surabaya',1),(220,'','2112-0000-1664','niken','Niken Pramedi','6282233652006','6282233652006','Jagir Sidomukti 56 Jagir Wonokromo','Surabaya',1),(221,'','2112-0000-1665','ikhsan','M IKHSAN','6289638754300','6289638754300','jl. Binangun 004009 Genesa Pakisaji','MALANG',1),(222,'','2112-0000-1666','suwarno','Suwarno','6285718370703','6285718370703','Tumapel Ii 63 Pagentan Singosari','MALANG',1),(223,'','2112-0000-1667','mastuhin1','Maftuhin','0895340525739','62895340525739','Samborejo 006002 Samborejo Tirto','Pekalongan',1),(224,'','2112-0000-1668','sutanto1','Agus Sutanto','081321258085','6281321258085','DR Slamet No 31 Cipaganti Coblong','Bandung',1),(225,'','2112-0000-1669','purwanto','Agus Purwanto','6281226232725','6281226232725','Nglandung RtRw 011002 Nglandung Geger','MADIUN',1),(226,'','2112-0000-1670','buyun','Buyun  Adi Pamikatsih','085233771414','6285233771414','Perum Bumi Mas 2 Blok QQ No. 1 Mojorejo Taman','MADIUN',1),(227,'','2112-0000-1671','harsono','Muhammad Harsono','081335647104','6281335647104','Pangeran 001002 Demangan Siman Ponorogo','Ponorogo',1),(228,'','2112-0000-1672','arafah','Nur Arafah Setia','6289510547686','6289510547686','Jl. Manunggal XVII no. 2 Lubang Buaya','Jakarta timur',1),(229,'','2112-0000-1673','ginanjar','Ginanjar Wisnu Saputral','6281293842865','6281293842865','Jl. Karang satria no. 25 RTRW 0308 Duren Jaya Bekasi Timur','Bekasi',1),(230,'','2112-0000-1674','syamhudin','Nur Muhammad Syamhudin','6281289368407','6281289368407','Jl. Karang satria no. 25 RTRW 0308 Duren Jaya Bekasi Timur','Bekasi',1),(231,'','2112-0000-1675','pontjo','BRM PONTJO KUNTJORI','628129021179','628129021179','CILEDUG INDAH 2 D1411 PEDURENAN KARANG TENGAH','TANGERANG',1),(232,'','2112-0000-1676','hennry','Hennry Nizmul Fallah','6281314223337','6281314223337','Kemirimuka RT.006003 Kemirimuka Beji','DEPOK',1),(233,'','2112-0000-1677','sudarto','Sudarto','6281330416053','6281330416053','Bluru Permai HQ - 18 Bluru Kidul','Sidoarjo',1),(234,'','2112-0000-1678','rahmawati','IKA RAHMAWATI','6285655617020','6285655617020','DUSUN BEYAN RT 022  006  PANDWAWANGI DIWEk','JOMBANG',1),(235,'','2112-0000-1679','bahrul','MUH. BAHRUL HUDA','6285735581186','6285735581186','JL. CANDI SUROWONO RT: 002  RW : 019 CANGGU BADAS','KEDIRI',1),(236,'','2112-0000-1680','hariyanto','HARIYANTO','628113002285','628113002285','JL. S PARMAN GG. 10 PERUM GREENLEND SEMERU G. 14 SUMBERSARI','JEMBER',1),(237,'','2112-0000-1681','ferry','Ferry Effendy','6281289608844','6281289608844','Kp. Pedurenan RtRw 002006 Duren jaya Bekasi Timur','Bekasi',1),(238,'','2112-0000-1682','rohmah','ROHMAH','6282232926805','6282232926805','DSN. SIDAYU 006004 SIDOREJO PAGELARAN SIDOREJO PAGELARAN','MALANG',1),(239,'','2112-0000-1683','msukarno','Muhamad Sukarno','628119220190','628119220190','Jl. Pondok serut 1 RtRw 004003 Pondok kacang barat Pondok Aren','TANGERANG SELATAN',1),(240,'','2112-0000-1684','ilham','Moch Ilham Khoirur Rizqi','6285546744557','6285546744557','Jl. Sumpil II 20 ax Purwodadi Blimbing Malang','Malang',1),(241,'','2112-0000-1685','mukiman','Drs. H Mukiman','628123082842','628123082842','Pondok Benowo indah blok AI1 babatan jerawat pakal','Surabaya',1),(242,'','2112-0000-1686','marifah','Siti Marifah','6285748042775','6285748042775','Bunut Randegan sari Driyorejo','Gresik',1),(243,'','2112-0000-1687','rachmawati','ATI RACHMAWATI','6281288695274','6281288695274','JL. MERANTI I  BLOK C 27 DUREN JAYA','BEKASI TIMUR BEKASI',1),(244,'','2112-0000-1688','amruzi','Amruzi Setiagama','6282180676299','6282180676299','Jln.Padat karya no 93 LK.1 RT.007- rajabasa raya raja basa','Lampung Selatan',1),(245,'','2112-0000-1689','amaliah','Siti Amaliah','6285353840374','6285353840374','Perum griya damai Kusuma 2,3 RT.008001 megu cilik weru','cirebon',1),(246,'','2112-0000-1690','sutrisno','Imam Sutrisno','6285691518952','6285691518952','PERUM KARTIA ASABRI BLOK H223 Wonosari cibitung','sukabumi',1),(247,'','2112-0000-1691','laode','Laode Baharuddin','6281344366659','6281344366659','Cibuntu sayuran RT.10006 warung muncang bandung kulon','bandung',1),(248,'','2112-0000-1692','riris','RIRIS LISTIANA','6285719021796','6285719021796','GANG E PATIK II RT001RW010 CIRACAS','Jakarta Timur',1),(249,'','2112-0000-1693','bilal','Moch Bilal Drajat Anugrah','6285101152353','6285101152353','Jl. Masjid 25 001004 Pagentan Singosari Pagentan Singosari','Malang',1),(250,'','2112-0000-1694','jayadi','Jayadi','6285718066721','6285718066721','Balimatraman RtRw 004009 Manggarai Selatan Tebet','Jakarta Selatan',1),(251,'','2112-0000-1695','abdgani','Abdul Gani','6281908182875','6281908182875','Jln. Al-Wustho RT.017007 Pondok bambu Duren Sawit','Jakarta',1),(252,'','2112-0000-1696','fitriyah','FITRIYAH','6285700020669','6285700020669','DSN. KARANGSONO, RT 002 RW 001 KARANGSONO SUKOREJO','PASURUAN',1),(253,'','2112-0000-1697','fadal','Moh. Fadal, S.H.I','6285257282055','6285257282055','Dusun Duko Ketawang Laok Guluk-Guluk','Sumenep',1),(254,'','2112-0000-1698','najih','M. Najih Irfan','6285156430953','6285156430953','Perum Diren Jaya Blok C 165 Duren Jaya Bekasi Timur','Bekasi',1),(255,'','2112-0000-1699','masmawi','Moch. Asmawi','6289510190630','6289510190630','Perum. Taman Rahayu Regency B2 No. 24 Ciketingudik Bantar Gebang','Bekasi',1),(257,'','2112-0000-1700','aryanti','Yuli Aryanti','628176662771','628176662771','Jl. P. Singkep Raya No. 12 RtRw 009016 Aren Jaya Bekasi Timur','BEKASI',1),(258,'','2112-0000-1702','yuniarti','Yuniarti','6285108084444','6285108084444','Katulistiwa gg teluk selamat no.1 siantar hilir pontiananak utara','Pontianak',1),(259,'','2112-0000-1703','darmawan','R Darmawan supriono dewa','6285713939507','6285713939507','Ngadiauryan KTJ62 YK Patehan kraton','Jogjakarta',1),(260,'','2112-0000-1701','thoyib','Moh Thoyib','6281322599560','6281322599560','Buntet Pesantren Mertapada Kulon Astanajayapura','Cirebon',1),(261,'','2112-0000-1704','sohibul','RD Sohibul Sifillah','6282127257840','6282127257840','Dusun 03 RT 002 RW 005 Pakusamben Babakan','CIREBON',1),(262,'','2112-0000-1705','badrudin','Badrudin','628131354014','628131354014','Dusun 01 Pejayen rtrw 001001 Lebakmekar Greged','CIREBON',1),(263,'','2112-0000-1706','mardiyaningsih','Neneng Mardiyaningsih','6285724110987','6285724110987','Jln. Nuri blok W no 4 Mekarsari Cimanggis','DEPOK',1),(264,'','2112-0000-1707','melita','Melita Lestari','6282116204717','6282116204717','Jln. Nuri blok D no 18 Mekarsari Cimanggis','DEPOK',1),(265,'','2112-0000-1708','mulyawati','Yuti Mulyawati','6282315','6282315000','Jln Mustika Raya no. 5 Mekarjaya Cimanggis','DEPOK',1),(266,'','2112-0000-1709','rezatito','Reza M Tito','6281219878565','6281219878565','KP Bojong Buah Pangauban Katapang','BANDUNG',1),(267,'','2112-0000-1710','rulis','Rulis Sunani','6289507650592','6289507650592','KP Kekupu Rangkapan Jaya Pancoran Mas','DEPOK',1),(268,'','2112-0000-1711','sunarmi','Sunarmi','6285693894836','6285693894836','KP Pitara Rangkapan Jaya Pancoran Mas','DEPOK',1),(269,'','2112-0000-1712','nurzeni','NURZENI RATMANTO','6285645472121','6285645472121','DESA KARANGSONO, RT 002RW 001 KARANGSONO Sukorejo','PASURUAN',1),(270,'','2112-0000-1713','maymunah','Siti Maymunah','6285776922881','6285776922881','Kp. Muara RT.001011 Bojonggede','BOGOR',1),(271,'','2112-0000-1714','poniman','Poniman','628771234899','628771234899','Dusun III RtRw 002007 Buntet Astanajapura','CIREBON',1),(272,'','2112-0000-1715','yuliana','Yuliana','628994665079','628994665079','Jln. Musyawarah no.9A RT.012002 Kebon jeruk','Jakarta Barat',1),(273,'','2112-0000-1716','fatichah','Nurul Fatichah','6285224063399','6285224063399','Buntet pesantren RtRw 011004 Mertapada kulon Astanajapura','Cirebon',1),(274,'','2112-0000-1717','wijaya','Agus wijaya','6285959030812','6285959030812','PUP Sektor v Blok F 1 No 7 RtRw 001023 Bahagia Babelan','BEKASI',1),(275,'','2112-0000-1718','abid1','Muhammad Abid','6281931930742','6281931930742','SIDOREJO RT002RW002 SIDOREJO SEDAN','REMBANG',1),(276,'','2112-0000-1719','retno','Retno Rochinasih','62851035806666','62851035806666','Jl. Dwijaya 32 RtRw 036008 Klegen Kartoharjo','MADIUN',1),(277,'','2112-0000-1720','ardiansjah','Ardiansjah','6285100618885','6285100618885','Jl. Dwijaya 32 RtRw 036008 Klegen Kartoharjo','MADIUN',1),(278,'','2112-0000-1721','naufan','Muhammad Naufan Faikar','6289629098732','6289629098732','Perum Diren Jaya Blok C 165 Duren jaya Bekasi Timur','BEKASI',1),(279,'','2112-0000-1722','nabila','Devi Nabila','6285224401847','6285224401847','Buntet pesantren RtRw 011004 Mertapada kulon Astanajapura','CIREBON',1),(280,'','2112-0000-1723','nailul','Lulu Nailul Muna','6287897175504','6287897175504','Buntet pesantren RtRw 011004 Mertapada kulon Astanajapura','CIREBON',1),(281,'','2112-0000-1724','raden','Raden Imam Hanafi, Spd','6285295851682','6285295851682','Dusun 03 RtRw 001005 Pakusaben Babakan','CIREBON',1),(282,'','2112-0000-1725','nanik','Nanik Normaidah','6285230910153','6285230910153','Dsn Tanjek 001001 Tanjek Wagir Krembung','Bandung',1),(283,'','2112-0000-1726','komarudin','Komarudin','6285884559386','6285884559386','Kp.Rawa Bamban RT.02007 Jurumudi baru Benda','Tangerang',1),(284,'','2112-0000-1727','nizam','Nizam Gumawan Firdiansyah','62895703091556','62895703091556','Jln. Masjid Ar-Riyad RT.0204 Cipayung Ciputat','Tangerang Selatan',1),(285,'','2112-0000-1728','abdal','Yusron Abdal Baqi','6285921531560','6285921531560','Jl. HM. Idrus II No. 83 Kp cikunir Jatikramat Jatiasih','BEKASI',1),(286,'','2112-0000-1729','yasin','Yasin','6281380182926','6281380182926','Jl. Mushollah Arrohman RtRw 002004 Jatibening Baru Pondok Gede','BEKASI',1),(287,'','2112-0000-1730','qusyairy','Achmad Qusyairy','6285920758306','6285920758306','Kp Cibening 004002 Jatibening Baru Pondok Gede','BEKASI',1),(288,'','2112-0000-1731','arifainur','Arif Ainur Rofiq, MPD.','6282232222097','6282232222097','Wisma Lidah Kulon Blok B92 Lida Kulon Lakarsantri','SURABAYA',1),(289,'','2112-0000-1732','malinda','Malinda','6282245972313','6282245972313','Simokerto Tebasan No. 9 Tambakrejo Simokerto','SURABAYA',1),(290,'','2112-0000-1733','damayanti','Vika Damayanti','6285850224220','6285850224220','Dk Kramat 225 Jajar Tunggal Wiyung','SURABAYA',1),(291,'','2112-0000-1734','mzainul','Moch Zainul Arifin','6281330424890','6281330424890','Jemur Wonosari Gg. Masjid Jemur Wonosari Wonocolo','SURABAYA',1),(292,'','2112-0000-1735','ilah1','ILAH','6281991848169','6281991848169','Kp. Resmi Galih RTRW 002001 Batujajar Timur Batujajar','BANDUNG BARAT',1),(293,'','2112-0000-1736','farhan','Farhan Fathurrahman','6282335517419','6282335517419','Perum GPP Blok N9-06 RtRw 001010 Pamengkang Mundu','CIREBON',1),(294,'','2112-0000-1737','sahmans','Sahman Sabirin','6281212754552','6281212754552','Jln. Swadaya 9 blok B no.30 RT.009001 Jati Cempaka Pondok Gede','BEKASI',1),(295,'','2112-0000-1738','sujani','Sujani','6282233443452','6282233443452','Gunungsari Indah PP-11 Kedurus Karangpilang','SURABAYA',1),(296,'','2112-0000-1739','handayani','Sri Handayani','6282333589683','6282333589683','Jl. Nori No. 39 RtRw 001001 Nambangan lor Mangunharjo','MADIUN',1),(297,'','2112-0000-1740','nurfatmawati','Heny Nurfatmawati','6282230215151','6282230215151','Heny Nurfatmawati Manisrejo Taman','MADIUN',1),(298,'','2112-0000-1741','nurmaulida','Nur maulida Dina rahmani','6289678429403','6289678429403','Wedoro madrasah RT 002003 Wedoro waru','SIDOARJO',1),(299,'','2112-0000-1742','imastita','Imas Tita Rosita','6283100523819','6283100523819','Jln.Kayu Agung Ii no 12 Turangga Lengkong','BANDUNG',1),(300,'','2112-0000-1743','tifanieka','Tifani Eka anggraini','6281259085251','6281259085251','Karangrejo baru 47 Wonokromo','SURABAYA',1),(301,'','2112-0000-1744','cecillia','Cecillia Martha Triana','6287857064467','6287857064467','Griya kencana III HH21 Mojosarirejo Driyorejo','GRESIK',1),(302,'','2112-0000-1745','utrica','Utrica meidina fani','6285704545253','6285704545253','Jl. Wilis F 44 Kepuhkiriman Waru','SIDOARJO',1),(303,'','2112-0000-1746','nuraindini','Isa nur aindini','6285604091868','6285604091868','Dsn. Kademangan Dlanggu','MOJOKERTO',1),(304,'','2112-0000-1747','arviany','Arviany renandhita priambudi','6281335648645','6281335648645','Dsn. Bandung kulon RT 001003 Pagerejo Ngadirejo','Pacitan',1),(305,'','2112-0000-1748','afifah','Afifah Kartika sari','6285707179584','6285707179584','Gubeng Kertajaya 11 D15 Airlangga Gubeng','SURABAYA',1),(306,'','2112-0000-1749','denisa','Denisa ramadina meustoro','6281259098161','6281259098161','Kedung Bajul RT 001006 Kalianyar Kertosono','Nganjuk',1),(307,'','2112-0000-1750','pranata','Pranata Hadi chandra','6281217413262','6281217413262','Perum istana megasari D-46 Sumokali Candi','SIDOARJO',1),(308,'','2112-0000-1751','amanda','Amanda novitasari','6283857277950','6283857277950','Plastuk Donomulyo utara 1A69 Sidotopo Wetan','SURABAYA',1),(309,'','2112-0000-1752','shafaaulia','Shafa Aulia hasnaningrum','6285735177157','6285735177157','Karangrejo timur 437 Wonokromo','SURABAYA',1),(310,'','2112-0000-1753','umikhoridah','Umi Khoridah','6281233203574','6281233203574','JL. Suropati 003013 Wajak','MALANG',1),(311,'','2112-0000-1754','ekaaruma','Eka Aruma Widya Ningsih','6285696341143','6285696341143','Dsn Rawan 012006 Tanjekwager Krembung','SIDOARJO',1),(312,'','2112-0000-1755','nilasari','nilasari Istiqomah','628983643495','628983643495','Dsn Kedunglo 014007 Kedungrawan Krembung','SIDOARJO',1),(313,'','2112-0000-1756','indahkhoirun','Indah Khoirun Nisa','6281242262085','6281242262085','Dsn Rawan 013006 Tanjekwager Krembung','SIDOARJO',1),(314,'','2112-0000-1757','ismakhun','Ismakhun','6282228012645','6282228012645','Dsn Rawan 011006 Tanjekwager Krembung','SIDOARJO',1),(315,'','2112-0000-1758','nurulhidayati','Nurul Hidayati','6281230125957','6281230125957','Dsn Rawan 011006 Tanjekwager Krembung','SIDOARJO',1),(316,'','2112-0000-1759','silviya','Silviya Indriyani','6285730938252','6285730938252','Dsn Kedunglo 014007 Kedungrawan Krembung','SIDOARJO',1),(317,'','2112-0000-1763','ismail','Ismail','6281252602265','6281252602265','Dusun Jagalan RtRw 002002 Karangsono Sukorejo','Pasuruan',1),(318,'','2112-0000-1836','imron','IMRON WAHYUDI, S. KOM','6285607544266','6285607544266','Jl. MUHARTO GG 7 RT004RW010 KOTALAMA Kedungkandang','MALANG',1),(319,'','2112-0000-1760','lulut','LULUT HARYONO','6281334719118','6281334719118','Jl. Adi setia no 36 rt 04 rw 01 Ardirejo Kepanjen','Malang',1),(320,'','2112-0000-1761','sutomo','Sutomo B Nurhamidin','6282215222069','6282215222069','Villa Bekasi Indah blok E1 no.14 RT 007012 Mangun jaya Tambun Selatan','BEKASI',1),(321,'','2112-0000-1764','ainunluthfi','Muhammad Ainun Luthfi','628883578236','628883578236','Dusun Karangsono RtRw 003005 Karangsono Sukorejo','Pasuruan',1),(322,'','2112-0000-1762','rano01','Rano Handoko','6281218457177','6281218457177','Jatirasa tengah RtRw 003005 Karangpawitan karawang Barat','KARAWANG',1),(323,'','2112-0000-1765','sahman','Sahman Sabirin','6281212754552','6281212754552','Swadaya 9 Blok B No. 30 Jaticempaka Pondok Gede','BEKASI',1),(324,'','2112-0000-1766','warum','Warum','6281315008105','6281315008105','Jl. P. Karimun Jawa XII No. 214 Aren Jaya Bekasi Timur','BEKASI',1),(325,'','2112-0000-1767','arfina','Dra. Arfina Maulita','6282195872800','6282195872800','Perum Guriang Permai blok E 8 Duren jaya Bekasi Timur','BEKASI',1),(326,'','2112-0000-1768','nuryasin','Nur Yasin','6285101669175','6285101669175','JL. Getek 023003 Sukorejo Gondanglegi Sukorejo Gondanglegi','MALANG',1),(327,'','2112-0000-1769','tajuislami','Muhammad Taju Islami','6285736146176','6285736146176','Bokor 014 005 Bokor Tumpang Bokor Tumpang','MALANG',1),(328,'','2112-0000-1770','anifa','Anifa','6283831077203','6283831077203','Kendung 9 no. 17 Sememi Benowo','SURABAYA',1),(329,'','2112-0000-1771','bambangs','Bambang soegiarto','6287884273596','6287884273596','Pesona permata ungu C 22 Tempel Krian','SURABAYA',1),(330,'','2112-0000-1774','ellwyn','Ellwyn Dyana Amnetta','628151636947','628151636947','Margahayu Jaya Blok E No. 30 Margahayu Bekasi Timur','BEKASI',1),(331,'','2112-0000-1775','euisfitriani','Euis Fitiriani','628112066275','628112066275','Jl. Asrama Nyantong No. 103 RtRw 0307 Kahuripan Tawang','TASIKMALAYA',1),(332,'','2112-0000-1776','yesa1','Yesa Nabila marsitoh','6285816142276','6285816142276','Dukuh talang RT 003001 Selotinatah Ngariboyo','MAGETAN',1),(333,'','2112-0000-1777','umykhoiriyah','Umy khoiriyah','6285234278951','6285234278951','Jl. Sumber rt 02 rw 04 Panggungrejo Kepanjen','MALANG',1),(334,'','2112-0000-1778','istini','Istini','6281280521217','6281280521217','Jl. P Kalimantan 4 No. 141 Perum III Setia Mekar Aren Jaya Bekasi Timur','BEKASI',1),(335,'','2112-0000-1779','yayueka','Yayu Eka Muthia Rahayu','6281283830117','6281283830117','Bumi Sani Parmai Blok B2 No. 20 Setia Mekar Bekasi Timur','BEKASI',1),(336,'','2112-0000-1781','haryati','Haryati','628129776947','628129776947','Wisma Jaya Kusuma Timur 3 Blok F9 No. 17 Aren Jaya Bekasi Timur','BEKASI',1),(337,'','2112-0000-1782','pipih','Pipih Hodayati','6281219586982','6281219586982','Permata Griya Satria Blok G 5 No. 5 Karangsatria Tambun Utara','BEKASI',1),(338,'','2112-0000-1783','wiwikarif','Wiwik Arif Budiono','628128806096','628128806096','Jl. Kampus Unkris No. 122 RtRw 005009 Jaticempaka Pondok Gede','BEKASI',1),(339,'','2112-0000-1785','suratmin','Suratmin, Drs','628125278462','628125278462','Jln. Sidomulyo no 62 rt 01 rw 01 NGADILANGKUNG Kepanjen','MALANG',1),(340,'','2112-0000-1786','adeahmad','Ade Ahmad','6281904051196','6281904051196','Jl. Taman Duta VII Blok E9 No. 1 RtRw 07014 Tugu Ciamis','DEPOK',1),(341,'','2112-0000-1787','agusmulyono','Agus Mulyono','6285267709777','6285267709777','Jl. Kali Kesik RtRw 001000 Watervang Lubuk Linggau Timur I','LUBUK LINGGAU',1),(342,'','2112-0000-1788','etysuhartini','Ety Suhartini','6281357986559','6281357986559','Perum Bumi Mas 2 Blok QQ No. 1 RtRw 059014 Mojorejo Taman','Madiun',1),(343,'','2112-0000-1789','sanatanadharma','Sanatana Dharma','6288809865271','6288809865271','Jl. P. Singkep Raya No 12 RtRw 009016 Aren Jaya Bekasi Timur','BEKASI',1),(344,'','2112-0000-1948','aqidatul','AQIDATUL IZZAH','6282247746802','6282247746802','Jl. KI AGENG BRIBIG I 001003 Madyopuro Kedungkandang','MALANG',1),(345,'','2112-0000-1792','ardafa','Ardafa Nabil Makharim','6287887973004','6287887973004','Perum Bumi Mas 2 Blok QQ No. 1 RtRw 059014 Mojorejo Taman','Madiun',1),(346,'','2112-0000-1884','chotijah','Siti Chotijah','6282132367906','6282132367906','Jl. Sidomulyo 006002 Pagentan Singosari','MALANG',1),(347,'','2112-0000-1883','marfatus','Laila Marfatus Sholikha','628950677775','628950677775','Jl. Slimpi  purwodadi Blimbing','Malang',1),(348,'','2112-0000-1885','muamar','Muamar','6281234803304','6281234803304','Sumber Sekar Gang Dahlia 222 Kalirejo Lawang','MALANG',1),(349,'','2112-0000-1922','mutamakin','AHMAD MUTAMAKIN','6289603533849','6289603533849','Ngenep Krajan 003001 Ngenep Karang Ploso','MALANG',1),(350,'','2201-0000-1947','zuchi','Zuchi Permata Putri','6282113492227','6281806109259','Jl. Akasia raya blok J28 perum pondok hijau permai Pengasinan Rawa Lumbu','BEKASI',1),(351,'','2201-0000-1946','irham','Irham nurrohim','6282135460618','6282135460618','Klodangan Klodangangondang wetan Pasrepan','Pasuruan',1),(352,'','2112-0000-1945','aditya','Aditya Saputra','6287808755715','6287808755715','Kav. Perwirasari jl mawar IV 013008 Perwira Bekasi Utara','BEKASI',1),(353,'','2112-0000-1944','nuridayati','nur hidayati','628123456834','628123456834','Areng areng selatan Sambisirah Wonorejo','PASURUAN',1),(354,'','2112-0000-1943','fauszan','H.a,fauszan','6281233230249','6281233230249','Sambisiarah timur Sambisirah Wonorejo','PASURUAN',1),(355,'','2112-0000-1942','yulis','Yulis mauliyana','6282338924809','6282338924809','Jembatan baru Gladak anyar Pamekasan','Pamekasan',1),(356,'','2112-0000-1941','yenni','Yenni dwi cahyani','6283134777252','6283134777252','Jembatan baru Gladak anyar Pamekasan','Pamekasan',1),(357,'','2112-0000-1940','samsiyah','Yayuk rusamsiyah','628175296939','628175296939','Jembatan baru Gladak anyar Pamekasan','Pamekasan',1),(358,'','2112-0000-1939','herawati','Rini herawati','6282334889919','6282334889919','Bunder timur Bunder Pademawu','Pamekasan',1),(359,'','2112-0000-1938','permana','Indra Permana','6281235549455','6281235549455','Dsn Tepas 001003 Tepas Kesamben','JOMBANG',1),(360,'','2112-0000-1937','fikaayu','Fika Ayuningtyas putih','6281568485275','6281568485275','Jl. Raya Joglo gg. Mushola 004008 Jogo Kembangan','Jakarta Barat',1),(361,'','2112-0000-1936','juhairiyah','Nanik juhairiyah','6285964085889','6285964085889','Bunder timur Bunder Pademawu','Pamekasan',1),(362,'','2112-0000-1935','dewikurniati','Dewi kurniati','6281214774582','6281214774582','Kp. Sunarmukti 003004 Selacau Batujajar','BANDUNG',1),(363,'','2112-0000-1934','prasulis','Prasulis Budi Hernowo','6281226646622','6281226646622','Jl. Sidanegara IV no 13 rtrw 003006 Putwokerto  Kulon Purwokerto Selatan','BANYUMAS',1),(364,'','2112-0000-1933','sufiatin','Endang sufiatin','6281999564150','6281999564150','Jl.alun alun utara 5 Bangilan Panggungrejo','PASURUAN',1),(365,'','2112-0000-1932','resmana','Etty Resmana','6285655282846','6285655282846','Griya Candra Mas EB03 Ds. Pepe Sedati','SIDOARJO',1),(366,'','2112-0000-1931','linda','Linda Rahmawati','6282210107778','6282210107778','Deles IV No. 36 Klampis Ngasem','SURABAYA',1),(367,'','2112-0000-1930','sukma','Sukma','6281256860540','6281256860540','Cilelang 000000 Cilelang Mallusetasi','Barru',1),(368,'','2112-0000-1929','fahdi','Fahdi Rahadian','6282221077773','6282221077773','Bekasi tengah 003006 Margahayu Bekasi Timur','Bekasi',1),(369,'','2112-0000-1928','winarti','Winarti','6285334865174','6285334865174','Dsn. Rayung RT 0903 Bulurejo Benjeng','Gresik',1),(370,'','2112-0000-1927','didiksantoso','DIDIK SANTOSO','6285257092588','6285257092588','Jl.alun alun utara 5 Bangilan Panggungrejo','PASURUAN',1),(371,'','2112-0000-1926','rudirus','Rudy rus supriyanto','6285227707992','6285227707992','Dusun ploso 002001 Plosorejo Tawangharjo','GROBOGAN',1),(372,'','2112-0000-1925','nurmawati','Nurmawati','6282229051864','6282229051864','Kedung anyar 9  40 Sawahan','SURABAYA',1),(373,'','2112-0000-1821','umriyasa','Umri yasa, SE, MM','081285432059','6281381949539','Jl. Akasia Raya Blok J 2 ni. 8 Pengasinab Rawalumbu','Bekasi',1),(374,'','2112-0000-1820','taufikrahman','M. Taufik Rahman','628128236789','628128236789','Jl. Campedak selatan IIE-615 Pengasinan Rawa Lumbu','Bekasi',1),(375,'','2202-0000-1979','suryatanu','Bugi Suryatanu','6287871270131','6287871270131','Jl. Bogonia indah blok Q-I No.7 Kedungwaringin Tanah Sarael','BOGOR',1),(376,'','2203-0000-1980','indahmustika','Indah Mustika A','628223330977','628223330977','Krajan 56 Krajan Tengah Dampit','Malang',1),(377,'','2206-0000-1981','ahaliem','ABDOEL HALIEM','6281803000025','6281803000025','Sukodono I 29 RT. 001 RW. 015 Ampel Semampir Surabaya','SURABAYA',1),(378,'','1501-0000-0034','umrohku','M HIDAYATULLOH','6285731618872','6285731618872','Perum jaya regency blok BD 33 PP','SIDOARJO',1),(379,'','2202-0000-1982','sumiati','Hj. Sumiati','6281210418188','6281210418188','Birmis Cisauk Cisoka Tanggarang','Banten',1),(380,'','2207-0000-1989','alief','Muhammad Alief Fitral','6285893644425','6285893644425','Jl.Masjid Alwudtho Rt.07 R07','KOTA ADM. JAKARTA TIMUR',1),(381,'','2207-0000-1987','sudewi','Sudewi','628158080622','628158080622','Jl. Dahlia Blok c234 Perum Duta Kranji','KOTA BEKASI',1),(382,'','2206-0000-1983','ningsumarsih','Ning sumarsih','6282324889810','6282324889810','Candiwulan Rt 04 Rw 01','KAB. BANJARNEGARA',1),(383,'','2207-0000-1985','satirah','SATIRAH','6285975074438','6285975074438','DUKUH KRAJAN 003001 KALIURIP','KAB. BANJARNEGARA',1),(384,'','2207-0000-1984','hudi01','Hudi','6281391074647','6281391074647','BANJARKULON 003003','KAB. BANJARNEGARA',1),(385,'','2207-0000-1986','satiman','SATIMAN','6285786492115','6285786492115','DUSUN 1 003001 Kaligondang','KAB. PURBALINGGA',1),(386,'','2207-0000-1988','rrastutik','RR. Astuti Mardiyani','6287889925583','6287889925583','Reni jaya Blok H13-3 Pondok Petir Bojong Gede','KAB. BOGOR',1),(387,'','2207-0000-1990','ikhwand','H. Ikhwan Darmawan','6285781502810','6285781502810','Bermis serpong asri blok B321 rt 00404 cisauk','KAB. TANGERANG',1),(388,'','2207-0000-1991','agusr','Agus Rohman','6281332426569','6281332426569','Jl. Melati Rt 19 Rw 03 Geger','KAB. MADIUN',1),(389,'','2112-0000-1903','jayaningsih','Jayaningsih, SE','6282123598133','6282123598133','Jl. Akasia raya blok J28 perum pondok hijau permai','KOTA BEKASI',1),(390,'','2207-0000-1992','ssuroso','Slamet Suroso','6281391522500','6281391522500','Kalikajar rt 002008 Kalikajar Kaligondang','Purbalingga',1),(391,'','2207-0000-1993','komari','Komari','6282221688008','6282221688008','Bancar 003006 Bancar Purbalingga','Purbalingga',1),(392,'','2207-0000-1994','asepsaepul','Asep Saepul','6281280518871','6281280518871','Jln. Margonda Raya Rt 006Rw 003 Beji','KOTA DEPOK',1),(393,'','2112-0000-1866','slinda','Hj Siti Lindayani','62818088875088','62818088875088','Jl Durian blok L-4 Mekarsari Cimanggis','KOTA DEPOK',1),(394,'','2112-0000-1815','arrin','Arrin Yuliana','6281210377529','6281210377529','Jl. Pete Iii no 192 Pulo Kebayoran Baru','KOTA ADM. JAKARTA SELATAN',1),(395,'','2207-0000-1995','hasbi','Drs. AAS HASBI AS SHIDIQ','6281287851525','628161443841','Jl. Dahlia 1 Blok F1 No.14 PHP Pengasinan Rawa Lumbu','Kota Bekasi',1),(396,'assets/images/member/1__Logo_Brand.jpeg','2207-0000-1998','sariayu01','Sari Ayu Andharwati','081287826565','6281287826565','JL. Merpati blok Z1 No. 18','KOTA DEPOK',1),(397,'assets/images/member/1__Logo_Brand1.jpeg','2207-0000-1999','ekodarma01','Eko Darma Putra','082226552499','6282226552499','Jl. Nuri blok w no. 4 009002 Mekarsari Cimanggis','KOTA DEPOK',1),(398,'','2207-0000-1997','khairiluthfi','Khairi Luthfi','082299059177','6282299059177','JL. Irigasi taman 2 D10 8 bekasi jaya','Bekasi',1),(399,'','2207-0000-1996','anisaal','Anisa Albakir','6281289558970','6281289558970','Perum Duren Jaya Blok C No. 145 Duren Jaya Bekasi Timur','Bekasi',1),(400,'','2207-0000-2000','imamuddin','IMAMUDDIN','6287886186463','6287886186463','JL. Jambu permai 5 blok I148 Bojong Rawalumbu','Bekasi',1),(401,'assets/images/member/qfRHu1SE_400x400.jpg','2207-0000-2001','yasman01','Yasman','081290473182','6281290473182','Jl. Joe GG.H.Mael Rt09 Rw08 No.29','JAKARTA SELATAN',1),(402,'assets/images/member/1__Logo_Brand2.jpeg','2207-0000-2002','nina01','Nina','081211438566','6281211438566','Jl.Gongseng Raya GG.H.JIPIN Rt 07 Rw 010','KOTA ADM. JAKARTA TIMUR',1),(403,'assets/images/member/1__Logo_Brand3.jpeg','2207-0000-2003','syafri01','Achmad Syafri','0811815323','62811815323','Jl.Remaja Rt 002 Rw 001 No.51','KOTA ADM. JAKARTA TIMUR',1),(404,'assets/images/member/1__Logo_Brand4.jpeg','2207-0000-2004','nashihun01','Muhammad Nashihun Amin','6285694668830','6285694668830','Perum Duren Jaya Jl. Akasia V C 165','KOTA BEKASI',1),(405,'assets/images/member/WhatsApp_Image_2022-07-06_at_09_14_24.jpeg','2207-0000-2006','jumadi01','Jumadi, S. Pd','6281383680471','6281383680471','Jl. H. Ilyas No. 30 RTRW 002010','KOTA ADM. JAKARTA SELATAN',1),(406,'assets/images/member/WhatsApp_Image_2022-07-06_at_09_14_241.jpeg','2207-0000-2005','nurlaila01','Nurlaila','6281291211650','6281291211650','Jl dahlia 1 blok f.114 rt 0515 php','KOTA BEKASI',1),(407,'','2207-0000-2007','erlinanand','ERLINA NANDIKA','628111611710','628111611710','JL. GURAME IV NO.316 007009 DEPOK JAYA PANCORAN MAS','KOTA DEPOK',1),(408,'','2207-0000-2008','gitaparwita','GITA PARWITA SARI','628119321056','628119321056','GG SEJAHTERA NO.18  006002 RANGKAPAN JAYA BARU PANCORAN MAS','KOTA DEPOK',1),(409,'assets/images/member/WhatsApp_Image_2022-07-06_at_09_14_242.jpeg','2207-0000-2009','samanhudi01','SAMANHUDI W PANGGUCI AHT','6281287674600','6281287674600','l. Balap Sepeda LRG Muhajirin III No. 18-1427 Rt.025 Rw 007','KOTA PALEMBANG',1),(410,'assets/images/member/WhatsApp_Image_2022-07-06_at_09_14_243.jpeg','2207-0000-2010','amalia01','Amalia Rachmadanty','6281317302893','6281317302893','Prima Harapan Regency Blok B433','KOTA BEKASI',1),(411,'assets/images/member/1__Logo_Brand5.jpeg','2207-0000-2011','andri01','Andri Rivelino','6281296903109','6281296903109','Jln. Kebagusan 3 GG. Melati RT.005 RW.05','KOTA ADM. JAKARTA SELATAN',1),(412,'assets/images/member/logo_aminah.png','2207-0000-2012','moha0011','Mohammad Ageng Riadi','085727531367','6285727531367','Srikandi RT 003 RW.01','KAB. BANJARNEGARA',1),(413,'assets/images/member/logo_aminah1.png','2207-0000-2013','soch0001','sochadi','081284784669','6281284784669','Mandiraja wetan RT.005 RW.001','KAB. BANJARNEGARA',1),(414,'assets/images/member/logo_aminah2.png','2207-0000-2014','siti0055','Siti Ajiningsih','082137940668','6282137940668','Purwareja RT.003 RW. 006','KAB. BANJARNEGARA',1),(415,'assets/images/member/logo_aminah3.png','2207-0000-2015','sadi0001','Sadirun','089616837408','6289616837408','Kecitran RT.003 RW.002','KAB. BANJARNEGARA',1),(416,'assets/images/member/logo_aminah4.png','2207-0000-2016','daff0001','Daffa Satriani Lumban Tobing','085157887177','6285157887177','Blok Sawo RT.002 RW 003','KOTA DEPOK',1),(417,'assets/images/member/logo_aminah5.png','2207-0000-2017','trib0001','Tri Bayu Ningsih','085313763713','6285313763713','Jln. Pisangan lama 3 RT.010 RW 011','JAKARTA TIMUR',1),(418,'assets/images/member/logo_aminah6.png','2207-0000-2018','muha0042','Muhammad Syahnan.SH','085386946417','6285386946417','Jln. Pisangan lama 3 RT.010 RW 011','JAKARTA TIMUR',1),(419,'assets/images/member/logo_aminah7.png','2207-0000-2019','ratn0004','RATNA SARI','087781647672','6287781647672','JL. BEGONIA INDAH BLOK Q-1 NO.7','BOGOR',1),(420,'assets/images/member/logo_aminah8.png','2207-0000-2020','evis0001','EVI SUCIATI','081808156886','6281808156886','PESING KENONG 014008','ADM. JAKARTA BARAT',1),(421,'assets/images/member/logo_aminah9.png','2207-0000-2021','fiaa0001','Fia Andriani','082110808890','6282110808890','Jln. Mulawarman no.7 RT.015 RW.000','BALIKPAPAN',1),(422,'assets/images/member/logo_aminah10.png','2207-0000-2022','aces0001','ACE SUDRAJAT HAROEN','085846016040','6285846016040','JL. MULIA NO. II 61','BANDUNG',1),(423,'assets/images/member/logo_aminah11.png','2207-0000-2023','dery0001','Dery Bagja Sukma Putra','08113151800','628113151800','Griya Anggraini F.13 10','BOGOR',1),(424,'assets/images/member/logo_aminah12.png','2207-0000-2024','siti0056','Siti Sopiah','088295500047','6288295500047','Jl. Pepaya I 65','DEPOK',1),(425,'assets/images/member/logo_aminah13.png','2207-0000-2025','siti0057','Siti Masngadah','085327946433','6285327946433','Banjar kulon RT.003 RW.003','KAB. BANJARNEGARA',1),(426,'assets/images/member/logo_aminah14.png','2207-0000-2026','wars0001','Warsono','087850543421','6287850543421','Dukuh Krajan RT.003 RW.001','KAB. BANJARNEGARA',1),(427,'assets/images/member/logo_aminah15.png','2207-0000-2027','muhh0001','Muh Hidayatulloh','082135981619','6282135981619','Glempang RT 003 RW.004','KAB. BANJARNEGARA',1),(428,'assets/images/member/logo_aminah16.png','2207-0000-2028','muha0043','Muhadi','081391655611','6281391655611','Candiwulan RT.003 RW.002','KAB. BANJARNEGARA',1),(429,'assets/images/member/logo_aminah17.png','2207-0000-2029','srih0003','Sri Harti','081327969715','6281327969715','Babakan RT.015 RW.004','KAB. PURBALINGGA',1),(430,'assets/images/member/logo_aminah18.png','2207-0000-2030','sumi0008','Suminah','085713608467','6285713608467','Kertayasa RT.006 RW.004','KAB. BANJARNEGARA',1),(431,'assets/images/member/logo_aminah19.png','2207-0000-2031','enis0001','Eni Sutresno Ningsih','081310118223','6281310118223','Simbang RT.004 RW.001','KAB. BANJARNEGARA',1),(432,'assets/images/member/logo_aminah20.png','2207-0000-2032','dita0002','Dita yunitasari','082137375510','6282137375510','Candiwulan RT.004 RW.001','KAB. BANJARNEGARA',1),(433,'assets/images/member/logo_aminah21.png','2207-0000-2033','yoyo0001','YOYON YUSWADI','085234999009','6285234999009','JINTEN NO. 16','SURABAYA',1),(434,'assets/images/member/logo_aminah22.png','2207-0000-2034','titi0003','TITIK RODIAH','081216178037','6281216178037','PERMANU','MALANG',1),(435,'assets/images/member/logo_aminah23.png','2207-0000-2035','rick0001','RICKY ANGGA PRIYAMBUDI, SE.','081239239293','6281239239293','PERUM. JOYO ASRI BLOK J-1','MALANG',1),(436,'','1804-0000-1081','joes01','JOES SULISTYORINI','6281934674008','6281934674008','Wonokromo','SURABAYA',1),(437,'','1705-0000-0725','herriamin','HERRI MUHAMMAD AMIN','628124208464','628124208464','MASOLO RT.001 RW.001 MASOLO PATAMPANUA','PINRANG - SULSEL',1),(438,'','2210-0000-2036','sawidji','Sawidji Kurniawan','6281219286291','6281219286291','Krandon Kalinongko Loano','KAB. PURWOREJO - JATENG',1),(441,'assets/images/member/WhatsApp_Image_2022-11-16_at_14_21_54.jpeg','2211-0000-2038','msarbini','M. SARBINI','6281915646467','6281915646467','JL. KERAPU 1 NO. 23 SUMENEP','KAB. SUMENEP',1),(442,'assets/images/member/WhatsApp_Image_2022-11-16_at_14_21_541.jpeg','2211-0000-2037','mrohimin','MOHAMMAD ROHIMIN','6282245294402','6282245294402','Dusun Karangsono RT 02 RW 01, Desa Karangsono. Kec. Sukorejo. Kab Pasuruan','KAB. PASURUAN',1),(443,'','2211-0000-2040','martinandika','MARTIN ANDIKA','6281317589542','6281317589542','Jl. SENTOSA NO 14 RT 003 RW 001 MUNJUL Cipayung','KOTA ADM. JAKARTA TIMUR',1),(444,'','2211-0000-2041','fadilahend','FADILA HENDRIYANTO','6282112948303','6282112948303','JL SUMPIL I8 Purwodadi Blimbing','Malang',1),(445,'','2211-0000-2042','hildaprafika','HILDA PRAFIKA SARI','6282228921694','6282228921694','DUKUH BANYU URIP RT 006 RW 0009 Pagak','Malang',1),(446,'','2211-0000-2043','arindyosa','GILIH TESKA ARINDY OSA REZANDA','6282220310935','6282220310935','DUSUN PALANG RT 001 RW 005 Lembang Sukorejo','Pasuruan',1),(447,'','2211-0000-2044','miqbal','MUHAMMAD IQBAL','628987068045','628987068045','LINGK. LANGKA PANCAR RT 002 RW 003 Bojongkatnong','Kota Banjar',1),(448,'','2211-0000-2045','hjsupinah','Hj Supinah','6282140153336','6282140153336','Pagerwojo 0502 Pagerwojo Buduran','SIDOARJO',1),(449,'','2211-0000-2046','pujihariadi','Puji Hariadi','6285648092687','6285648092687','Wijaya Kusuma Sekar Putih Pendem Junrejo','Batu',1),(450,'','2211-0000-2047','afifatuzzahroh','Afifatuzzahroh','6281238603069','6281238603069','Talang Wonosari Gempol','PASURUAN',1),(451,'','2211-0000-2048','ismariyah','ISMARIYAH','6289654220364','6289654220364','Langlang Singosari','Malang',1),(452,'','2211-0000-2049','sitiaminatul','Siti Aminatul','6285707979270','6285707979270','Jl. Sumpil I34 Purwodadi Blimbing','Malang',1),(453,'','2211-0000-2050','eduarda','Eduarda Roosilawati, SM.FC','6282333543875','6282333543875','JL. Sumpil II 56B Purwodadi Blimbing','Malang',1),(454,'','2211-0000-2052','msuyutidahlan','M. SUYUTI DAHLAN','6285646557662','6285646557662','GUNUNG PETUNG TUTUR','PASURUAN',1),(455,'','2211-0000-2051','mokhrifai','Mokhamad Rifai','6285877842251','6285877842251','PEDES LEBAKREJO PURWODADI','PASURUAN',1),(456,'','2211-0000-2053','mohkhoironi','MOH KHOIRONI','6281238887368','6281238887368','SEPINGAN BARU BALIKPAPAN SELATAN','BALIKPAPAN',1),(457,'','2211-0000-2054','sitijuariyah','SITI JUARIYAH','6282132869904','6282132869904','Dusun Karangsono RT 03 RW 01 , Karangsono Sukorejo','KAB. PASURUAN',1),(458,'','2211-0000-2055','didahendra','DIDA HENDRA LUKMANA','6285648544814','6285648544814','Dan Karangsono 003001 Karangsono Sukorejo','Pasuruan',1),(459,'','2211-0000-2056','lusiamaria','Lusia Maria P','6285856613843','6285856613843','Jl Sumpil 2 no. 56B Purwodadi Blimbing','Malang',1),(460,'','2211-0000-2057','sitiaisyah','Siti Aisyah','6285102127464','6285102127464','Dsn Kalimalang 1604 Tawangargo Karangploso','Malang',1),(461,'','2211-0000-2058','husniati','Husniati','6282245659678','6282245659678','Krajan 56 Tlengkung Junrejo','Batu',1),(462,'','2211-0000-2059','achzamach','Achmad Zamach Syari','6285337404527','6285337404527','Dk Ngenep 002001 Ngenep Karang Ploso','Malang',1),(463,'','2211-0000-2060','idhoocta','Idho Octa Kurniawan, SE','6281252506541','6281252506541','perum TSK Cluster Merkurius A25 Tulangan','SIDOARJO',1),(464,'','2211-0000-2061','sitinurasih','Siti Nurasih','6281333409789','6281333409789','Gubugklakah 001003 Gubugklakah Poncokusumo','MALANG',1),(465,'','2211-0000-2062','wijichodijah','Wiji Chodijah','6285748032129','6285748032129','Sumber suko 001002 Bandung Diwek','Jombang',1),(466,'','2211-0000-2063','saptobudi','Sapto Budiwasono','6282232984301','6282232984301','Jl Adi Santoso 201 Kepanjen','MALANG',1),(467,'','2211-0000-2064','mfuad','Muhammad Fuad','6281555933421','6281555933421','Kedondong No. 17 Turi Sukorejo','Blitar',1),(468,'','2211-0000-2065','almuhadjirin','AL Muhadjirin','6285791454917','6285791454917','Ngranah Seng reng Sumberpucung','Malang',1),(469,'','2211-0000-2066','anitarita','Anita Rita','62818538561','62818538561','Sidomulyo II43 purwodadi blimbing','Malang',1),(470,'','2211-0000-2067','ekaprihatini','Eka Prihatini','6282257495521','6282257495521','Jl Kawi Mancity Mangunrejo Kepanjen','Malang',1),(471,'','2211-0000-2068','andisaifudin','Andi Saifudin','6281217008089','6281217008089','Ds Sareng 006001 Geger Madiun','Madiun',1),(472,'','2211-0000-2069','dwieas','Dwie Astutik','6281364564706','6281364564706','Jl. HM Sunan SH Penarukan Kepanjen','Malang',1),(473,'','2211-0000-2070','irmaagustin','Irma Agustini','628133308882','628133308882','Jl. Adi Santoso 020005 Sido rahayu Wagir','Malang',1),(474,'','2211-0000-2071','gatotsuwito','Gatot Suwito','6281233308882','6281233308882','Buntan 020005 Sido rahayu Wagir','Malang',1),(475,'','2211-0000-2072','ermonidros','Ermon Idros','6281311229435','6281311229435','Komplek Sawangan Permai jl Nuri Blok E832 Pasir Putih Sawangan','Depok',1),(476,'','2211-0000-2073','msodik','Muhammad Sodik','6285843840688','6285843840688','Sunan Ampel 101 Legok Sukoharjo Kepanjen','Malang',1),(477,'','2211-0000-2074','irfanlutfi','Irfan Lutfi','628123456789','628123456789','Ds Sareng Geger','Madiun',1),(478,'','2211-0000-2075','kusrianah','Kusrianah','6285103021166','6285103021166','Dsn Bunton 020005 Sido rahayu wagir','Malang',1),(479,'','2211-0000-2076','ratnadwi','Ratna Dwi Wulandari','6285749771609','6285749771609','Sareng Geger','Madiun',1),(480,'','2211-0000-2077','fatlinda','Fatlunda Nur Laili','6285231852485','6285231852485','Sareng Geger','Madiun',1),(481,'','2211-0000-2078','nuernafilah','Nuer Nafilah','6285706859107','6285706859107','Perum bumi ardimulyo T 11 Candirenggo Singosari','MALANG',1),(482,'','2211-0000-2079','fuadi','Mokhammad Khoirul Fuadi','6289524587994','6289524587994','Sumpil purwodadi blimbing','MALANG',1),(483,'','2212-0000-2080','diahsubadriyah','DIAH SUBADRIYAH','6285702119953','6285702119953','Jl. Muharto V B No. 135 Kotalama Kedungkandang','Malang',1),(484,'','2212-0000-2081','asrofi','Asrofi','6281235733327','6281235733327','Dsn Besole 002 001 Besole  Besuki','Tulungagung',1),(485,'','2212-0000-2082','miskan','Miskan','6281233651144','6281233651144','Binangun Bumiaji','Kota Batu',1),(486,'','2212-0000-2086','hendrosoeyoto','HENDRO SOEYOTO','6282257993888','6282257993888','BARUK UTARA 12 ND-43 002007 KEDUNG BARUK RUNGKUT','SURABAYA',1),(487,'','2212-0000-2087','sugihsuroso','SUGIH SUROSO HADIYUWONO','6281803267405','6281803267405','TAMAN SURYA AGUNG L-1 RT.005006 WAGE TAMAN','SIDOARJO',1),(488,'','2212-0000-2088','mamikmariana','MAMIK MARIANA','628121741428','628121741428','GADING BLOK F36 BOHAR TAMAN','SIDOARJO',1),(489,'','2212-0000-2089','erfiansyah','IR. ERFIANSYAH','628157602701','628157602701','DANAU BOGOR RAYA BLOK TH. 101 CIMAHPAR BOGOR UTARA','KOTA BOGOR - JAWA BARAT',1),(490,'','2212-0000-2090','rr_endang','RR Endang Susilowati','628165431939','628165431939','Taman Surya Agung L-1 RT 05 RW 06 Wage Taman','SIDOARJO',1),(491,'','2212-0000-2091','mnurali','MUHAMMAD NURALI','6285230980777','6285230980777','JL. SURYOPRANOTO NO. 3 RT.008008 PETOJO SELATAN','KOTA ADM. JAKARTA PUSAT',1),(492,'','2212-0000-2092','wahyudi','WAHYUDI','62895345880844','62895345880844','TAMAN SUKO ASRI 1 BLOK CC NO. 38 SUKO SUKODONO','SIDOARJO',1),(493,'','2212-0000-2093','nickydamara','NICKY DAMARA IRVAN MOHEDE','6282244681797','6282244681797','Penjaringan Timur III No. 6 (YPK Pandugo I Blok Pi-6) Rungkut','KOTA SURABAYA',1),(494,'','2212-0000-2094','aliefbagus','ALIEF BAGUS PRILIAMTONO','6287777888772','6287777888772','JL. SIDOSERMO INDAH II NO. 6-8 SIDOSERMO WONOCOLO','KOTA SURABAYA',1),(495,'','2212-0000-2095','roniismail','RONI ISMAIL','62811374598','62811374598','PANTAI MENTARI RC 3 RT. 001 RW. 004 KENJERAN BULAK','KOTA SURABAYA',1),(496,'','2212-0000-2096','mifhidayah','MIFTAKHUL HIDAYAH','6287817366887','6287817366887','JL. SANAN XI 33 PURWANTORO BLIMBING','MALANG - JAWA TIMUR',1),(497,'','2212-0000-2097','farghani','Farghani Icmiardhika','6281231379029','6281231379029','Jl Gundih 2 No.58, Bubutan','SURABAYA',1),(498,'','2212-0000-2103','rickysteven','Ricky Steven Teixar','628123233088','628123233088','Jl. Imam Bonjol No. 19 Karang Mumus Samarinda','Samarinda - Kaltim',1),(499,'','2301-0000-2104','sahuriku','LILIK PURNAMASARI','6285106027088','6287777786444','KALIBOKOR KENCANA 431 RT. 003 005 PUCANG SEWU GUBENG','SURABAYA',1),(500,'','2302-0000-2114','nafilah','NAFILAH KHUSNIA','6281235307775','6281235307775','Pandaan','PASURUAN',1),(501,'','2302-0000-2115','ariswija','ARIS WIJANARKO','628155074284','628155074284','JL. JAMBANGAN VII-E7 RT003 RW003','JABANGAN',1),(502,'','2302-0000-2116','niniklestari','NINIK LESTARI','6287761610373','6287761610373','GUBENG KLINGSINGAN GUBENG','SURABAYA',1),(503,'','2302-0000-2117','lestariutamiputri','LESTARI UTAMI PUTRI','6281212910900','6281212910900','TAMAN MANGU INDAH H 313 RT008 RW006 PONDOK AREN','TANGSEL',1),(504,'','2302-0000-2118','ratnatriastuti','RATNA TRIASTUTI, ST','6287854955000','6287854955000','RUNGKUT MENANGGAL HARAPAN K7 RT011 RW004 RUNGKUT MENANGGAL','SURABAYA',1),(505,'','2302-0000-2119','rosihananhar','ROSIHAN ANHAR','62813338983','62813338983','CITRA FAJAR GOLF D 7199 GEBANG','SIDOARJO',1),(506,'','2302-0000-2120','ekosamsul','EKO SAMSUL MUBAHSRI','6281359636489','6281359636489','BALONG BIRU RT002 RW004 BALONG BESUK DIWEK','JOMBANG',1),(507,'','2302-0000-2121','syarifatul','SYARIFATUL AISYAH','6281330355842','6281330355842','BOTOPUTIH 157-A RT 006RW 009 SIMOLAWANG SIMOKERTO','SURABAYA',1),(508,'','2302-0000-2122','azainalalim','ACHMAD ZAINAL ALIM','628123280402','628123280402','PONDOK WAGE INDAH IILL 25 WAGE','SIDOARJO',1),(509,'','2302-0000-2123','anas01','MUHAMMAD ANAS','6281333123059','6281333123059','GANG NIAGA 003002 PANDAAN','PASURUAN',1),(510,'','2302-0000-2124','retnowulandari','RETNO WULANDARI','6282233343702','6282233343702','KARANGAN JAYA II30 BABATAN WIYUNG','SURABAYA',1),(511,'','2302-0000-2125','rizkyarif','Rizky Arif','62881027017101','62881027017101','Jl. Asem 1 No. 16 Asemrowo','SURABAYA',1),(512,'','2302-0000-2126','mocherwin','Mochammad Erwin','6281230555853','6281230555853','Kupang Panjaan 38 Dr. Soetomo Tegalsari','SURABAYA',1),(513,'','2302-0000-2127','yanuarsetia','Yanuar setiawan','6285749653367','6285749653367','Dukuh menanggal Gayungan','SURABAYA',1),(514,'','2302-0000-2128','mustari','Mustari','6282161373909','6282161373909','Desa madya mulya RT. 11 DUSUN 03 kec. Lalan kab. Musi banyuasin provinsi sumatera selatan','MUSI BANYUASIN - SUMATERA',1),(515,'','2302-0000-2129','adammaulana','ADAM MAULANA ISHAK','6281330737378','6281330737378','SIDOSERMO I8A, RT002 RW001 SIDOSERMO Wonocolo','SURABAYA',1),(516,'','2003-0000-1458','sulistriningsih','Hj. Sulistriningsih','6282131712400','6282131712400','Krembung','SIDOARJO',1),(517,'','2302-0000-2130','arinaayuningtyas','ARINA AYUNINGTYAS','6281231919124','6281231919124','PAKIS GELORA 37-A DARMO WONOKROMO','SIDOARJO',1),(518,'','2302-0000-2131','wulanwardhana','WULUR WARDHANA','6283831775844','6283831775844','KARANGAN JAYA III8 BABATAN WIYUNG','SURABAYA',1),(519,'','2302-0000-2132','madeputri','MADE PUTRI MARTTINI','6281233535005','6281233535005','BANJAR KEMANTREN BUDURAN','SIDOARJO',1),(520,'','2302-0000-2133','endangsrie','ENDANG SRIE KATONI','6281357566054','6281357566054','KARANGAN JAYA 262 BABATAN WIYUNG','SURABAYA',1),(521,'','2302-0000-2134','misbakhuddin','MISBAKHUDDIN, SE','6281233721190','6281233721190','DSN. SEDATI RT.001RW.002 SEDATI NGORO','JOMBANG',1),(522,'','2212-0000-2100','yulia','Yulia wahyuningsih','62852349990009','62852349990009','Jinten no 16 rt 007 rw 012 kel. Krembangan kec. Krembangan','SURABAYA',1),(523,'','2302-0000-2135','wahyutri','Wahyu Tri handayani','6281333397498','6281333397498','Simo magerejo tengah no 17 rt 06 rw 01 Simomulyo Sukomanunggal','SURABAYA',1),(524,'','2302-0000-2136','shohibbulumroh','SHOHIB BUL UMRON','6281231599899','6281231599899','TENGGILIS KAUMAN GG BUNTU 27 TENGGILIS MEJOYO','SURABAYA',1),(525,'','2302-0000-2137','mamiksetya','Mamik setya rini','6282331425060','6282331425060','Dusun Krajan wetan rt 017 rw 003 Tanjung rejo Wuluhan','JEMBER',1),(526,'','2302-0000-2138','ekawahyuni','Eka wahyuni','6285268261389','6285268261389','Rt. 011 dusun 03 Madya mulya Lalan','KAB. MUSI BANYUASIN',1),(527,'','2303-0000-2139','nurfajri','NUR FAJRIYATUL HIKMSH','6281332533920','6281332533920','BSURENO RT004 RW002 Baureno','BOJONEGORO',1),(528,'','2303-0000-2140','desinurjannah','Desi nurjannah','6281384995282','6281384995282','Dusun badan rt 001 rw 001 kraksaan Kregenan','PROBOLINGGO',1),(529,'','2303-0000-2141','syarif','Syarif','6289653077839','6289653077839','Koto rapak jorong baso rt 000 rw 000 Tabek panjang Baso','KAB AGAM',1),(530,'','2303-0000-2142','puspa','PUSPA ARTIKO SHANTI','6281335184325','6281335184325','JL. ASTA TINGGI NO. 01 RT.006RW.003 KEBUNAGUNG SUMENEP','SUMENEP',1),(531,'','2303-0000-2143','alfanhelmi','ALFAN HELMI JUNANSYAH','6285156299304','6285156299304','SEDATI AGUNG I SEDATI SIDOARJO','SIDOARJO',1),(532,'','2303-0000-2148','irsyamteinandra','IRSYAM TEINANDRA','6285655297676','6285655297676','JL. SIWALANKERTO TIMUR I  NO. 2 SIWALANKERTO WONOCOLO','SURABAYA',1),(533,'','2303-0000-2149','yanuarnurimam','Yanuar Nur Imam Ismail','6285606615515','6285606615515','Jl. Slaga GG 1 No.25 Pakuncen Pangungrejo','PASURUAN',1),(534,'','2303-0000-2150','choifin','Choifin','628525991692','628525991692','Krikilan 003001 Latek Bangil','PASURUAN',1),(535,'','2303-0000-2151','wempy','WEMPY GATOT SUKOWALOYO','6285645911214','6285645911214','JL. SYUKUR VII GG GABUNG JAYA I NO. 20 RT.001 RW.001 SEDATIGEDE SEDATI','SIDOARJO',1),(536,'','2304-0000-2152','susetyo','SUSETYO WIBOWO SANTOSO','6285731057559','6285731057559','Jl. Karangsono RT 02 RW 01 Dusun Karangsono Sukorejo','Pasuruan',1),(537,'','2304-0000-2153','ekosup02','EKO SUPRIYONO','62811344985','62811344985','Jl. Bambu Runcing RT 02 RW 01 Dusun Karangsono Sukorejo','Pasuruan',1),(538,'','2304-0000-2154','ekosup03','EKO SUPRIYONO','62811344985','62811344985','Jl. Bambu Runcing RT 02 RW 01 Dusun Karangsono Sukorejo','Pasuruan',1),(539,'','2304-0000-2155','ekosup04','EKO SUPRIYONO','62811344985','62811344985','Jl. Bambu Runcing RT 02 RW 01 Dusun Karangsono Sukorejo','Pasuruan',1),(540,'','2304-0000-2156','ekosup05','EKO SUPRIYONO','62811344985','62811344985','Jl. Bambu Runcing RT 02 RW 01 Dusun Karangsono Sukorejo','Pasuruan',1),(541,'','2304-0000-2157','supriyatino','SUPRIYATINO','6281238291600','6281238291600','JL. DEMANGSARI RT.005 RW.001 KEBOANANOM GEDANGAN','SIDOARJO',1),(542,'','2304-0000-2159','ikesanti','IKE SANTI AGUSTIANA','6285334618878','6285334618878','JL. YOS SUDARSO RT.006 RW.004 KERTASADA KALIANGET','KALIANGET',1),(543,'','2304-0000-2158','lika_like','MARFUATUS SOLIKHAH','6285707667991','6285707667991','BERAT WETAN 006004 BERATWETAN GEDEG BERAT WETAN GEDEG','MOJOKERTO',1),(544,'','2304-0000-2176','triangga','TRI ANGGA SETYAYANA','6285157914788','6285157914788','GUBENG JAYA 48-A GUBENG SURABAYA','SURABAYA',1),(545,'','2305-0000-2177','sultan','SULTAN','6285234898114','6285234898114','DUSUN BERINGIN RT.003003 KALINGANYAR ARJASA','SUMENEP',1),(546,'','2305-0000-2178','muhammadrifaie','MUHAMMAD RIFAIE','6282336849644','6282336849644','DUSUN KEBBEN RT.RW.009006 ANGON ANGON ARJASA','SUMENEP',1),(547,'','2305-0000-2179','anton','Anton','6285234285420','6285234285420','Dusun Assenan rt 016 rw 003 Brani wetan Maron','PROBOLINGGO',1),(548,'','2305-0000-2180','sugengkarso','Sugeng karso wahyudi','6285259010155','6285259010155','Dusun Krajan rt 001 rw 001 Bocor wetan Pakuniran','PROBOLINGGO',1),(549,'','2305-0000-2181','rahmadfajar','Rahmad fajar','6282302320389','6282302320389','Dusun gading rt 016 rw 005 Wonorejo Maron','PROBOLINGGO',1),(550,'','2305-0000-2182','abdhamid','ABD HAMID','6285259265902','6285259265902','DUSUN KALOPANG RTRW.005005 KALINGANYAR ARJASA','SUMENEP',1),(551,'','2305-0000-2183','hairulanam','HAIRUL ANAM','6281335212819','6281335212819','DUSUN LEMBUNGAN RTRW.001001 KALINGANYAR ARJASA','SUMENEP',1),(552,'','2305-0000-2184','sahid','SAHID','6282111247807','6282111247807','DSN BERINGIN RTRW.003003 KALINGANYAR ARJASA','SUMENEP',1),(553,'','2305-0000-2185','fathorasi','FATHORASI, S.Pd.i','6287750183556','6287750183556','DUSUN PATEREMAN RTRW. 005004 ANGKATAN ARJASA','SUMENEP',1),(554,'','2305-0000-2186','matsaini','MATSAINI','6281234233535','6281234233535','DUSUN BERINGIN RT.003003 KARANGANYAR ARJASA','SUMENEP',1),(555,'','2305-0000-2187','bashri','BASHRI','6281357619467','6281357619467','DUSUN BERINGIN RT.003003 KALINGANYAR ARJASA','SUMENEP',1),(556,'','2305-0000-2188','sukiyatno','SUKIYANTO','6285236935146','6285236935146','LAOK JANG-JANG RTRW.001001 ARJASA LAOK JANG-JANG','SUMENEP',1),(557,'','2305-0000-2189','paosan','PAOSAN RASYIDI','6281331543112','6281331543112','LAOK JANGJANG RTRW.002002 LAOK JANGJANG Arjasa','SUMENEP',1),(558,'','2305-0000-2190','saifulrizal','SAIFUL RIJAL','6281331107404','6281331107404','DUSUN ANYAR KALINGANYAR Arjasa','SUMENEP',1),(559,'','2305-0000-2191','masyhuri','MASYHURI','6287718181738','6287718181738','DUSUN TAMBAK RTRW.007002 LAOK JANGJANG Arjasa','SUMENEP',1),(560,'','2305-0000-2192','msyafiims','M. SYAFII MS','6285230225812','6285230225812','DUSUN ANYAR RTRW.002002 KALINGANYAR ARJASA','SUMENEP',1),(561,'','2305-0000-2193','hamsa','HAMSA','6281217326599','6281217326599','DUSUN BERINGIN RTRW. 003003 KALINGANYAR ARJASA','SUMENEP',1),(562,'','2305-0000-2194','rizkiya','RISKIYA B','6285230579772','6285230579772','DUSUN ANYAR RTRW.002002 KALINGANYAR ARJASA','SUMENEP',1),(563,'','2305-0000-2195','sydumar','SYD. UMAR','6282332722155','6282332722155','DUSUN NGOMBER RTRW. 004005 LAOK JANGJANG ARJASA','SUMENEP',1),(564,'','2305-0000-2196','matsari','MATSARI','6282335676265','6282335676265','DUSUN PARSE RT.RW. 003003 DUKO ARJASA','SUMENEP',1),(565,'','2305-0000-2197','nurlaila','NURLAILA','6285212203953','6285212203953','DUSUN ANYAR RTRW.002002 KARANGANYAR ARJASA','SUMENEP',1),(566,'','2305-0000-2198','fikrihaikal','FIKRI HAIKAL','6285236251518','6285236251518','DUSUN BERINGIN RT.003003 KARANGANYAR ARJASA','SUMENEP',1),(567,'','2305-0000-2199','suara','SUARA','6281324561079','6281324561079','DUSUN ANYAR RTRW.002002 KARANGANYAR ARJASA','SUMENEP',1),(568,'','2305-0000-2200','yantinur','YANTI NUR AINI','6281216332472','6281216332472','DUSUN NGOMBER RTRW. 004005 LAOK JANGJANG ARJASA','SUMENEP',1),(569,'','2305-0000-2201','abdrochman','ABD ROCHMAN','6285102300448','6285102300448','DSN BARAN GUNUNGSARI TAJINAN','MALANG',1),(570,'','2305-0000-2202','anylinawati','ANy Linawati','6281808710508','6281808710508','Jl. Lansep 2 No 60 Geluran Taman Sidoarjo','SIDOARJO',1),(571,'','2305-0000-2207','rosmayuli','ROSMA YULIANI, ST','6282232584624','6282232584624','ROYAL RESIDENCE BLOK B11 NO. 09 RT.006RW.002 SUMURWELUT LAKARSANTRI','SURABAYA',1),(572,'','2305-0000-2208','suhadi','SUHADI ARIESTIAWAN','6281998245079','6281998245079','Perum. Taman Gading G07 Rt.01Rw.02 Tegal Besar Kaliwates','JEMBER',1),(573,'','2305-0000-2209','rachmadcatur','Rachmad Catur Wibawa','6285108110040','6285108110040','Jl.Trosobo Utama C-8 Sidodadi Taman','SIDOARJO',1),(574,'','2306-0000-2214','nazhifah','NAZHIFAH FAIRUZSYAWAL','6282264752909','6282264752909','KARANGAN JAYA II30 BABATAN WIYUNG','SURABAYA',1),(575,'','2306-0000-2215','lailinurul','LAILI NURUL HAKIMA','62895324964479','62895324964479','KARANGAN JAYA II34 BABATAN WIYUNG','SURABAYA',1),(576,'','2306-0000-2216','alimmuhamad','ALIM MUHAMAD','6281216500028','6281216500028','JL.JENGGOLO I DSN MAMBANG PUCANG','SIDOARJO',1),(577,'','2306-0000-2217','ramaaditya','RAMA ADITYA HERMAWAN,SE.','628563006838','628563006838','JL.SEMERU 68 PEPELEGI WARU','SIDOARJO',1),(578,'','2306-0000-2218','nunukagustina','NUNUK AGUSTINA','62895377309100','62895377309100','JL.PURWOREJO RT.035 RW.005 KARANGKATES SUMBERPUCUNG','MALANG',1),(579,'','2306-0000-2219','mukhamadyahya','MUKHAMAD YAHYA','6283833636824','6283833636824','JL. SULAWESI 8  22 TRAJENG PANGGUNGREJO','PASURUAN',1),(580,'','2306-0000-2220','dzulfikri','DZULFIKRI ISNAENI','6285746931810','6285746931810','DSN NGRANCAH RT.19 RW.06 SENGRENG SUMBERPUCUNG','MALANG',1),(581,'','2306-0000-2221','sulistyawati','SULISTYAWATI','6282232957471','6282232957471','DSN NGRANCAH RT.19 RW.06 SENGRENG SUMBERPUCUNG','MALANG',1),(582,'','2306-0000-2224','sultonkhutbi','Sulton khutbi','6281235558070','6281235558070','Wonorejo gang dalam 2 rt 003 rw 001 Wonorejo Rungkut','SURABAYA',1),(583,'','2306-0000-2225','watidwi','Wati dwi anggraeni','628385701186','628385701186','Branjangan 19 rt 001 rw 010 Krembangan selatan Krembangan','SURABAYA',1),(584,'','2306-0000-2226','ra_dewi','RA DEWI ANGGRAINI','6281233261919','6281233261919','GRIYA KEBRAON UTAMA  KEBRAON  KARANGPILANG','SURABAYA',1),(585,'','2307-0000-2229','anitazulya','ANITA ZULYA','6285853806106','6285853806106','SUROWONO RT 002RW 019 CANGGU BADAS','KEDIRI',1),(586,'','2307-0000-2232','prnucanggu','PRNU CANGGU','6285735581186','6285735581186','SUROWONO RT 002RW 019 CANGGU BADAS','KEDIRI',1),(587,'','2307-0000-2236','mashudi01','MASHUDI  ARIYANTO','6285732097305','6285732097305','MEJOYO II NO. 2 004007 KALIRUNGKUT RUNGKUT','SURABAYA',1),(588,'','2307-0000-2237','tubagus','TUBAGUS IMAT HIKMATULLAH, SE','6282132979459','6282132979459','METAMBAK WEDI I 10 001002 TAMBAK WEDI  KENJERAN','SURABAYA',1),(589,'','2307-0000-2238','hardianto01','HARDIANTO KAHAR','6282131491288','6282131491288','BLOK III16 018005 SUGIHWARAS CANDI','SIDOARJO',1),(590,'','2307-0000-2239','cahyo','DWI CAHYO BUDIONO, ST','62811348659','62811348659','MULYOSARI UTARA 8 NO. 5','SURABAYA',1),(591,'','2307-0000-2242','m_ilyas','MOHAMMAD ILYAS','6287888816669','6287888816669','JL. PEMUDA BARU VI - 6 RT 001 RW 004 RONGTENGAH SAMPANG','KAB SAMPANG',1),(592,'','2308-0000-2249','auliamaulani','AULIYA MAULANI','6287850171480','6287850171480','PERUM GRIYA PERMATA GEDANGAN BLOK M2 NO. 29 KEBOAN SIKEP','SIDOARJO',1),(593,'','2308-0000-2250','sustamurniati','SUSTA MURNIATI','6281231236714','6281231236714','KEBRAON 2 DUKU 42 002003 KEBRAON KARANGPILANG','SURABAYA',1),(594,'','2308-0000-2251','r_agung','R AGUNG SURADIPAJANA','6285335198292','6285335198292','GRIYA KEBRAON UTAMA DM 9 KEBRAON KARANGPILANG','SURABAYA',1),(595,'','2308-0000-2252','indraerna','INDRA ERNA WATTY','6281334241961','6281334241961','PURI SURYA JAYA TAMAN NAGOYA BLOK E3 NO. 59 GEDANGAN','SIDOARJO',1),(596,'','2308-0000-2253','aswinardi','ASWIN ARDI','6281332821972','6281332821972','PDK WAGE INDAH II BLOK H 30 WAGE TAMAN','SIDOARJO',1),(597,'','2308-0000-2265','sitiai','HJ SITI AISYAH','6281230306129','6281230306129','RA KARTINI 14A32 SIDOMORO KEBOMAS','GRESIK',1),(598,'','2308-0000-2266','agungcahyono','AGUNG CAHYONO','6281216581234','6281216581234','JL. KARANGMENJANGAN 001001 KARAMGMENJANGAN MOJOAGUNG','JOMBANG',1),(599,'','2308-0000-2267','idafitriah','IDA FITRIAH','6281331058242','6281331058242','PULO TEGALSARI 224-C   RTRW.005007 wonokromo','SURABAYA',1),(600,'','2307-0000-2227','robi_s','Robi sulianto se','6287851440869','6287851440869','Dusun sugihan rt 10 rw 04 Kedung sumber Temayang','BOJONEGORO',1),(602,'','2308-0000-2310','abrita','Abrita Sigit Marfianto','62811117318','62811117318','Jl. Beruang Raya A3 No.32 Jayamukti Cikarang Pusat Bekasi','BEKASI',1),(603,'','2307-0000-2235','alazhar','Ahmad al azhar','6282141651664','6282141651664','Tumapel 100 singosari','MALANG',1),(604,'','2309-0000-2315','yanal','YANAL AROFAH','6282338150959','6282338150959','Dk. Jelindro No. 17 Sambikerep','SURABAYA',1),(605,'','2308-0000-2283','wulandari','Wulandari Yuliana','6281390905815','6281390905815','Jl. H. Abdul Rahman no.169rt 3 rw 2 sedati Gede - Sidoarjo','SIDOARJO',1),(606,'','2308-0000-2284','dyah_m','Dyah Mangajuningratri','6281359174717','6281359174717','jl. Karang menjangan I no 2-b Mojo GubengSurabaya','SURABAYA',1),(607,'','2308-0000-2285','rr_aisyah','Rr.Aisyah syafahilal','6285733657510','6285733657510','jl.gundih 2 no.17 Gundih Bubutan','SURABAYA',1),(608,'','2309-0000-2317','huuriyah','HUURIYAH NAZIIHA ZAATIL AQMAR','6282154037955','6282154037955','KOMPLEK PESONA PRIMA GRIYA A29 BIRING ROMANG Manggala','KOTA MAKASSAR',1),(609,'assets/images/member/IMG-20200815-WA0000.jpg','2309-0000-2333-.','hanafi','Muhammad Hanafi','081944941188','6281944941188','Desa Renteng RT 1 RW 1 Kec. Praya','Lombok Tengah',1),(610,'','2309-0000-2332','aste01','ASTE','6281918227841','6281918227841','Segampang Suwagi Sakra','Lombok Tengah',1),(611,'assets/images/member/logo_aminah28.png','2309-0000-2323','faizi','Muhammad Faizi','085338332671','6285338332671','Jago Praya Lombok Tengah','KAB. Lombok Tengah',1),(612,'assets/images/member/IMG-20200815-WA00001.jpg','2309-0000-2334','zulpahri','Zulpahri','081928925587','6281928925587','Lombok Timur','Lombok',1),(613,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM.jpeg','2309-0000-2327','muhammadtaufik','muhammadtaufik','081805701600','6281805701600','Pancor','Lombok Timur',1),(614,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM1.jpeg','2309-0000-2336','ihwalzahwari','Ihwal Zahwari','085954372681','6285954372681','Gelondong Panjisari','KAB. Lombok Tengah',1),(615,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM2.jpeg','2309-0000-2337','sucirita','Hj. Suci Rita','087864614293','6287864614293','Lingkungan Gelondong','KAB. Lombok Tengah',1),(616,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM3.jpeg','2309-0000-2338','hajisudiarni','Haji Sudiarni, S. Pd.','087862992927','6287862992927','Banyu Urip','KAB. Lombok Tengah',1),(617,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM4.jpeg','2309-0000-2339','sumiatisudiarni','Sumiati','087862992927','6287862992927','Banyu Urip','KAB. Lombok Tengah',1),(618,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM5.jpeg','2309-0000-2340','sumitar','Sumitar','087879350379','6287879350379','Gelondong','KAB. Lombok Tengah',1),(619,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM6.jpeg','2309-0000-2342','akhmadrasyidi','Akhmad Rasyidi','087850717283','6287850717283','Aik Ampat','KAB. Lombok Tengah',1),(620,'assets/images/member/WhatsApp_Image_2023-09-24_at_4_09_35_PM7.jpeg','2309-0000-2343','khaerigunarsa','Khaeri Gunarsa','081999118484','6281999118484','Gubuk Daya RW Makmur','KAB. Lombok Timur',1),(621,'assets/images/member/LOGO_AMINAH_G3.jpeg','2309-0000-2318','subaki','H. SUBAKI, S. Ag','081803627831','6281803627831','Jurang Tangi puyung','KAB. Lombok Tengah',1),(622,'assets/images/member/LOGO_AMINAH_G31.jpeg','2309-0000-2319','mardiana','Mardiana','081936165477','6281936165477','Jurang Tangi puyung','KAB. Lombok Tengah',1),(623,'assets/images/member/LOGO_AMINAH_G32.jpeg','2309-0000-2320','mujna','MUJNA, SS','081934339791','6281934339791','Jurang Tangi puyung','KAB. Lombok Tengah',1),(624,'assets/images/member/LOGO_AMINAH_G33.jpeg','2309-0000-2321','sumardi','H. Sumardi','08175790116','628175790116','Songak Baret','KAB. Lombok Timur',1),(625,'assets/images/member/LOGO_AMINAH_G34.jpeg','2309-0000-2322','mashum','H. MASHUM','087859546886','6287859546886','KAMP. MEREMBU, DESA PERAPEN, KEC. PRAYA. KAB. LOMBOK TENGAH','KAB. Lombok Timur',1),(626,'assets/images/member/LOGO_AMINAH_G35.jpeg','2309-0000-2324','awaludin','AWALUDIN','087762225269','6287762225269','RONSENG, DESA BATUJAI KEC. PRAYA BARAT','KAB. Lombok Tengah',1),(627,'assets/images/member/LOGO_AMINAH_G36.jpeg','2309-0000-2325','wajedi','Wajedi','081803661108','6281803661108','KWANG JUKUT, DESA PRINGGARATA. KEC. PRINGGARATA. KAB. LOMBOK TENGAH','KAB. Lombok Tengah',1),(628,'assets/images/member/LOGO_AMINAH_G37.jpeg','2309-0000-2326','ahmadyani','Ahmad yani','081907221257','6281907221257','Dayan masjid II','KAB. Lombok Timur',1),(629,'assets/images/member/LOGO_AMINAH_G38.jpeg','2309-0000-2328','usman','H. Usman','087841723119','6287841723119','DUSUN PRERENAN RT 003 RW 000','KAB. Lombok Timur',1),(630,'assets/images/member/LOGO_AMINAH_G39.jpeg','2309-0000-2329','muhammadnardi','Muhammad Nardi saputra','081917803219','6281917803219','Songak barat','KAB. Lombok Timur',1),(631,'assets/images/member/LOGO_AMINAH_G310.jpeg','2309-0000-2330','haruns','HARUNS, Pd., MM.','087865179099','6287865179099','WAKI, DESA BATUJAI. KEC. PRAYA BARAT. KAB.  LOMBOK TENGAH','KAB. Lombok Tengah',1),(632,'assets/images/member/LOGO_AMINAH_G311.jpeg','2309-0000-2331','herawatish','HERAWATI, SH','085931192201','6285931192201','JALAN RENGGANIS RAYA NO.21','KAB. Lombok Barat',1),(633,'assets/images/member/LOGO_AMINAH_G312.jpeg','2309-0000-2335','yogisatria','YOGI SATRIA PRATAMA','081917524355','6281917524355','Lauq Masjid  RT 011','KAB. Lombok Tengah',1),(634,'assets/images/member/LOGO_AMINAH_G313.jpeg','2309-0000-2341','ahmaddai','Ahmad Dai','087865580974','6287865580974','Banteng kurus','KAB. Lombok Tengah',1),(635,'','2308-0000-2309','joe_entrepreneur','JOE ENTREPRENEUR (Weriono Sutedjo)','6287781332000','6287781332000','GANG SOKA VIII NO 81 A 001007 KARANGTENGAH TANGERANG','KAB. TANGERANG',1),(636,'assets/images/member/LOGO_AMINAH_G314.jpeg','2310-0000-2344','yuliani','Yuliani Astuti Apriani','085293780334','6285293780334','Puyung jonggat','KAB. Lombok Tengah',1),(637,'assets/images/member/LOGO_AMINAH_G315.jpeg','2310-0000-2345','srihariati','Srihariati','081999102352','6281999102352','Juring','KAB. Lombok Tengah',1),(638,'assets/images/member/LOGO_AMINAH_G316.jpeg','2310-0000-2346','sulaipi','SULAIPI','081939643651','6281939643651','Pepekat','KAB. Lombok Tengah',1),(639,'assets/images/member/LOGO_AMINAH_G317.jpeg','2310-0000-2347','fatimatuzzahro','Fatimatuzzahro','087765520603','6287765520603','Puyung, jonggat, kab.lombok tengah NTB','KAB. Lombok Tengah',1),(640,'assets/images/member/LOGO_AMINAH_G318.jpeg','2310-0000-2348','mustihan','Mustihan','087763217465','6287763217465','Karang sukun','KAB. Lombok Tengah',1),(641,'assets/images/member/LOGO_AMINAH_G319.jpeg','2310-0000-2349','hasnawati','Hasnawati','081937193479','6281937193479','Anjani barat','KAB. Lombok Timur',1),(642,'assets/images/member/LOGO_AMINAH_G320.jpeg','2310-0000-2350','wasipatil','Wasipatil ulya','087810066359','6287810066359','Bunklotok','KAB. Lombok Tengah',1),(643,'assets/images/member/LOGO_AMINAH_G321.jpeg','2310-0000-2351','baiqrochmini','BAIQ ROCHMINI ENDRAWATI','081917960501','6281917960501','BTN BHP Jl. BINTANG RAYA BLOK G NO. 11','KAB. Lombok Barat',1),(644,'assets/images/member/LOGO_AMINAH_G322.jpeg','2310-0000-2352','muhammadsofyan','MUHAMMAD SOFYAN AMIRUSSYAKIR','081999182988','6281999182988','BODAK','KAB. Lombok Tengah',1),(645,'assets/images/member/LOGO_AMINAH_G323.jpeg','2310-0000-2353','hurni','Hurni','081917107170','6281917107170','BERERONG','KAB. Lombok Tengah',1),(646,'assets/images/member/LOGO_AMINAH_G324.jpeg','2310-0000-2354','rakmah','Rakmah','081917669689','6281917669689','TANGGAK','KAB. Lombok Tengah',1),(647,'','2310-0000-2355','kartayadi','Lalu kartayadi','6287856663000','6287856663000','Batu belek desa pengembur Pengembur Praya','LOMBOK TENGAH',1),(648,'','2310-0000-2356','iinnovianti','Iin novianti','6287752006462','6287752006462','Setanggor timur Praya Barat','LOMBOK TENGAH - NTT',1),(649,'','2308-0000-2286','abdillah','Abdillah','628123066093','628123066093','Griya Kebraon utama blok DC 16 sby','SURABAYA',1),(650,'','2310-0000-2357','ellyp','Elly Puji Astuti','6285655485115','6285655485115','Ds Ngampelsari Rt 6 Rw3 no 199 Ngampelsari Candi-Sidoarjo','SIDOARJO',1),(651,'','2310-0000-2358','isnawati','Isnawati','6281337364462','6281337364462','Dusun belet Bagik payung Suralaga','KAB. LOMBOK TIMUR NTB',1),(652,'','2308-0000-2287','henny','Henny Titik Purbowati','6281803159010','6281803159010','jl. Griya Kebraon Tengah IX Blok U no.12 B','SURABAYA',1),(653,'','2310-0000-2359','husman','H USMAN SPDI','6281944943396','6281944943396','Jabon Lombok Tengah Praya','Lombok Tengah',1),(654,'','2310-0000-2360','hsukardi','H SUKARDI','6285932027062','6285932027062','Buncaland Desa Sukarare Praya','Lombok Tengah',1),(655,'','2311-0000-2361','imamthohari','IMAM THOHARI','6281553504912','6281553504912','KEBONAGUNG RT.004 RW.001','KAB. SIDOARJO',1),(656,'','2311-0000-2363','sakurwadi','Sakur Wadi','6281909076623','6281909076623','Dusun Bunklotok Batujai Praya Barat','NTB',1),(657,'','2311-0000-2364','didikin','DIDIK INDRA WIRATNO','6282233420189','6282233420189','Margorejo 2F75A Margorejo Wonocolo','SURABAYA',1),(658,'','2311-0000-2365','aguspriyo','AGUS PRIYO HANDOKO','6281335396161','6281335396161','Jl. Gadung No.3 Wage Taman','KAB. SIDOARJO',1),(659,'','2311-0000-2366','aguspamuji','AGUS PAMUJI','628155059454','628155059454','Griya wage','KAB. PEMALANG',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengumuman`
--

DROP TABLE IF EXISTS `pengumuman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengumuman` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `tampil` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengumuman`
--

LOCK TABLES `pengumuman` WRITE;
/*!40000 ALTER TABLE `pengumuman` DISABLE KEYS */;
INSERT INTO `pengumuman` (`id`, `aman`, `foto`, `judul`, `diskripsi`, `tanggal`, `tampil`) VALUES (18,'5b996d71838ebb20224ce8cc401a76a2f5143476','assets/images/fotoumum/IMG-20200721-WA0013.jpg','PT. AMINAH dari UMMAT untuk UMMAT','<p>ANDA INGIN MEMBERDAYAKAN UMMAT ATAU MEMBERDAYAKAN DIRI SENDIRI UNTUK BISA MEMBANTU SESAMA ???<span style=\"font-size: 1rem;\">&nbsp;</span></p>\r\n\r\n<p>INGIN MEMPUNYAI BISNIS TOUR &amp; TRAVEL YANG BER-IZIN RESMI ??</p><p><span style=\"font-size: 1rem;\">DENGAN BERMODAL SEMANGAT, TEKUN DAN MAU BELAJAR \"YAKIN &amp; YAKINLAH BAHWA SUKSES MENANTI ANDA\"</span></p><p>\r\nPT. AMINAH<br>\r\nTempatnya Karena</p>\r\n\r\n<ol>\r\n	<li>Menciptakan BISNIS ADA DIGENGGAMAN ANDA.</li>\r\n	<li>MENG-AKOMODIR &amp; MEMFASILITASI UMMAT Untuk BISA BERDAYA. dengan berazaskan \"DARI UMMAT UNTUK UMMAT\"</li><li>PERIZINAN PT.AMINAH&nbsp; TDP. 503/10380.D/436.6.11/2013&nbsp; &nbsp;NPWP : 31.820.935.0-609.000&nbsp; DISPARTA : 503.08/083/436.6.14/2014&nbsp; &nbsp;IZIN UMRAH : KEMENAG No. 927 th 2019</li></ol>\r\n\r\n<hr>\r\n<p>PEMBERITAHUAN</p><p>Penggunaan Aplikasi ini diatur dengan konsep \"Login\", sehingga segala sesuatu yang berhubungan dengan penyalahgunaan login, PT. AMINAH tidak bertanggung jawab.</p>\r\n\r\n<p>Segala bentuk transaksi WAJIB melalui&nbsp;Rekening PT. AMINAH,&nbsp; diluar ketentuan PT. AMINAH tidak bertanggujawab.</p>\r\n\r\n<p>Rek. PT. AMINAH</p>\r\n\r\n<p>Bank Mandiri 1420013662985</p>\r\n\r\n<p>BANK BNI 8888881455</p><p><br></p><p>Persyaratan Umrah :</p><ol><li>Mengisi formulir pendaftaran</li><li>Paspor 3 kata yang masih berlaku 7 bulan saat keberangkatan</li><li>Vaksin Meningitis dan Influenza</li><li>Surat Mahram bagi perempuan &lt;45 tahun, umrah sendiri tanpa suami / saudara laki-laki / bapak kandung</li><li>Foto berwarna background putih tampak wajah 80%&nbsp; 3x4 dan 4x6 masing-masing 4&nbsp;lembar</li><li>Surat nikah asli bagi suami-istri &lt;45 tahun</li><li>Foto copy Akte lahir bagi Anak &lt;17 tahun</li><li>Foto copy Akte lahir bagi perempuan &lt;45 tahun yang berangkat&nbsp;bersama orang tua</li></ol><p>Biaya belum termasuk :</p><ol><li>Pengurusan Paspor dan tambah nama.</li><li>Dokumen tambahan untuk perempuan &lt;45 tahun umroh sendiri tanpa suami/saudara laki-laki/bapak kandung atau jamaah yang tidak lengkap dokumennya.</li><li>Pengeluaran pribadi : laundry, telepon hotel, kelebihan bagasi, dsb.</li><li>Biaya kesehatan dan vaksin meningitis.</li><li>Biaya Regulasi, jika ada seperti kenaikkan PPN Saudi, Vaksin covid 19 (PCR), Biaya Karantina yang timbul dan&nbsp; biaya tiket akibat social distancing</li><li>Pengurusan Visa di luar Saudi Arabia dan asuransi&nbsp;</li></ol><p>Pembatalan</p><p>Pembatalan yang dilakukan</p><p>1. Sebelum 1 bulan DP. Hangus</p><p>2. Satu bulan sebelum pemberangkatan dikenakan&nbsp;<span style=\"font-size: 1rem;\">biaya DP. Hangus dan&nbsp; pemotongan 75% dari dana masuk setelah dikurangi DP.</span></p><p>3. KURANG dari satu bulan&nbsp;sebelum pemberangkatan dana yang masuk hangus.</p><p><br></p>','2020-05-11 14:07:07',1);
/*!40000 ALTER TABLE `pengumuman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` date NOT NULL,
  `urut` int(5) NOT NULL,
  `baca` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` (`id`, `foto`, `judul`, `diskripsi`, `tanggal`, `urut`, `baca`) VALUES (1,'assets/images/fotoproject/IMG-20191030-WA0010.jpg','Pingin ibadah umroh lagi','<p>Pengalaman umroh Milad ke-6 Aminah Tour&nbsp;sangat berkesan. Kami berharap bisa berangkat umroh lagi dikemudian hari bersama Aminah Tour</p>','2020-06-06',1,2245),(3,'assets/images/fotoproject/IMG-20191223-WA0006.jpg','Ibadah Umroh menjadi sangat nikmat','<p>Sejak keberangkatan ibadah umroh kami merasakan kehangatan dan pelayanan yang luar biasa</p>','2020-08-12',3,2311),(4,'assets/images/fotoproject/IMG-20191030-WA0013.jpg','Perjalanan umroh yang sangat berkesan','<p>Kami sangat berteima kasih kepada Aminah Toru dan Travel yang membantu kami dalam beribadah umroh dengan lancar. Fasilitas yang sangat berkesan selama ber-ibadah di Medinah dan Mekkah</p>','2020-06-07',4,2360),(5,'assets/images/fotoproject/IMG-20200315-WA0003.jpg','Keakraban Pebisnis Aminah Tour','<p>Suasana Keakraban para Pebisnis tatkala Lounching Program Generasi ke-2 untuk mendekatkan diri dg Calon Jamaah&nbsp;</p>','2020-06-07',5,1809),(6,'assets/images/fotoproject/IMG-20191030-WA0008.jpg','Umroh Penuh Kenangan','<p>Unroh bersama Aminah Tour penuh kenangan dan hikmat</p>','2020-06-07',6,2020),(7,'assets/images/fotoproject/IMG-20200228-WA0006.jpg','Peninjauan Kelayakan  Kantor Aminah Tour','<p>Peninjauan Kelayakan kantor AMINAH TOUR oleh Team Kemenag Propinsi Jawa Timur</p>','2020-06-07',7,2523);
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_tampil`
--

DROP TABLE IF EXISTS `project_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_tampil` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `tampil` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_tampil`
--

LOCK TABLES `project_tampil` WRITE;
/*!40000 ALTER TABLE `project_tampil` DISABLE KEYS */;
INSERT INTO `project_tampil` (`id`, `navbar`, `judul`, `diskripsi`, `foto`, `tampil`) VALUES (1,'Testimoni','Umrah Dambaan Umat','Umrah Aman dan Nyaman','assets/images/fotoservice/mekkah8.jpg','Tampil');
/*!40000 ALTER TABLE `project_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prosedur`
--

DROP TABLE IF EXISTS `prosedur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prosedur` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `tagline` varchar(200) NOT NULL,
  `diskripsi` longtext NOT NULL,
  `foto` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prosedur`
--

LOCK TABLES `prosedur` WRITE;
/*!40000 ALTER TABLE `prosedur` DISABLE KEYS */;
INSERT INTO `prosedur` (`id`, `judul`, `tagline`, `diskripsi`, `foto`) VALUES (1,'Syarat dan Ketentuan','“ Melayani Tamu Allah adalah Pengabdian Kepada Allah ”','<p>Persyaratan Umrah :</p>\r\n\r\n<ol>\r\n	<li>Mengisi formulir pendaftaran</li>\r\n	<li>Paspor 3 kata yang masih berlaku 7 bulan saat keberangkatan</li>\r\n	<li>Vaksin Meningitis dan Influenza</li>\r\n	<li>Surat Mahram bagi perempuan <45 tahun, umrah sendiri tanpa suami / saudara laki-laki / bapak kandung</li>\r\n	<li>Foto berwarna background putih tampak wajah 80%  3x4 dan 4x6 masing-masing 4 lembar</li>\r\n	<li>Surat nikah asli bagi suami-istri <45 tahun</li>\r\n	<li>Foto copy Akte lahir bagi Anak <17 tahun</li>\r\n	<li>Foto copy Akte lahir bagi perempuan <45 tahun yang berangkat bersama orang tua</li>\r\n</ol>\r\n\r\n<p>Biaya belum termasuk :</p>\r\n\r\n<ol>\r\n	<li>Pengurusan Paspor dan tambah nama.</li>\r\n	<li>Dokumen tambahan untuk perempuan <45 tahun umroh sendiri tanpa suami/saudara laki-laki/bapak kandung atau jamaah yang tidak lengkap dokumennya.</li>\r\n	<li>Pengeluaran pribadi : laundry, telepon hotel, kelebihan bagasi, dsb.</li>\r\n	<li>Biaya kesehatan dan vaksin meningitis.</li>\r\n	<li>Biaya Regulasi, jika ada seperti kenaikkan PPN Saudi, Vaksin covid 19 (PCR), Biaya Karantina yang timbul dan  biaya tiket akibat social distancing</li>\r\n	<li>Pengurusan Visa di luar Saudi Arabia dan asuransi </li>\r\n</ol>\r\n\r\n<p>Pembatalan</p>\r\n\r\n<p>Pembatalan yang dilakukan </p><p>1. Sebelum 1 bulan DP. Hangus</p><p>2. Satu bulan sebelum pemberangkatan dikenakan biaya DP. Hangus dan  pemotongan 75% dari dana masuk setelah dikurangi DP. </p><p>3. KURANG dari satu bulan sebelum pemberangkatan dana yang masuk hangus.</p><p><br></p>','assets/images/about/nabawi2.jpg');
/*!40000 ALTER TABLE `prosedur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume`
--

DROP TABLE IF EXISTS `resume`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(15) NOT NULL,
  `kerja` varchar(50) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `urut` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume`
--

LOCK TABLES `resume` WRITE;
/*!40000 ALTER TABLE `resume` DISABLE KEYS */;
INSERT INTO `resume` (`id`, `tahun`, `kerja`, `jabatan`, `diskripsi`, `urut`) VALUES (4,'2013','Langkah Awal','Penyelanggara Umroh, Tour Domistik dan Internasional','Memulai sesuatu yang telah lama dirintis dalam tour umroh, tour domistik dan internasional',4),(6,'2016','Memiliki izin sendiri','Semakin berkibar','Memiliki izin sebagai penyelenggara umroh, tour domistik  internasional',3),(7,'2018','Tour Domistik dan internasional','Mengakomodir  wisatawan religi','Aminah Tour Melayani Tour domistik  internasional dalam rangka mengakomodir wisatawan religi, Aminah Tour siap melayani dengan sepenuh hati.',5);
/*!40000 ALTER TABLE `resume` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resume_tampil`
--

DROP TABLE IF EXISTS `resume_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resume_tampil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resume_tampil`
--

LOCK TABLES `resume_tampil` WRITE;
/*!40000 ALTER TABLE `resume_tampil` DISABLE KEYS */;
INSERT INTO `resume_tampil` (`id`, `navbar`, `judul`, `tampil`, `diskripsi`) VALUES (1,'Resume','Resume yang berbagi','Tidak','Ini pelayanan kami yang luar biasa');
/*!40000 ALTER TABLE `resume_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `harga` varchar(25) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `diskripsi` text NOT NULL,
  `urut` int(2) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `kamar` int(1) NOT NULL,
  `hotelmadinah` varchar(50) NOT NULL,
  `bintangmadinah` int(1) NOT NULL,
  `hotelmekkah` varchar(50) NOT NULL,
  `bintangmekkah` int(1) NOT NULL,
  `pesawat` varchar(50) NOT NULL,
  `lama` int(2) NOT NULL,
  `baca` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` (`id`, `kode`, `kategori`, `jenis`, `judul`, `foto`, `harga`, `tanggal`, `diskripsi`, `urut`, `tampil`, `kamar`, `hotelmadinah`, `bintangmadinah`, `hotelmekkah`, `bintangmekkah`, `pesawat`, `lama`, `baca`) VALUES (12,'AMHP-0001','KTP006','Jasa','Digital Technology','assets/images/fotoservice/PicsArt_12-25-02_24_38.jpg','10000000','-','<p>SOFTWARE</p><p> DIGITAL TECHNOLOGI</p><p>PERUSAHAAN ANDA TERASA ANDA BAWA KEMANA-MANA</p>',13,'Tampil',1,'-',1,'-',1,'-',1,3097),(16,'AMHH-0002','KTP002','Jasa','BADAL HAJI','assets/images/fotoservice/IMG-20230913-WA0018.jpg','12.500.000','22 Juni 2024','<p>BADAL HAJI 2024</p><p>KUPERUNTUKKAN SESEORANG YANG AKU CINTAI YANG TEL IAH MENDAHULUI KITA</p><p>PELAKSANAAN BADAL HAJI MENYESUAIKAN, TANGGAL DAN TAHUN JATUHNYA PELAKSANAAN HAJI.</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>',17,'Tampil',1,'-',1,'-',1,'-',5,3728),(22,'AMHU-0014','KTP001','Jasa','BADAL UMROH','assets/images/fotoservice/WhatsApp_Image_2023-09-19_at_12_49_28.jpeg','2500000','10 Desember 2024','<p>BADAL UMROH</p><p>DIPERUNTUKKAN UNTUK ORANG YANG TELAH MENDAHULUI KITA.</p><p>KELUARGA YANG BERKEINGINAN UNTUK MENG-UMROH-KAN SEBAGAI BENTUK KASIH SAYANG SEKALIGUS BENTUK SEBAGAI MANUSIA YANG SHOLEH SHOLEHA.</p>',23,'Tampil',1,'-',1,'-',1,'-',1,3184),(23,'AMHU-0001','KTP001','Jasa','TABUNGAN PERCEPATAN UMROH','assets/images/fotoservice/Yellow_Gold_Minimalist_Hajj_Instagram_Story-21.png','0','2 Pebruari 2024','<p>TABUNGAN PERCEPATAN UMROH</p><p>Merupakan cara ber-ibadah UMROH dengan MENABUNG SUKA- SUKA menggunakan rekening atas nama sendiri, sehingga bisa dipantau diri sendiri.</p>',24,'Tampil',4,'Luluk Mubarok',3,'Karam al Refa',3,'Lion Airline',9,3339),(72,'AMHU-0056','KTP001','Jasa','UMROH MILAD 1445 H, SBY','assets/images/fotoservice/1_20230518_092539_0000.png','39750000','8 Oktober 2023','<p>UMROH MILAD, RASA BERSYUKUR &amp; KEBERSAMAAN&nbsp; MEMBUAT HATI TENANG &amp;<span style=\"font-size: 1rem;\">SENANG</span></p><p><span style=\"font-size: 1rem;\">KEBERANGKATAN, 8 Oktober 2023</span></p><p>KURS DOLLAR MAX. 15.200</p>',67,'Tampil',4,'JAUHARAD AL RASHEED/KAYAN AL MASI',4,'Le Meredian Tower/Final Rehab',5,'LION AIRLINE',16,1589),(73,'AMHU-0057','KTP001','Jasa','UMROH MILAD, SBY','assets/images/fotoservice/20230518_093050_0000.png','39800000','8 Oktober 2023','<p>UMROH BERSAMA-SAMA MENSYUKURI NIKMAT.</p><p>PENUH KASIH SAYANG.</p><p>KEBERANGKATAN, 8 OKTOBER 2023</p><p>KURS DOLLAR MAX. 15.000</p>',68,'Tampil',4,'JAUHARAD AL RASHEED/KAYAN AL MASI',4,'Le Meredian Tower/Final Rehab/Grand Ar Raya',5,'LION AIR',16,1412),(74,'AMHU-0058','KTP001','Jasa','UMROH MILAD AMINAH TOUR,','assets/images/fotoservice/WhatsApp_Image_2023-09-19_at_12_49_17.jpeg','36850000','8 Oktober 2023','<p>UMROH KHUSUS DAN SPESIAL&nbsp;<span style=\"font-size: 1rem;\">BERSYUKUR</span></p><p><span style=\"font-size: 1rem;\">PENUH HIKMAT, NYAMAN DAN AMAN</span></p><p><span style=\"font-size: 1rem;\">KEBERANGKATAN, 8 OKTOBER 2023</span></p><p><span style=\"font-size: 1rem;\">KURS DOLLAR MAX. 15.200</span></p>',69,'Tampil',4,'JAUHARAD AL RASHEED/KAYAN AL MASI',4,'Le Meredian Tower/Final Rehab/Grand Ar Raya',5,'LION AIRLINE',16,1567),(77,'AMHU-0061','KTP001','Jasa','UMROH PENUH NIKMAT','assets/images/fotoservice/WhatsApp_Image_2023-09-19_at_12_48_47.jpeg','36250000','16 Nopember 2023','<p>UMROH PREMIUM</p><p>PENUH NIKMAT, HIKMAT DAN MENYENANGKAN </p><p>KEBERANGKATAN, 16 NOPEMBER 2023</p><p>KURS DOLLAR MAX. 15.200</p>',72,'Tampil',4,'FAIRUS SHATTA/GRAND PLAZA',4,'HILTON TOWER/VILLA',5,'LION AIR',13,1661),(91,'AMHU-00073','KTP001','Jasa','UMROH HEMAT 16H SUB','assets/images/fotoservice/IMG-20230929-WA0012.jpg','34950000','23 JANUARI 2024','<p>UMROH HEMAT </p><p>PAKET 16 HARI</p><p>SURABAYA LANGSUNG JEDDAH</p><p>KEBERANGKATAN, 23 JANUARI 2024 </p><p>HARGA SEWAKTU-WAKTU DAPAT BERUBAH MENGIKUTI REGULASI YANG ADA.</p>',74,'Tampil',4,'RIYARD AL ZAHRO/SETARA',3,'MANAL AJYAD/FAJAR BADE 4',3,'LION AIR',16,310),(92,'AMHU-00074','KTP001','Jasa','UMROH HEMAT SUB','assets/images/fotoservice/IMG-20230929-WA0013.jpg','34950000','6 FEBRUARI 2024','<p>PAKET HEMAT</p><p>16 HARI</p><p>KEBERANGKATAN 6 FEBRUARI 2024 SURABAYA LANGSUNG JEDDAH</p><p>MAX $15.200</p><p>HARGA DAPAT BERUBAH SEWAKTU-WAKTU MENGIKUTI REGULASI YANG ADA</p>',75,'Tampil',4,'RIYARD AL ZAHRO/SETARA',3,'MANAL AJYAD/FAJAR BADE 4',3,'LION AIR',16,720),(93,'AMHU-0075','KTP001','Produk','UMROH PENUH KENANGAN','assets/images/fotoservice/3.png','34.950.000','16 NOVEMBER 2023','<p>UMROH PENUH KENANGAN</p><p>16 HARI</p><p>KEBERANGKATAN 16 NOVEMBER 2024 SURABAYA LANGSUNG JEDDAH</p><p>MAX $15.200</p><p>HARGA DAPAT BERUBAH SEWAKTU-WAKTU MENGIKUTI REGULASI YANG ADA</p>',76,'Tampil',4,'RIYARD AL ZAHRO/SETARA',3,'MANAL AJYAD/FAJAR BADE 4',3,'LION AIR',16,397),(94,'AMHU-0077','KTP001','Jasa','PAKET EKONOMI','assets/images/fotoservice/IMG-20231002-WA0003.jpg','36950000','23 JANUARI 2024','<p>UMROH EKONOMI, AMAN dan NYAMAN</p><p>KEBERANGKATAN, 23 JANUARI 2024</p><p>PAKET 16 HARI</p><p>SURABAYA LANGSUNH JEDDAH</p><p>MAX. KURS DOLLAR 15.300</p><p><br></p>',77,'Tampil',4,'RIYADH AL - ZAHRO',3,'AL MANNAR AJYAD',3,'LION AIR',16,468),(95,'AMHU-0078','KTP001','Jasa','PAKET HEMAT','assets/images/fotoservice/IMG-20231002-WA0002.jpg','36950000','6 FEBRUARI 2024','<p>PAKET HEMAT</p><p> KEBERANGKATAN TANGGAL 6 FEBRUARI 2024&nbsp;</p><p>PAKET 16 HARI</p><p>MASKAPAI LION AIR</p><p>SURABAYA - JEDDAH - SURABAYA</p><p><br></p>',78,'Tampil',4,'RIYADH AL - ZAHRO',3,'AL - MANNAR AJYAD',3,'LION AIR',16,361);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_tampil`
--

DROP TABLE IF EXISTS `service_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_tampil` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  `jumlah` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_tampil`
--

LOCK TABLES `service_tampil` WRITE;
/*!40000 ALTER TABLE `service_tampil` DISABLE KEYS */;
INSERT INTO `service_tampil` (`id`, `navbar`, `judul`, `diskripsi`, `tampil`, `jumlah`) VALUES (1,'Produk','Produk Unggulan','Produk kami siap melayani Anda','Tampil',24);
/*!40000 ALTER TABLE `service_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `skill` varchar(25) NOT NULL,
  `prosen` int(3) NOT NULL,
  `urut` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` (`id`, `skill`, `prosen`, `urut`) VALUES (3,'Penyelanggara Umroh',90,4),(4,'Umroh dan Tour Religi',70,3);
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skill_tampil`
--

DROP TABLE IF EXISTS `skill_tampil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skill_tampil` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `navbar` varchar(15) NOT NULL,
  `judul` varchar(25) NOT NULL,
  `diskripsi` varchar(200) NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill_tampil`
--

LOCK TABLES `skill_tampil` WRITE;
/*!40000 ALTER TABLE `skill_tampil` DISABLE KEYS */;
INSERT INTO `skill_tampil` (`id`, `navbar`, `judul`, `diskripsi`, `tampil`) VALUES (1,'Skill','Pengalaman yang luas','Keahlian yang sangat luar biasa','Tidak');
/*!40000 ALTER TABLE `skill_tampil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `foto` varchar(200) NOT NULL,
  `heading` varchar(250) NOT NULL,
  `baris1` varchar(250) NOT NULL,
  `baris2` varchar(250) NOT NULL,
  `urut` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` (`id`, `foto`, `heading`, `baris1`, `baris2`, `urut`) VALUES (20,'assets/images/slider/mekkah8.jpg','Go Digital','Ingin Punya Bisnis','Kami Memberi Fasilitas',3),(21,'assets/images/slider/background.jpg','Langkah diawali niat','Selamat & Sukses <span>AMINAH TOUR</span> Go Digital','Bisnis Ada Digenggaman Anda',4),(30,'assets/images/slider/nabawi4.jpg','Kami Hadir','Bekerja <span>Dengan</span> Hati','Melayani Ummat',2);
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `namavideo` varchar(150) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `urut` int(2) NOT NULL,
  `tampil` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'aminahto_aminaht'
--

--
-- Dumping routines for database 'aminahto_aminaht'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-23  7:07:37
