-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: aminahto_aminahku
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(50) NOT NULL,
  `uraian` mediumtext NOT NULL,
  `foto` varchar(150) NOT NULL,
  `fb` varchar(200) NOT NULL,
  `tw` varchar(200) NOT NULL,
  `ig` varchar(200) NOT NULL,
  `yt` varchar(150) NOT NULL,
  `video` varchar(200) NOT NULL,
  `perusahaan` varchar(255) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `kota` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `gmap` text NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` (`id`, `judul`, `uraian`, `foto`, `fb`, `tw`, `ig`, `yt`, `video`, `perusahaan`, `tagline`, `alamat`, `kota`, `email`, `hp`, `phone`, `gmap`, `tampil`) VALUES (1,'Tentang Kami','<p>PT. AMINAH</p><p>PT. AMINAH ADALAH PERUSAHAAN YANG BERGERAK DIBIDANG TOUR YANG DIKEMBANGKAN DENGAN MENYEDIAKAN PRODUK-PRODUK KEBUTUHAN SEHARI-HARI MAUPUN PRODUK YANG BERSIFAT UMUM YANG BERTUJUAN MEMBERI WADAH PARA PENGEMBANG BISNIS DAN MEMBERDAYAKAN UMAT DALAM KANCAH TEKNOLOGI. DENGAN TEKNOLOGI SEMUANYA SUDAH ADA DIGENGGAMAN SEHINGGA KAPAN DAN DIMANAPUN KITA BERADA, KITA BISA MENJALANI BISNIS KITA TANPA ADA HALANGAN DENGAN DEMIKIAN KONSUMEN PUAS.</p><p>KAMI SIAP MEMBERI WADAH BAGI ANDA YANG MEMERLUKAN WADAH UNTUK DIPASARKAN KARENA KAMI TELAH TERBENTUK KOMUNITAS BISNIS YANG JUMLAHNYA SUDAH RIBUAN PEBISNIS. </p><p><br></p>','assets/images/about/kantor_aminah.jpeg','https://www.facebook.com/username','http://twitter.com/username','https://www.instagram.com/username','https://www.youtube.com/channel/UCDPMexCdKzD4h0kTW_7t-Xg','4a1N74fK5dU','PT. AMINAH','Produk Berkualitas, Pulsa dan PPOB','Jl. Raya Wiguna Timur 48A','SURABAYA','aminah_a54@yahoo.com','082131973557','(031) 87854771','<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7914.291553805343!2d112.801625!3d-7.337521000000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7faae58751c03%3A0x12c124a28c02bc3c!2sJl.%20Raya%20Wiguna%20Timur%20No.48%2C%20Gn.%20Anyar%20Tambak%2C%20Kec.%20Gn.%20Anyar%2C%20Kota%20SBY%2C%20Jawa%20Timur%2060294!5e0!3m2!1sid!2sid!4v1645366344640!5m2!1sid!2sid\" width=\"1200\" height=\"600\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>','Tidak');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(256) NOT NULL,
  `lupapassword` varchar(200) NOT NULL,
  `singkat` varchar(150) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `hp` varchar(16) NOT NULL,
  `gmap` text NOT NULL,
  `foto` varchar(200) NOT NULL,
  `level` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`, `lupapassword`, `singkat`, `alamat`, `kota`, `email`, `hp`, `gmap`, `foto`, `level`, `created`) VALUES (1,'admin','$2y$10$Ms2sRJ3fQt74l0Zm46i6Pu4QOrLO.KVpyI6u5iSOnGnomjzDnbreq','kokbisalupa','HOTEL DEKAT, HARGA HEMAT, IBADAH NIKMAT','Trillium Office and Residence brJl. Pemuda 108 - 116 Lt. I No. 07','Surabaya','aminah_a54@yahoo.com','+6231 5116900','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.778945994214!2d112.74673651466809!3d-7.2659789947552875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7f962bc2c8d51%3A0x984f49879deb4e25!2sPT%20SAFARI%20GLOBAL%20PERKASA%20-%20Surabaya!5e0!3m2!1sid!2sid!4v1595148116942!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','assets/images/about/3D-Abstract-Background-Wallpapers-Part-2-3-300x187.jpg',1,'2020-04-01 00:00:00'),(2,'admin1708','$2y$10$AV.yJ4Zn.kngMgLh7L8EBOKBjtphDBm.I0N23oj1Z6YQ07p5qdP0C','kokbisalupa','HOTEL DEKAT, HARGA HEMAT, IBADAH NIKMAT','Trillium Office and Residence brJl. Pemuda 108 - 116 Lt. I No. 07','Surabaya','aminah_a54@yahoo.com','+6231 5116900','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.778945994214!2d112.74673651466809!3d-7.2659789947552875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7f962bc2c8d51%3A0x984f49879deb4e25!2sPT%20SAFARI%20GLOBAL%20PERKASA%20-%20Surabaya!5e0!3m2!1sid!2sid!4v1595148116942!5m2!1sid!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','assets/images/about/3D-Abstract-Background-Wallpapers-Part-2-3-300x187.jpg',1,'2020-04-01 00:00:00');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acak` varchar(5) NOT NULL,
  `userpasti` varchar(100) NOT NULL,
  `url_web` varchar(50) NOT NULL,
  `th_web` varchar(4) NOT NULL,
  `titel_web` varchar(150) NOT NULL,
  `keyword_web` varchar(250) NOT NULL,
  `diskripsi_web` varchar(250) NOT NULL,
  `judul_web` varchar(150) NOT NULL,
  `favicon` varchar(100) NOT NULL,
  `fontawesome` varchar(50) NOT NULL,
  `sessionadmin` varchar(255) NOT NULL,
  `sessionpassadmin` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`id`, `acak`, `userpasti`, `url_web`, `th_web`, `titel_web`, `keyword_web`, `diskripsi_web`, `judul_web`, `favicon`, `fontawesome`, `sessionadmin`, `sessionpassadmin`) VALUES (1,'0','1401-0000-0001','aminahku.com','2022','Produk Berkualitas dan Bermanfaat','produk jamu, madu','Kami menjual produk madu dengan kualotas tinggi','Aminahku.com','assets/images/favicon.ico','<i class=\"fas fa-user\"></i>','Admin','PasswordAdmin');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kabupaten`
--

DROP TABLE IF EXISTS `kabupaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kabupaten` (
  `id_kab` char(4) NOT NULL,
  `id_prov` char(2) NOT NULL,
  `nama` tinytext NOT NULL,
  `id_jenis` int(11) NOT NULL,
  PRIMARY KEY (`id_kab`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kabupaten`
--

LOCK TABLES `kabupaten` WRITE;
/*!40000 ALTER TABLE `kabupaten` DISABLE KEYS */;
INSERT INTO `kabupaten` (`id_kab`, `id_prov`, `nama`, `id_jenis`) VALUES ('1101','11','KAB. ACEH SELATAN',1),('1102','11','KAB. ACEH TENGGARA',1),('1103','11','KAB. ACEH TIMUR',1),('1104','11','KAB. ACEH TENGAH',1),('1105','11','KAB. ACEH BARAT',1),('1106','11','KAB. ACEH BESAR',1),('1107','11','KAB. PIDIE',1),('1108','11','KAB. ACEH UTARA',1),('1109','11','KAB. SIMEULUE',1),('1110','11','KAB. ACEH SINGKIL',1),('1111','11','KAB. BIREUEN',1),('1112','11','KAB. ACEH BARAT DAYA',1),('1113','11','KAB. GAYO LUES',1),('1114','11','KAB. ACEH JAYA',1),('1115','11','KAB. NAGAN RAYA',1),('1116','11','KAB. ACEH TAMIANG',1),('1117','11','KAB. BENER MERIAH',1),('1118','11','KAB. PIDIE JAYA',1),('1171','11','KOTA BANDA ACEH',2),('1172','11','KOTA SABANG',2),('1173','11','KOTA LHOKSEUMAWE',2),('1174','11','KOTA LANGSA',2),('1175','11','KOTA SUBULUSSALAM',2),('1201','12','KAB. TAPANULI TENGAH',1),('1202','12','KAB. TAPANULI UTARA',1),('1203','12','KAB. TAPANULI SELATAN',1),('1204','12','KAB. NIAS',1),('1205','12','KAB. LANGKAT',1),('1206','12','KAB. KARO',1),('1207','12','KAB. DELI SERDANG',1),('1208','12','KAB. SIMALUNGUN',1),('1209','12','KAB. ASAHAN',1),('1210','12','KAB. LABUHANBATU',1),('1211','12','KAB. DAIRI',1),('1212','12','KAB. TOBA SAMOSIR',1),('1213','12','KAB. MANDAILING NATAL',1),('1214','12','KAB. NIAS SELATAN',1),('1215','12','KAB. PAKPAK BHARAT',1),('1216','12','KAB. HUMBANG HASUNDUTAN',1),('1217','12','KAB. SAMOSIR',1),('1218','12','KAB. SERDANG BEDAGAI',1),('1219','12','KAB. BATU BARA',1),('1220','12','KAB. PADANG LAWAS UTARA',1),('1221','12','KAB. PADANG LAWAS',1),('1222','12','KAB. LABUHANBATU SELATAN',1),('1223','12','KAB. LABUHANBATU UTARA',1),('1224','12','KAB. NIAS UTARA',1),('1225','12','KAB. NIAS BARAT',1),('1271','12','KOTA MEDAN',2),('1272','12','KOTA PEMATANG SIANTAR',2),('1273','12','KOTA SIBOLGA',2),('1274','12','KOTA TANJUNG BALAI',2),('1275','12','KOTA BINJAI',2),('1276','12','KOTA TEBING TINGGI',2),('1277','12','KOTA PADANGSIDIMPUAN',2),('1278','12','KOTA GUNUNGSITOLI',2),('1301','13','KAB. PESISIR SELATAN',1),('1302','13','KAB. SOLOK',1),('1303','13','KAB. SIJUNJUNG',1),('1304','13','KAB. TANAH DATAR',1),('1305','13','KAB. PADANG PARIAMAN',1),('1306','13','KAB. AGAM',1),('1307','13','KAB. LIMA PULUH KOTA',1),('1308','13','KAB. PASAMAN',1),('1309','13','KAB. KEPULAUAN MENTAWAI',1),('1310','13','KAB. DHARMASRAYA',1),('1311','13','KAB. SOLOK SELATAN',1),('1312','13','KAB. PASAMAN BARAT',1),('1371','13','KOTA PADANG',2),('1372','13','KOTA SOLOK',2),('1373','13','KOTA SAWAHLUNTO',2),('1374','13','KOTA PADANG PANJANG',2),('1375','13','KOTA BUKITTINGGI',2),('1376','13','KOTA PAYAKUMBUH',2),('1377','13','KOTA PARIAMAN',2),('1401','14','KAB. KAMPAR',1),('1402','14','KAB. INDRAGIRI HULU',1),('1403','14','KAB. BENGKALIS',1),('1404','14','KAB. INDRAGIRI HILIR',1),('1405','14','KAB. PELALAWAN',1),('1406','14','KAB. ROKAN HULU',1),('1407','14','KAB. ROKAN HILIR',1),('1408','14','KAB. SIAK',1),('1409','14','KAB. KUANTAN SINGINGI',1),('1410','14','KAB. KEPULAUAN MERANTI',1),('1471','14','KOTA PEKANBARU',2),('1472','14','KOTA DUMAI',2),('1501','15','KAB. KERINCI',1),('1502','15','KAB. MERANGIN',1),('1503','15','KAB. SAROLANGUN',1),('1504','15','KAB. BATANGHARI',1),('1505','15','KAB. MUARO JAMBI',1),('1506','15','KAB. TANJUNG JABUNG BARAT',1),('1507','15','KAB. TANJUNG JABUNG TIMUR',1),('1508','15','KAB. BUNGO',1),('1509','15','KAB. TEBO',1),('1571','15','KOTA JAMBI',2),('1572','15','KOTA SUNGAI PENUH',2),('1601','16','KAB. OGAN KOMERING ULU',1),('1602','16','KAB. OGAN KOMERING ILIR',1),('1603','16','KAB. MUARA ENIM',1),('1604','16','KAB. LAHAT',1),('1605','16','KAB. MUSI RAWAS',1),('1606','16','KAB. MUSI BANYUASIN',1),('1607','16','KAB. BANYUASIN',1),('1608','16','KAB. OGAN KOMERING ULU TIMUR',1),('1609','16','KAB. OGAN KOMERING ULU SELATAN',1),('1610','16','KAB. OGAN ILIR',1),('1611','16','KAB. EMPAT LAWANG',1),('1612','16','KAB. PENUKAL ABAB LEMATANG ILIR',1),('1613','16','KAB. MUSI RAWAS UTARA',1),('1671','16','KOTA PALEMBANG',2),('1672','16','KOTA PAGAR ALAM',2),('1673','16','KOTA LUBUK LINGGAU',2),('1674','16','KOTA PRABUMULIH',2),('1701','17','KAB. BENGKULU SELATAN',1),('1702','17','KAB. REJANG LEBONG',1),('1703','17','KAB. BENGKULU UTARA',1),('1704','17','KAB. KAUR',1),('1705','17','KAB. SELUMA',1),('1706','17','KAB. MUKO MUKO',1),('1707','17','KAB. LEBONG',1),('1708','17','KAB. KEPAHIANG',1),('1709','17','KAB. BENGKULU TENGAH',1),('1771','17','KOTA BENGKULU',2),('1801','18','KAB. LAMPUNG SELATAN',1),('1802','18','KAB. LAMPUNG TENGAH',1),('1803','18','KAB. LAMPUNG UTARA',1),('1804','18','KAB. LAMPUNG BARAT',1),('1805','18','KAB. TULANG BAWANG',1),('1806','18','KAB. TANGGAMUS',1),('1807','18','KAB. LAMPUNG TIMUR',1),('1808','18','KAB. WAY KANAN',1),('1809','18','KAB. PESAWARAN',1),('1810','18','KAB. PRINGSEWU',1),('1811','18','KAB. MESUJI',1),('1812','18','KAB. TULANG BAWANG BARAT',1),('1813','18','KAB. PESISIR BARAT',1),('1871','18','KOTA BANDAR LAMPUNG',2),('1872','18','KOTA METRO',2),('1901','19','KAB. BANGKA',1),('1902','19','KAB. BELITUNG',1),('1903','19','KAB. BANGKA SELATAN',1),('1904','19','KAB. BANGKA TENGAH',1),('1905','19','KAB. BANGKA BARAT',1),('1906','19','KAB. BELITUNG TIMUR',1),('1971','19','KOTA PANGKAL PINANG',2),('2101','21','KAB. BINTAN',1),('2102','21','KAB. KARIMUN',1),('2103','21','KAB. NATUNA',1),('2104','21','KAB. LINGGA',1),('2105','21','KAB. KEPULAUAN ANAMBAS',1),('2171','21','KOTA BATAM',2),('2172','21','KOTA TANJUNG PINANG',2),('3101','31','KAB. ADM. KEP. SERIBU',1),('3171','31','KOTA ADM. JAKARTA PUSAT',2),('3172','31','KOTA ADM. JAKARTA UTARA',2),('3173','31','KOTA ADM. JAKARTA BARAT',2),('3174','31','KOTA ADM. JAKARTA SELATAN',2),('3175','31','KOTA ADM. JAKARTA TIMUR',2),('3201','32','KAB. BOGOR',1),('3202','32','KAB. SUKABUMI',1),('3203','32','KAB. CIANJUR',1),('3204','32','KAB. BANDUNG',1),('3205','32','KAB. GARUT',1),('3206','32','KAB. TASIKMALAYA',1),('3207','32','KAB. CIAMIS',1),('3208','32','KAB. KUNINGAN',1),('3209','32','KAB. CIREBON',1),('3210','32','KAB. MAJALENGKA',1),('3211','32','KAB. SUMEDANG',1),('3212','32','KAB. INDRAMAYU',1),('3213','32','KAB. SUBANG',1),('3214','32','KAB. PURWAKARTA',1),('3215','32','KAB. KARAWANG',1),('3216','32','KAB. BEKASI',1),('3217','32','KAB. BANDUNG BARAT',1),('3218','32','KAB. PANGANDARAN',1),('3271','32','KOTA BOGOR',2),('3272','32','KOTA SUKABUMI',2),('3273','32','KOTA BANDUNG',2),('3274','32','KOTA CIREBON',2),('3275','32','KOTA BEKASI',2),('3276','32','KOTA DEPOK',2),('3277','32','KOTA CIMAHI',2),('3278','32','KOTA TASIKMALAYA',2),('3279','32','KOTA BANJAR',2),('3301','33','KAB. CILACAP',1),('3302','33','KAB. BANYUMAS',1),('3303','33','KAB. PURBALINGGA',1),('3304','33','KAB. BANJARNEGARA',1),('3305','33','KAB. KEBUMEN',1),('3306','33','KAB. PURWOREJO',1),('3307','33','KAB. WONOSOBO',1),('3308','33','KAB. MAGELANG',1),('3309','33','KAB. BOYOLALI',1),('3310','33','KAB. KLATEN',1),('3311','33','KAB. SUKOHARJO',1),('3312','33','KAB. WONOGIRI',1),('3313','33','KAB. KARANGANYAR',1),('3314','33','KAB. SRAGEN',1),('3315','33','KAB. GROBOGAN',1),('3316','33','KAB. BLORA',1),('3317','33','KAB. REMBANG',1),('3318','33','KAB. PATI',1),('3319','33','KAB. KUDUS',1),('3320','33','KAB. JEPARA',1),('3321','33','KAB. DEMAK',1),('3322','33','KAB. SEMARANG',1),('3323','33','KAB. TEMANGGUNG',1),('3324','33','KAB. KENDAL',1),('3325','33','KAB. BATANG',1),('3326','33','KAB. PEKALONGAN',1),('3327','33','KAB. PEMALANG',1),('3328','33','KAB. TEGAL',1),('3329','33','KAB. BREBES',1),('3371','33','KOTA MAGELANG',2),('3372','33','KOTA SURAKARTA',2),('3373','33','KOTA SALATIGA',2),('3374','33','KOTA SEMARANG',2),('3375','33','KOTA PEKALONGAN',2),('3376','33','KOTA TEGAL',2),('3401','34','KAB. KULON PROGO',1),('3402','34','KAB. BANTUL',1),('3403','34','KAB. GUNUNG KIDUL',1),('3404','34','KAB. SLEMAN',1),('3471','34','KOTA YOGYAKARTA',2),('3501','35','KAB. PACITAN',1),('3502','35','KAB. PONOROGO',1),('3503','35','KAB. TRENGGALEK',1),('3504','35','KAB. TULUNGAGUNG',1),('3505','35','KAB. BLITAR',1),('3506','35','KAB. KEDIRI',1),('3507','35','KAB. MALANG',1),('3508','35','KAB. LUMAJANG',1),('3509','35','KAB. JEMBER',1),('3510','35','KAB. BANYUWANGI',1),('3511','35','KAB. BONDOWOSO',1),('3512','35','KAB. SITUBONDO',1),('3513','35','KAB. PROBOLINGGO',1),('3514','35','KAB. PASURUAN',1),('3515','35','KAB. SIDOARJO',1),('3516','35','KAB. MOJOKERTO',1),('3517','35','KAB. JOMBANG',1),('3518','35','KAB. NGANJUK',1),('3519','35','KAB. MADIUN',1),('3520','35','KAB. MAGETAN',1),('3521','35','KAB. NGAWI',1),('3522','35','KAB. BOJONEGORO',1),('3523','35','KAB. TUBAN',1),('3524','35','KAB. LAMONGAN',1),('3525','35','KAB. GRESIK',1),('3526','35','KAB. BANGKALAN',1),('3527','35','KAB. SAMPANG',1),('3528','35','KAB. PAMEKASAN',1),('3529','35','KAB. SUMENEP',1),('3571','35','KOTA KEDIRI',2),('3572','35','KOTA BLITAR',2),('3573','35','KOTA MALANG',2),('3574','35','KOTA PROBOLINGGO',2),('3575','35','KOTA PASURUAN',2),('3576','35','KOTA MOJOKERTO',2),('3577','35','KOTA MADIUN',2),('3578','35','KOTA SURABAYA',2),('3579','35','KOTA BATU',2),('3601','36','KAB. PANDEGLANG',1),('3602','36','KAB. LEBAK',1),('3603','36','KAB. TANGERANG',1),('3604','36','KAB. SERANG',1),('3671','36','KOTA TANGERANG',2),('3672','36','KOTA CILEGON',2),('3673','36','KOTA SERANG',2),('3674','36','KOTA TANGERANG SELATAN',2),('5101','51','KAB. JEMBRANA',1),('5102','51','KAB. TABANAN',1),('5103','51','KAB. BADUNG',1),('5104','51','KAB. GIANYAR',1),('5105','51','KAB. KLUNGKUNG',1),('5106','51','KAB. BANGLI',1),('5107','51','KAB. KARANGASEM',1),('5108','51','KAB. BULELENG',1),('5171','51','KOTA DENPASAR',2),('5201','52','KAB. LOMBOK BARAT',1),('5202','52','KAB. LOMBOK TENGAH',1),('5203','52','KAB. LOMBOK TIMUR',1),('5204','52','KAB. SUMBAWA',1),('5205','52','KAB. DOMPU',1),('5206','52','KAB. BIMA',1),('5207','52','KAB. SUMBAWA BARAT',1),('5208','52','KAB. LOMBOK UTARA',1),('5271','52','KOTA MATARAM',2),('5272','52','KOTA BIMA',2),('5301','53','KAB. KUPANG',1),('5302','53','KAB TIMOR TENGAH SELATAN',1),('5303','53','KAB. TIMOR TENGAH UTARA',1),('5304','53','KAB. BELU',1),('5305','53','KAB. ALOR',1),('5306','53','KAB. FLORES TIMUR',1),('5307','53','KAB. SIKKA',1),('5308','53','KAB. ENDE',1),('5309','53','KAB. NGADA',1),('5310','53','KAB. MANGGARAI',1),('5311','53','KAB. SUMBA TIMUR',1),('5312','53','KAB. SUMBA BARAT',1),('5313','53','KAB. LEMBATA',1),('5314','53','KAB. ROTE NDAO',1),('5315','53','KAB. MANGGARAI BARAT',1),('5316','53','KAB. NAGEKEO',1),('5317','53','KAB. SUMBA TENGAH',1),('5318','53','KAB. SUMBA BARAT DAYA',1),('5319','53','KAB. MANGGARAI TIMUR',1),('5320','53','KAB. SABU RAIJUA',1),('5321','53','KAB. MALAKA',1),('5371','53','KOTA KUPANG',2),('6101','61','KAB. SAMBAS',1),('6102','61','KAB. MEMPAWAH',1),('6103','61','KAB. SANGGAU',1),('6104','61','KAB. KETAPANG',1),('6105','61','KAB. SINTANG',1),('6106','61','KAB. KAPUAS HULU',1),('6107','61','KAB. BENGKAYANG',1),('6108','61','KAB. LANDAK',1),('6109','61','KAB. SEKADAU',1),('6110','61','KAB. MELAWI',1),('6111','61','KAB. KAYONG UTARA',1),('6112','61','KAB. KUBU RAYA',1),('6171','61','KOTA PONTIANAK',2),('6172','61','KOTA SINGKAWANG',2),('6201','62','KAB. KOTAWARINGIN BARAT',1),('6202','62','KAB. KOTAWARINGIN TIMUR',1),('6203','62','KAB. KAPUAS',1),('6204','62','KAB. BARITO SELATAN',1),('6205','62','KAB. BARITO UTARA',1),('6206','62','KAB. KATINGAN',1),('6207','62','KAB. SERUYAN',1),('6208','62','KAB. SUKAMARA',1),('6209','62','KAB. LAMANDAU',1),('6210','62','KAB. GUNUNG MAS',1),('6211','62','KAB. PULANG PISAU',1),('6212','62','KAB. MURUNG RAYA',1),('6213','62','KAB. BARITO TIMUR',1),('6271','62','KOTA PALANGKARAYA',2),('6301','63','KAB. TANAH LAUT',1),('6302','63','KAB. KOTABARU',1),('6303','63','KAB. BANJAR',1),('6304','63','KAB. BARITO KUALA',1),('6305','63','KAB. TAPIN',1),('6306','63','KAB. HULU SUNGAI SELATAN',1),('6307','63','KAB. HULU SUNGAI TENGAH',1),('6308','63','KAB. HULU SUNGAI UTARA',1),('6309','63','KAB. TABALONG',1),('6310','63','KAB. TANAH BUMBU',1),('6311','63','KAB. BALANGAN',1),('6371','63','KOTA BANJARMASIN',2),('6372','63','KOTA BANJARBARU',2),('6401','64','KAB. PASER',1),('6402','64','KAB. KUTAI KARTANEGARA',1),('6403','64','KAB. BERAU',1),('6407','64','KAB. KUTAI BARAT',1),('6408','64','KAB. KUTAI TIMUR',1),('6409','64','KAB. PENAJAM PASER UTARA',1),('6411','64','KAB. MAHAKAM ULU',1),('6471','64','KOTA BALIKPAPAN',2),('6472','64','KOTA SAMARINDA',2),('6474','64','KOTA BONTANG',2),('6501','65','KAB. BULUNGAN',1),('6502','65','KAB. MALINAU',1),('6503','65','KAB. NUNUKAN',1),('6504','65','KAB. TANA TIDUNG',1),('6571','65','KOTA TARAKAN',2),('7101','71','KAB. BOLAANG MONGONDOW',1),('7102','71','KAB. MINAHASA',1),('7103','71','KAB. KEPULAUAN SANGIHE',1),('7104','71','KAB. KEPULAUAN TALAUD',1),('7105','71','KAB. MINAHASA SELATAN',1),('7106','71','KAB. MINAHASA UTARA',1),('7107','71','KAB. MINAHASA TENGGARA',1),('7108','71','KAB. BOLAANG MONGONDOW UTARA',1),('7109','71','KAB. KEP. SIAU TAGULANDANG BIARO',1),('7110','71','KAB. BOLAANG MONGONDOW TIMUR',1),('7111','71','KAB. BOLAANG MONGONDOW SELATAN',1),('7171','71','KOTA MANADO',2),('7172','71','KOTA BITUNG',2),('7173','71','KOTA TOMOHON',2),('7174','71','KOTA KOTAMOBAGU',2),('7201','72','KAB. BANGGAI',1),('7202','72','KAB. POSO',1),('7203','72','KAB. DONGGALA',1),('7204','72','KAB. TOLI TOLI',1),('7205','72','KAB. BUOL',1),('7206','72','KAB. MOROWALI',1),('7207','72','KAB. BANGGAI KEPULAUAN',1),('7208','72','KAB. PARIGI MOUTONG',1),('7209','72','KAB. TOJO UNA UNA',1),('7210','72','KAB. SIGI',1),('7211','72','KAB. BANGGAI LAUT',1),('7212','72','KAB. MOROWALI UTARA',1),('7271','72','KOTA PALU',2),('7301','73','KAB. KEPULAUAN SELAYAR',1),('7302','73','KAB. BULUKUMBA',1),('7303','73','KAB. BANTAENG',1),('7304','73','KAB. JENEPONTO',1),('7305','73','KAB. TAKALAR',1),('7306','73','KAB. GOWA',1),('7307','73','KAB. SINJAI',1),('7308','73','KAB. BONE',1),('7309','73','KAB. MAROS',1),('7310','73','KAB. PANGKAJENE KEPULAUAN',1),('7311','73','KAB. BARRU',1),('7312','73','KAB. SOPPENG',1),('7313','73','KAB. WAJO',1),('7314','73','KAB. SIDENRENG RAPPANG',1),('7315','73','KAB. PINRANG',1),('7316','73','KAB. ENREKANG',1),('7317','73','KAB. LUWU',1),('7318','73','KAB. TANA TORAJA',1),('7322','73','KAB. LUWU UTARA',1),('7324','73','KAB. LUWU TIMUR',1),('7326','73','KAB. TORAJA UTARA',1),('7371','73','KOTA MAKASSAR',2),('7372','73','KOTA PARE PARE',2),('7373','73','KOTA PALOPO',2),('7401','74','KAB. KOLAKA',1),('7402','74','KAB. KONAWE',1),('7403','74','KAB. MUNA',1),('7404','74','KAB. BUTON',1),('7405','74','KAB. KONAWE SELATAN',1),('7406','74','KAB. BOMBANA',1),('7407','74','KAB. WAKATOBI',1),('7408','74','KAB. KOLAKA UTARA',1),('7409','74','KAB. KONAWE UTARA',1),('7410','74','KAB. BUTON UTARA',1),('7411','74','KAB. KOLAKA TIMUR',1),('7412','74','KAB. KONAWE KEPULAUAN',1),('7413','74','KAB. MUNA BARAT',1),('7414','74','KAB. BUTON TENGAH',1),('7415','74','KAB. BUTON SELATAN',1),('7471','74','KOTA KENDARI',2),('7472','74','KOTA BAU BAU',2),('7501','75','KAB. GORONTALO',1),('7502','75','KAB. BOALEMO',1),('7503','75','KAB. BONE BOLANGO',1),('7504','75','KAB. PAHUWATO',1),('7505','75','KAB. GORONTALO UTARA',1),('7571','75','KOTA GORONTALO',2),('7601','76','KAB. MAMUJU UTARA',1),('7602','76','KAB. MAMUJU',1),('7603','76','KAB. MAMASA',1),('7604','76','KAB. POLEWALI MANDAR',1),('7605','76','KAB. MAJENE',1),('7606','76','KAB. MAMUJU TENGAH',1),('8101','81','KAB. MALUKU TENGAH',1),('8102','81','KAB. MALUKU TENGGARA',1),('8103','81','KAB MALUKU TENGGARA BARAT',1),('8104','81','KAB. BURU',1),('8105','81','KAB. SERAM BAGIAN TIMUR',1),('8106','81','KAB. SERAM BAGIAN BARAT',1),('8107','81','KAB. KEPULAUAN ARU',1),('8108','81','KAB. MALUKU BARAT DAYA',1),('8109','81','KAB. BURU SELATAN',1),('8171','81','KOTA AMBON',2),('8172','81','KOTA TUAL',2),('8201','82','KAB. HALMAHERA BARAT',1),('8202','82','KAB. HALMAHERA TENGAH',1),('8203','82','KAB. HALMAHERA UTARA',1),('8204','82','KAB. HALMAHERA SELATAN',1),('8205','82','KAB. KEPULAUAN SULA',1),('8206','82','KAB. HALMAHERA TIMUR',1),('8207','82','KAB. PULAU MOROTAI',1),('8208','82','KAB. PULAU TALIABU',1),('8271','82','KOTA TERNATE',2),('8272','82','KOTA TIDORE KEPULAUAN',2),('9101','91','KAB. MERAUKE',1),('9102','91','KAB. JAYAWIJAYA',1),('9103','91','KAB. JAYAPURA',1),('9104','91','KAB. NABIRE',1),('9105','91','KAB. KEPULAUAN YAPEN',1),('9106','91','KAB. BIAK NUMFOR',1),('9107','91','KAB. PUNCAK JAYA',1),('9108','91','KAB. PANIAI',1),('9109','91','KAB. MIMIKA',1),('9110','91','KAB. SARMI',1),('9111','91','KAB. KEEROM',1),('9112','91','KAB PEGUNUNGAN BINTANG',1),('9113','91','KAB. YAHUKIMO',1),('9114','91','KAB. TOLIKARA',1),('9115','91','KAB. WAROPEN',1),('9116','91','KAB. BOVEN DIGOEL',1),('9117','91','KAB. MAPPI',1),('9118','91','KAB. ASMAT',1),('9119','91','KAB. SUPIORI',1),('9120','91','KAB. MAMBERAMO RAYA',1),('9121','91','KAB. MAMBERAMO TENGAH',1),('9122','91','KAB. YALIMO',1),('9123','91','KAB. LANNY JAYA',1),('9124','91','KAB. NDUGA',1),('9125','91','KAB. PUNCAK',1),('9126','91','KAB. DOGIYAI',1),('9127','91','KAB. INTAN JAYA',1),('9128','91','KAB. DEIYAI',1),('9171','91','KOTA JAYAPURA',2),('9201','92','KAB. SORONG',1),('9202','92','KAB. MANOKWARI',1),('9203','92','KAB. FAK FAK',1),('9204','92','KAB. SORONG SELATAN',1),('9205','92','KAB. RAJA AMPAT',1),('9206','92','KAB. TELUK BINTUNI',1),('9207','92','KAB. TELUK WONDAMA',1),('9208','92','KAB. KAIMANA',1),('9209','92','KAB. TAMBRAUW',1),('9210','92','KAB. MAYBRAT',1),('9211','92','KAB. MANOKWARI SELATAN',1),('9212','92','KAB. PEGUNUNGAN ARFAK',1),('9271','92','KOTA SORONG',2);
/*!40000 ALTER TABLE `kabupaten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_catproduct_11`
--

DROP TABLE IF EXISTS `m_catproduct_11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_catproduct_11` (
  `fidsys` bigint(19) NOT NULL,
  `fidcat` varchar(55) COLLATE latin1_general_ci NOT NULL,
  `fnamacat` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `faktif` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_catproduct_11`
--

LOCK TABLES `m_catproduct_11` WRITE;
/*!40000 ALTER TABLE `m_catproduct_11` DISABLE KEYS */;
INSERT INTO `m_catproduct_11` (`fidsys`, `fidcat`, `fnamacat`, `faktif`) VALUES (13,'CAT-0002','Health Food','1'),(14,'CAT-0003','Skin Care','1');
/*!40000 ALTER TABLE `m_catproduct_11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_pebisnis_11`
--

DROP TABLE IF EXISTS `m_pebisnis_11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_pebisnis_11` (
  `fidsys` int(10) NOT NULL AUTO_INCREMENT,
  `fidmember` varchar(50) NOT NULL,
  `frefer` varchar(50) NOT NULL,
  `fnama` varchar(50) NOT NULL,
  `fnohp` varchar(40) NOT NULL,
  `fnamabank` varchar(150) DEFAULT NULL,
  `fnorekening` varchar(25) NOT NULL,
  `fatasnama` varchar(200) NOT NULL,
  `falamat` varchar(200) NOT NULL,
  `fcountry` varchar(15) NOT NULL DEFAULT 'ID',
  `fprop` varchar(30) NOT NULL DEFAULT 'I',
  `fkota` varchar(30) NOT NULL,
  `fkec` varchar(55) DEFAULT NULL,
  `femail` varchar(50) NOT NULL,
  `faktif` varchar(1) NOT NULL DEFAULT '0',
  `ftglaktif` datetime DEFAULT NULL,
  `fnoktp` varchar(100) NOT NULL,
  `fket` varchar(254) NOT NULL,
  `fsynctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fsaldovcr` double DEFAULT '0',
  PRIMARY KEY (`fidsys`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_pebisnis_11`
--

LOCK TABLES `m_pebisnis_11` WRITE;
/*!40000 ALTER TABLE `m_pebisnis_11` DISABLE KEYS */;
INSERT INTO `m_pebisnis_11` (`fidsys`, `fidmember`, `frefer`, `fnama`, `fnohp`, `fnamabank`, `fnorekening`, `fatasnama`, `falamat`, `fcountry`, `fprop`, `fkota`, `fkec`, `femail`, `faktif`, `ftglaktif`, `fnoktp`, `fket`, `fsynctime`, `fsaldovcr`) VALUES (1,'1401-0000-0001','1401-0000-0001','PT. AMINAH','082131973557','BBBB','123','Amino','Alamat Ketintang','ID','35','15','01','','1','2014-01-01 00:00:00','9999999999999','','2020-02-01 23:15:50',56701),(2,'1411-0000-0002','1411-0000-0002','DRS.MOHAMAD TAUFIQ','6282334299439','BANK SYARIAH MANDIRI','7015600718','MOHAMAD TAUFIQ QQ TABUNGAN','NGINDEN INTAN BARAT V-22/C6-39 RT.01 RW.11','ID','35','78','09','','1','2014-11-22 10:23:10','','','2020-02-01 23:15:50',0);
/*!40000 ALTER TABLE `m_pebisnis_11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_product_11`
--

DROP TABLE IF EXISTS `m_product_11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_product_11` (
  `fidsys` bigint(20) NOT NULL AUTO_INCREMENT,
  `fidproduk` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fnamaproduk` varchar(254) COLLATE latin1_general_ci DEFAULT NULL,
  `fidcat` varchar(55) COLLATE latin1_general_ci DEFAULT NULL,
  `fmerk` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fexpired` date DEFAULT NULL,
  `fmodel` varchar(55) COLLATE latin1_general_ci DEFAULT NULL,
  `fbarcode` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fsatuan` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `fhargajual1` double(15,2) DEFAULT '0.00',
  `fhargajual2` double(15,2) DEFAULT '0.00',
  `fhargajual3` double(15,2) DEFAULT '0.00',
  `fhargajual4` double(15,2) DEFAULT '0.00',
  `fvat` double DEFAULT '0',
  `fsize` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `fidcolor` varchar(125) COLLATE latin1_general_ci DEFAULT NULL,
  `fpabrik` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `fkemasan` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `fhpp` float DEFAULT NULL,
  `fhargabeli` float DEFAULT NULL,
  `fgambar` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `fpointmember` float DEFAULT NULL,
  `fpointstockist` float DEFAULT NULL,
  `fpointadmin` float DEFAULT NULL,
  `fketerangan` varchar(254) COLLATE latin1_general_ci DEFAULT NULL,
  `fberat` float DEFAULT NULL,
  `fvolume` float DEFAULT NULL,
  `fsession` varchar(254) COLLATE latin1_general_ci DEFAULT NULL,
  `fuserid` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `ftglentry` datetime DEFAULT NULL,
  `faktif` varchar(1) COLLATE latin1_general_ci DEFAULT NULL,
  `fbalance` double DEFAULT '0',
  `fref` varchar(55) COLLATE latin1_general_ci DEFAULT NULL,
  `fimage` varchar(155) COLLATE latin1_general_ci DEFAULT NULL,
  `fdesc` text COLLATE latin1_general_ci,
  PRIMARY KEY (`fidsys`),
  UNIQUE KEY `IDX_CODE` (`fidproduk`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_product_11`
--

LOCK TABLES `m_product_11` WRITE;
/*!40000 ALTER TABLE `m_product_11` DISABLE KEYS */;
INSERT INTO `m_product_11` (`fidsys`, `fidproduk`, `fnamaproduk`, `fidcat`, `fmerk`, `fexpired`, `fmodel`, `fbarcode`, `fsatuan`, `fhargajual1`, `fhargajual2`, `fhargajual3`, `fhargajual4`, `fvat`, `fsize`, `fidcolor`, `fpabrik`, `fkemasan`, `fhpp`, `fhargabeli`, `fgambar`, `fpointmember`, `fpointstockist`, `fpointadmin`, `fketerangan`, `fberat`, `fvolume`, `fsession`, `fuserid`, `ftglentry`, `faktif`, `fbalance`, `fref`, `fimage`, `fdesc`) VALUES (19,'HFP-003','MADUTULANG','CAT-0002',NULL,NULL,NULL,NULL,NULL,180000.00,0.00,0.00,0.00,198000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,280,NULL,NULL,NULL,NULL,'1',0,NULL,'8ecJFg7k-2.jpg','Kandungannya yang kaya nutrisi membuat madu memiliki berbagai manfaat kesehatan.  Bahkan, madu juga dianggap sebagai salah satu bahan terbaik untuk menguatkan tulang dan menambah kekuatan otak tanpa efek samping. \r\n\r\n\r\n'),(20,'HFP-004','MADULEMAK','CAT-0003',NULL,NULL,NULL,NULL,NULL,200000.00,215000.00,0.00,0.00,220000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,280,NULL,NULL,NULL,NULL,'1',0,NULL,'8ecJFg7k-5.jpg','Kandungannya yang kaya nutrisi membuat madu memiliki berbagai manfaat kesehatan.  Bahkan, madu juga dianggap sebagai salah satu bahan terbaik untuk menurunkan berat badan, karena madu dapat membantu mengurangi dan membakar lemak tanpa efek samping. \r\n\r\nArtikel ini telah tayang di Kontan.co.id dengan judul \"Konsumsi madu bisa turunkan berat badan, berikut caranya\", Klik untuk baca: https://kesehatan.kontan.co.id/news/konsumsi-madu-bisa-turunkan-berat-badan-berikut-caranya?page=all.\r\n\r\nEditor: Herlina Kartika Dewi |  Reporter: Herlina KD\r\n');
/*!40000 ALTER TABLE `m_product_11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `hp` varchar(15) NOT NULL,
  `wa` varchar(15) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `ig` varchar(255) NOT NULL,
  `tw` varchar(255) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(25) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`id`, `aman`, `user_id`, `username`, `foto`, `nama`, `hp`, `wa`, `fb`, `ig`, `tw`, `alamat`, `kota`, `status`) VALUES (1,'a4a1685500867d93760f5d5c84af45ad455f6acf','AGT0001','admin','assets/images/member/hero-3.jpg','Aswinardi','081332821972','6281332821972','https://www.facebook.com/aswin.ardi','instagramku','tweeterku','Jl Karah 83 RT 1RW 06 Karah Jambangan','Surabaya',1),(23,'cb4e2704acbd5b83f6ffa3e38f308e3e243263a3','AGT0002','cobadong','assets/home/img/agent/agent/hero-1.jpg','Coba Dong','081332821972','6281332821972','fb','ig','tw','Raya Gubeng Kertajaya IV','Surabaya',1);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengumuman`
--

DROP TABLE IF EXISTS `pengumuman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pengumuman` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `tombol` varchar(20) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `diskripsi` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `tampil` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengumuman`
--

LOCK TABLES `pengumuman` WRITE;
/*!40000 ALTER TABLE `pengumuman` DISABLE KEYS */;
INSERT INTO `pengumuman` (`id`, `aman`, `tombol`, `foto`, `judul`, `diskripsi`, `tanggal`, `tampil`) VALUES (18,'ac9033bf82259618c80a07fdf0a39f73c334937f','Setuju','assets/images/pengumuman/1_20221214_173133_0000.png','PT. AMINAH','<h3><b style=\"\"><font color=\"#ff0000\"><span style=\"font-family: Verdana;\"><u>PERHATIAN!!!</u></span></font></b></h3><p><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">Pembayaran diakui sah jika dibayarkan transfer ke rekening perusahaan </span><span style=\"font-size: 1rem; font-family: \" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\"> :</span></p><h4><b style=\"font-size: 1rem;\"><span style=\"font-family: \" times=\"\" new=\"\" roman\";\"=\"\" helvetica\";\"=\"\" source=\"\" sans=\"\" pro\";\"=\"\">PT. AMINAH</span></b></h4><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><u><br></u></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><u><span style=\"font-family: \" tahoma\";\"=\"\">BANK  MANDIRI </span></u><br></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \">No Rek : 1420013662985  (IDR)</span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><b style=\"font-size: 1rem;\"><span style=\"font-family: \"><br></span></b></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u>BANK BNI</u></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u>No. Rek :  8888881455   (IDR)</u></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u><br></u></span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u>BANK BRI</u></span></b><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\"><u> </u>                                </span></b></h6><h6><b style=\"font-size: 1rem;\"><span style=\"font-family: \" source=\"\" sans=\"\" pro\";\"=\"\">No Rek :  058401001297305   (IDR)</span></b></h6><h6><b style=\"color: inherit; font-family: inherit; font-size: 1rem;\"><span source=\"\" sans=\"\" pro\";\"=\"\">                  </span></b><br></h6><h6><br></h6><p><b>            </b></p>','2020-05-11 14:07:07','Tampil');
/*!40000 ALTER TABLE `pengumuman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `aman` varchar(40) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `urut` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` (`id`, `aman`, `foto`, `judul`, `nama`, `urut`) VALUES (1,'193025d9110e4d0432c75424d41dbe2ab86d003d','assets/images/slider/IMG-20221217-WA0005.jpg','CALSIUM MAG Membantu Menguatkan Tulang','banner1',4),(3,'','assets/images/slider/banner3.jpeg','Madu Menjaga Kesehatan Sistem Pencernaan','banner3',2),(5,'26a9d6a0de7692b94b5c107a63a8ccef2d2068e8','assets/images/slider/product08.png','Laptop Cangihh untuk abad  24','',5),(7,'de34cf6704fc264f7d7faf0e3e62064bf9c0742b','assets/images/slider/IMG-20221216-WA0013.jpg','HALAWA BUMBU PREBIOTIK','',7),(8,'f1ef756bcc40055c9b60efb7d62b68264148bfa2','assets/images/slider/png_20230614_085344_0000.png','HAJI LANGSUNG BERANGKAT','',8);
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'aminahto_aminahku'
--

--
-- Dumping routines for database 'aminahto_aminahku'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-23  7:07:24
