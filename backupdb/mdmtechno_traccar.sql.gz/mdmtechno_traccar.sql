-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: mdmtechno_traccar
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(255) NOT NULL,
  `AUTHOR` varchar(255) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `ORDEREXECUTED` int(11) NOT NULL,
  `EXECTYPE` varchar(10) NOT NULL,
  `MD5SUM` varchar(35) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `COMMENTS` varchar(255) DEFAULT NULL,
  `TAG` varchar(255) DEFAULT NULL,
  `LIQUIBASE` varchar(20) DEFAULT NULL,
  `CONTEXTS` varchar(255) DEFAULT NULL,
  `LABELS` varchar(255) DEFAULT NULL,
  `DEPLOYMENT_ID` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOG` VALUES ('changelog-4.0-clean','author','changelog-4.0-clean','2022-07-26 08:19:10',1,'EXECUTED','8:d59fa93049c031a8bcfbc02958c1942c','createTable tableName=tc_attributes; createTable tableName=tc_calendars; createTable tableName=tc_commands; createTable tableName=tc_device_attribute; createTable tableName=tc_device_command; createTable tableName=tc_device_driver; createTable tab...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0-clean-common','author','changelog-4.0-clean','2022-07-26 08:19:10',2,'EXECUTED','8:1adabae3238e02ccc97cc422359a58a0','addForeignKeyConstraint baseTableName=tc_groups, constraintName=fk_groups_groupid, referencedTableName=tc_groups; addForeignKeyConstraint baseTableName=tc_user_user, constraintName=fk_user_user_manageduserid, referencedTableName=tc_users','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.3','author','changelog-3.3','2022-07-26 08:19:10',3,'MARK_RAN','8:ea6f202534dc7845fd1a49e1d8384d9c','createTable tableName=users; addUniqueConstraint constraintName=uk_user_email, tableName=users; createTable tableName=devices; addUniqueConstraint constraintName=uk_device_uniqueid, tableName=devices; createTable tableName=user_device; addForeignK...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.5','author','changelog-3.5','2022-07-26 08:19:10',4,'MARK_RAN','8:194e3ae7ec6d201917136e04a26e237b','createTable tableName=groups; createTable tableName=user_group; addForeignKeyConstraint baseTableName=user_group, constraintName=fk_user_group_userid, referencedTableName=users; addForeignKeyConstraint baseTableName=user_group, constraintName=fk_u...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.6','author','changelog-3.6','2022-07-26 08:19:10',5,'MARK_RAN','8:1ec7941b03749f24e365bc6126b07e1a','createTable tableName=events; addForeignKeyConstraint baseTableName=events, constraintName=fk_event_deviceid, referencedTableName=devices; addColumn tableName=devices; createTable tableName=geofences; createTable tableName=user_geofence; addForeig...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.7','author','changelog-3.7','2022-07-26 08:19:10',6,'MARK_RAN','8:2e444e379f31d0b8e09273ec7ffe87a0','update tableName=devices; addForeignKeyConstraint baseTableName=devices, constraintName=fk_device_group_groupid, referencedTableName=groups; update tableName=groups; addColumn tableName=devices; dropColumn columnName=motion, tableName=devices; dro...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.7-notmssql','author','changelog-3.7','2022-07-26 08:19:11',7,'MARK_RAN','8:974c33d2fb399ef6477c3897450fb078','addForeignKeyConstraint baseTableName=groups, constraintName=fk_group_group_groupid, referencedTableName=groups','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.8','author','changelog-3.8','2022-07-26 08:19:11',8,'MARK_RAN','8:74d68027951f8d2ae6bb2e24df8365bc','createTable tableName=attribute_aliases; addForeignKeyConstraint baseTableName=attribute_aliases, constraintName=fk_attribute_aliases_deviceid, referencedTableName=devices; addUniqueConstraint constraintName=uk_deviceid_attribute, tableName=attrib...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.9','author','changelog-3.9','2022-07-26 08:19:11',9,'MARK_RAN','8:34822842d65deb843a7d16f857d52ecc','addColumn tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.10','author','changelog-3.10','2022-07-26 08:19:11',10,'MARK_RAN','8:e1ddbe83e1ecf856a912755fc118f82e','createTable tableName=calendars; createTable tableName=user_calendar; addForeignKeyConstraint baseTableName=user_calendar, constraintName=fk_user_calendar_userid, referencedTableName=users; addForeignKeyConstraint baseTableName=user_calendar, cons...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.10-notmssql','author','changelog-3.10','2022-07-26 08:19:11',11,'MARK_RAN','8:191c21d8f0f921845cf93bbc9d0639b9','addForeignKeyConstraint baseTableName=user_user, constraintName=fk_user_user_manageduserid, referencedTableName=users','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.10-mssql','author','changelog-3.10','2022-07-26 08:19:11',12,'MARK_RAN','8:ad1f63566e8d08812fbf0b93a118ef6e','sql','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.7-mssql','author','changelog-3.10','2022-07-26 08:19:11',13,'MARK_RAN','8:127b36b9d32a9d236df51d19b18c3766','sql','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.11','author','changelog-3.11','2022-07-26 08:19:11',14,'MARK_RAN','8:7800f890b9706a480bd5a79b591b6ca7','addColumn tableName=users; addColumn tableName=notifications; addColumn tableName=server; addColumn tableName=server; addColumn tableName=users','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.12','author','changelog-3.12','2022-07-26 08:19:11',15,'MARK_RAN','8:5ce520811d626ad325a014b9fcbb1a13','addColumn tableName=statistics; createTable tableName=attributes; createTable tableName=user_attribute; addForeignKeyConstraint baseTableName=user_attribute, constraintName=fk_user_attribute_userid, referencedTableName=users; addForeignKeyConstrai...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.12-notmssql','author','changelog-3.12','2022-07-26 08:19:11',16,'MARK_RAN','8:a3bf7fabcde29e106fe2f89829a76a84','dropForeignKeyConstraint baseTableName=groups, constraintName=fk_group_group_groupid; addForeignKeyConstraint baseTableName=groups, constraintName=fk_groups_groupid, referencedTableName=groups','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.12-pgsql','author','changelog-3.12','2022-07-26 08:19:11',17,'MARK_RAN','8:cfc881bd2dadb561aa9c1a467bc8cc1c','dropColumn columnName=data, tableName=calendars; addColumn tableName=calendars','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.14','author','changelog-3.14','2022-07-26 08:19:11',18,'MARK_RAN','8:1be7e6c0520f8be53ef1b099d96afba5','createTable tableName=drivers; addUniqueConstraint constraintName=uk_driver_uniqueid, tableName=drivers; createTable tableName=user_driver; addForeignKeyConstraint baseTableName=user_driver, constraintName=fk_user_driver_userid, referencedTableNam...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.15','author','changelog-3.15','2022-07-26 08:19:11',19,'MARK_RAN','8:ac8ccec176027e98bbf45dc6c15d9b05','dropForeignKeyConstraint baseTableName=attribute_aliases, constraintName=fk_attribute_aliases_deviceid; dropUniqueConstraint constraintName=uk_deviceid_attribute, tableName=attribute_aliases; dropTable tableName=attribute_aliases; dropColumn colum...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.16','author','changelog-3.16','2022-07-26 08:19:11',20,'MARK_RAN','8:b59407d70bfe9bf57bc9968adfbbdf1c','addColumn tableName=devices; addColumn tableName=users; addColumn tableName=servers; addColumn tableName=notifications; addForeignKeyConstraint baseTableName=notifications, constraintName=fk_notification_calendar_calendarid, referencedTableName=ca...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.3-admin','author','changelog-3.17','2022-07-26 08:19:11',21,'MARK_RAN','8:3f14c3b08068eb7628d0d3e2941eb2d3','renameColumn newColumnName=administrator, oldColumnName=admin, tableName=users','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-3.17','author','changelog-3.17','2022-07-26 08:19:11',22,'MARK_RAN','8:8aa3e56afe6ba86cd004fa801507bc28','addColumn tableName=events; createTable tableName=maintenances; createTable tableName=user_maintenance; addForeignKeyConstraint baseTableName=user_maintenance, constraintName=fk_user_maintenance_userid, referencedTableName=users; addForeignKeyCons...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0-pre','author','changelog-4.0','2022-07-26 08:19:11',23,'MARK_RAN','8:3974bfe5a2e962c0cd663433c832c16a','addColumn tableName=notifications','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0-common','author','changelog-4.0','2022-07-26 08:19:11',24,'MARK_RAN','8:65fb49c5be37693183708351c507dd50','update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0-pg','author','changelog-4.0','2022-07-26 08:19:11',25,'MARK_RAN','8:9831511507d8ae1d6759c8ccf506a27a','update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications; update tableName=notifications','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0','author','changelog-4.0','2022-07-26 08:19:11',26,'MARK_RAN','8:ac63c4153f5b2ee5c7a07056da269571','dropDefaultValue columnName=web, tableName=notifications; dropColumn columnName=web, tableName=notifications; dropDefaultValue columnName=mail, tableName=notifications; dropColumn columnName=mail, tableName=notifications; dropDefaultValue columnNa...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.0-renaming','author','changelog-4.0','2022-07-26 08:19:11',27,'MARK_RAN','8:90aedfa378aa717f8d8ae541f97b87b2','renameTable newTableName=tc_attributes, oldTableName=attributes; renameTable newTableName=tc_calendars, oldTableName=calendars; renameTable newTableName=tc_commands, oldTableName=commands; renameTable newTableName=tc_device_attribute, oldTableName...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.1-mssql','author','changelog-4.1','2022-07-26 08:19:11',28,'MARK_RAN','8:b148f52efe9c6a3e74a56e33e257a3e2','sql; sql; sql; sql','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.7','author','changelog-4.7','2022-07-26 08:19:11',29,'EXECUTED','8:a23040cfc84d4b8021f40ee214a9d78b','createIndex indexName=user_device_user_id, tableName=tc_user_device; createIndex indexName=position_deviceid_fixtime, tableName=tc_positions','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.9','author','changelog-4.9','2022-07-26 08:19:11',30,'EXECUTED','8:805ef202791dcc246373ca16f7c19c4f','createIndex indexName=event_deviceid_servertime, tableName=tc_events','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.10','author','changelog-4.10','2022-07-26 08:19:11',31,'EXECUTED','8:64f89f4092585f8f768d0dee54dc30c8','addColumn tableName=tc_statistics','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.11','author','changelog-4.11','2022-07-26 08:19:11',32,'EXECUTED','8:234eaa970d9202e9a90b6534050f59ab','addColumn tableName=tc_servers','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.13','author','changelog-4.13','2022-07-26 08:19:11',33,'EXECUTED','8:015570907a13a62d5eb01cea87ccebd8','renameColumn newColumnName=eventtime, oldColumnName=servertime, tableName=tc_events','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-4.15','author','changelog-4.15','2022-07-26 08:19:11',34,'EXECUTED','8:247904615a0ae53ec78fed0243951bde','createTable tableName=tc_orders; createTable tableName=tc_user_order; addForeignKeyConstraint baseTableName=tc_user_order, constraintName=fk_user_order_userid, referencedTableName=tc_users; addForeignKeyConstraint baseTableName=tc_user_order, cons...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-5.0','author','changelog-5.0','2022-07-26 08:19:11',35,'EXECUTED','8:8d4d7b932a771b2f2a2e70f697ee39ea','addColumn tableName=tc_servers; addColumn tableName=tc_users; renameColumn newColumnName=toaddresstmp, oldColumnName=toAddress, tableName=tc_orders; renameColumn newColumnName=fromaddresstmp, oldColumnName=fromAddress, tableName=tc_orders; renameC...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-5.1','author','changelog-5.1','2022-07-26 08:19:11',36,'EXECUTED','8:972a7ee476bb2d14a92aac82866a6aba','createIndex indexName=idx_drivers_uniqueid, tableName=tc_drivers; createIndex indexName=idx_devices_uniqueid, tableName=tc_devices; createIndex indexName=idx_users_email, tableName=tc_users; createIndex indexName=idx_users_login, tableName=tc_user...','',NULL,'4.7.0',NULL,NULL,'8798350081'),('changelog-5.2','author','changelog-5.2','2022-07-26 08:19:11',37,'EXECUTED','8:c11566f2c5e293bf4e110fdd5882ea77','addColumn tableName=tc_devices; addColumn tableName=tc_devices','',NULL,'4.7.0',NULL,NULL,'8798350081');
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` bit(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
INSERT INTO `DATABASECHANGELOGLOCK` VALUES (1,_binary '','2025-04-19 21:08:30','172.17.0.1 (172.17.0.1)');
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_attributes`
--

DROP TABLE IF EXISTS `tc_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(4000) NOT NULL,
  `type` varchar(128) NOT NULL,
  `attribute` varchar(128) NOT NULL,
  `expression` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_attributes`
--

LOCK TABLES `tc_attributes` WRITE;
/*!40000 ALTER TABLE `tc_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_calendars`
--

DROP TABLE IF EXISTS `tc_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `data` mediumblob NOT NULL,
  `attributes` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_calendars`
--

LOCK TABLES `tc_calendars` WRITE;
/*!40000 ALTER TABLE `tc_calendars` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_commands`
--

DROP TABLE IF EXISTS `tc_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_commands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(4000) NOT NULL,
  `type` varchar(128) NOT NULL,
  `textchannel` bit(1) NOT NULL DEFAULT b'0',
  `attributes` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_commands`
--

LOCK TABLES `tc_commands` WRITE;
/*!40000 ALTER TABLE `tc_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_attribute`
--

DROP TABLE IF EXISTS `tc_device_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_attribute` (
  `deviceid` int(11) NOT NULL,
  `attributeid` int(11) NOT NULL,
  KEY `fk_user_device_attribute_attributeid` (`attributeid`),
  KEY `fk_user_device_attribute_deviceid` (`deviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_attribute`
--

LOCK TABLES `tc_device_attribute` WRITE;
/*!40000 ALTER TABLE `tc_device_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_command`
--

DROP TABLE IF EXISTS `tc_device_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_command` (
  `deviceid` int(11) NOT NULL,
  `commandid` int(11) NOT NULL,
  KEY `fk_device_command_commandid` (`commandid`),
  KEY `fk_device_command_deviceid` (`deviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_command`
--

LOCK TABLES `tc_device_command` WRITE;
/*!40000 ALTER TABLE `tc_device_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_driver`
--

DROP TABLE IF EXISTS `tc_device_driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_driver` (
  `deviceid` int(11) NOT NULL,
  `driverid` int(11) NOT NULL,
  KEY `fk_device_driver_deviceid` (`deviceid`),
  KEY `fk_device_driver_driverid` (`driverid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_driver`
--

LOCK TABLES `tc_device_driver` WRITE;
/*!40000 ALTER TABLE `tc_device_driver` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_geofence`
--

DROP TABLE IF EXISTS `tc_device_geofence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_geofence` (
  `deviceid` int(11) NOT NULL,
  `geofenceid` int(11) NOT NULL,
  KEY `fk_device_geofence_deviceid` (`deviceid`),
  KEY `fk_device_geofence_geofenceid` (`geofenceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_geofence`
--

LOCK TABLES `tc_device_geofence` WRITE;
/*!40000 ALTER TABLE `tc_device_geofence` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_geofence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_maintenance`
--

DROP TABLE IF EXISTS `tc_device_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_maintenance` (
  `deviceid` int(11) NOT NULL,
  `maintenanceid` int(11) NOT NULL,
  KEY `fk_device_maintenance_deviceid` (`deviceid`),
  KEY `fk_device_maintenance_maintenanceid` (`maintenanceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_maintenance`
--

LOCK TABLES `tc_device_maintenance` WRITE;
/*!40000 ALTER TABLE `tc_device_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_notification`
--

DROP TABLE IF EXISTS `tc_device_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_notification` (
  `deviceid` int(11) NOT NULL,
  `notificationid` int(11) NOT NULL,
  KEY `fk_device_notification_deviceid` (`deviceid`),
  KEY `fk_device_notification_notificationid` (`notificationid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_notification`
--

LOCK TABLES `tc_device_notification` WRITE;
/*!40000 ALTER TABLE `tc_device_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_device_order`
--

DROP TABLE IF EXISTS `tc_device_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_device_order` (
  `deviceid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  KEY `fk_device_order_deviceid` (`deviceid`),
  KEY `fk_device_order_orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_device_order`
--

LOCK TABLES `tc_device_order` WRITE;
/*!40000 ALTER TABLE `tc_device_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_device_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_devices`
--

DROP TABLE IF EXISTS `tc_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `uniqueid` varchar(128) NOT NULL,
  `lastupdate` timestamp NULL DEFAULT NULL,
  `positionid` int(11) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `model` varchar(128) DEFAULT NULL,
  `contact` varchar(512) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `disabled` bit(1) DEFAULT b'0',
  `status` char(8) DEFAULT NULL,
  `geofenceIds` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniqueid` (`uniqueid`),
  KEY `fk_devices_groupid` (`groupid`),
  KEY `idx_devices_uniqueid` (`uniqueid`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_devices`
--

LOCK TABLES `tc_devices` WRITE;
/*!40000 ALTER TABLE `tc_devices` DISABLE KEYS */;
INSERT INTO `tc_devices` VALUES (1,'Android','250492','2022-07-25 23:02:36',5,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0','unknown',NULL),(2,'398c7825eb87310f13244749','398c7825eb87310f13244749',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(3,'7b2b6dd48a5e3434084384a7','7b2b6dd48a5e3434084384a7',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(4,'5426ac9adfeb16aa12451f2b','5426ac9adfeb16aa12451f2b',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(5,'59604855a99209f209aca922','59604855a99209f209aca922',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(6,'c8ad2fd788cd7a1098b9881e','c8ad2fd788cd7a1098b9881e',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(7,'dc1c29f10d5519ef39d7f6ad','dc1c29f10d5519ef39d7f6ad',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(8,'86063e7d8425c146b141693d','86063e7d8425c146b141693d',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(9,'605b2e9a6775904f401f07a3','605b2e9a6775904f401f07a3',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(10,'81697055aa5a3d01fb670b17','81697055aa5a3d01fb670b17',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(11,'a8e29fecfaf8bd8bca01e8ec','a8e29fecfaf8bd8bca01e8ec',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(12,'d6490f94badb911b02fb8121','d6490f94badb911b02fb8121',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(13,'e3b1ddaa85e35323f9e21fb6','e3b1ddaa85e35323f9e21fb6',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(14,'287446a7330da54909ae2af6','287446a7330da54909ae2af6',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(15,'a7b32d38b76ddf3d4392f2c9','a7b32d38b76ddf3d4392f2c9',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(16,'9c1b3acb5bdde45522804e1c','9c1b3acb5bdde45522804e1c',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(17,'54ad9113b8922c0f0d797dd7','54ad9113b8922c0f0d797dd7',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(18,'8a1c8cdf9d661add4220468e','8a1c8cdf9d661add4220468e',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(19,'63e415455f8a958c5b3a3cdd','63e415455f8a958c5b3a3cdd',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(20,'0c3c0ecb3a94bbe5b2b64646','0c3c0ecb3a94bbe5b2b64646',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(21,'fdfd80a3c00da407f8c2d8ca','fdfd80a3c00da407f8c2d8ca',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(22,'83630713f28ba3f3ba242f62','83630713f28ba3f3ba242f62',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(23,'66f0d10fbd319f194c72f8e0','66f0d10fbd319f194c72f8e0',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(24,'ad77f2321e6a7aab756ed6cc','ad77f2321e6a7aab756ed6cc',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(25,'6eee2a72cb60fdb716243239','6eee2a72cb60fdb716243239',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(26,'9adb7084ed57a11019b30da8','9adb7084ed57a11019b30da8',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(27,'7d149ea2933f011303cce1f8','7d149ea2933f011303cce1f8',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(28,'0a26b6a6edcf852ad54f0810','0a26b6a6edcf852ad54f0810',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(29,'b4edca7f0ffb02c8ee04aff3','b4edca7f0ffb02c8ee04aff3',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(30,'3825f0bd34c24d7b48d71233','3825f0bd34c24d7b48d71233',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(31,'fb3c12c1e32f03d3ec84ff35','fb3c12c1e32f03d3ec84ff35',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(32,'ff759c048d5f4b7fa26aab65','ff759c048d5f4b7fa26aab65',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(33,'d661fcc17fdd5243c2ab80b1','d661fcc17fdd5243c2ab80b1',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(34,'cb19f6828539d8f22f489d75','cb19f6828539d8f22f489d75',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(35,'dd7faf00b88454bd97444247','dd7faf00b88454bd97444247',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(36,'b635b6461d53e535fe5f94f7','b635b6461d53e535fe5f94f7',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(37,'9bea68cb4c1b40a20df170e9','9bea68cb4c1b40a20df170e9',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(38,'63a3bdbd560d6e68e4b33d22','63a3bdbd560d6e68e4b33d22',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(39,'5aa40fb80d3ad2af11b22b2a','5aa40fb80d3ad2af11b22b2a',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(40,'e84429ad20e04b70b3de8392','e84429ad20e04b70b3de8392',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(41,'ef2fc37f6f67771c5cc6fa00','ef2fc37f6f67771c5cc6fa00',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(42,'a81e8ae9b50c46e2e5375101','a81e8ae9b50c46e2e5375101',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(43,'5157a4216f02a436711f0b24','5157a4216f02a436711f0b24',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(44,'a8d7067f0ac16adb12a58cd1','a8d7067f0ac16adb12a58cd1',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(45,'ddf73a00f112cc0a351efd2d','ddf73a00f112cc0a351efd2d',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(46,'2cd232dd8feb6e8688695dbb','2cd232dd8feb6e8688695dbb',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(47,'766d49482fa41d3f07641064','766d49482fa41d3f07641064',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(48,'574b4f170e413e4d865f07cd','574b4f170e413e4d865f07cd',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(49,'46c39ce81ce3e1062d1db586','46c39ce81ce3e1062d1db586',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(50,'0a6201452b04ea56b5cfd58a','0a6201452b04ea56b5cfd58a',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(51,'a530e4901579ea08546c7fc7','a530e4901579ea08546c7fc7',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(52,'1e71de1d2985cd41d4c0e655','1e71de1d2985cd41d4c0e655',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(53,'01342499cf439512c0ec8b58','01342499cf439512c0ec8b58',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(54,'3176dec01989472e27e2bef6','3176dec01989472e27e2bef6',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(55,'0f6f219f1dad6214c38e448c','0f6f219f1dad6214c38e448c',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(56,'0aebe1df9342ea9eb0fa9e6f','0aebe1df9342ea9eb0fa9e6f',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(57,'5542adb68d9921f14409d7d9','5542adb68d9921f14409d7d9',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(58,'4ee90f9a471936546fceaf97','4ee90f9a471936546fceaf97',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(59,'ce414562bf74b616a21ed997','ce414562bf74b616a21ed997',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(60,'dee488a1fc69af5146ca1a35','dee488a1fc69af5146ca1a35',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(61,'9ff97b9fef46e1b5cd33d727','9ff97b9fef46e1b5cd33d727',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(62,'6e6bafd73a0780b7ed1a8c7e','6e6bafd73a0780b7ed1a8c7e',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(63,'2328ee3c9bc49f0ea9679c38','2328ee3c9bc49f0ea9679c38',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(64,'b0fb59d18fcc455c9b46a187','b0fb59d18fcc455c9b46a187',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(65,'8d85a860746348b72cb91eaf','8d85a860746348b72cb91eaf',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(66,'e6f3f21774bfa2e865ef6e1d','e6f3f21774bfa2e865ef6e1d',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(67,'2eff09a7899e96ca22966655','2eff09a7899e96ca22966655',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(68,'fee31fe35ae3549c9f74790c','fee31fe35ae3549c9f74790c',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(69,'881efa8a1bcd19764c606fcd','881efa8a1bcd19764c606fcd',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(70,'8fb31e79f70d5cbdb0787705','8fb31e79f70d5cbdb0787705',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(71,'1d131a4687316fa49ead731c','1d131a4687316fa49ead731c',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(72,'3cf1a8e778981f6e08bec208','3cf1a8e778981f6e08bec208',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(73,'bf7ca2abd0cd2bfed9535c7c','bf7ca2abd0cd2bfed9535c7c',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(74,'f06409a3f3e4089db098e6ce','f06409a3f3e4089db098e6ce',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(75,'5f082f720c56fcc6466824df','5f082f720c56fcc6466824df',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(76,'8f18dd109427c658efdccd7d','8f18dd109427c658efdccd7d',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(77,'48a007e5ad7b20482b8bd8b3','48a007e5ad7b20482b8bd8b3',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(78,'7c1e91adaaed2c5b9342ef2d','7c1e91adaaed2c5b9342ef2d',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(79,'06c6d05cc182e3c0297e954a','06c6d05cc182e3c0297e954a',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(80,'SPNYUkHyYevIJSuq','mfeZ6FbDLZTayAgZ',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(81,'cW8PqeYiv9vDb4Tw','XTfa3mtq6GuXnj25',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(82,'Nylrs0DZurIXiaNK','vvNz5ydqnxxtLaRi',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(83,'PKCxrVu1Y4TjX53M','Xj7EEnVlo4WQc2zb',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(84,'m0NQ6QtHPvakos01','Mlk4KHZtbbhCSCz0',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(85,'hs59t3CU43c6mKsw','XLpFbIciCTXMD3IY',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(86,'9KBxu8A9OAamSbI0','H4eE2LczoblAPZgq',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(87,'zxNcNaL2XpGBZwcM','DJ60mblkhusXv0Ue',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(88,'VZOx8zJhTYkuGuot','FPbNxO6cgImdLUMl',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(89,'8FBjeolK2kUeLJjI','FBFgObQOhJNElRYu',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL),(90,'ZTjtQS4Am4WqrAsv','MNPTru8ECAONXJSO',NULL,NULL,NULL,'{}',NULL,NULL,NULL,NULL,_binary '\0',NULL,NULL);
/*!40000 ALTER TABLE `tc_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_drivers`
--

DROP TABLE IF EXISTS `tc_drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_drivers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `uniqueid` varchar(128) NOT NULL,
  `attributes` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniqueid` (`uniqueid`),
  KEY `idx_drivers_uniqueid` (`uniqueid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_drivers`
--

LOCK TABLES `tc_drivers` WRITE;
/*!40000 ALTER TABLE `tc_drivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_events`
--

DROP TABLE IF EXISTS `tc_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) NOT NULL,
  `eventtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deviceid` int(11) DEFAULT NULL,
  `positionid` int(11) DEFAULT NULL,
  `geofenceid` int(11) DEFAULT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  `maintenanceid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_deviceid_servertime` (`deviceid`,`eventtime`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_events`
--

LOCK TABLES `tc_events` WRITE;
/*!40000 ALTER TABLE `tc_events` DISABLE KEYS */;
INSERT INTO `tc_events` VALUES (1,'deviceOnline','2022-07-25 18:23:16',1,NULL,NULL,'{}',NULL),(2,'deviceUnknown','2022-07-25 18:35:17',1,NULL,NULL,'{}',NULL),(3,'deviceOnline','2022-07-25 23:02:36',1,NULL,NULL,'{}',NULL),(4,'deviceUnknown','2022-07-25 23:12:36',1,NULL,NULL,'{}',NULL);
/*!40000 ALTER TABLE `tc_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_geofences`
--

DROP TABLE IF EXISTS `tc_geofences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_geofences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `description` varchar(128) DEFAULT NULL,
  `area` varchar(4096) NOT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  `calendarid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_geofence_calendar_calendarid` (`calendarid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_geofences`
--

LOCK TABLES `tc_geofences` WRITE;
/*!40000 ALTER TABLE `tc_geofences` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_geofences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_attribute`
--

DROP TABLE IF EXISTS `tc_group_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_attribute` (
  `groupid` int(11) NOT NULL,
  `attributeid` int(11) NOT NULL,
  KEY `fk_group_attribute_attributeid` (`attributeid`),
  KEY `fk_group_attribute_groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_attribute`
--

LOCK TABLES `tc_group_attribute` WRITE;
/*!40000 ALTER TABLE `tc_group_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_command`
--

DROP TABLE IF EXISTS `tc_group_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_command` (
  `groupid` int(11) NOT NULL,
  `commandid` int(11) NOT NULL,
  KEY `fk_group_command_commandid` (`commandid`),
  KEY `fk_group_command_groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_command`
--

LOCK TABLES `tc_group_command` WRITE;
/*!40000 ALTER TABLE `tc_group_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_driver`
--

DROP TABLE IF EXISTS `tc_group_driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_driver` (
  `groupid` int(11) NOT NULL,
  `driverid` int(11) NOT NULL,
  KEY `fk_group_driver_driverid` (`driverid`),
  KEY `fk_group_driver_groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_driver`
--

LOCK TABLES `tc_group_driver` WRITE;
/*!40000 ALTER TABLE `tc_group_driver` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_geofence`
--

DROP TABLE IF EXISTS `tc_group_geofence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_geofence` (
  `groupid` int(11) NOT NULL,
  `geofenceid` int(11) NOT NULL,
  KEY `fk_group_geofence_geofenceid` (`geofenceid`),
  KEY `fk_group_geofence_groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_geofence`
--

LOCK TABLES `tc_group_geofence` WRITE;
/*!40000 ALTER TABLE `tc_group_geofence` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_geofence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_maintenance`
--

DROP TABLE IF EXISTS `tc_group_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_maintenance` (
  `groupid` int(11) NOT NULL,
  `maintenanceid` int(11) NOT NULL,
  KEY `fk_group_maintenance_groupid` (`groupid`),
  KEY `fk_group_maintenance_maintenanceid` (`maintenanceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_maintenance`
--

LOCK TABLES `tc_group_maintenance` WRITE;
/*!40000 ALTER TABLE `tc_group_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_notification`
--

DROP TABLE IF EXISTS `tc_group_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_notification` (
  `groupid` int(11) NOT NULL,
  `notificationid` int(11) NOT NULL,
  KEY `fk_group_notification_groupid` (`groupid`),
  KEY `fk_group_notification_notificationid` (`notificationid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_notification`
--

LOCK TABLES `tc_group_notification` WRITE;
/*!40000 ALTER TABLE `tc_group_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_group_order`
--

DROP TABLE IF EXISTS `tc_group_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_group_order` (
  `groupid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  KEY `fk_group_order_groupid` (`groupid`),
  KEY `fk_group_order_orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_group_order`
--

LOCK TABLES `tc_group_order` WRITE;
/*!40000 ALTER TABLE `tc_group_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_group_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_groups`
--

DROP TABLE IF EXISTS `tc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `groupid` int(11) DEFAULT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_groups_groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_groups`
--

LOCK TABLES `tc_groups` WRITE;
/*!40000 ALTER TABLE `tc_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_maintenances`
--

DROP TABLE IF EXISTS `tc_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_maintenances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(4000) NOT NULL,
  `type` varchar(128) NOT NULL,
  `start` double NOT NULL DEFAULT '0',
  `period` double NOT NULL DEFAULT '0',
  `attributes` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_maintenances`
--

LOCK TABLES `tc_maintenances` WRITE;
/*!40000 ALTER TABLE `tc_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_notifications`
--

DROP TABLE IF EXISTS `tc_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(128) NOT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  `always` bit(1) NOT NULL DEFAULT b'0',
  `calendarid` int(11) DEFAULT NULL,
  `notificators` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_calendar_calendarid` (`calendarid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_notifications`
--

LOCK TABLES `tc_notifications` WRITE;
/*!40000 ALTER TABLE `tc_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_orders`
--

DROP TABLE IF EXISTS `tc_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uniqueid` varchar(128) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `fromaddress` varchar(512) DEFAULT NULL,
  `toaddress` varchar(512) DEFAULT NULL,
  `attributes` varchar(4000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_orders`
--

LOCK TABLES `tc_orders` WRITE;
/*!40000 ALTER TABLE `tc_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_positions`
--

DROP TABLE IF EXISTS `tc_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` varchar(128) DEFAULT NULL,
  `deviceid` int(11) NOT NULL,
  `servertime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `devicetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fixtime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `valid` bit(1) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `altitude` float NOT NULL,
  `speed` float NOT NULL,
  `course` float NOT NULL,
  `address` varchar(512) DEFAULT NULL,
  `attributes` varchar(4000) DEFAULT NULL,
  `accuracy` double NOT NULL DEFAULT '0',
  `network` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `position_deviceid_fixtime` (`deviceid`,`fixtime`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_positions`
--

LOCK TABLES `tc_positions` WRITE;
/*!40000 ALTER TABLE `tc_positions` DISABLE KEYS */;
INSERT INTO `tc_positions` VALUES (1,'osmand',1,'2022-07-25 18:23:16','2022-07-25 18:19:52','2022-07-25 18:19:52',_binary '',-7.2952048,112.7809781,34.2,0,0,NULL,'{\"batteryLevel\":92.0,\"distance\":0.0,\"totalDistance\":0.0,\"motion\":false}',11.180999755859375,'null'),(2,'osmand',1,'2022-07-25 18:23:16','2022-07-25 18:19:52','2022-07-25 18:19:52',_binary '',-7.2952048,112.7809781,34.2,0,0,NULL,'{\"batteryLevel\":92.0,\"distance\":0.0,\"totalDistance\":0.0,\"motion\":false}',11.180999755859375,'null'),(3,'osmand',1,'2022-07-25 18:23:16','2022-07-25 18:19:52','2022-07-25 18:19:52',_binary '',-7.2952048,112.7809781,34.2,0,0,NULL,'{\"batteryLevel\":92.0,\"distance\":0.0,\"totalDistance\":0.0,\"motion\":false}',11.180999755859375,'null'),(4,'osmand',1,'2022-07-25 18:25:17','2022-07-25 18:25:15','2022-07-25 18:25:15',_binary '',-7.2947817,112.7809197,34.1,0,0,NULL,'{\"batteryLevel\":91.0,\"distance\":47.54,\"totalDistance\":47.54,\"motion\":false}',83.90299987792969,'null'),(5,'osmand',1,'2022-07-25 23:02:36','2022-07-25 23:02:28','2022-07-25 23:02:28',_binary '',-7.301793,112.7835336,37.5,0,0,NULL,'{\"batteryLevel\":82.0,\"distance\":832.15,\"totalDistance\":879.69,\"motion\":false}',12.850000381469727,'null');
/*!40000 ALTER TABLE `tc_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_servers`
--

DROP TABLE IF EXISTS `tc_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration` bit(1) NOT NULL DEFAULT b'1',
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `zoom` int(11) NOT NULL DEFAULT '0',
  `map` varchar(128) DEFAULT NULL,
  `bingkey` varchar(128) DEFAULT NULL,
  `mapurl` varchar(512) DEFAULT NULL,
  `readonly` bit(1) NOT NULL DEFAULT b'0',
  `twelvehourformat` bit(1) NOT NULL DEFAULT b'0',
  `attributes` varchar(4000) DEFAULT NULL,
  `forcesettings` bit(1) NOT NULL DEFAULT b'0',
  `coordinateformat` varchar(128) DEFAULT NULL,
  `devicereadonly` bit(1) DEFAULT b'0',
  `limitcommands` bit(1) DEFAULT b'0',
  `poilayer` varchar(512) DEFAULT NULL,
  `announcement` varchar(4000) DEFAULT NULL,
  `disablereports` bit(1) DEFAULT b'0',
  `overlayurl` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_servers`
--

LOCK TABLES `tc_servers` WRITE;
/*!40000 ALTER TABLE `tc_servers` DISABLE KEYS */;
INSERT INTO `tc_servers` VALUES (1,_binary '',0,0,0,NULL,NULL,NULL,_binary '\0',_binary '\0',NULL,_binary '\0',NULL,_binary '\0',_binary '\0',NULL,NULL,_binary '\0',NULL);
/*!40000 ALTER TABLE `tc_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_statistics`
--

DROP TABLE IF EXISTS `tc_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capturetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activeusers` int(11) NOT NULL DEFAULT '0',
  `activedevices` int(11) NOT NULL DEFAULT '0',
  `requests` int(11) NOT NULL DEFAULT '0',
  `messagesreceived` int(11) NOT NULL DEFAULT '0',
  `messagesstored` int(11) NOT NULL DEFAULT '0',
  `attributes` varchar(4096) NOT NULL,
  `mailsent` int(11) NOT NULL DEFAULT '0',
  `smssent` int(11) NOT NULL DEFAULT '0',
  `geocoderrequests` int(11) NOT NULL DEFAULT '0',
  `geolocationrequests` int(11) NOT NULL DEFAULT '0',
  `protocols` varchar(4096) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=979 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_statistics`
--

LOCK TABLES `tc_statistics` WRITE;
/*!40000 ALTER TABLE `tc_statistics` DISABLE KEYS */;
INSERT INTO `tc_statistics` VALUES (1,'2022-07-26 10:32:33',1,1,35,73,5,'{}',0,0,0,0,'{\"osmand\":1}'),(2,'2022-07-27 10:44:14',1,0,16,107,0,'{}',0,0,0,0,'null'),(3,'2022-07-28 11:16:38',0,0,0,145,0,'{}',0,0,0,0,'null'),(4,'2022-07-29 11:43:40',0,0,0,122,0,'{}',0,0,0,0,'null'),(5,'2022-07-30 10:21:13',0,0,0,265,0,'{}',0,0,0,0,'null'),(6,'2022-07-31 10:17:32',0,0,0,99,0,'{}',0,0,0,0,'null'),(7,'2022-08-01 10:12:49',0,0,0,112,0,'{}',0,0,0,0,'null'),(8,'2022-08-02 12:13:09',0,0,0,816,0,'{}',0,0,0,0,'null'),(9,'2022-08-03 10:44:13',0,0,0,107,0,'{}',0,0,0,0,'null'),(10,'2022-08-04 10:33:30',0,0,0,320,0,'{}',0,0,0,0,'null'),(11,'2022-08-05 10:11:38',0,0,0,274,0,'{}',0,0,0,0,'null'),(12,'2022-08-06 14:24:28',0,0,0,117,0,'{}',0,0,0,0,'null'),(13,'2022-08-07 11:02:17',0,0,0,219,0,'{}',0,0,0,0,'null'),(14,'2022-08-08 10:19:49',0,0,0,90,0,'{}',0,0,0,0,'null'),(15,'2022-08-09 10:45:25',0,0,0,103,0,'{}',0,0,0,0,'null'),(16,'2022-08-10 12:12:00',0,0,0,151,0,'{}',0,0,0,0,'null'),(17,'2022-08-11 10:20:08',0,0,0,84,0,'{}',0,0,0,0,'null'),(18,'2022-08-12 10:03:12',0,0,0,210,0,'{}',0,0,0,0,'null'),(19,'2022-08-13 10:20:43',0,0,0,352,0,'{}',0,0,0,0,'null'),(20,'2022-08-14 10:59:15',0,0,0,149,0,'{}',0,0,0,0,'null'),(21,'2022-08-15 10:48:02',0,0,0,208,0,'{}',0,0,0,0,'null'),(22,'2022-08-16 10:38:56',0,0,0,201,0,'{}',0,0,0,0,'null'),(23,'2022-08-17 10:10:49',0,0,0,215,0,'{}',0,0,0,0,'null'),(24,'2022-08-18 13:45:02',0,0,0,168,0,'{}',0,0,0,0,'null'),(25,'2022-08-19 10:36:01',0,0,0,98,0,'{}',0,0,0,0,'null'),(26,'2022-08-20 10:59:06',0,0,0,136,0,'{}',0,0,0,0,'null'),(27,'2022-08-21 10:04:20',0,0,0,225,0,'{}',0,0,0,0,'null'),(28,'2022-08-22 10:25:32',0,0,0,213,0,'{}',0,0,0,0,'null'),(29,'2022-08-23 10:34:02',0,0,0,872,0,'{}',0,0,0,0,'null'),(30,'2022-08-24 11:12:51',0,0,0,245,0,'{}',0,0,0,0,'null'),(31,'2022-08-25 10:58:28',0,0,0,253,0,'{}',0,0,0,0,'null'),(32,'2022-08-26 10:00:02',0,0,0,53,0,'{}',0,0,0,0,'null'),(33,'2022-08-27 10:29:34',0,0,0,259,0,'{}',0,0,0,0,'null'),(34,'2022-08-28 12:42:00',0,0,0,111,0,'{}',0,0,0,0,'null'),(35,'2022-08-29 10:47:23',0,0,0,201,0,'{}',0,0,0,0,'null'),(36,'2022-08-30 12:03:20',0,0,0,109,0,'{}',0,0,0,0,'null'),(37,'2022-08-31 10:24:48',0,0,0,80,0,'{}',0,0,0,0,'null'),(38,'2022-09-01 12:00:05',0,0,0,120,0,'{}',0,0,0,0,'null'),(39,'2022-09-03 10:11:59',0,0,0,181,0,'{}',0,0,0,0,'null'),(40,'2022-09-04 10:25:04',0,0,0,165,0,'{}',0,0,0,0,'null'),(41,'2022-09-05 10:07:15',0,0,0,192,0,'{}',0,0,0,0,'null'),(42,'2022-09-06 10:19:07',0,0,0,104,0,'{}',0,0,0,0,'null'),(43,'2022-09-07 11:21:35',0,0,0,143,0,'{}',0,0,0,0,'null'),(44,'2022-09-08 10:10:36',0,0,0,84,0,'{}',0,0,0,0,'null'),(45,'2022-09-09 10:24:42',0,0,0,144,0,'{}',0,0,0,0,'null'),(46,'2022-09-10 11:16:17',0,0,0,171,0,'{}',0,0,0,0,'null'),(47,'2022-09-11 11:18:45',0,0,0,133,0,'{}',0,0,0,0,'null'),(48,'2022-09-12 11:07:13',0,0,0,137,0,'{}',0,0,0,0,'null'),(49,'2022-09-13 10:14:46',0,0,0,207,0,'{}',0,0,0,0,'null'),(50,'2022-09-14 10:28:52',0,0,0,159,0,'{}',0,0,0,0,'null'),(51,'2022-09-15 11:16:46',0,0,0,143,0,'{}',0,0,0,0,'null'),(52,'2022-09-16 10:49:54',0,0,0,70,0,'{}',0,0,0,0,'null'),(53,'2022-09-17 10:25:05',0,0,0,177,0,'{}',0,0,0,0,'null'),(54,'2022-09-18 10:23:18',0,0,0,155,0,'{}',0,0,0,0,'null'),(55,'2022-09-19 10:40:58',0,0,0,121,0,'{}',0,0,0,0,'null'),(56,'2022-09-20 10:16:51',0,0,0,207,0,'{}',0,0,0,0,'null'),(57,'2022-09-21 11:54:56',0,0,0,284,0,'{}',0,0,0,0,'null'),(58,'2022-09-22 10:53:59',0,0,0,138,0,'{}',0,0,0,0,'null'),(59,'2022-09-23 10:18:45',0,0,0,86,0,'{}',0,0,0,0,'null'),(60,'2022-09-24 11:09:59',0,0,0,106,0,'{}',0,0,0,0,'null'),(61,'2022-09-25 10:07:41',0,0,0,434,0,'{}',0,0,0,0,'null'),(62,'2022-09-26 11:03:34',0,0,0,520,0,'{}',0,0,0,0,'null'),(63,'2022-09-27 10:01:08',0,0,0,235,0,'{}',0,0,0,0,'null'),(64,'2022-09-28 10:28:34',0,0,0,215,0,'{}',0,0,0,0,'null'),(65,'2022-09-29 10:06:39',0,0,0,374,0,'{}',0,0,0,0,'null'),(66,'2022-09-30 10:02:43',0,0,0,921,0,'{}',0,0,0,0,'null'),(67,'2022-10-01 10:33:51',0,0,0,669,0,'{}',0,0,0,0,'null'),(68,'2022-10-02 10:20:17',0,0,0,210,0,'{}',0,0,0,0,'null'),(69,'2022-10-03 11:15:19',0,0,0,368,0,'{}',0,0,0,0,'null'),(70,'2022-10-04 10:40:24',0,0,0,170,0,'{}',0,0,0,0,'null'),(71,'2022-10-05 10:09:43',0,0,0,278,0,'{}',0,0,0,0,'null'),(72,'2022-10-06 12:23:39',0,0,0,115,0,'{}',0,0,0,0,'null'),(73,'2022-10-07 10:00:59',0,0,0,231,0,'{}',0,0,0,0,'null'),(74,'2022-10-08 10:12:56',0,0,0,210,0,'{}',0,0,0,0,'null'),(75,'2022-10-09 10:17:04',0,0,0,103,0,'{}',0,0,0,0,'null'),(76,'2022-10-10 10:11:43',0,0,0,246,0,'{}',0,0,0,0,'null'),(77,'2022-10-11 12:27:30',0,0,0,174,0,'{}',0,0,0,0,'null'),(78,'2022-10-12 10:22:00',0,0,0,166,0,'{}',0,0,0,0,'null'),(79,'2022-10-13 10:21:13',0,0,0,260,0,'{}',0,0,0,0,'null'),(80,'2022-10-14 10:56:28',0,0,0,159,0,'{}',0,0,0,0,'null'),(81,'2022-10-15 10:24:01',0,0,0,324,0,'{}',0,0,0,0,'null'),(82,'2022-10-16 12:13:26',0,0,0,106,0,'{}',0,0,0,0,'null'),(83,'2022-10-17 10:18:51',0,0,0,239,0,'{}',0,0,0,0,'null'),(84,'2022-10-18 12:53:55',0,0,0,145,0,'{}',0,0,0,0,'null'),(85,'2022-10-19 10:28:44',0,0,0,611,0,'{}',0,0,0,0,'null'),(86,'2022-10-20 10:19:49',0,0,0,287,0,'{}',0,0,0,0,'null'),(87,'2022-10-21 12:09:05',0,0,0,333,0,'{}',0,0,0,0,'null'),(88,'2022-10-22 14:40:42',0,0,0,308,0,'{}',0,0,0,0,'null'),(89,'2022-10-23 12:46:25',0,0,0,175,0,'{}',0,0,0,0,'null'),(90,'2022-10-24 12:52:05',0,0,0,221,0,'{}',0,0,0,0,'null'),(91,'2022-10-25 10:20:48',0,0,0,115,0,'{}',0,0,0,0,'null'),(92,'2022-10-26 10:58:42',0,0,0,193,0,'{}',0,0,0,0,'null'),(93,'2022-10-27 10:03:51',0,0,0,250,0,'{}',0,0,0,0,'null'),(94,'2022-10-28 11:05:55',0,0,0,377,0,'{}',0,0,0,0,'null'),(95,'2022-10-29 10:18:02',0,0,0,712,0,'{}',0,0,0,0,'null'),(96,'2022-10-30 10:02:33',0,0,0,420,0,'{}',0,0,0,0,'null'),(97,'2022-10-31 10:05:20',0,0,0,433,0,'{}',0,0,0,0,'null'),(98,'2022-11-01 10:02:38',0,0,0,480,0,'{}',0,0,0,0,'null'),(99,'2022-11-02 13:18:00',0,0,0,370,0,'{}',0,0,0,0,'null'),(100,'2022-11-03 11:39:12',0,0,0,109,0,'{}',0,0,0,0,'null'),(101,'2022-11-04 12:00:20',0,0,0,164,0,'{}',0,0,0,0,'null'),(102,'2022-11-05 11:36:40',0,0,0,233,0,'{}',0,0,0,0,'null'),(103,'2022-11-06 10:03:36',0,0,0,183,0,'{}',0,0,0,0,'null'),(104,'2022-11-07 10:11:24',0,0,0,229,0,'{}',0,0,0,0,'null'),(105,'2022-11-08 10:43:01',0,0,0,321,0,'{}',0,0,0,0,'null'),(106,'2022-11-09 10:22:25',0,0,0,70,0,'{}',0,0,0,0,'null'),(107,'2022-11-10 10:55:36',0,0,0,318,0,'{}',0,0,0,0,'null'),(108,'2022-11-11 11:42:37',0,0,0,166,0,'{}',0,0,0,0,'null'),(109,'2022-11-12 11:06:14',0,0,0,578,0,'{}',0,0,0,0,'null'),(110,'2022-11-13 11:33:43',0,0,0,1371,0,'{}',0,0,0,0,'null'),(111,'2022-11-14 10:02:57',0,0,0,103,0,'{}',0,0,0,0,'null'),(112,'2022-11-15 10:59:27',0,0,0,152,0,'{}',0,0,0,0,'null'),(113,'2022-11-16 10:29:45',0,0,0,188,0,'{}',0,0,0,0,'null'),(114,'2022-11-17 11:25:09',0,0,0,213,0,'{}',0,0,0,0,'null'),(115,'2022-11-18 10:31:28',0,0,0,226,0,'{}',0,0,0,0,'null'),(116,'2022-11-19 10:28:14',0,0,0,661,0,'{}',0,0,0,0,'null'),(117,'2022-11-20 10:00:20',0,0,0,395,0,'{}',0,0,0,0,'null'),(118,'2022-11-21 11:52:50',0,0,0,654,0,'{}',0,0,0,0,'null'),(119,'2022-11-22 11:12:40',0,0,0,156,0,'{}',0,0,0,0,'null'),(120,'2022-11-23 10:41:40',0,0,0,105,0,'{}',0,0,0,0,'null'),(121,'2022-11-24 10:05:09',0,0,0,182,0,'{}',0,0,0,0,'null'),(122,'2022-11-25 10:20:27',0,0,0,253,0,'{}',0,0,0,0,'null'),(123,'2022-11-26 12:07:28',0,0,0,274,0,'{}',0,0,0,0,'null'),(124,'2022-11-27 10:51:49',0,0,0,185,0,'{}',0,0,0,0,'null'),(125,'2022-11-28 10:04:59',0,0,0,123,0,'{}',0,0,0,0,'null'),(126,'2022-11-29 11:55:52',0,0,0,182,0,'{}',0,0,0,0,'null'),(127,'2022-11-30 10:49:34',0,0,0,251,0,'{}',0,0,0,0,'null'),(128,'2022-12-01 10:06:06',0,0,0,485,0,'{}',0,0,0,0,'null'),(129,'2022-12-02 10:30:36',0,0,0,295,0,'{}',0,0,0,0,'null'),(130,'2022-12-03 10:16:52',0,0,0,111,0,'{}',0,0,0,0,'null'),(131,'2022-12-04 10:02:45',0,0,0,731,0,'{}',0,0,0,0,'null'),(132,'2022-12-05 11:04:32',0,0,0,1000,0,'{}',0,0,0,0,'null'),(133,'2022-12-06 10:06:10',0,0,0,80,0,'{}',0,0,0,0,'null'),(134,'2022-12-07 11:30:01',0,0,0,85,0,'{}',0,0,0,0,'null'),(135,'2022-12-08 11:16:34',0,0,0,176,0,'{}',0,0,0,0,'null'),(136,'2022-12-09 11:22:17',0,0,0,193,0,'{}',0,0,0,0,'null'),(137,'2022-12-11 10:06:47',0,0,0,490,0,'{}',0,0,0,0,'null'),(138,'2022-12-12 10:07:07',0,0,0,204,0,'{}',0,0,0,0,'null'),(139,'2022-12-13 10:01:04',0,0,0,132,0,'{}',0,0,0,0,'null'),(140,'2022-12-14 11:12:48',0,0,0,120,0,'{}',0,0,0,0,'null'),(141,'2022-12-15 11:39:37',0,0,0,210,0,'{}',0,0,0,0,'null'),(142,'2022-12-16 10:24:25',0,0,0,52,0,'{}',0,0,0,0,'null'),(143,'2022-12-17 10:15:26',0,0,0,276,0,'{}',0,0,0,0,'null'),(144,'2022-12-18 10:11:48',0,0,0,637,0,'{}',0,0,0,0,'null'),(145,'2022-12-19 11:01:57',0,0,0,323,0,'{}',0,0,0,0,'null'),(146,'2022-12-20 10:03:15',0,0,0,1583,0,'{}',0,0,0,0,'null'),(147,'2022-12-21 10:08:33',0,0,0,337,0,'{}',0,0,0,0,'null'),(148,'2022-12-22 10:54:48',0,0,0,360,0,'{}',0,0,0,0,'null'),(149,'2022-12-23 10:14:00',0,0,0,124,0,'{}',0,0,0,0,'null'),(150,'2022-12-24 11:57:52',0,0,0,279,0,'{}',0,0,0,0,'null'),(151,'2022-12-25 10:42:38',0,0,0,113,0,'{}',0,0,0,0,'null'),(152,'2022-12-26 10:49:04',0,0,0,758,0,'{}',0,0,0,0,'null'),(153,'2022-12-27 10:20:21',0,0,0,193,0,'{}',0,0,0,0,'null'),(154,'2022-12-28 10:17:04',0,0,0,131,0,'{}',0,0,0,0,'null'),(155,'2022-12-29 10:41:43',0,0,0,306,0,'{}',0,0,0,0,'null'),(156,'2022-12-30 10:22:32',0,0,0,345,0,'{}',0,0,0,0,'null'),(157,'2022-12-31 12:18:32',0,0,0,344,0,'{}',0,0,0,0,'null'),(158,'2023-01-01 13:20:09',0,0,0,144,0,'{}',0,0,0,0,'null'),(159,'2023-01-02 10:56:26',0,0,0,122,0,'{}',0,0,0,0,'null'),(160,'2023-01-03 10:22:35',0,0,0,197,0,'{}',0,0,0,0,'null'),(161,'2023-01-04 10:39:18',0,0,0,166,0,'{}',0,0,0,0,'null'),(162,'2023-01-05 10:17:40',0,0,0,223,0,'{}',0,0,0,0,'null'),(163,'2023-01-06 10:24:50',0,0,0,1207,0,'{}',0,0,0,0,'null'),(164,'2023-01-07 11:01:45',0,0,0,409,0,'{}',0,0,0,0,'null'),(165,'2023-01-08 11:42:03',0,0,0,105,0,'{}',0,0,0,0,'null'),(166,'2023-01-09 10:49:09',0,0,0,173,0,'{}',0,0,0,0,'null'),(167,'2023-01-10 10:02:41',0,0,0,937,0,'{}',0,0,0,0,'null'),(168,'2023-01-11 10:40:19',0,0,0,534,0,'{}',0,0,0,0,'null'),(169,'2023-01-12 10:00:26',0,0,0,783,0,'{}',0,0,0,0,'null'),(170,'2023-01-13 10:05:36',0,0,0,377,0,'{}',0,0,0,0,'null'),(171,'2023-01-14 10:00:16',0,0,0,654,0,'{}',0,0,0,0,'null'),(172,'2023-01-15 10:18:47',0,0,0,516,0,'{}',0,0,0,0,'null'),(173,'2023-01-16 10:16:43',0,0,0,146,0,'{}',0,0,0,0,'null'),(174,'2023-01-17 11:29:22',0,0,0,421,0,'{}',0,0,0,0,'null'),(175,'2023-01-19 10:18:53',0,0,0,261,0,'{}',0,0,0,0,'null'),(176,'2023-01-20 10:12:37',0,0,0,619,0,'{}',0,0,0,0,'null'),(177,'2023-01-21 10:26:13',0,0,0,378,0,'{}',0,0,0,0,'null'),(178,'2023-01-22 10:06:54',0,0,0,94,0,'{}',0,0,0,0,'null'),(179,'2023-01-23 10:37:07',0,0,0,111,0,'{}',0,0,0,0,'null'),(180,'2023-01-24 10:31:11',0,0,0,77,0,'{}',0,0,0,0,'null'),(181,'2023-01-25 11:12:21',0,0,0,183,0,'{}',0,0,0,0,'null'),(182,'2023-01-26 10:20:06',0,0,0,945,0,'{}',0,0,0,0,'null'),(183,'2023-01-27 12:05:55',0,0,0,114,0,'{}',0,0,0,0,'null'),(184,'2023-01-28 10:12:21',0,0,0,166,0,'{}',0,0,0,0,'null'),(185,'2023-01-29 10:12:38',0,0,0,688,0,'{}',0,0,0,0,'null'),(186,'2023-01-30 10:05:49',0,0,0,1328,0,'{}',0,0,0,0,'null'),(187,'2023-01-31 10:37:25',0,0,0,400,0,'{}',0,0,0,0,'null'),(188,'2023-02-01 10:02:37',0,0,0,136,0,'{}',0,0,0,0,'null'),(189,'2023-02-02 10:01:42',0,0,0,463,0,'{}',0,0,0,0,'null'),(190,'2023-02-03 10:00:14',0,0,0,465,0,'{}',0,0,0,0,'null'),(191,'2023-02-04 10:25:55',0,0,0,275,0,'{}',0,0,0,0,'null'),(192,'2023-02-05 10:16:18',0,0,0,575,0,'{}',0,0,0,0,'null'),(193,'2023-02-06 10:06:15',0,0,0,226,0,'{}',0,0,0,0,'null'),(194,'2023-02-07 10:37:45',0,0,0,267,0,'{}',0,0,0,0,'null'),(195,'2023-02-08 10:11:12',0,0,0,697,0,'{}',0,0,0,0,'null'),(196,'2023-02-09 11:44:01',0,0,0,342,0,'{}',0,0,0,0,'null'),(197,'2023-02-10 10:08:17',0,0,0,757,0,'{}',0,0,0,0,'null'),(198,'2023-02-11 10:17:31',0,0,0,688,0,'{}',0,0,0,0,'null'),(199,'2023-02-12 10:27:09',0,0,0,205,0,'{}',0,0,0,0,'null'),(200,'2023-02-13 10:25:47',0,0,0,527,0,'{}',0,0,0,0,'null'),(201,'2023-02-14 11:56:43',0,0,0,572,0,'{}',0,0,0,0,'null'),(202,'2023-02-15 11:26:57',0,0,0,361,0,'{}',0,0,0,0,'null'),(203,'2023-02-16 10:13:11',0,0,0,638,0,'{}',0,0,0,0,'null'),(204,'2023-02-17 10:07:40',0,0,0,433,0,'{}',0,0,0,0,'null'),(205,'2023-02-18 10:13:39',0,0,0,99,0,'{}',0,0,0,0,'null'),(206,'2023-02-19 10:13:56',0,0,0,1056,0,'{}',0,0,0,0,'null'),(207,'2023-02-20 10:18:49',0,0,0,410,0,'{}',0,0,0,0,'null'),(208,'2023-02-21 10:00:10',0,0,0,205,0,'{}',0,0,0,0,'null'),(209,'2023-02-22 10:25:49',0,0,0,588,0,'{}',0,0,0,0,'null'),(210,'2023-02-23 11:12:13',0,0,0,318,0,'{}',0,0,0,0,'null'),(211,'2023-02-24 10:12:35',0,0,0,198,0,'{}',0,0,0,0,'null'),(212,'2023-02-25 10:04:42',0,0,0,1513,0,'{}',0,0,0,0,'null'),(213,'2023-02-26 11:17:06',0,0,0,1106,0,'{}',0,0,0,0,'null'),(214,'2023-02-27 10:27:52',0,0,0,323,0,'{}',0,0,0,0,'null'),(215,'2023-02-28 10:04:33',0,0,0,646,0,'{}',0,0,0,0,'null'),(216,'2023-03-01 10:27:41',0,0,0,199,0,'{}',0,0,0,0,'null'),(217,'2023-03-02 10:22:24',0,0,0,447,0,'{}',0,0,0,0,'null'),(218,'2023-03-03 12:06:50',0,0,0,550,0,'{}',0,0,0,0,'null'),(219,'2023-03-05 10:31:15',0,0,0,465,0,'{}',0,0,0,0,'null'),(220,'2023-03-06 10:13:19',0,0,0,625,0,'{}',0,0,0,0,'null'),(221,'2023-03-07 11:13:20',0,0,0,146,0,'{}',0,0,0,0,'null'),(222,'2023-03-08 10:04:23',0,0,0,440,0,'{}',0,0,0,0,'null'),(223,'2023-03-09 10:58:56',0,0,0,516,0,'{}',0,0,0,0,'null'),(224,'2023-03-10 11:11:23',0,0,0,302,0,'{}',0,0,0,0,'null'),(225,'2023-03-11 11:12:46',0,0,0,330,0,'{}',0,0,0,0,'null'),(226,'2023-03-12 10:14:21',0,0,0,244,0,'{}',0,0,0,0,'null'),(227,'2023-03-13 12:10:01',0,0,0,170,0,'{}',0,0,0,0,'null'),(228,'2023-03-14 10:34:00',0,0,0,186,0,'{}',0,0,0,0,'null'),(229,'2023-03-15 10:00:01',0,0,0,201,0,'{}',0,0,0,0,'null'),(230,'2023-03-16 11:50:05',0,0,0,163,0,'{}',0,0,0,0,'null'),(231,'2023-03-17 10:03:41',0,0,0,88,0,'{}',0,0,0,0,'null'),(232,'2023-03-18 11:42:25',0,0,0,229,0,'{}',0,0,0,0,'null'),(233,'2023-03-19 10:50:42',0,0,0,130,0,'{}',0,0,0,0,'null'),(234,'2023-03-20 10:37:52',0,0,0,267,0,'{}',0,0,0,0,'null'),(235,'2023-03-21 10:45:24',0,0,0,384,0,'{}',0,0,0,0,'null'),(236,'2023-03-22 10:59:05',0,0,0,248,0,'{}',0,0,0,0,'null'),(237,'2023-03-23 10:57:12',0,0,0,203,0,'{}',0,0,0,0,'null'),(238,'2023-03-24 10:01:14',0,0,0,265,0,'{}',0,0,0,0,'null'),(239,'2023-03-25 11:41:01',0,0,0,929,0,'{}',0,0,0,0,'null'),(240,'2023-03-26 10:05:47',0,0,0,190,0,'{}',0,0,0,0,'null'),(241,'2023-03-27 10:32:12',0,0,0,225,0,'{}',0,0,0,0,'null'),(242,'2023-03-28 11:09:13',0,0,0,795,0,'{}',0,0,0,0,'null'),(243,'2023-03-29 10:26:18',0,0,0,110,0,'{}',0,0,0,0,'null'),(244,'2023-03-30 10:45:04',0,0,0,357,0,'{}',0,0,0,0,'null'),(245,'2023-03-31 11:15:54',0,0,0,170,0,'{}',0,0,0,0,'null'),(246,'2023-04-01 11:55:23',0,0,0,198,0,'{}',0,0,0,0,'null'),(247,'2023-04-02 11:15:39',0,0,0,90,0,'{}',0,0,0,0,'null'),(248,'2023-04-03 10:12:52',0,0,0,216,0,'{}',0,0,0,0,'null'),(249,'2023-04-04 13:50:11',0,0,0,182,0,'{}',0,0,0,0,'null'),(250,'2023-04-05 11:12:31',0,0,0,192,0,'{}',0,0,0,0,'null'),(251,'2023-04-06 10:04:57',0,0,0,184,0,'{}',0,0,0,0,'null'),(252,'2023-04-07 10:48:53',0,0,0,145,0,'{}',0,0,0,0,'null'),(253,'2023-04-08 10:12:09',0,0,0,312,0,'{}',0,0,0,0,'null'),(254,'2023-04-09 10:05:10',0,0,0,303,0,'{}',0,0,0,0,'null'),(255,'2023-04-10 10:09:23',0,0,0,870,0,'{}',0,0,0,0,'null'),(256,'2023-04-11 10:04:44',0,0,0,256,0,'{}',0,0,0,0,'null'),(257,'2023-04-12 12:05:46',0,0,0,1559,0,'{}',0,0,0,0,'null'),(258,'2023-04-13 11:26:31',0,0,0,405,0,'{}',0,0,0,0,'null'),(259,'2023-04-14 10:00:10',0,0,0,284,0,'{}',0,0,0,0,'null'),(260,'2023-04-15 12:36:44',0,0,0,140,0,'{}',0,0,0,0,'null'),(261,'2023-04-16 10:07:04',0,0,0,528,0,'{}',0,0,0,0,'null'),(262,'2023-04-17 10:00:18',0,0,0,481,0,'{}',0,0,0,0,'null'),(263,'2023-04-18 10:00:32',0,0,0,277,0,'{}',0,0,0,0,'null'),(264,'2023-04-19 10:27:37',0,0,0,196,0,'{}',0,0,0,0,'null'),(265,'2023-04-20 12:01:51',0,0,0,262,0,'{}',0,0,0,0,'null'),(266,'2023-04-21 10:15:59',0,0,0,165,0,'{}',0,0,0,0,'null'),(267,'2023-04-22 10:00:44',0,0,0,558,0,'{}',0,0,0,0,'null'),(268,'2023-04-23 10:05:18',0,0,0,357,0,'{}',0,0,0,0,'null'),(269,'2023-04-24 11:01:28',0,0,0,380,0,'{}',0,0,0,0,'null'),(270,'2023-04-25 11:33:24',0,0,0,318,0,'{}',0,0,0,0,'null'),(271,'2023-04-26 10:01:10',0,0,0,138,0,'{}',0,0,0,0,'null'),(272,'2023-04-27 10:25:48',0,0,0,340,0,'{}',0,0,0,0,'null'),(273,'2023-04-28 10:06:36',0,0,0,261,0,'{}',0,0,0,0,'null'),(274,'2023-04-29 10:14:56',0,0,0,216,0,'{}',0,0,0,0,'null'),(275,'2023-04-30 10:09:10',0,0,0,387,0,'{}',0,0,0,0,'null'),(276,'2023-05-01 10:17:46',0,0,0,214,0,'{}',0,0,0,0,'null'),(277,'2023-05-02 10:09:53',0,0,0,292,0,'{}',0,0,0,0,'null'),(278,'2023-05-03 10:18:27',0,0,0,266,0,'{}',0,0,0,0,'null'),(279,'2023-05-04 10:07:43',0,0,0,369,0,'{}',0,0,0,0,'null'),(280,'2023-05-05 11:10:09',0,0,0,534,0,'{}',0,0,0,0,'null'),(281,'2023-05-06 10:48:03',0,0,0,684,0,'{}',0,0,0,0,'null'),(282,'2023-05-07 10:27:47',0,0,0,502,0,'{}',0,0,0,0,'null'),(283,'2023-05-08 10:46:09',0,0,0,489,0,'{}',0,0,0,0,'null'),(284,'2023-05-09 10:24:58',0,0,0,168,0,'{}',0,0,0,0,'null'),(285,'2023-05-10 10:51:24',0,0,0,2348,0,'{}',0,0,0,0,'null'),(286,'2023-05-11 10:24:48',0,0,0,155,0,'{}',0,0,0,0,'null'),(287,'2023-05-12 10:19:38',0,0,0,485,0,'{}',0,0,0,0,'null'),(288,'2023-05-13 10:15:11',0,0,0,275,0,'{}',0,0,0,0,'null'),(289,'2023-05-14 10:26:14',0,0,0,185,0,'{}',0,0,0,0,'null'),(290,'2023-05-15 10:59:37',0,0,0,624,0,'{}',0,0,0,0,'null'),(291,'2023-05-16 10:16:02',0,0,0,854,0,'{}',0,0,0,0,'null'),(292,'2023-05-17 10:02:53',0,0,0,230,0,'{}',0,0,0,0,'null'),(293,'2023-05-18 10:15:44',0,0,0,342,0,'{}',0,0,0,0,'null'),(294,'2023-05-19 10:56:52',0,0,0,425,0,'{}',0,0,0,0,'null'),(295,'2023-05-20 10:21:32',0,0,0,341,0,'{}',0,0,0,0,'null'),(296,'2023-05-21 10:14:44',0,0,0,348,0,'{}',0,0,0,0,'null'),(297,'2023-05-22 10:08:42',0,0,0,310,0,'{}',0,0,0,0,'null'),(298,'2023-05-23 10:02:16',0,0,0,187,0,'{}',0,0,0,0,'null'),(299,'2023-05-24 10:02:55',0,0,0,302,0,'{}',0,0,0,0,'null'),(300,'2023-05-25 10:33:07',0,0,0,228,0,'{}',0,0,0,0,'null'),(301,'2023-05-26 10:00:40',0,0,0,430,0,'{}',0,0,0,0,'null'),(302,'2023-05-27 10:00:03',0,0,0,438,0,'{}',0,0,0,0,'null'),(303,'2023-05-28 11:17:21',0,0,0,431,0,'{}',0,0,0,0,'null'),(304,'2023-05-29 10:01:13',0,0,0,289,0,'{}',0,0,0,0,'null'),(305,'2023-05-30 10:21:20',0,0,0,227,0,'{}',0,0,0,0,'null'),(306,'2023-05-31 10:10:12',0,0,0,201,0,'{}',0,0,0,0,'null'),(307,'2023-06-01 10:07:09',0,0,0,241,0,'{}',0,0,0,0,'null'),(308,'2023-06-02 10:05:52',0,0,0,418,0,'{}',0,0,0,0,'null'),(309,'2023-06-03 10:15:17',0,0,0,347,0,'{}',0,0,0,0,'null'),(310,'2023-06-04 10:05:47',0,0,0,378,0,'{}',0,0,0,0,'null'),(311,'2023-06-05 10:28:52',0,0,0,300,0,'{}',0,0,0,0,'null'),(312,'2023-06-06 10:22:27',0,0,0,318,0,'{}',0,0,0,0,'null'),(313,'2023-06-07 10:46:29',0,0,0,275,0,'{}',0,0,0,0,'null'),(314,'2023-06-08 10:17:04',0,0,0,375,0,'{}',0,0,0,0,'null'),(315,'2023-06-09 10:42:57',0,0,0,215,0,'{}',0,0,0,0,'null'),(316,'2023-06-10 11:06:23',0,0,0,1071,0,'{}',0,0,0,0,'null'),(317,'2023-06-11 10:35:58',0,0,0,179,0,'{}',0,0,0,0,'null'),(318,'2023-06-12 10:20:28',0,0,0,311,0,'{}',0,0,0,0,'null'),(319,'2023-06-13 10:30:46',0,0,0,387,0,'{}',0,0,0,0,'null'),(320,'2023-06-14 10:28:08',0,0,0,1961,0,'{}',0,0,0,0,'null'),(321,'2023-06-15 10:38:13',0,0,0,230,0,'{}',0,0,0,0,'null'),(322,'2023-06-16 10:02:10',0,0,0,283,0,'{}',0,0,0,0,'null'),(323,'2023-06-17 10:05:55',0,0,0,311,0,'{}',0,0,0,0,'null'),(324,'2023-06-18 10:43:21',0,0,0,241,0,'{}',0,0,0,0,'null'),(325,'2023-06-19 10:02:56',0,0,0,174,0,'{}',0,0,0,0,'null'),(326,'2023-06-20 10:20:13',0,0,0,321,0,'{}',0,0,0,0,'null'),(327,'2023-06-21 10:31:30',0,0,0,368,0,'{}',0,0,0,0,'null'),(328,'2023-06-22 10:09:39',0,0,0,337,0,'{}',0,0,0,0,'null'),(329,'2023-06-23 10:41:50',0,0,0,374,0,'{}',0,0,0,0,'null'),(330,'2023-06-24 10:05:29',0,0,0,659,0,'{}',0,0,0,0,'null'),(331,'2023-06-25 10:19:35',0,0,0,394,0,'{}',0,0,0,0,'null'),(332,'2023-06-26 10:10:52',0,0,0,334,0,'{}',0,0,0,0,'null'),(333,'2023-06-27 11:20:34',0,0,0,248,0,'{}',0,0,0,0,'null'),(334,'2023-06-28 10:35:17',0,0,0,373,0,'{}',0,0,0,0,'null'),(335,'2023-06-29 10:06:38',0,0,0,346,0,'{}',0,0,0,0,'null'),(336,'2023-06-30 10:33:03',0,0,0,450,0,'{}',0,0,0,0,'null'),(337,'2023-07-01 10:11:58',0,0,0,401,0,'{}',0,0,0,0,'null'),(338,'2023-07-02 10:03:07',0,0,0,283,0,'{}',0,0,0,0,'null'),(339,'2023-07-03 10:03:02',0,0,0,320,0,'{}',0,0,0,0,'null'),(340,'2023-07-04 10:52:06',0,0,0,591,0,'{}',0,0,0,0,'null'),(341,'2023-07-05 10:14:47',0,0,0,278,0,'{}',0,0,0,0,'null'),(342,'2023-07-06 10:01:05',0,0,0,244,0,'{}',0,0,0,0,'null'),(343,'2023-07-07 10:23:37',0,0,0,449,0,'{}',0,0,0,0,'null'),(344,'2023-07-08 10:37:38',0,0,0,490,0,'{}',0,0,0,0,'null'),(345,'2023-07-09 10:12:49',0,0,0,215,0,'{}',0,0,0,0,'null'),(346,'2023-07-10 10:29:15',0,0,0,235,0,'{}',0,0,0,0,'null'),(347,'2023-07-11 10:09:09',0,0,0,375,0,'{}',0,0,0,0,'null'),(348,'2023-07-12 10:04:54',0,0,0,298,0,'{}',0,0,0,0,'null'),(349,'2023-07-13 10:01:16',0,0,0,231,0,'{}',0,0,0,0,'null'),(350,'2023-07-14 10:32:47',0,0,0,1278,0,'{}',0,0,0,0,'null'),(351,'2023-07-15 10:01:46',0,0,0,356,0,'{}',0,0,0,0,'null'),(352,'2023-07-16 10:09:55',0,0,0,209,0,'{}',0,0,0,0,'null'),(353,'2023-07-17 10:01:59',0,0,0,297,0,'{}',0,0,0,0,'null'),(354,'2023-07-18 10:03:31',0,0,0,362,0,'{}',0,0,0,0,'null'),(355,'2023-07-19 11:18:45',0,0,0,320,0,'{}',0,0,0,0,'null'),(356,'2023-07-20 10:27:56',0,0,0,349,0,'{}',0,0,0,0,'null'),(357,'2023-07-21 10:21:10',0,0,0,359,0,'{}',0,0,0,0,'null'),(358,'2023-07-22 11:39:03',0,0,0,207,0,'{}',0,0,0,0,'null'),(359,'2023-07-23 12:00:56',0,0,0,201,0,'{}',0,0,0,0,'null'),(360,'2023-07-24 10:12:14',0,0,0,142,0,'{}',0,0,0,0,'null'),(361,'2023-07-25 11:22:24',0,0,0,940,0,'{}',0,0,0,0,'null'),(362,'2023-07-26 10:01:37',0,0,0,105,0,'{}',0,0,0,0,'null'),(363,'2023-07-27 11:03:45',0,0,0,339,0,'{}',0,0,0,0,'null'),(364,'2023-07-28 10:58:41',0,0,0,505,0,'{}',0,0,0,0,'null'),(365,'2023-07-29 10:30:08',0,0,0,303,0,'{}',0,0,0,0,'null'),(366,'2023-07-30 10:54:09',0,0,0,234,0,'{}',0,0,0,0,'null'),(367,'2023-07-31 11:19:30',0,0,0,304,0,'{}',0,0,0,0,'null'),(368,'2023-08-01 10:00:59',0,0,0,235,0,'{}',0,0,0,0,'null'),(369,'2023-08-02 10:16:11',0,0,0,229,0,'{}',0,0,0,0,'null'),(370,'2023-08-03 10:06:15',0,0,0,211,0,'{}',0,0,0,0,'null'),(371,'2023-08-04 10:04:23',0,0,0,153,0,'{}',0,0,0,0,'null'),(372,'2023-08-05 10:11:14',0,0,0,226,0,'{}',0,0,0,0,'null'),(373,'2023-08-06 10:08:17',0,0,0,172,0,'{}',0,0,0,0,'null'),(374,'2023-08-07 10:23:42',0,0,0,369,0,'{}',0,0,0,0,'null'),(375,'2023-08-08 10:45:41',0,0,0,117,0,'{}',0,0,0,0,'null'),(376,'2023-08-09 11:25:28',0,0,0,310,0,'{}',0,0,0,0,'null'),(377,'2023-08-10 10:06:50',0,0,0,248,0,'{}',0,0,0,0,'null'),(378,'2023-08-11 10:05:27',0,0,0,1790,0,'{}',0,0,0,0,'null'),(379,'2023-08-12 10:03:22',0,0,0,271,0,'{}',0,0,0,0,'null'),(380,'2023-08-13 11:08:33',0,0,0,861,0,'{}',0,0,0,0,'null'),(381,'2023-08-14 10:16:16',0,0,0,86,0,'{}',0,0,0,0,'null'),(382,'2023-08-15 11:06:22',0,0,0,132,0,'{}',0,0,0,0,'null'),(383,'2023-08-16 12:01:39',0,0,0,127,0,'{}',0,0,0,0,'null'),(384,'2023-08-17 10:37:16',0,0,0,163,0,'{}',0,0,0,0,'null'),(385,'2023-08-18 10:56:21',0,0,0,118,0,'{}',0,0,0,0,'null'),(386,'2023-08-19 10:50:52',0,0,0,1718,0,'{}',0,0,0,0,'null'),(387,'2023-08-20 12:04:54',0,0,0,307,0,'{}',0,0,0,0,'null'),(388,'2023-08-21 10:17:52',0,0,0,568,0,'{}',0,0,0,0,'null'),(389,'2023-08-22 10:38:46',0,0,0,260,0,'{}',0,0,0,0,'null'),(390,'2023-08-23 10:01:24',0,0,0,368,0,'{}',0,0,0,0,'null'),(391,'2023-08-24 10:28:51',0,0,0,156,0,'{}',0,0,0,0,'null'),(392,'2023-08-25 11:01:47',0,0,0,63,0,'{}',0,0,0,0,'null'),(393,'2023-08-26 10:14:33',0,0,0,884,0,'{}',0,0,0,0,'null'),(394,'2023-08-27 11:24:29',0,0,0,269,0,'{}',0,0,0,0,'null'),(395,'2023-08-28 10:16:58',0,0,0,224,0,'{}',0,0,0,0,'null'),(396,'2023-08-29 12:14:47',0,0,0,174,0,'{}',0,0,0,0,'null'),(397,'2023-08-30 10:22:47',0,0,0,91,0,'{}',0,0,0,0,'null'),(398,'2023-08-31 11:25:04',0,0,0,177,0,'{}',0,0,0,0,'null'),(399,'2023-09-01 10:18:45',0,0,0,139,0,'{}',0,0,0,0,'null'),(400,'2023-09-02 10:07:34',0,0,0,122,0,'{}',0,0,0,0,'null'),(401,'2023-09-03 10:00:34',0,0,0,204,0,'{}',0,0,0,0,'null'),(402,'2023-09-04 13:07:18',0,0,0,263,0,'{}',0,0,0,0,'null'),(403,'2023-09-05 10:21:01',0,0,0,176,0,'{}',0,0,0,0,'null'),(404,'2023-09-06 10:05:57',0,0,0,183,0,'{}',0,0,0,0,'null'),(405,'2023-09-07 10:43:49',0,0,0,174,0,'{}',0,0,0,0,'null'),(406,'2023-09-08 11:30:02',0,0,0,194,0,'{}',0,0,0,0,'null'),(407,'2023-09-09 10:24:04',0,0,0,286,0,'{}',0,0,0,0,'null'),(408,'2023-09-10 13:00:33',0,0,0,960,0,'{}',0,0,0,0,'null'),(409,'2023-09-11 10:25:37',0,0,0,113,0,'{}',0,0,0,0,'null'),(410,'2023-09-12 10:07:18',0,0,0,216,0,'{}',0,0,0,0,'null'),(411,'2023-09-13 11:53:56',0,0,0,150,0,'{}',0,0,0,0,'null'),(412,'2023-09-14 10:24:16',0,0,0,354,0,'{}',0,0,0,0,'null'),(413,'2023-09-15 10:05:20',0,0,0,602,0,'{}',0,0,0,0,'null'),(414,'2023-09-16 10:25:54',0,0,0,527,0,'{}',0,0,0,0,'null'),(415,'2023-09-17 10:11:31',0,0,0,427,0,'{}',0,0,0,0,'null'),(416,'2023-09-18 10:29:30',0,0,0,436,0,'{}',0,0,0,0,'null'),(417,'2023-09-19 11:24:12',0,0,0,178,0,'{}',0,0,0,0,'null'),(418,'2023-09-20 11:32:36',0,0,0,119,0,'{}',0,0,0,0,'null'),(419,'2023-09-21 10:39:40',0,0,0,605,0,'{}',0,0,0,0,'null'),(420,'2023-09-22 10:21:56',0,0,0,149,0,'{}',0,0,0,0,'null'),(421,'2023-09-23 10:26:54',0,0,0,189,0,'{}',0,0,0,0,'null'),(422,'2023-09-24 11:25:19',0,0,0,328,0,'{}',0,0,0,0,'null'),(423,'2023-09-25 10:06:10',0,0,0,220,0,'{}',0,0,0,0,'null'),(424,'2023-09-26 15:49:49',0,0,0,281,0,'{}',0,0,0,0,'null'),(425,'2023-09-27 10:06:35',0,0,0,110,0,'{}',0,0,0,0,'null'),(426,'2023-09-28 11:09:31',0,0,0,287,0,'{}',0,0,0,0,'null'),(427,'2023-09-29 11:03:01',0,0,0,283,0,'{}',0,0,0,0,'null'),(428,'2023-09-30 11:04:17',0,0,0,427,0,'{}',0,0,0,0,'null'),(429,'2023-10-01 12:06:49',0,0,0,411,0,'{}',0,0,0,0,'null'),(430,'2023-10-02 10:04:29',0,0,0,117,0,'{}',0,0,0,0,'null'),(431,'2023-10-03 10:32:46',0,0,0,207,0,'{}',0,0,0,0,'null'),(432,'2023-10-04 10:59:37',0,0,0,318,0,'{}',0,0,0,0,'null'),(433,'2023-10-05 10:36:59',0,0,0,178,0,'{}',0,0,0,0,'null'),(434,'2023-10-06 10:20:37',0,0,0,246,0,'{}',0,0,0,0,'null'),(435,'2023-10-07 13:49:32',0,0,0,418,0,'{}',0,0,0,0,'null'),(436,'2023-10-08 10:00:00',0,0,0,66,0,'{}',0,0,0,0,'null'),(437,'2023-10-09 11:24:13',0,0,0,1839,0,'{}',0,0,0,0,'null'),(438,'2023-10-10 10:36:02',0,0,0,914,0,'{}',0,0,0,0,'null'),(439,'2023-10-11 10:08:02',0,0,0,137,0,'{}',0,0,0,0,'null'),(440,'2023-10-12 11:22:54',0,0,0,213,0,'{}',0,0,0,0,'null'),(441,'2023-10-13 10:44:03',0,0,0,1823,0,'{}',0,0,0,0,'null'),(442,'2023-10-14 10:27:58',0,0,0,333,0,'{}',0,0,0,0,'null'),(443,'2023-10-15 10:27:19',0,0,0,355,0,'{}',0,0,0,0,'null'),(444,'2023-10-16 12:03:44',0,0,0,274,0,'{}',0,0,0,0,'null'),(445,'2023-10-17 10:25:36',0,0,0,151,0,'{}',0,0,0,0,'null'),(446,'2023-10-18 10:51:07',0,0,0,213,0,'{}',0,0,0,0,'null'),(447,'2023-10-19 10:02:00',0,0,0,391,0,'{}',0,0,0,0,'null'),(448,'2023-10-20 10:16:30',0,0,0,236,0,'{}',0,0,0,0,'null'),(449,'2023-10-21 10:08:27',0,0,0,256,0,'{}',0,0,0,0,'null'),(450,'2023-10-22 10:52:07',0,0,0,370,0,'{}',0,0,0,0,'null'),(451,'2023-10-23 10:25:11',0,0,0,165,0,'{}',0,0,0,0,'null'),(452,'2023-10-24 10:34:41',0,0,0,224,0,'{}',0,0,0,0,'null'),(453,'2023-10-25 11:20:37',0,0,0,965,0,'{}',0,0,0,0,'null'),(454,'2023-10-26 10:19:42',0,0,0,235,0,'{}',0,0,0,0,'null'),(455,'2023-10-27 10:00:59',0,0,0,255,0,'{}',0,0,0,0,'null'),(456,'2023-10-28 10:53:21',0,0,0,351,0,'{}',0,0,0,0,'null'),(457,'2023-10-29 10:53:34',0,0,0,230,0,'{}',0,0,0,0,'null'),(458,'2023-10-30 12:27:20',0,0,0,267,0,'{}',0,0,0,0,'null'),(459,'2023-10-31 10:36:38',0,0,0,624,0,'{}',0,0,0,0,'null'),(460,'2023-11-01 11:10:29',0,0,0,192,0,'{}',0,0,0,0,'null'),(461,'2023-11-02 10:24:21',0,0,0,52,0,'{}',0,0,0,0,'null'),(462,'2023-11-03 10:26:46',0,0,0,77,0,'{}',0,0,0,0,'null'),(463,'2023-11-04 10:21:27',0,0,0,376,0,'{}',0,0,0,0,'null'),(464,'2023-11-05 10:03:04',0,0,0,491,0,'{}',0,0,0,0,'null'),(465,'2023-11-06 10:38:34',0,0,0,422,0,'{}',0,0,0,0,'null'),(466,'2023-11-07 10:51:36',0,0,0,127,0,'{}',0,0,0,0,'null'),(467,'2023-11-08 10:47:48',0,0,0,105,0,'{}',0,0,0,0,'null'),(468,'2023-11-09 11:03:03',0,0,0,893,0,'{}',0,0,0,0,'null'),(469,'2023-11-10 10:06:20',0,0,0,976,0,'{}',0,0,0,0,'null'),(470,'2023-11-11 10:17:47',0,0,0,96,0,'{}',0,0,0,0,'null'),(471,'2023-11-12 10:01:04',0,0,0,195,0,'{}',0,0,0,0,'null'),(472,'2023-11-13 12:19:35',0,0,0,177,0,'{}',0,0,0,0,'null'),(473,'2023-11-14 11:11:09',0,0,0,313,0,'{}',0,0,0,0,'null'),(474,'2023-11-15 10:35:52',0,0,0,106,0,'{}',0,0,0,0,'null'),(475,'2023-11-16 11:53:30',0,0,0,317,0,'{}',0,0,0,0,'null'),(476,'2023-11-17 10:14:57',0,0,0,169,0,'{}',0,0,0,0,'null'),(477,'2023-11-18 12:16:18',0,0,0,207,0,'{}',0,0,0,0,'null'),(478,'2023-11-19 11:25:46',0,0,0,223,0,'{}',0,0,0,0,'null'),(479,'2023-11-20 12:14:01',0,0,0,151,0,'{}',0,0,0,0,'null'),(480,'2023-11-21 10:04:44',0,0,0,82,0,'{}',0,0,0,0,'null'),(481,'2023-11-22 12:00:14',0,0,0,201,0,'{}',0,0,0,0,'null'),(482,'2023-11-23 10:14:33',0,0,0,302,0,'{}',0,0,0,0,'null'),(483,'2023-11-24 10:19:25',0,0,0,384,0,'{}',0,0,0,0,'null'),(484,'2023-11-25 10:12:16',0,0,0,1251,0,'{}',0,0,0,0,'null'),(485,'2023-11-26 10:26:10',0,0,0,640,0,'{}',0,0,0,0,'null'),(486,'2023-11-27 10:01:01',0,0,0,91,0,'{}',0,0,0,0,'null'),(487,'2023-11-28 10:14:13',0,0,0,349,0,'{}',0,0,0,0,'null'),(488,'2023-11-29 10:10:02',0,0,0,125,0,'{}',0,0,0,0,'null'),(489,'2023-11-30 13:07:25',0,0,0,206,0,'{}',0,0,0,0,'null'),(490,'2023-12-01 10:41:27',0,0,0,74,0,'{}',0,0,0,0,'null'),(491,'2023-12-02 11:35:53',0,0,0,1603,0,'{}',0,0,0,0,'null'),(492,'2023-12-03 11:48:20',0,0,0,41,0,'{}',0,0,0,0,'null'),(493,'2023-12-04 10:24:59',0,0,0,210,0,'{}',0,0,0,0,'null'),(494,'2023-12-05 10:31:41',0,0,0,125,0,'{}',0,0,0,0,'null'),(495,'2023-12-06 10:01:13',0,0,0,130,0,'{}',0,0,0,0,'null'),(496,'2023-12-07 10:44:34',0,0,0,275,0,'{}',0,0,0,0,'null'),(497,'2023-12-08 10:38:12',0,0,0,63,0,'{}',0,0,0,0,'null'),(498,'2023-12-09 12:46:27',0,0,0,1082,0,'{}',0,0,0,0,'null'),(499,'2023-12-10 10:25:29',0,0,0,898,0,'{}',0,0,0,0,'null'),(500,'2023-12-11 10:03:32',0,0,0,208,0,'{}',0,0,0,0,'null'),(501,'2023-12-12 10:30:07',0,0,0,145,0,'{}',0,0,0,0,'null'),(502,'2023-12-13 10:03:26',0,0,0,226,0,'{}',0,0,0,0,'null'),(503,'2023-12-15 10:06:21',0,0,0,219,0,'{}',0,0,0,0,'null'),(504,'2023-12-16 10:09:52',0,0,0,303,0,'{}',0,0,0,0,'null'),(505,'2023-12-17 10:17:57',0,0,0,297,0,'{}',0,0,0,0,'null'),(506,'2023-12-18 11:01:56',0,0,0,203,0,'{}',0,0,0,0,'null'),(507,'2023-12-19 15:42:48',0,0,0,202,0,'{}',0,0,0,0,'null'),(508,'2023-12-20 11:01:02',0,0,0,91,0,'{}',0,0,0,0,'null'),(509,'2023-12-21 10:00:33',0,0,0,228,0,'{}',0,0,0,0,'null'),(510,'2023-12-22 10:32:02',0,0,0,205,0,'{}',0,0,0,0,'null'),(511,'2023-12-23 10:40:08',0,0,0,169,0,'{}',0,0,0,0,'null'),(512,'2023-12-24 11:08:34',0,0,0,130,0,'{}',0,0,0,0,'null'),(513,'2023-12-25 12:54:39',0,0,0,138,0,'{}',0,0,0,0,'null'),(514,'2023-12-26 10:13:03',0,0,0,1541,0,'{}',0,0,0,0,'null'),(515,'2023-12-27 10:12:29',0,0,0,110,0,'{}',0,0,0,0,'null'),(516,'2023-12-28 11:05:43',0,0,0,242,0,'{}',0,0,0,0,'null'),(517,'2023-12-29 10:27:17',0,0,0,145,0,'{}',0,0,0,0,'null'),(518,'2023-12-30 13:30:09',0,0,0,299,0,'{}',0,0,0,0,'null'),(519,'2023-12-31 10:04:26',0,0,0,50,0,'{}',0,0,0,0,'null'),(520,'2024-01-01 11:26:45',0,0,0,498,0,'{}',0,0,0,0,'null'),(521,'2024-01-02 10:25:53',0,0,0,95,0,'{}',0,0,0,0,'null'),(522,'2024-01-03 10:00:11',0,0,0,85,0,'{}',0,0,0,0,'null'),(523,'2024-01-04 10:44:07',0,0,0,607,0,'{}',0,0,0,0,'null'),(524,'2024-01-05 11:03:49',0,0,0,296,0,'{}',0,0,0,0,'null'),(525,'2024-01-06 11:01:54',0,0,0,403,0,'{}',0,0,0,0,'null'),(526,'2024-01-07 10:53:52',0,0,0,426,0,'{}',0,0,0,0,'null'),(527,'2024-01-08 10:37:41',0,0,0,234,0,'{}',0,0,0,0,'null'),(528,'2024-01-09 10:49:18',0,0,0,243,0,'{}',0,0,0,0,'null'),(529,'2024-01-10 11:28:50',0,0,0,112,0,'{}',0,0,0,0,'null'),(530,'2024-01-11 11:27:46',0,0,0,2391,0,'{}',0,0,0,0,'null'),(531,'2024-01-12 11:07:27',0,0,0,179,0,'{}',0,0,0,0,'null'),(532,'2024-01-13 10:53:11',0,0,0,221,0,'{}',0,0,0,0,'null'),(533,'2024-01-14 10:43:58',0,0,0,111,0,'{}',0,0,0,0,'null'),(534,'2024-01-15 12:32:12',0,0,0,1299,0,'{}',0,0,0,0,'null'),(535,'2024-01-16 13:08:32',0,0,0,224,0,'{}',0,0,0,0,'null'),(536,'2024-01-17 13:03:26',0,0,0,437,0,'{}',0,0,0,0,'null'),(537,'2024-01-18 11:10:44',0,0,0,154,0,'{}',0,0,0,0,'null'),(538,'2024-01-19 10:50:55',0,0,0,671,0,'{}',0,0,0,0,'null'),(539,'2024-01-20 10:00:00',0,0,0,1851,0,'{}',0,0,0,0,'null'),(540,'2024-01-21 10:37:39',0,0,0,444,0,'{}',0,0,0,0,'null'),(541,'2024-01-22 10:04:45',0,0,0,350,0,'{}',0,0,0,0,'null'),(542,'2024-01-23 11:03:40',0,0,0,367,0,'{}',0,0,0,0,'null'),(543,'2024-01-24 11:58:30',0,0,0,115,0,'{}',0,0,0,0,'null'),(544,'2024-01-25 10:05:55',0,0,0,951,0,'{}',0,0,0,0,'null'),(545,'2024-01-26 10:25:57',0,0,0,320,0,'{}',0,0,0,0,'null'),(546,'2024-01-27 10:33:31',0,0,0,292,0,'{}',0,0,0,0,'null'),(547,'2024-01-28 10:32:28',0,0,0,1636,0,'{}',0,0,0,0,'null'),(548,'2024-01-29 10:01:39',0,0,0,349,0,'{}',0,0,0,0,'null'),(549,'2024-01-30 11:40:42',0,0,0,350,0,'{}',0,0,0,0,'null'),(550,'2024-01-31 13:14:08',0,0,0,84,0,'{}',0,0,0,0,'null'),(551,'2024-02-01 10:20:51',0,0,0,225,0,'{}',0,0,0,0,'null'),(552,'2024-02-02 10:06:54',0,0,0,279,0,'{}',0,0,0,0,'null'),(553,'2024-02-03 10:02:56',0,0,0,225,0,'{}',0,0,0,0,'null'),(554,'2024-02-04 10:26:20',0,0,0,66,0,'{}',0,0,0,0,'null'),(555,'2024-02-05 10:32:15',0,0,0,360,0,'{}',0,0,0,0,'null'),(556,'2024-02-06 10:08:13',0,0,0,94,0,'{}',0,0,0,0,'null'),(557,'2024-02-07 10:26:51',0,0,0,231,0,'{}',0,0,0,0,'null'),(558,'2024-02-08 10:03:35',0,0,0,85,0,'{}',0,0,0,0,'null'),(559,'2024-02-09 11:24:35',0,0,0,1587,0,'{}',0,0,0,0,'null'),(560,'2024-02-10 10:01:47',0,0,0,242,0,'{}',0,0,0,0,'null'),(561,'2024-02-11 10:18:28',0,0,0,505,0,'{}',0,0,0,0,'null'),(562,'2024-02-12 10:34:31',0,0,0,1652,0,'{}',0,0,0,0,'null'),(563,'2024-02-13 10:02:21',0,0,0,333,0,'{}',0,0,0,0,'null'),(564,'2024-02-14 10:00:51',0,0,0,324,0,'{}',0,0,0,0,'null'),(565,'2024-02-15 10:10:23',0,0,0,1904,0,'{}',0,0,0,0,'null'),(566,'2024-02-16 10:01:48',0,0,0,1009,0,'{}',0,0,0,0,'null'),(567,'2024-02-17 10:24:42',0,0,0,239,0,'{}',0,0,0,0,'null'),(568,'2024-02-18 10:37:02',0,0,0,979,0,'{}',0,0,0,0,'null'),(569,'2024-02-19 10:10:02',0,0,0,205,0,'{}',0,0,0,0,'null'),(570,'2024-02-20 10:53:01',0,0,0,470,0,'{}',0,0,0,0,'null'),(571,'2024-02-21 10:19:39',0,0,0,1251,0,'{}',0,0,0,0,'null'),(572,'2024-02-22 10:00:25',0,0,0,1197,0,'{}',0,0,0,0,'null'),(573,'2024-02-23 10:02:09',0,0,0,186,0,'{}',0,0,0,0,'null'),(574,'2024-02-24 10:00:14',0,0,0,436,0,'{}',0,0,0,0,'null'),(575,'2024-02-25 10:51:11',0,0,0,1497,0,'{}',0,0,0,0,'null'),(576,'2024-02-26 10:13:14',0,0,0,279,0,'{}',0,0,0,0,'null'),(577,'2024-02-27 10:13:12',0,0,0,99,0,'{}',0,0,0,0,'null'),(578,'2024-02-28 10:02:58',0,0,0,867,0,'{}',0,0,0,0,'null'),(579,'2024-02-29 10:42:44',0,0,0,125,0,'{}',0,0,0,0,'null'),(580,'2024-03-01 11:09:33',0,0,0,388,0,'{}',0,0,0,0,'null'),(581,'2024-03-02 10:12:40',0,0,0,227,0,'{}',0,0,0,0,'null'),(582,'2024-03-03 10:10:03',0,0,0,264,0,'{}',0,0,0,0,'null'),(583,'2024-03-04 13:55:59',0,0,0,127,0,'{}',0,0,0,0,'null'),(584,'2024-03-05 10:18:59',0,0,0,170,0,'{}',0,0,0,0,'null'),(585,'2024-03-06 10:23:58',0,0,0,427,0,'{}',0,0,0,0,'null'),(586,'2024-03-07 11:35:51',0,0,0,927,0,'{}',0,0,0,0,'null'),(587,'2024-03-08 10:32:02',0,0,0,183,0,'{}',0,0,0,0,'null'),(588,'2024-03-09 10:32:35',0,0,0,335,0,'{}',0,0,0,0,'null'),(589,'2024-03-11 11:05:32',0,0,0,1883,0,'{}',0,0,0,0,'null'),(590,'2024-03-12 10:06:13',0,0,0,270,0,'{}',0,0,0,0,'null'),(591,'2024-03-13 10:53:46',0,0,0,733,0,'{}',0,0,0,0,'null'),(592,'2024-03-14 10:49:18',0,0,0,111,0,'{}',0,0,0,0,'null'),(593,'2024-03-15 10:06:11',0,0,0,1852,0,'{}',0,0,0,0,'null'),(594,'2024-03-16 11:24:19',0,0,0,787,0,'{}',0,0,0,0,'null'),(595,'2024-03-17 10:00:41',0,0,0,274,0,'{}',0,0,0,0,'null'),(596,'2024-03-18 10:19:47',0,0,0,337,0,'{}',0,0,0,0,'null'),(597,'2024-03-19 11:00:24',0,0,0,1741,0,'{}',0,0,0,0,'null'),(598,'2024-03-20 11:35:06',0,0,0,194,0,'{}',0,0,0,0,'null'),(599,'2024-03-21 10:07:10',0,0,0,769,0,'{}',0,0,0,0,'null'),(600,'2024-03-22 10:16:30',0,0,0,1000,0,'{}',0,0,0,0,'null'),(601,'2024-03-23 10:34:23',0,0,0,389,0,'{}',0,0,0,0,'null'),(602,'2024-03-24 10:33:44',0,0,0,1142,0,'{}',0,0,0,0,'null'),(603,'2024-03-25 10:48:47',0,0,0,816,0,'{}',0,0,0,0,'null'),(604,'2024-03-26 10:05:32',0,0,0,219,0,'{}',0,0,0,0,'null'),(605,'2024-03-27 10:20:20',0,0,0,306,0,'{}',0,0,0,0,'null'),(606,'2024-03-28 10:30:31',0,0,0,1651,0,'{}',0,0,0,0,'null'),(607,'2024-03-29 10:10:47',0,0,0,640,0,'{}',0,0,0,0,'null'),(608,'2024-03-30 10:00:11',0,0,0,1214,0,'{}',0,0,0,0,'null'),(609,'2024-03-31 10:57:36',0,0,0,863,0,'{}',0,0,0,0,'null'),(610,'2024-04-01 10:19:33',0,0,0,103,0,'{}',0,0,0,0,'null'),(611,'2024-04-02 10:14:28',0,0,0,251,0,'{}',0,0,0,0,'null'),(612,'2024-04-03 10:05:23',0,0,0,109,0,'{}',0,0,0,0,'null'),(613,'2024-04-04 10:15:20',0,0,0,995,0,'{}',0,0,0,0,'null'),(614,'2024-04-05 10:03:25',0,0,0,805,0,'{}',0,0,0,0,'null'),(615,'2024-04-06 10:17:34',0,0,0,631,0,'{}',0,0,0,0,'null'),(616,'2024-04-07 10:03:46',0,0,0,1043,0,'{}',0,0,0,0,'null'),(617,'2024-04-08 10:20:32',0,0,0,145,0,'{}',0,0,0,0,'null'),(618,'2024-04-09 10:25:50',0,0,0,820,0,'{}',0,0,0,0,'null'),(619,'2024-04-10 11:22:21',0,0,0,94,0,'{}',0,0,0,0,'null'),(620,'2024-04-11 10:11:02',0,0,0,518,0,'{}',0,0,0,0,'null'),(621,'2024-04-12 10:14:25',0,0,0,889,0,'{}',0,0,0,0,'null'),(622,'2024-04-13 11:05:39',0,0,0,1739,0,'{}',0,0,0,0,'null'),(623,'2024-04-14 11:00:15',0,0,0,85,0,'{}',0,0,0,0,'null'),(624,'2024-04-15 10:09:23',0,0,0,332,0,'{}',0,0,0,0,'null'),(625,'2024-04-16 10:07:16',0,0,0,942,0,'{}',0,0,0,0,'null'),(626,'2024-04-17 10:09:59',0,0,0,426,0,'{}',0,0,0,0,'null'),(627,'2024-04-18 10:02:57',0,0,0,468,0,'{}',0,0,0,0,'null'),(628,'2024-04-19 10:08:38',0,0,0,2492,0,'{}',0,0,0,0,'null'),(629,'2024-04-20 10:50:18',0,0,0,331,0,'{}',0,0,0,0,'null'),(630,'2024-04-21 10:00:02',0,0,0,655,0,'{}',0,0,0,0,'null'),(631,'2024-04-22 10:02:51',0,0,0,2179,0,'{}',0,0,0,0,'null'),(632,'2024-04-23 10:00:52',0,0,0,479,0,'{}',0,0,0,0,'null'),(633,'2024-04-24 10:44:45',0,0,0,1063,0,'{}',0,0,0,0,'null'),(634,'2024-04-25 10:00:53',0,0,0,396,0,'{}',0,0,0,0,'null'),(635,'2024-04-26 10:22:58',0,0,0,386,0,'{}',0,0,0,0,'null'),(636,'2024-04-27 10:02:41',0,0,0,1074,0,'{}',0,0,0,0,'null'),(637,'2024-04-28 10:08:59',0,0,0,480,0,'{}',0,0,0,0,'null'),(638,'2024-04-29 10:02:12',0,0,0,539,0,'{}',0,0,0,0,'null'),(639,'2024-04-30 10:00:30',0,0,0,827,0,'{}',0,0,0,0,'null'),(640,'2024-05-01 11:05:48',0,0,0,477,0,'{}',0,0,0,0,'null'),(641,'2024-05-02 10:12:22',0,0,0,721,0,'{}',0,0,0,0,'null'),(642,'2024-05-03 11:40:32',0,0,0,421,0,'{}',0,0,0,0,'null'),(643,'2024-05-04 10:35:16',0,0,0,485,0,'{}',0,0,0,0,'null'),(644,'2024-05-05 10:41:43',0,0,0,459,0,'{}',0,0,0,0,'null'),(645,'2024-05-06 10:01:57',0,0,0,1001,0,'{}',0,0,0,0,'null'),(646,'2024-05-07 10:29:27',0,0,0,585,0,'{}',0,0,0,0,'null'),(647,'2024-05-08 10:03:48',0,0,0,313,0,'{}',0,0,0,0,'null'),(648,'2024-05-09 10:50:48',0,0,0,293,0,'{}',0,0,0,0,'null'),(649,'2024-05-10 10:38:27',0,0,0,173,0,'{}',0,0,0,0,'null'),(650,'2024-05-11 10:14:07',0,0,0,11,0,'{}',0,0,0,0,'null'),(651,'2024-05-12 19:51:38',0,0,0,6,0,'{}',0,0,0,0,'null'),(652,'2024-05-13 10:20:11',0,0,0,78,0,'{}',0,0,0,0,'null'),(653,'2024-05-14 10:13:32',0,0,0,148,0,'{}',0,0,0,0,'null'),(654,'2024-05-15 10:46:36',0,0,0,603,0,'{}',0,0,0,0,'null'),(655,'2024-05-16 10:44:04',0,0,0,1676,0,'{}',0,0,0,0,'null'),(656,'2024-05-17 11:35:17',0,0,0,855,0,'{}',0,0,0,0,'null'),(657,'2024-05-18 12:26:21',0,0,0,177,0,'{}',0,0,0,0,'null'),(658,'2024-05-19 10:42:46',0,0,0,146,0,'{}',0,0,0,0,'null'),(659,'2024-05-20 10:35:28',0,0,0,183,0,'{}',0,0,0,0,'null'),(660,'2024-05-21 10:06:25',0,0,0,1177,0,'{}',0,0,0,0,'null'),(661,'2024-05-22 13:14:44',0,0,0,230,0,'{}',0,0,0,0,'null'),(662,'2024-05-23 11:52:49',0,0,0,269,0,'{}',0,0,0,0,'null'),(663,'2024-05-24 10:05:16',0,0,0,1245,0,'{}',0,0,0,0,'null'),(664,'2024-05-25 10:12:05',0,0,0,401,0,'{}',0,0,0,0,'null'),(665,'2024-05-26 10:11:38',0,0,0,322,0,'{}',0,0,0,0,'null'),(666,'2024-05-27 10:09:09',0,0,0,129,0,'{}',0,0,0,0,'null'),(667,'2024-05-28 10:43:36',0,0,0,205,0,'{}',0,0,0,0,'null'),(668,'2024-05-29 10:47:29',0,0,0,95,0,'{}',0,0,0,0,'null'),(669,'2024-05-30 10:16:47',0,0,0,1014,0,'{}',0,0,0,0,'null'),(670,'2024-05-31 10:04:40',0,0,0,157,0,'{}',0,0,0,0,'null'),(671,'2024-06-01 10:57:52',0,0,0,331,0,'{}',0,0,0,0,'null'),(672,'2024-06-02 10:19:38',0,0,0,288,0,'{}',0,0,0,0,'null'),(673,'2024-06-03 10:29:17',0,0,0,260,0,'{}',0,0,0,0,'null'),(674,'2024-06-04 10:17:11',0,0,0,230,0,'{}',0,0,0,0,'null'),(675,'2024-06-05 10:03:54',0,0,0,400,0,'{}',0,0,0,0,'null'),(676,'2024-06-06 11:00:05',0,0,0,1311,0,'{}',0,0,0,0,'null'),(677,'2024-06-07 10:13:14',0,0,0,268,0,'{}',0,0,0,0,'null'),(678,'2024-06-08 11:48:22',0,0,0,80,0,'{}',0,0,0,0,'null'),(679,'2024-06-09 10:36:22',0,0,0,268,0,'{}',0,0,0,0,'null'),(680,'2024-06-10 10:03:10',0,0,0,295,0,'{}',0,0,0,0,'null'),(681,'2024-06-11 10:06:59',0,0,0,93,0,'{}',0,0,0,0,'null'),(682,'2024-06-12 10:12:56',0,0,0,181,0,'{}',0,0,0,0,'null'),(683,'2024-06-13 12:43:40',0,0,0,423,0,'{}',0,0,0,0,'null'),(684,'2024-06-14 10:03:39',0,0,0,105,0,'{}',0,0,0,0,'null'),(685,'2024-06-15 10:16:00',0,0,0,1166,0,'{}',0,0,0,0,'null'),(686,'2024-06-16 10:22:55',0,0,0,215,0,'{}',0,0,0,0,'null'),(687,'2024-06-17 10:14:19',0,0,0,48,0,'{}',0,0,0,0,'null'),(688,'2024-06-18 11:15:11',0,0,0,147,0,'{}',0,0,0,0,'null'),(689,'2024-06-19 10:10:56',0,0,0,414,0,'{}',0,0,0,0,'null'),(690,'2024-06-20 10:31:36',0,0,0,199,0,'{}',0,0,0,0,'null'),(691,'2024-06-21 10:02:16',0,0,0,198,0,'{}',0,0,0,0,'null'),(692,'2024-06-22 10:13:49',0,0,0,177,0,'{}',0,0,0,0,'null'),(693,'2024-06-23 10:07:55',0,0,0,203,0,'{}',0,0,0,0,'null'),(694,'2024-06-24 11:20:24',0,0,0,206,0,'{}',0,0,0,0,'null'),(695,'2024-06-25 10:41:17',0,0,0,412,0,'{}',0,0,0,0,'null'),(696,'2024-06-26 10:11:34',0,0,0,373,0,'{}',0,0,0,0,'null'),(697,'2024-06-27 10:06:24',0,0,0,1892,0,'{}',0,0,0,0,'null'),(698,'2024-06-28 10:05:46',0,0,0,190,0,'{}',0,0,0,0,'null'),(699,'2024-06-29 10:30:04',0,0,0,1086,0,'{}',0,0,0,0,'null'),(700,'2024-06-30 13:02:05',0,0,0,860,0,'{}',0,0,0,0,'null'),(701,'2024-07-01 10:03:12',0,0,0,168,0,'{}',0,0,0,0,'null'),(702,'2024-07-02 10:54:35',0,0,0,438,0,'{}',0,0,0,0,'null'),(703,'2024-07-04 10:34:47',0,0,0,755,0,'{}',0,0,0,0,'null'),(704,'2024-07-05 10:21:43',0,0,0,238,0,'{}',0,0,0,0,'null'),(705,'2024-07-06 11:16:52',0,0,0,239,0,'{}',0,0,0,0,'null'),(706,'2024-07-07 11:43:42',0,0,0,307,0,'{}',0,0,0,0,'null'),(707,'2024-07-08 13:35:14',0,0,0,87,0,'{}',0,0,0,0,'null'),(708,'2024-07-09 10:06:27',0,0,0,313,0,'{}',0,0,0,0,'null'),(709,'2024-07-10 14:08:48',0,0,0,259,0,'{}',0,0,0,0,'null'),(710,'2024-07-11 11:15:34',0,0,0,226,0,'{}',0,0,0,0,'null'),(711,'2024-07-12 10:38:26',0,0,0,251,0,'{}',0,0,0,0,'null'),(712,'2024-07-13 10:23:19',0,0,0,323,0,'{}',0,0,0,0,'null'),(713,'2024-07-14 10:08:43',0,0,0,516,0,'{}',0,0,0,0,'null'),(714,'2024-07-15 10:25:42',0,0,0,128,0,'{}',0,0,0,0,'null'),(715,'2024-07-16 10:21:33',0,0,0,238,0,'{}',0,0,0,0,'null'),(716,'2024-07-17 10:50:41',0,0,0,190,0,'{}',0,0,0,0,'null'),(717,'2024-07-18 10:01:42',0,0,0,715,0,'{}',0,0,0,0,'null'),(718,'2024-07-20 10:39:44',0,0,0,688,0,'{}',0,0,0,0,'null'),(719,'2024-07-21 10:59:34',0,0,0,369,0,'{}',0,0,0,0,'null'),(720,'2024-07-22 12:00:17',0,0,0,198,0,'{}',0,0,0,0,'null'),(721,'2024-07-23 10:25:09',0,0,0,234,0,'{}',0,0,0,0,'null'),(722,'2024-07-24 10:48:36',0,0,0,1029,0,'{}',0,0,0,0,'null'),(723,'2024-07-25 11:11:53',0,0,0,519,0,'{}',0,0,0,0,'null'),(724,'2024-07-26 11:03:28',0,0,0,78,0,'{}',0,0,0,0,'null'),(725,'2024-07-27 10:46:22',0,0,0,174,0,'{}',0,0,0,0,'null'),(726,'2024-07-28 13:30:37',0,0,0,350,0,'{}',0,0,0,0,'null'),(727,'2024-07-29 10:33:20',0,0,0,262,0,'{}',0,0,0,0,'null'),(728,'2024-07-30 10:18:58',0,0,0,2723,0,'{}',0,0,0,0,'null'),(729,'2024-07-31 10:08:05',0,0,0,815,0,'{}',0,0,0,0,'null'),(730,'2024-08-01 10:28:43',0,0,0,538,0,'{}',0,0,0,0,'null'),(731,'2024-08-02 11:18:06',0,0,0,141,0,'{}',0,0,0,0,'null'),(732,'2024-08-03 10:03:13',0,0,0,147,0,'{}',0,0,0,0,'null'),(733,'2024-08-04 11:49:16',0,0,0,341,0,'{}',0,0,0,0,'null'),(734,'2024-08-05 10:55:16',0,0,0,287,0,'{}',0,0,0,0,'null'),(735,'2024-08-06 10:41:26',0,0,0,932,0,'{}',0,0,0,0,'null'),(736,'2024-08-07 10:10:57',0,0,0,269,0,'{}',0,0,0,0,'null'),(737,'2024-08-08 10:19:01',0,0,0,166,0,'{}',0,0,0,0,'null'),(738,'2024-08-09 10:07:34',0,0,0,214,0,'{}',0,0,0,0,'null'),(739,'2024-08-10 10:16:23',0,0,0,1604,0,'{}',0,0,0,0,'null'),(740,'2024-08-11 10:10:54',0,0,0,689,0,'{}',0,0,0,0,'null'),(741,'2024-08-12 10:03:13',0,0,0,1046,0,'{}',0,0,0,0,'null'),(742,'2024-08-13 10:01:49',0,0,0,199,0,'{}',0,0,0,0,'null'),(743,'2024-08-14 10:15:33',0,0,0,257,0,'{}',0,0,0,0,'null'),(744,'2024-08-15 10:33:49',0,0,0,298,0,'{}',0,0,0,0,'null'),(745,'2024-08-16 11:54:27',0,0,0,737,0,'{}',0,0,0,0,'null'),(746,'2024-08-17 10:31:17',0,0,0,301,0,'{}',0,0,0,0,'null'),(747,'2024-08-18 11:46:52',0,0,0,475,0,'{}',0,0,0,0,'null'),(748,'2024-08-19 10:31:03',0,0,0,148,0,'{}',0,0,0,0,'null'),(749,'2024-08-20 10:04:32',0,0,0,407,0,'{}',0,0,0,0,'null'),(750,'2024-08-21 10:16:15',0,0,0,1000,0,'{}',0,0,0,0,'null'),(751,'2024-08-22 10:49:07',0,0,0,305,0,'{}',0,0,0,0,'null'),(752,'2024-08-23 11:11:29',0,0,0,155,0,'{}',0,0,0,0,'null'),(753,'2024-08-24 10:08:17',0,0,0,413,0,'{}',0,0,0,0,'null'),(754,'2024-08-25 10:06:18',0,0,0,227,0,'{}',0,0,0,0,'null'),(755,'2024-08-26 10:31:54',0,0,0,362,0,'{}',0,0,0,0,'null'),(756,'2024-08-27 10:23:02',0,0,0,780,0,'{}',0,0,0,0,'null'),(757,'2024-08-28 10:05:28',0,0,0,461,0,'{}',0,0,0,0,'null'),(758,'2024-08-29 10:42:56',0,0,0,238,0,'{}',0,0,0,0,'null'),(759,'2024-08-30 10:24:09',0,0,0,150,0,'{}',0,0,0,0,'null'),(760,'2024-08-31 10:00:15',0,0,0,438,0,'{}',0,0,0,0,'null'),(761,'2024-09-01 10:29:38',0,0,0,450,0,'{}',0,0,0,0,'null'),(762,'2024-09-02 11:01:19',0,0,0,461,0,'{}',0,0,0,0,'null'),(763,'2024-09-03 10:26:13',0,0,0,2044,0,'{}',0,0,0,0,'null'),(764,'2024-09-04 10:14:16',0,0,0,208,0,'{}',0,0,0,0,'null'),(765,'2024-09-05 10:07:46',0,0,0,234,0,'{}',0,0,0,0,'null'),(766,'2024-09-06 10:40:33',0,0,0,80,0,'{}',0,0,0,0,'null'),(767,'2024-09-07 11:11:55',2,0,8,137,0,'{}',0,0,0,0,'null'),(768,'2024-09-08 10:56:07',1,0,4,339,0,'{}',0,0,0,0,'null'),(769,'2024-09-09 10:20:40',1,0,4,1101,0,'{}',0,0,0,0,'null'),(770,'2024-09-10 12:45:58',2,0,8,382,0,'{}',0,0,0,0,'null'),(771,'2024-09-11 10:55:20',1,0,4,751,0,'{}',0,0,0,0,'null'),(772,'2024-09-12 10:17:22',0,0,0,573,0,'{}',0,0,0,0,'null'),(773,'2024-09-13 10:51:22',1,0,4,112,0,'{}',0,0,0,0,'null'),(774,'2024-09-14 12:02:42',1,0,4,1151,0,'{}',0,0,0,0,'null'),(775,'2024-09-15 10:03:30',1,0,4,650,0,'{}',0,0,0,0,'null'),(776,'2024-09-16 11:14:12',1,0,4,152,0,'{}',0,0,0,0,'null'),(777,'2024-09-17 10:43:19',0,0,0,196,0,'{}',0,0,0,0,'null'),(778,'2024-09-18 10:26:10',0,0,0,1029,0,'{}',0,0,0,0,'null'),(779,'2024-09-19 10:06:33',1,0,4,354,0,'{}',0,0,0,0,'null'),(780,'2024-09-20 13:22:47',2,0,8,361,0,'{}',0,0,0,0,'null'),(781,'2024-09-21 10:25:32',1,0,4,246,0,'{}',0,0,0,0,'null'),(782,'2024-09-22 10:13:52',1,0,4,540,0,'{}',0,0,0,0,'null'),(783,'2024-09-23 10:41:07',1,0,4,394,0,'{}',0,0,0,0,'null'),(784,'2024-09-24 10:57:13',0,0,0,112,0,'{}',0,0,0,0,'null'),(785,'2024-09-25 10:07:38',2,0,8,140,0,'{}',0,0,0,0,'null'),(786,'2024-09-26 10:06:39',0,0,0,2232,0,'{}',0,0,0,0,'null'),(787,'2024-09-27 11:52:58',0,0,0,878,0,'{}',0,0,0,0,'null'),(788,'2024-09-28 13:58:57',1,0,4,1199,0,'{}',0,0,0,0,'null'),(789,'2024-09-29 10:09:40',0,0,0,194,0,'{}',0,0,0,0,'null'),(790,'2024-09-30 10:05:56',2,0,5,316,0,'{}',0,0,0,0,'null'),(791,'2024-10-01 12:12:44',1,0,4,241,0,'{}',0,0,0,0,'null'),(792,'2024-10-02 10:06:17',0,0,0,441,0,'{}',0,0,0,0,'null'),(793,'2024-10-03 10:57:40',2,0,8,343,0,'{}',0,0,0,0,'null'),(794,'2024-10-04 10:44:58',1,0,4,600,0,'{}',0,0,0,0,'null'),(795,'2024-10-05 10:11:37',0,0,0,774,0,'{}',0,0,0,0,'null'),(796,'2024-10-06 10:20:56',2,0,8,258,0,'{}',0,0,0,0,'null'),(797,'2024-10-07 10:26:22',0,0,0,247,0,'{}',0,0,0,0,'null'),(798,'2024-10-08 10:13:29',1,0,4,114,0,'{}',0,0,0,0,'null'),(799,'2024-10-09 10:03:59',1,0,4,641,0,'{}',0,0,0,0,'null'),(800,'2024-10-10 10:10:09',2,0,8,185,0,'{}',0,0,0,0,'null'),(801,'2024-10-11 10:10:21',2,0,8,656,0,'{}',0,0,0,0,'null'),(802,'2024-10-12 10:06:04',0,0,0,525,0,'{}',0,0,0,0,'null'),(803,'2024-10-13 10:54:44',0,0,0,1878,0,'{}',0,0,0,0,'null'),(804,'2024-10-14 10:11:03',2,0,8,244,0,'{}',0,0,0,0,'null'),(805,'2024-10-15 10:40:48',2,0,8,139,0,'{}',0,0,0,0,'null'),(806,'2024-10-16 10:07:27',0,0,0,261,0,'{}',0,0,0,0,'null'),(807,'2024-10-17 10:16:07',2,0,8,634,0,'{}',0,0,0,0,'null'),(808,'2024-10-18 10:43:44',0,0,0,223,0,'{}',0,0,0,0,'null'),(809,'2024-10-19 12:13:34',1,0,4,195,0,'{}',0,0,0,0,'null'),(810,'2024-10-20 10:24:12',2,0,8,526,0,'{}',0,0,0,0,'null'),(811,'2024-10-21 10:22:14',0,0,0,102,0,'{}',0,0,0,0,'null'),(812,'2024-10-22 10:24:07',0,0,0,147,0,'{}',0,0,0,0,'null'),(813,'2024-10-23 10:10:03',0,0,0,259,0,'{}',0,0,0,0,'null'),(814,'2024-10-24 10:53:44',1,0,4,187,0,'{}',0,0,0,0,'null'),(815,'2024-10-25 10:16:48',1,0,4,599,0,'{}',0,0,0,0,'null'),(816,'2024-10-26 10:26:17',2,0,8,1975,0,'{}',0,0,0,0,'null'),(817,'2024-10-27 10:41:07',1,0,4,869,0,'{}',0,0,0,0,'null'),(818,'2024-10-28 10:12:13',2,0,8,549,0,'{}',0,0,0,0,'null'),(819,'2024-10-29 10:24:06',2,0,8,103,0,'{}',0,0,0,0,'null'),(820,'2024-10-30 12:45:56',2,0,8,269,0,'{}',0,0,0,0,'null'),(821,'2024-10-31 10:01:14',1,0,4,736,0,'{}',0,0,0,0,'null'),(822,'2024-11-01 10:16:27',2,0,8,227,0,'{}',0,0,0,0,'null'),(823,'2024-11-02 10:01:00',1,0,4,398,0,'{}',0,0,0,0,'null'),(824,'2024-11-03 10:47:28',2,0,8,418,0,'{}',0,0,0,0,'null'),(825,'2024-11-04 10:00:55',1,0,4,89,0,'{}',0,0,0,0,'null'),(826,'2024-11-05 10:31:48',2,0,8,129,0,'{}',0,0,0,0,'null'),(827,'2024-11-06 11:25:12',0,0,0,851,0,'{}',0,0,0,0,'null'),(828,'2024-11-07 10:41:48',2,0,8,343,0,'{}',0,0,0,0,'null'),(829,'2024-11-08 10:35:13',2,0,8,421,0,'{}',0,0,0,0,'null'),(830,'2024-11-09 10:43:14',1,0,4,247,0,'{}',0,0,0,0,'null'),(831,'2024-11-10 10:40:17',2,0,8,553,0,'{}',0,0,0,0,'null'),(832,'2024-11-11 10:24:39',0,0,0,203,0,'{}',0,0,0,0,'null'),(833,'2024-11-12 10:36:14',1,0,4,244,0,'{}',0,0,0,0,'null'),(834,'2024-11-13 11:33:47',2,0,8,264,0,'{}',0,0,0,0,'null'),(835,'2024-11-14 10:08:03',1,0,4,397,0,'{}',0,0,0,0,'null'),(836,'2024-11-15 10:03:50',1,0,4,1094,0,'{}',0,0,0,0,'null'),(837,'2024-11-16 12:12:17',1,0,4,326,0,'{}',0,0,0,0,'null'),(838,'2024-11-17 11:10:13',1,0,4,129,0,'{}',0,0,0,0,'null'),(839,'2024-11-18 10:04:25',0,0,0,138,0,'{}',0,0,0,0,'null'),(840,'2024-11-19 11:13:08',1,0,4,127,0,'{}',0,0,0,0,'null'),(841,'2024-11-20 10:27:17',0,0,0,263,0,'{}',0,0,0,0,'null'),(842,'2024-11-21 10:00:55',1,0,5,721,0,'{}',0,0,0,0,'null'),(843,'2024-11-22 10:11:59',0,0,0,462,0,'{}',0,0,0,0,'null'),(844,'2024-11-23 11:11:54',0,0,0,326,0,'{}',0,0,0,0,'null'),(845,'2024-11-24 10:01:10',0,0,0,324,0,'{}',0,0,0,0,'null'),(846,'2024-11-25 12:36:15',0,0,0,742,0,'{}',0,0,0,0,'null'),(847,'2024-11-26 10:20:48',0,0,0,21,0,'{}',0,0,0,0,'null'),(848,'2024-11-27 10:23:03',1,0,5,299,0,'{}',0,0,0,0,'null'),(849,'2024-11-28 11:47:35',1,0,5,614,0,'{}',0,0,0,0,'null'),(850,'2024-11-29 11:18:36',0,0,0,226,0,'{}',0,0,0,0,'null'),(851,'2024-11-30 10:24:38',2,0,6,296,0,'{}',0,0,0,0,'null'),(852,'2024-12-01 10:07:40',1,0,3,300,0,'{}',0,0,0,0,'null'),(853,'2024-12-02 11:38:12',1,0,3,586,0,'{}',0,0,0,0,'null'),(854,'2024-12-03 11:09:09',4,0,12,180,0,'{}',0,0,0,0,'null'),(855,'2024-12-04 11:27:33',0,0,0,176,0,'{}',0,0,0,0,'null'),(856,'2024-12-05 10:24:59',0,0,0,506,0,'{}',0,0,0,0,'null'),(857,'2024-12-06 10:00:35',0,0,0,655,0,'{}',0,0,0,0,'null'),(858,'2024-12-07 10:09:38',0,0,0,434,0,'{}',0,0,0,0,'null'),(859,'2024-12-08 10:24:12',0,0,0,217,0,'{}',0,0,0,0,'null'),(860,'2024-12-09 10:00:12',0,0,0,696,0,'{}',0,0,0,0,'null'),(861,'2024-12-10 10:28:36',0,0,0,315,0,'{}',0,0,0,0,'null'),(862,'2024-12-11 10:01:30',0,0,0,442,0,'{}',0,0,0,0,'null'),(863,'2024-12-12 10:02:36',0,0,0,806,0,'{}',0,0,0,0,'null'),(864,'2024-12-13 10:14:01',0,0,0,30,0,'{}',0,0,0,0,'null'),(865,'2024-12-14 10:23:58',0,0,0,743,0,'{}',0,0,0,0,'null'),(866,'2024-12-15 10:05:39',0,0,0,297,0,'{}',0,0,0,0,'null'),(867,'2024-12-16 10:26:56',0,0,0,456,0,'{}',0,0,0,0,'null'),(868,'2024-12-17 10:00:40',0,0,0,280,0,'{}',0,0,0,0,'null'),(869,'2024-12-18 10:00:37',0,0,0,198,0,'{}',0,0,0,0,'null'),(870,'2024-12-19 11:22:21',0,0,0,670,0,'{}',0,0,0,0,'null'),(871,'2024-12-20 10:57:52',0,0,0,175,0,'{}',0,0,0,0,'null'),(872,'2024-12-21 10:13:22',0,0,0,230,0,'{}',0,0,0,0,'null'),(873,'2024-12-22 11:12:20',0,0,0,1086,0,'{}',0,0,0,0,'null'),(874,'2024-12-23 10:05:06',0,0,0,220,0,'{}',0,0,0,0,'null'),(875,'2024-12-24 10:38:49',0,0,0,260,0,'{}',0,0,0,0,'null'),(876,'2024-12-25 10:07:33',0,0,0,304,0,'{}',0,0,0,0,'null'),(877,'2024-12-26 10:26:30',0,0,0,415,0,'{}',0,0,0,0,'null'),(878,'2024-12-27 10:13:28',0,0,0,81,0,'{}',0,0,0,0,'null'),(879,'2024-12-28 10:16:54',0,0,0,324,0,'{}',0,0,0,0,'null'),(880,'2024-12-29 10:22:53',0,0,0,361,0,'{}',0,0,0,0,'null'),(881,'2024-12-30 10:08:13',0,0,0,155,0,'{}',0,0,0,0,'null'),(882,'2024-12-31 10:56:52',0,0,0,335,0,'{}',0,0,0,0,'null'),(883,'2025-01-01 10:22:59',0,0,0,352,0,'{}',0,0,0,0,'null'),(884,'2025-01-02 10:01:37',0,0,0,588,0,'{}',0,0,0,0,'null'),(885,'2025-01-03 12:11:34',0,0,0,1035,0,'{}',0,0,0,0,'null'),(886,'2025-01-04 10:06:13',0,0,0,170,0,'{}',0,0,0,0,'null'),(887,'2025-01-05 10:23:24',0,0,0,494,0,'{}',0,0,0,0,'null'),(888,'2025-01-06 10:20:33',0,0,0,355,0,'{}',0,0,0,0,'null'),(889,'2025-01-07 11:11:00',0,0,0,239,0,'{}',0,0,0,0,'null'),(890,'2025-01-08 10:04:47',0,0,0,319,0,'{}',0,0,0,0,'null'),(891,'2025-01-09 10:15:12',0,0,0,223,0,'{}',0,0,0,0,'null'),(892,'2025-01-10 10:35:10',0,0,0,791,0,'{}',0,0,0,0,'null'),(893,'2025-01-11 10:08:39',0,0,0,227,0,'{}',0,0,0,0,'null'),(894,'2025-01-12 10:04:04',0,0,0,2413,0,'{}',0,0,0,0,'null'),(895,'2025-01-13 10:10:30',0,0,0,171,0,'{}',0,0,0,0,'null'),(896,'2025-01-14 11:12:20',0,0,0,196,0,'{}',0,0,0,0,'null'),(897,'2025-01-15 10:52:03',0,0,0,211,0,'{}',0,0,0,0,'null'),(898,'2025-01-16 10:19:49',0,0,0,1000,0,'{}',0,0,0,0,'null'),(899,'2025-01-17 10:14:56',0,0,0,291,0,'{}',0,0,0,0,'null'),(900,'2025-01-18 10:00:50',0,0,0,242,0,'{}',0,0,0,0,'null'),(901,'2025-01-19 10:49:17',0,0,0,183,0,'{}',0,0,0,0,'null'),(902,'2025-01-20 10:20:52',0,0,0,131,0,'{}',0,0,0,0,'null'),(903,'2025-01-21 11:51:40',0,0,0,1048,0,'{}',0,0,0,0,'null'),(904,'2025-01-22 13:42:22',0,0,0,140,0,'{}',0,0,0,0,'null'),(905,'2025-01-23 10:20:55',0,0,0,226,0,'{}',0,0,0,0,'null'),(906,'2025-01-24 12:52:09',0,0,0,96,0,'{}',0,0,0,0,'null'),(907,'2025-01-25 10:07:39',0,0,0,84,0,'{}',0,0,0,0,'null'),(908,'2025-01-26 15:44:39',0,0,0,41,0,'{}',0,0,0,0,'null'),(909,'2025-01-27 14:02:03',0,0,0,44,0,'{}',0,0,0,0,'null'),(910,'2025-01-28 12:40:15',0,0,0,54,0,'{}',0,0,0,0,'null'),(911,'2025-01-29 13:41:40',0,0,0,57,0,'{}',0,0,0,0,'null'),(912,'2025-01-30 10:01:09',0,0,0,129,0,'{}',0,0,0,0,'null'),(913,'2025-01-31 10:04:00',0,0,0,541,0,'{}',0,0,0,0,'null'),(914,'2025-02-01 11:00:53',0,0,0,347,0,'{}',0,0,0,0,'null'),(915,'2025-02-02 10:08:14',0,0,0,344,0,'{}',0,0,0,0,'null'),(916,'2025-02-03 10:12:58',0,0,0,612,0,'{}',0,0,0,0,'null'),(917,'2025-02-04 11:36:14',0,0,0,362,0,'{}',0,0,0,0,'null'),(918,'2025-02-05 10:06:54',0,0,0,211,0,'{}',0,0,0,0,'null'),(919,'2025-02-06 10:04:13',0,0,0,625,0,'{}',0,0,0,0,'null'),(920,'2025-02-07 11:09:40',0,0,0,321,0,'{}',0,0,0,0,'null'),(921,'2025-02-08 10:13:22',0,0,0,230,0,'{}',0,0,0,0,'null'),(922,'2025-02-09 10:06:15',0,0,0,431,0,'{}',0,0,0,0,'null'),(923,'2025-02-10 10:01:09',0,0,0,165,0,'{}',0,0,0,0,'null'),(924,'2025-02-11 10:00:02',0,0,0,305,0,'{}',0,0,0,0,'null'),(925,'2025-02-12 12:08:06',0,0,0,215,0,'{}',0,0,0,0,'null'),(926,'2025-02-13 10:02:22',0,0,0,143,0,'{}',0,0,0,0,'null'),(927,'2025-02-14 10:17:18',0,0,0,394,0,'{}',0,0,0,0,'null'),(928,'2025-02-15 10:21:06',0,0,0,280,0,'{}',0,0,0,0,'null'),(929,'2025-02-16 10:00:30',0,0,0,1899,0,'{}',0,0,0,0,'null'),(930,'2025-02-17 10:01:11',0,0,0,1132,0,'{}',0,0,0,0,'null'),(931,'2025-02-18 12:11:04',0,0,0,3423,0,'{}',0,0,0,0,'null'),(932,'2025-02-19 11:45:21',0,0,0,81,0,'{}',0,0,0,0,'null'),(933,'2025-02-20 10:08:46',0,0,0,479,0,'{}',0,0,0,0,'null'),(934,'2025-02-21 10:25:12',0,0,0,267,0,'{}',0,0,0,0,'null'),(935,'2025-02-22 10:34:04',0,0,0,277,0,'{}',0,0,0,0,'null'),(936,'2025-02-23 10:10:16',0,0,0,121,0,'{}',0,0,0,0,'null'),(937,'2025-02-24 11:06:38',0,0,0,110,0,'{}',0,0,0,0,'null'),(938,'2025-02-25 10:38:17',0,0,0,56,0,'{}',0,0,0,0,'null'),(939,'2025-02-26 10:22:44',0,0,0,113,0,'{}',0,0,0,0,'null'),(940,'2025-02-27 10:01:46',0,0,0,373,0,'{}',0,0,0,0,'null'),(941,'2025-02-28 10:09:55',0,0,0,99,0,'{}',0,0,0,0,'null'),(942,'2025-03-01 10:02:27',0,0,0,437,0,'{}',0,0,0,0,'null'),(943,'2025-03-02 13:10:28',0,0,0,211,0,'{}',0,0,0,0,'null'),(944,'2025-03-03 10:17:05',0,0,0,59,0,'{}',0,0,0,0,'null'),(945,'2025-03-04 10:45:57',0,0,0,463,0,'{}',0,0,0,0,'null'),(946,'2025-03-05 10:25:23',0,0,0,265,0,'{}',0,0,0,0,'null'),(947,'2025-03-06 10:38:25',0,0,0,319,0,'{}',0,0,0,0,'null'),(948,'2025-03-07 10:02:13',0,0,0,204,0,'{}',0,0,0,0,'null'),(949,'2025-03-08 10:01:48',0,0,0,542,0,'{}',0,0,0,0,'null'),(950,'2025-03-09 10:00:52',0,0,0,135,0,'{}',0,0,0,0,'null'),(951,'2025-03-10 11:11:45',0,0,0,1951,0,'{}',0,0,0,0,'null'),(952,'2025-03-11 11:02:23',0,0,0,606,0,'{}',0,0,0,0,'null'),(953,'2025-03-12 10:25:08',0,0,0,834,0,'{}',0,0,0,0,'null'),(954,'2025-03-13 10:03:44',0,0,0,255,0,'{}',0,0,0,0,'null'),(955,'2025-03-14 10:33:41',0,0,0,630,0,'{}',0,0,0,0,'null'),(956,'2025-03-15 10:46:55',0,0,0,262,0,'{}',0,0,0,0,'null'),(957,'2025-03-16 10:23:42',0,0,0,557,0,'{}',0,0,0,0,'null'),(958,'2025-03-17 11:08:23',0,0,0,284,0,'{}',0,0,0,0,'null'),(959,'2025-03-18 11:54:42',0,0,0,594,0,'{}',0,0,0,0,'null'),(960,'2025-03-19 10:56:36',0,0,0,117,0,'{}',0,0,0,0,'null'),(961,'2025-03-20 10:39:36',0,0,0,179,0,'{}',0,0,0,0,'null'),(962,'2025-03-21 10:10:37',0,0,0,294,0,'{}',0,0,0,0,'null'),(963,'2025-03-22 10:22:35',0,0,0,673,0,'{}',0,0,0,0,'null'),(964,'2025-03-23 11:03:11',0,0,0,218,0,'{}',0,0,0,0,'null'),(965,'2025-03-24 10:08:13',0,0,0,377,0,'{}',0,0,0,0,'null'),(966,'2025-03-25 10:50:03',0,0,0,137,0,'{}',0,0,0,0,'null'),(967,'2025-03-26 10:16:15',0,0,0,168,0,'{}',0,0,0,0,'null'),(968,'2025-03-27 10:04:50',0,0,0,348,0,'{}',0,0,0,0,'null'),(969,'2025-03-28 10:43:16',0,0,0,354,0,'{}',0,0,0,0,'null'),(970,'2025-03-29 11:51:00',0,0,0,30,0,'{}',0,0,0,0,'null'),(971,'2025-03-30 10:58:17',0,0,0,54,0,'{}',0,0,0,0,'null'),(972,'2025-03-31 12:59:53',0,0,0,46,0,'{}',0,0,0,0,'null'),(973,'2025-04-01 12:47:01',0,0,0,38,0,'{}',0,0,0,0,'null'),(974,'2025-04-02 13:46:17',0,0,0,53,0,'{}',0,0,0,0,'null'),(975,'2025-04-06 10:56:17',0,0,0,1,0,'{}',0,0,0,0,'null'),(976,'2025-04-10 11:03:19',0,0,0,0,0,'{}',0,0,0,0,'null'),(977,'2025-04-12 10:01:16',0,0,0,0,0,'{}',0,0,0,0,'null'),(978,'2025-04-13 10:53:51',0,0,0,0,0,'{}',0,0,0,0,'null');
/*!40000 ALTER TABLE `tc_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_attribute`
--

DROP TABLE IF EXISTS `tc_user_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_attribute` (
  `userid` int(11) NOT NULL,
  `attributeid` int(11) NOT NULL,
  KEY `fk_user_attribute_attributeid` (`attributeid`),
  KEY `fk_user_attribute_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_attribute`
--

LOCK TABLES `tc_user_attribute` WRITE;
/*!40000 ALTER TABLE `tc_user_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_calendar`
--

DROP TABLE IF EXISTS `tc_user_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_calendar` (
  `userid` int(11) NOT NULL,
  `calendarid` int(11) NOT NULL,
  KEY `fk_user_calendar_calendarid` (`calendarid`),
  KEY `fk_user_calendar_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_calendar`
--

LOCK TABLES `tc_user_calendar` WRITE;
/*!40000 ALTER TABLE `tc_user_calendar` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_command`
--

DROP TABLE IF EXISTS `tc_user_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_command` (
  `userid` int(11) NOT NULL,
  `commandid` int(11) NOT NULL,
  KEY `fk_user_command_commandid` (`commandid`),
  KEY `fk_user_command_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_command`
--

LOCK TABLES `tc_user_command` WRITE;
/*!40000 ALTER TABLE `tc_user_command` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_device`
--

DROP TABLE IF EXISTS `tc_user_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_device` (
  `userid` int(11) NOT NULL,
  `deviceid` int(11) NOT NULL,
  KEY `fk_user_device_deviceid` (`deviceid`),
  KEY `user_device_user_id` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_device`
--

LOCK TABLES `tc_user_device` WRITE;
/*!40000 ALTER TABLE `tc_user_device` DISABLE KEYS */;
INSERT INTO `tc_user_device` VALUES (2,1),(3,2),(4,3),(5,4),(6,5),(7,6),(8,7),(9,8),(10,9),(11,10),(12,11),(13,12),(14,13),(15,14),(16,15),(17,16),(18,17),(19,18),(20,19),(21,20),(22,21),(23,22),(24,23),(25,24),(26,25),(27,26),(28,27),(29,28),(30,29),(31,30),(32,31),(33,32),(34,33),(35,34),(36,35),(37,36),(38,37),(39,38),(40,39),(41,40),(42,41),(43,42),(44,43),(45,44),(46,45),(47,46),(48,47),(49,48),(50,49),(51,50),(52,51),(53,52),(54,53),(55,54),(56,55),(57,56),(58,57),(59,58),(60,59),(61,60),(62,61),(64,62),(65,63),(66,64),(67,65),(68,66),(69,67),(70,68),(72,69),(73,70),(74,71),(75,72),(76,73),(77,74),(78,75),(79,76),(80,77),(81,78),(82,79),(83,80),(84,81),(85,82),(86,83),(87,84),(88,85),(89,86),(90,87),(91,88),(92,89),(93,90);
/*!40000 ALTER TABLE `tc_user_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_driver`
--

DROP TABLE IF EXISTS `tc_user_driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_driver` (
  `userid` int(11) NOT NULL,
  `driverid` int(11) NOT NULL,
  KEY `fk_user_driver_driverid` (`driverid`),
  KEY `fk_user_driver_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_driver`
--

LOCK TABLES `tc_user_driver` WRITE;
/*!40000 ALTER TABLE `tc_user_driver` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_geofence`
--

DROP TABLE IF EXISTS `tc_user_geofence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_geofence` (
  `userid` int(11) NOT NULL,
  `geofenceid` int(11) NOT NULL,
  KEY `fk_user_geofence_geofenceid` (`geofenceid`),
  KEY `fk_user_geofence_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_geofence`
--

LOCK TABLES `tc_user_geofence` WRITE;
/*!40000 ALTER TABLE `tc_user_geofence` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_geofence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_group`
--

DROP TABLE IF EXISTS `tc_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_group` (
  `userid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  KEY `fk_user_group_groupid` (`groupid`),
  KEY `fk_user_group_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_group`
--

LOCK TABLES `tc_user_group` WRITE;
/*!40000 ALTER TABLE `tc_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_maintenance`
--

DROP TABLE IF EXISTS `tc_user_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_maintenance` (
  `userid` int(11) NOT NULL,
  `maintenanceid` int(11) NOT NULL,
  KEY `fk_user_maintenance_maintenanceid` (`maintenanceid`),
  KEY `fk_user_maintenance_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_maintenance`
--

LOCK TABLES `tc_user_maintenance` WRITE;
/*!40000 ALTER TABLE `tc_user_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_notification`
--

DROP TABLE IF EXISTS `tc_user_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_notification` (
  `userid` int(11) NOT NULL,
  `notificationid` int(11) NOT NULL,
  KEY `fk_user_notification_notificationid` (`notificationid`),
  KEY `fk_user_notification_userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_notification`
--

LOCK TABLES `tc_user_notification` WRITE;
/*!40000 ALTER TABLE `tc_user_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_order`
--

DROP TABLE IF EXISTS `tc_user_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_order` (
  `userid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  KEY `fk_user_order_userid` (`userid`),
  KEY `fk_user_order_orderid` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_order`
--

LOCK TABLES `tc_user_order` WRITE;
/*!40000 ALTER TABLE `tc_user_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_user_user`
--

DROP TABLE IF EXISTS `tc_user_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_user_user` (
  `userid` int(11) NOT NULL,
  `manageduserid` int(11) NOT NULL,
  KEY `fk_user_user_userid` (`userid`),
  KEY `fk_user_user_manageduserid` (`manageduserid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_user_user`
--

LOCK TABLES `tc_user_user` WRITE;
/*!40000 ALTER TABLE `tc_user_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `tc_user_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tc_users`
--

DROP TABLE IF EXISTS `tc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `hashedpassword` varchar(128) DEFAULT NULL,
  `salt` varchar(128) DEFAULT NULL,
  `readonly` bit(1) NOT NULL DEFAULT b'0',
  `administrator` bit(1) DEFAULT NULL,
  `map` varchar(128) DEFAULT NULL,
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `zoom` int(11) NOT NULL DEFAULT '0',
  `twelvehourformat` bit(1) NOT NULL DEFAULT b'0',
  `attributes` varchar(4000) DEFAULT NULL,
  `coordinateformat` varchar(128) DEFAULT NULL,
  `disabled` bit(1) DEFAULT b'0',
  `expirationtime` timestamp NULL DEFAULT NULL,
  `devicelimit` int(11) DEFAULT '-1',
  `token` varchar(128) DEFAULT NULL,
  `userlimit` int(11) DEFAULT '0',
  `devicereadonly` bit(1) DEFAULT b'0',
  `phone` varchar(128) DEFAULT NULL,
  `limitcommands` bit(1) DEFAULT b'0',
  `login` varchar(128) DEFAULT NULL,
  `poilayer` varchar(512) DEFAULT NULL,
  `disablereports` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_login` (`login`),
  KEY `idx_users_token` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tc_users`
--

LOCK TABLES `tc_users` WRITE;
/*!40000 ALTER TABLE `tc_users` DISABLE KEYS */;
INSERT INTO `tc_users` VALUES (1,'admin','admin','D33DCA55ABD4CC5BC76F2BC0B4E603FE2C6F61F4C1EF2D47','000000000000000000000000000000000000000000000000',_binary '\0',_binary '',NULL,0,0,0,_binary '\0',NULL,NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(2,'Didit','a_didit_m@yahoo.com','aed7a3471c5dc73d290199e2b3edd0cfbc9be78e8448f311','12282ec9171dd73faa00e4643e0dc812d4d6d16a474d49a9',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(3,'221d4a8387f5f2e48a2c37c5076bebee','221d4a8387f5f2e48a2c37c5076bebee@example.org','4ad534e42958f132e51da42b4929be2fc7eeb51f4ac899cd','a032667a32ff01bb7a3e5e3a20505b3faa7fd37f93e4dd5f',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(4,'84ecb253cb6aea1e98a12dbd0d3bda1b','84ecb253cb6aea1e98a12dbd0d3bda1b@example.org','b129abb5cfdbfe5efd589a037a7940941a373aafa3d4ec8a','fc389cac9e2be0d6fceaa2f94d9a833748b0acfcd475d4b4',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(5,'58bba26d3b1d4402400e1a60d1200f33','58bba26d3b1d4402400e1a60d1200f33@example.org','f81c981cdbdaf74acef829e1e41933240e3c006764548231','357d2ff9194f74ac171e1f601fe814f1fb463a73775e0c94',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(6,'9ba40e58c43cf29ae3e5b16c2e259f0f','9ba40e58c43cf29ae3e5b16c2e259f0f@example.org','db81c5768b46990d3391940e084f35bef25043936fe30de8','58e5f5ffdb8b1a46926dd41acdf89fa2e1bf1d3dcc70df3a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(7,'433a0279281ada90bbdca487ff0a3840','433a0279281ada90bbdca487ff0a3840@example.org','bac1b7187b2aa7d7980ff626b9796cc3025be5f9a35ea55f','1cb28c1080479c5b836e3d1f074f8f4fef9241917d4d909d',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(8,'e45d2038e9648bb085661e520d58087b','e45d2038e9648bb085661e520d58087b@example.org','b16696b49828a37af84bcf6cc4e0dd9c3b312dc383ca374f','bd5ae3516e7d2ba4b923995d2e1124434d1d096ebfc877a0',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(9,'97713cff340283467adab7c7d8d4bd85','97713cff340283467adab7c7d8d4bd85@example.org','dce547bc5916cd7d577259f648946105b68acc6da2d73380','c8663c5a6673ae9e23014eeb6bde0950edfee6634329baef',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(10,'5540dd5b5aa5b356a0ab0064e98cdc2d','5540dd5b5aa5b356a0ab0064e98cdc2d@example.org','bff45684099d6963330c8ecef2d1cf2f3ffc0ac7d75e3d38','9794d0e080fa16e31072e1daa900081f2e90907d5170ed3d',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(11,'71351aef09a314e59a8990e50b84bde6','71351aef09a314e59a8990e50b84bde6@example.org','2c9b0b77513b1120fb1644f61b875f83e9fa1bac4aea37b5','c0b9b0398a0ec8ffe224adcc78084621e99dfa5fcaf969a5',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(12,'4b7083a31ee5c6197445d7b26dba2d11','4b7083a31ee5c6197445d7b26dba2d11@example.org','3376bc8227ab03302edbb80431f38febdd598ce2a963aa16','9e156ea88c830022225d8fc5ccaef5ff76a3373ef3cfb55b',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(13,'2755caab2a2b5552a31bd3f03f333065','2755caab2a2b5552a31bd3f03f333065@example.org','2bc93a908701c494c9d73759d450b8a16ae3b8d14a12bd1a','feb84c5d79eca82e812f56b60357db4e714180de5026cefe',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(14,'bc4d8bfd3834349ff42b1c3a238feeae','bc4d8bfd3834349ff42b1c3a238feeae@example.org','43f0a1122eff17482e7fe78b2e7d4adc9216506ee7d44408','4fcbf17e7d27868bc7c1ac4fa7f989486aff593836cb13fc',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(15,'7604f8e5788be2f0f2898135e799a96f','7604f8e5788be2f0f2898135e799a96f@example.org','b497d8309fb40fe7e2ecbfb740130b76f6216d0668ecc0c0','4347e3d697edc8d0907a7e16bdc227f66b2a865607e59802',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(16,'fa7711ab9ac36d1d5adf404e3a724419','fa7711ab9ac36d1d5adf404e3a724419@example.org','365b95e541f8943b45d62757d2e8fd38632834e2028f55e8','bc2aefa3fe09f836b958cd8dea122af5a8fff3931d8ff515',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(17,'e4598d3045b507e6b5e825bc3cfa7d2b','e4598d3045b507e6b5e825bc3cfa7d2b@example.org','e2c5b6c4dfd69dd968066a1025df775ffffca3ed6d5fd836','b6917d24b3c56184ce86cccaa42727f4df02d50eb5843c07',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(18,'26a9da0f193d91ecbb5ee834b75a7c2f','26a9da0f193d91ecbb5ee834b75a7c2f@example.org','562651d7307a804eb4c61412e1d0e1040f57b377e42b9cee','516ad8be969b0d374aa5a4215a044aec8283508af1ae0e44',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(19,'267beba4edd0ade829e0e01faec4e49d','267beba4edd0ade829e0e01faec4e49d@example.org','c350fc8556ccc97321059d5d08ff288c71601351b24f5526','18097f311f98af73ce19577dd2e059c8e2faf3a27397fdfd',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(20,'ae1e04afccbb1fa2581257d8b679d218','ae1e04afccbb1fa2581257d8b679d218@example.org','2c8f597c1d4b51e107a062e9f5baacd31b3efdb0873b688b','191044bf41aa156eb90e7e150f6134ce8e10793a0f125442',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(21,'8cc2c89df6bf1145dea46ad8084eaf88','8cc2c89df6bf1145dea46ad8084eaf88@example.org','cd12b634ceebc4797f89d8f4c12f680d37b4ed438fd7b949','65292b83c2fdb48a3b14b6441e1e57c361ec0e00de6620b7',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(22,'b4229a18825dfa1046b7697b57cbe75d','b4229a18825dfa1046b7697b57cbe75d@example.org','3689dfd72eafe1082aa35091f401caa229b57ee5676dda60','3223c642cc5afb61ee27b05bb970d8fde2a2674732a02c1e',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(23,'ab3769e5cc78352600a78cb1ed30c0d9','ab3769e5cc78352600a78cb1ed30c0d9@example.org','fa3368c1ad5f09b08b3749373dc84f4474e9ddcab0935a02','9c18a78ed0938ac9f42012bf8f33d4954df73c761420bd18',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(24,'e195fdae5c69aa489de401a6a62c3db3','e195fdae5c69aa489de401a6a62c3db3@example.org','9fce1ed1501601819601e1154e69a60a0834e223b5baa762','6001008b9b572d4192595582c8ef8ca48fe32ef3464f178b',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(25,'835b58420d6cdad8fbd8337864ac269b','835b58420d6cdad8fbd8337864ac269b@example.org','87a5a9093a6f2d1c81858a42d0cdf78fa9d34ad83b374e51','ec9e1eb86504d08324401009c50f26a11b745b6193a5e63d',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(26,'85ae95addb28ce6deb9529a00a14b430','85ae95addb28ce6deb9529a00a14b430@example.org','9ff452734e1fd5f0ff66dacf342bebd8801c20bab5fb8a4e','eec6a66d697ff283724eed2e460532125e0dc1654195ccfa',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(27,'88e3d1888d2cdce604afb053d905f616','88e3d1888d2cdce604afb053d905f616@example.org','d0874c6ab068a290a60473635a3bcc3d8bb067ce0aa08233','febfd9205d6e27d17da2349183592280cc92dc66deef66c8',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(28,'009b8c91b3496e8446364efd8aef60ed','009b8c91b3496e8446364efd8aef60ed@example.org','cc5d20421c6b92d52087b5e4631dfaf589a3bea4204427a0','ddd30125b433fa0910d18e1e5f4d67de87173d47f5b48d9a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(29,'eb4cc5f6a2a372a53d9ee5702b8f0837','eb4cc5f6a2a372a53d9ee5702b8f0837@example.org','f4a0ebc6645e7feee5175a22e165bde6eddca6f66ab6cc00','cf610be34b48219b9015b151cb5fa13e1306f0b707c36038',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(30,'46d29c66e5b4ae81b3dc506a2f24e9e4','46d29c66e5b4ae81b3dc506a2f24e9e4@example.org','c39f595fb8c75a2977d17400531531092e8a6b3c1e1b6c31','235a188da3267e87a183df126c727204d7a8058d20f96256',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(31,'33d0b3a28fda4572b099f1342ff163c4','33d0b3a28fda4572b099f1342ff163c4@example.org','ae8881fa62ce9efe2e112ff03046beca7d57c351a6c1e2cc','059371cc10d331ce72c6f9a5534c6c29a093deeab8892c9a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(32,'57002569d9fc6338402ccaa62cf578ee','57002569d9fc6338402ccaa62cf578ee@example.org','9f50355ec48e5431d58fa5b76dfb04cd911a5fbbcccb715e','3a20d9f44fb572844ab04b73b7904860bb4587806cae7772',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(33,'61ac8aabb12ecc89a368079fee0c4461','61ac8aabb12ecc89a368079fee0c4461@example.org','48918ace4faf7f33457caf65ad9835bcf45fbaf75af0349a','a6a7c3037d1c8141f9b1461d5154171763d95c6f5d905e22',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(34,'a43e669df0dcbff590f6cd469ccbdadd','a43e669df0dcbff590f6cd469ccbdadd@example.org','546c7e9a66b2fd1f1a1031569b6b8e2d55e29ae495bf8f0d','d8850a3595d78401f274453ab9dbe92518658594eaeb5bfe',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(35,'9780368addc39f218790577644c214a2','9780368addc39f218790577644c214a2@example.org','8e229b9cd8d6a7e9cf9a0cee2ae42c9521a057a018028c60','239f1aabff66aefab64521323e3603a8f1bd5d44609fc137',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(36,'02dfff9d7963e9f1dc1a52405ad8b750','02dfff9d7963e9f1dc1a52405ad8b750@example.org','544ca1b35514402894ab211cae8b226d20245f38e4c9a3fc','89d83396430bc5aeab8409f316e21990e926969b20bc6588',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(37,'775dc6c7f2a55e49d52f2c0d159ff7eb','775dc6c7f2a55e49d52f2c0d159ff7eb@example.org','a44ff7593889647319ae75960691b8ec884ba7223a11c9af','8470eaf40c09e256566646cb65259457b84e14f95915ab19',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(38,'ba30504c7efc866353ea6517df0c919e','ba30504c7efc866353ea6517df0c919e@example.org','769a9f48e3ffda3369f46a8d50476fc63d4033e94deb301d','9bae182be01c50ef8d843159db2949722520c89ba0b5a978',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(39,'e7c054b6286a9ac8f99f0ea946412474','e7c054b6286a9ac8f99f0ea946412474@example.org','5f064cda05ca5a29cb751dfc886ce45b78ba049dc33a2426','efa074cfd2dbe7b00c8d1eb06fb9af2cab45eeb636ead5dd',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(40,'00f78d8290c1d244a625beb18d370940','00f78d8290c1d244a625beb18d370940@example.org','f9d8ae0f0a05c33c9775d4585c68332784e612be96289c02','d08180e7c5b3c4483157b542ff736f24e5f131b414f8408a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(41,'f8aec18332cf806efddc2c5c0ddd6bec','f8aec18332cf806efddc2c5c0ddd6bec@example.org','42cc05e73a5a9e4228907494ff07be0b3aa2ada6c8d47ffb','fca33c3a72791ce1efbc34501753b8616a947c2effb27155',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(42,'7d03610b1fe192f207cc69f3ec80d801','7d03610b1fe192f207cc69f3ec80d801@example.org','236f8661580e3c497a7bdd6d8217c91e55e4149f1c923958','ea7310696acddc59b7fc562fbea72a830930b2c610f9158e',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(43,'2b47ff4051c4fb108573ed3ba511534a','2b47ff4051c4fb108573ed3ba511534a@example.org','cd2ea86f2b29d49c81bff96f0123f4d4dfd320e0d2d68320','a1ff2a0dfd1481be151665023b8877f170ad86284d91ee98',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(44,'b407273e40afce55e780a9b2bbd03060','b407273e40afce55e780a9b2bbd03060@example.org','05c9163b5fa9e70a0958d159b421b4f0ff3254b8b7b44131','1fbeaa59b2fe6987fd0d802d8b50c3e1ef9b409c749e7425',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(45,'dad29750de9d75895a1cf57cbaea57ab','dad29750de9d75895a1cf57cbaea57ab@example.org','d8ff1b602f906a8149130232e331eaebc4d0e03a4aec6010','bf99b4959db8611dfb9e8f899a25a30482f70f7c585d9d3b',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(46,'60206af0a558b412a375cdf9649636b5','60206af0a558b412a375cdf9649636b5@example.org','e93a53ed91759ea84ab257358e386ed37f61df4d5d513705','f9c3710fb682c1e7604a08e280b2dd1b4ceb957f91d909b2',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(47,'2cabec78148fe9d95288aa582c55801e','2cabec78148fe9d95288aa582c55801e@example.org','a60382b63340508de17528d935345004bda28dbd37cc37f3','57473ebf2107c46086d8f708be7e172f5e9c30f1a7324785',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(48,'673c961898666b8cfb453051e81c4384','673c961898666b8cfb453051e81c4384@example.org','33256f958af77fba3aa8539ae3edda6e1b1a578001285162','355677a36030ac45d9b71f6c214ad6e2ff138d4103e3b0c8',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(49,'d7251a8edf82efe1ba285802a0e6c2fa','d7251a8edf82efe1ba285802a0e6c2fa@example.org','3e6179d787388280964909058c46cff9c83575ceff9ef42c','6daf16efea8e62f9ada75ab07699ef028133faa394c1e894',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(50,'674bb89671350ba6972494e67731cc43','674bb89671350ba6972494e67731cc43@example.org','a529c342f744a20bd26f66e8e8d1ee137cd4dfdb91fb0c42','e20479b4f69f593810ee2c8e7bbb7cc3a0428da4e47fe415',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(51,'879e835af38b55a988efecee8fa7b71b','879e835af38b55a988efecee8fa7b71b@example.org','6757cfa6a1b21d471f21749ae95e5d70a13d24c6ac9598fb','5de11e49b83f3e44236f834ae50af18b2dd68c728f7ea76a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(52,'df0ce84d294f86e4854b4de750c5e200','df0ce84d294f86e4854b4de750c5e200@example.org','0ee0f5b7413bd2b226447c102b24be2232d1a0b0a74f8ae7','b9ba9931a5262fff316a5b9d84d02d95c54ae3297dd3730a',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(53,'546ad50575de1fd756f5184e5d683a23','546ad50575de1fd756f5184e5d683a23@example.org','6f0deca47fce5e55e86cdcea7da2e4a9fe7f81bb701248c6','26a48dabd6144075e2af49d66ab84321a063114039a2a0b5',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(54,'2432c0b6c05eddaae7a5e8c9d816144d','2432c0b6c05eddaae7a5e8c9d816144d@example.org','6e2d88c3e971c347a3ae53103b7e33f6a8e2d27366ea2dfb','b116a1c210e5706e8dd5564492631c95671d99800ba985dd',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(55,'41576ca5dee1954146a2c1c74e6a210c','41576ca5dee1954146a2c1c74e6a210c@example.org','b8e90916911028184d900e5809427d11842ad8a58f55f30c','9a8bc0a2b3d56fdf899f04b10d73bd5ec263293af2981e55',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(56,'12fe901ef1cd1251f992be7482caa4bc','12fe901ef1cd1251f992be7482caa4bc@example.org','595a7b5c02f1e7cf35d6950a503a97fea7d33e6fc9b3a09b','985829dd55b202f0ee24cc43ad37174cffca8d3f584365df',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(57,'bf36f8ca376fd025871afa2a45670d5b','bf36f8ca376fd025871afa2a45670d5b@example.org','c1cd352cf77d8beda933c556d906f6d52b96230dac6478db','f42d542fcab5df4d462fa3629c990b5e5be06606dd96e065',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(58,'30eb37025697c227edf0ed48805b9a01','30eb37025697c227edf0ed48805b9a01@example.org','728f07ec3ebfeb373ecfeba368bad919f97c9416fc7844fd','f4df82eeed8388477c8966b4a42ee6b6205b3b55927b0604',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(59,'3ae8297f6048b0a9c91f619bce2bf6b6','3ae8297f6048b0a9c91f619bce2bf6b6@example.org','db84674623eb7f906e906a499969de9790ec5abe2e4b6f55','57d9fcad660c50dd4a984d16222edc51e514196b36b6c6ed',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(60,'5e94f61e16f213ac4c59eb0e089a9573','5e94f61e16f213ac4c59eb0e089a9573@example.org','192cee6cf8283c17d2196b125c309457fd14e1846288cdb7','7d39217ab405b111621015e274cbe2222d7b9c366d27b436',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(61,'2a52ec167e987c84bb0dadc4c26582ca','2a52ec167e987c84bb0dadc4c26582ca@example.org','c26e60352bc04c644d3c60fd5286c946cd6513d6780fb78a','81dd64ad16c603f7ed19c3374beb7ce01cb782211ab8072c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(62,'25e765393a2472c8d6268ca98a8d1204','25e765393a2472c8d6268ca98a8d1204@example.org','23a49970e7e67c23dc66575c6f5ea210d83101115fab7f73','af8b62f9f7282aec2ed8fa901c367d23d341f97fd373b4ea',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(63,'c6dda5292f067fe6673fbd68d1f12db1','c6dda5292f067fe6673fbd68d1f12db1@example.org','e980ac27400ae999e876156c443c04d695c191fea9069f73','66ba8170aa0b228e77faff2053d59f66df033c18d6a4c68c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(64,'1cc46420f06ade8a843e4251b70b0a5c','1cc46420f06ade8a843e4251b70b0a5c@example.org','fb99126adb2c224f070ab43de4779441cc094327d88ec5fc','39501c76897a1577719ad7ea562b5077f9d87242f61d29c3',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(65,'d41165a2658762b1074965ee19b00698','d41165a2658762b1074965ee19b00698@example.org','76b7d4d68a60277f569c9f67c55108895d7f7b63d3f2d987','648baff6b9c8efabf85de083e73e53dd741da5186f5803d8',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(66,'7391e1154ca16fd17d92f759c7988426','7391e1154ca16fd17d92f759c7988426@example.org','db9dfd213806f5ff507b3b132ec2a52acd32c951ae58da8f','40436e85063e505ee2e4bbf09af72c325041cf1edb704b56',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(67,'0bbcd9c88ceea95741ec6a42c613e3ff','0bbcd9c88ceea95741ec6a42c613e3ff@example.org','c953b0cbfee51e896d9dad0c4c600a1daefdecf134828c46','4e2a6211c30a82f777ccf067fe4232c5e4caf16d6254c67f',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(68,'8ed678b7f071b53a4106b8927f021250','8ed678b7f071b53a4106b8927f021250@example.org','366519be9915acc5e650402d106fa2671229d384240290a6','8f54cf99f1cb87c3779a1e169093f840aa5dced0cca55e36',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(69,'a27c8ddb6e5b8f9e367c449f166a5dad','a27c8ddb6e5b8f9e367c449f166a5dad@example.org','8afd789095b742485016ebb107db731b9acf0f98842a219f','9e9b5a081189bb50fcabdce8bc43e0c89e5a9ae88cc99811',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(70,'306bb32f2d72d67f10cf2b3e08b8c1f4','306bb32f2d72d67f10cf2b3e08b8c1f4@example.org','d0cf074f5e7471cabd68dc1e9b99e16d6bba1aa132433d6e','60ab49b6531bc1f607cc7d14a6ec99cadf966b439eb73203',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(71,'501809fc8e113e24e4d1734429543b98','501809fc8e113e24e4d1734429543b98@example.org','fcbcc474517d5fec4169502f23b8e6d8a4dffb42b43fd531','a8f11a41156970c9b63b09df5cd59b8d74a92bf3b79d652c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(72,'bd8f63e0e2e54b973df620aa33b65dbe','bd8f63e0e2e54b973df620aa33b65dbe@example.org','aa4c5a11a30926f87a43e2446b4c5dc9f74b42048dc5282d','f8d9fc7d45fa7c1271c65ebe2eb86ba98ec850ceff147606',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(73,'f5cc8c289c90fa39aedd9055864e6868','f5cc8c289c90fa39aedd9055864e6868@example.org','d39ab6b1cab7642177a5522409e1a4acb9a994510c883e2a','76f164b181555c29e7afa4ebc289f7a04054acf01d6f681c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(74,'06cbe665c6cff48fe0c1ed7e51270b3a','06cbe665c6cff48fe0c1ed7e51270b3a@example.org','a66e619a4ac1196119bd180ef48bf96fb4c44e1f876aa670','1e3cb0c793a30a6c37236dd05de05b90bcee89c4e7ca710c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(75,'677c3a06a966558d21c04e3dff1be40f','677c3a06a966558d21c04e3dff1be40f@example.org','153ed6fded4d700f4df646802e1b11710fff3eaf921f3042','4a1d0be50c768d1b9ed16b94628c82b8d888985282a739b4',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(76,'63770a5059e714b6473850f0533b5afb','63770a5059e714b6473850f0533b5afb@example.org','0cb92908338a362e26356c1e03d8c838f1bee84c299b7adc','a27c4cc0b1aa31092d4b1f745323e87f76907f95a32cb7a0',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(77,'a32a8dfe9bd3a32d61409d0ef5bddca8','a32a8dfe9bd3a32d61409d0ef5bddca8@example.org','efccfc43f531d9a717a64e0f05dc2d5c0a3065e0721c9762','f9b84741c1e4f8a63173d167dc36d41fed9cd5edc6006b9f',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(78,'45ec9c2c77e0e1dc236bf8e47fc0c1c5','45ec9c2c77e0e1dc236bf8e47fc0c1c5@example.org','23326f489d2e6c37612cb3fd880513ea2d247cbb383f1800','965766611503dce3fb18222b2ffaeaa308da8e3a94d15626',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(79,'b76e284049d8036d4e23cf047063382b','b76e284049d8036d4e23cf047063382b@example.org','b3cdcfea1ec64b36343ecb4b553f7a9e9786fee4b69518d3','c89752cbcb70f3932bb9ab87828438175fe6cc4c736b85b5',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(80,'921d5379d4347bf9096c530c85403ae6','921d5379d4347bf9096c530c85403ae6@example.org','c3428ee5bb8b7bc84b41f2538ee0c2c0a2e89761b978024e','23b372e66a432411b68a86f229bd688c3acb11a2ff952e51',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(81,'38629e3c0d98aebdb5ce5f160baa2811','38629e3c0d98aebdb5ce5f160baa2811@example.org','4422023bd275a1bc1e58c414bff366fb5a401feba6bdc3e3','e5c0622b1f638ac324351fe716af9eed98aec7b6f575d243',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(82,'f1c9e639c43609803e214386e5e19aa6','f1c9e639c43609803e214386e5e19aa6@example.org','95c7f0d00f08a46af144d8de12b795321906f3bc2ba2dd1d','79016130786e883c1c487fcce6eb760483ecf6bcad31f81c',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(83,'oukkSuPt','oukkSuPt@dqAWCOZUHG.com','6bc193ee67772eb80104d4a18ae157b35ca5bd6e85285837','5a7053c9866b9034cd1a4ca239cb82a440d9ce7722eb6a09',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(84,'qpggrxgt','qpggrxgt@iaknujl.com','f84fd4f8c4d7ec84b6d7d405f4c1b0afd8de1d82d816821b','b5996f28a983b464856503854f3e2ca452d059d3b5495e21',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(85,'iwbyjqnw','iwbyjqnw@qiowzqj.com','0ad5b213483267cef1de9948145667c1010a44added16484','b6ff1109084d4ebe2b12b227ac87f227af5ec0b709e8e442',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(86,'reziacxb','reziacxb@afjwf.com','6b31e8745e770691f8212a536314c0b22e61e9aa1a806586','af12853de38a2a82b2cff55b6035da17c00b17ef1d5a1e65',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(87,'lcystruk','lcystruk@zaspgrgkf.com','9780abc56eaf125a00cdbda7858f683370e4d0dab05c266a','27173c12a8c294639d045286b65db634c96b35bfef9c15de',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(88,'zilxfqux','zilxfqux@fhzfkntufg.com','59dfe8859f9c334dd8fda9d6250f372d9b843b6a89def98a','792618e0b778fed489a5a0b83133254ee99d547f47db1b15',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(89,'naclrbel','naclrbel@pelrxreq.com','3ce1ee43f34835c78edf256a75bf9dc2f085900c6ab95dec','c25a18849743a452776857c998fb2ce7d9985fbedebbf61e',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(90,'yypvgefi','yypvgefi@kphyrg.com','6005a6d6f30838e9bdbd2497d28c81b940bea37060fa106c','dbdc0ec9001fd64585f2e61656d80cb056aa25630a9ed0c4',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(91,'mclfmncb','mclfmncb@nhmqdywgq.com','c5d6b6ec025990eed5111c81b0b1036527c500d488533528','41d888491404ee49777c91c28a43d6b8bfdf5606cfdab9ce',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(92,'pwqucrob','pwqucrob@dldofjcuj.com','3b2006bbf594698775e5cf37f7887b635787feea6e49cd89','1748945f369204253fa49a184bd21a43e362f2b7307f5d31',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0'),(93,'yjeymlom','yjeymlom@cmnylnhl.com','7a92bfe74198a4ab55f0ac744eca1767509e099a9100777e','74b03f38819a32db50d610389e0381f17d1a3d1d51cc884b',_binary '\0',_binary '\0',NULL,0,0,0,_binary '\0','{}',NULL,_binary '\0',NULL,-1,NULL,0,_binary '\0',NULL,_binary '\0',NULL,NULL,_binary '\0');
/*!40000 ALTER TABLE `tc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mdmtechno_traccar'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-07  5:47:32
