<?
  session_start();
   include_once("../server/config.php");
   include_once("../classes/memberclass.php");
   include_once(CLASS_DIR."dateclass.php");
   include_once("../classes/networkclass.php");
   include_once(CLASS_DIR."ifaceclass.php");
   include_once("../classes/ruleconfigclass.php");
   include_once(CLASS_DIR."komisiclass.php");
   include_once(CLASS_DIR."jualclass.php");
   include_once(CLASS_DIR."systemclass.php");
   include_once(CLASS_DIR."productclass.php");
   include_once(CLASS_DIR."texttoimageclass.php");
   include_once("../classes/mobdetectclass.php");
    if ($_SESSION['LoginUser']=='') { 	
      header("Location: ../main/logout.php");
	}
   
   $vIdSys = $_GET['id'];
   $vSQL = "select * from tb_print_invkui where fidsys = '$vIdSys' ";
   $db->query($vSQL);
   $db->next_record();
   $vJamaah = $db->f('fidmember');
   $vNoKui = $db->f('fnoinvkui');
   $vPayFor = $db->f('fpayfor');
   $vNominal=   $db->f('fnominal');
   
   $vAngs = $_GET['no'];
   
   $vSQL = "select * from m_anggota where fidmember = '$vJamaah' ";
   $db->query($vSQL);
   $db->next_record();
   $vName = $oMember->getMemberName($vJamaah);
   
  // echo "sssss ".$vAngsuran;
   
function Terbilang ($angka) {
        $angka = (float)$angka;
        $bilangan = array('','Satu','Dua','Tiga','Empat','Lima','Enam','Tujuh','Delapan','Sembilan','Sepuluh','Sebelas');
        if ($angka < 12) {
            return $bilangan[$angka];
        } else if ($angka < 20) {
            return $bilangan[$angka - 10] . ' Belas';
        } else if ($angka < 100) {
            $hasil_bagi = (int)($angka / 10);
            $hasil_mod = $angka % 10;
            return trim(sprintf('%s Puluh %s', $bilangan[$hasil_bagi], $bilangan[$hasil_mod]));
        } else if ($angka < 200) { return sprintf('Seratus %s', Terbilang($angka - 100));
        } else if ($angka < 1000) { $hasil_bagi = (int)($angka / 100); $hasil_mod = $angka % 100; return trim(sprintf('%s Ratus %s', $bilangan[$hasil_bagi], Terbilang($hasil_mod)));
        } else if ($angka < 2000) { return trim(sprintf('Seribu %s', Terbilang($angka - 1000)));
        } else if ($angka < 1000000) { $hasil_bagi = (int)($angka / 1000); $hasil_mod = $angka % 1000; return sprintf('%s Ribu %s', Terbilang($hasil_bagi), Terbilang($hasil_mod));
        } else if ($angka < 1000000000) { $hasil_bagi = (int)($angka / 1000000); $hasil_mod = $angka % 1000000; return trim(sprintf('%s Juta %s', Terbilang($hasil_bagi), Terbilang($hasil_mod)));
        } else if ($angka < 1000000000000) { $hasil_bagi = (int)($angka / 1000000000); $hasil_mod = fmod($angka, 1000000000); return trim(sprintf('%s Milyar %s', Terbilang($hasil_bagi), Terbilang($hasil_mod)));
        } else if ($angka < 1000000000000000) { $hasil_bagi = $angka / 1000000000000; $hasil_mod = fmod($angka, 1000000000000); return trim(sprintf('%s Triliun %s', Terbilang($hasil_bagi), Terbilang($hasil_mod)));
        } else {
            return 'Data Salah';
        }
}


?>

<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 12">
<!--<link id=Main-File rel=Main-File href="kuitansi.php">-->
<link rel=File-List href=kuitansi_files/filelist.xml>
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
x\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]-->
<link rel=Stylesheet href=kuitansi_files/stylesheet.css>
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->

    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:.75in .7in .75in .7in;
	mso-header-margin:.3in;
	mso-footer-margin:.3in;}
-->
.bgimage {
     background-image:url(../images/logobg.jpg);
	 background-repeat:no-repeat;	
	 background-position:center;
	
}
 .bgkui {
      background:url(../images/bgkui.jpg);
	  background-repeat:no-repeat;
	   background-position: center; 
	   background-opacity:0.3;
 }
</style>
<script src="../vendors/jquery/dist/jquery.min.js"></script>
<![if !supportTabStrip]><script language="JavaScript">
<!--
function fnUpdateTabs()
 {
  if (parent.window.g_iIEVer>=4) {
   if (parent.document.readyState=="complete"
    && parent.frames['frTabs'].document.readyState=="complete")
   parent.fnSetActiveSheet(0);
  else
   window.setTimeout("fnUpdateTabs();",150);
 }
}

//-->

function printKui(){

								document.getElementById('divPrint').style.display='none';
								window.print();
								document.getElementById('divPrint').style.display='';	
}

$(document).ready(function(){
   

});


function pad (str, max) {
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}

</script>
<![endif]>
<title>Kuitansi</title>




</head>

<body link=blue vlink=purple>
<div >
<table   border=0 cellpadding=0 cellspacing=0 width=1100 class="bgkui" style='border-collapse:
 collapse;table-layout:fixed;width:825pt; >
 <col width=72 span=5 style='width:54pt'>
 <col width=92 style='mso-width-source:userset;mso-width-alt:2944;width:69pt'>
 <col width=72 span=9 style='width:54pt'>
 <tr height=20 style='height:15.0pt'>
   <td height="20" align=left valign=top><!--[if gte vml 1]><v:shapetype id="_x0000_t75"
   coordsize="21600,21600" o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe"
   filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_1" o:spid="_x0000_s1031" type="#_x0000_t75"
   style='position:absolute;direction:LTR;text-align:left;margin-left:9pt;
   margin-top:3pt;width:48.75pt;height:53.25pt;z-index:1;visibility:visible'
   o:gfxdata="UEsDBBQABgAIAAAAIQBamK3CDAEAABgCAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbJSRwU7DMAyG
70i8Q5QralM4IITW7kDhCBMaDxAlbhvROFGcle3tSdZNgokh7Rjb3+8vyWK5tSObIJBxWPPbsuIM
UDltsK/5x/qleOCMokQtR4dQ8x0QXzbXV4v1zgOxRCPVfIjRPwpBagArqXQeMHU6F6yM6Rh64aX6
lD2Iu6q6F8phBIxFzBm8WbTQyc0Y2fM2lWcTjz1nT/NcXlVzYzOf6+JPIsBIJ4j0fjRKxnQ3MaE+
8SoOTmUi9zM0GE83SfzMhtz57fRzwYF7S48ZjAa2kiG+SpvMhQ4kvFFxEyBNlf/nZFFLhes6o6Bs
A61m8ih2boF2XxhgujS9Tdg7TMd0sf/X5hsAAP//AwBQSwMEFAAGAAgAAAAhAAjDGKTUAAAAkwEA
AAsAAABfcmVscy8ucmVsc6SQwWrDMAyG74O+g9F9cdrDGKNOb4NeSwu7GltJzGLLSG7avv1M2WAZ
ve2oX+j7xL/dXeOkZmQJlAysmxYUJkc+pMHA6fj+/ApKik3eTpTQwA0Fdt3qaXvAyZZ6JGPIoiol
iYGxlPymtbgRo5WGMqa66YmjLXXkQWfrPu2AetO2L5p/M6BbMNXeG+C934A63nI1/2HH4JiE+tI4
ipr6PrhHVO3pkg44V4rlAYsBz3IPGeemPgf6sXf9T28OrpwZP6phof7Oq/nHrhdVdl8AAAD//wMA
UEsDBBQABgAIAAAAIQAzjgjo/QEAAOQEAAASAAAAZHJzL3BpY3R1cmV4bWwueG1srFRdj5swEHyv
1P9g+b1HQiAfKHCKLrqq0qmNqvYH7JklWAUb2b4k9++7xkCUPlVNeTIe78x6ZmH7eGkbdkJjpVY5
nz/MOEMldCnVMec/fzx/WnNmHagSGq0w5+9o+WPx8cP2UpoMlKi1YUShbEYbOa+d67IosqLGFuyD
7lARWmnTgqNXc4xKA2cib5sons2Wke0MQmlrRLcPCC96bnfWT9g0uyCBpXQ7m3Pqwe8OZyqj23Ba
6KaIt5Fvyi97Blp8q6piHi/WcTphfquHjT6PJX457nk8WS3HCoL6ip76quf0pFEsJu5pL5CkyWaC
bmSHbv6U3aTz5SpU3MiOYp0UQUGdDlIczCD39XQwTJY5jzlT0FJIhLo3g2zOo+uZUAEZsbxo8csO
scE/hNaCVKSln2pQR9zZDoWj4fFqIQJqKcj1rzftvjaye5YNZQSZX9/dRpi+v5o9XVVS4F6LtxaV
CwNosAFHw29r2VnOTIbtK5KZ5kvZXwgy6ww6Ud/bqL9wRRf/TmZ5oybiwbSrMX6KbefzhexSmfZ/
KNPV2YUySjZpEqecvec8Wazn6cyHBhleHBOEL2ebNE44E4Qv/bPqQw19+IOdse4z6rt7Yp6IXCYz
6GOGDE4vdrBllBh8CU70g0SjO8xzIynAPTgYR+7mdzFUht9T8RsAAP//AwBQSwMEFAAGAAgAAAAh
AKomDr68AAAAIQEAAB0AAABkcnMvX3JlbHMvcGljdHVyZXhtbC54bWwucmVsc4SPQWrDMBBF94Xc
Qcw+lp1FKMWyN6HgbUgOMEhjWcQaCUkt9e0jyCaBQJfzP/89ph///Cp+KWUXWEHXtCCIdTCOrYLr
5Xv/CSIXZINrYFKwUYZx2H30Z1qx1FFeXMyiUjgrWEqJX1JmvZDH3IRIXJs5JI+lnsnKiPqGluSh
bY8yPTNgeGGKyShIk+lAXLZYzf+zwzw7TaegfzxxeaOQzld3BWKyVBR4Mg4fYddEtiCHXr48NtwB
AAD//wMAUEsDBBQABgAIAAAAIQBinFctFQEAAIYBAAAPAAAAZHJzL2Rvd25yZXYueG1sVFDLTsMw
ELwj8Q/WInGjTtKmtKFOVUUq4oAQbRFnJ3EeIrYr2zQpX88mpYo4WTM7M57d1bqTDTkJY2utGPgT
D4hQmc5rVTL4OGwfFkCs4yrnjVaCwVlYWMe3Nyse5bpVO3Hau5JgiLIRZ1A5d4wotVklJLcTfRQK
Z4U2kjuEpqS54S2Gy4YGnjenktcKf6j4USSVyL7235JBnb4etsuUp+/Kf9ZJvT/v5p8JY/d33eYJ
iBOdG8V/7pecQQD9KrgGxNivazYqq7QhxU7Y+gfLX/jCaEmMbgd9ppvhRfxWFFY4BtOF7+EZcHJl
fH82RYr2qU5fvOGgQDX0+KpchkH43zt7nAdhb6VjowGM54t/AQAA//8DAFBLAwQKAAAAAAAAACEA
6VPAEWERAABhEQAAFAAAAGRycy9tZWRpYS9pbWFnZTEucG5niVBORw0KGgoAAAANSUhEUgAAAEAA
AABGCAYAAAB8MJLDAAAACXBIWXMAAA7EAAAOxAGVKw4bAAARE0lEQVR4nO2aeXAc1Z3HP6+7p6fn
kjQ6bZ2WfMiXbGNjY+STG2IHHEIIhzEkZIEqyGaX1O5mN5WE3a1K7SbLFrvZZBNMQkglwcYYMIdJ
wIuxjQ/kS/Ihy7Yk67B1XzPSHN0z3W//0MZgZGM5kRBZ/K2av+bNe9/36V+/329+3UJKKfkMSxlr
A2OtywDG2sBY6zKAsTYw1roMYKwNjLUuAxhrA2OtzzwA7ZNYxHIS9MYjVLbX8l5bFUdCDfTEwwjh
AkXFSCYQwiHkVhBSRU8k0BwX35hzByuKFyAQo+ZtVAEMJOLsPVPN7tP72XmmmmOhZvoSESzHxsFG
CAWJghA2wpE4qDgCsE1EQqE8cwaL82aSpvtGzeOoAWiP9fHzvS/z88pNtMRbSGgKjssFUiAdG2wL
pA0ScOugapBUEcJGChukTV1vA93R0J8fgJ5YP/+2+7f8vPJ5eu0YwuNDqhIl4eBPCgxPKrm+HPK0
TKKKRVXoJL1mGISKQAGhIl0WjQPthMyB0bB4ViMOIJa0eL12Fy8efZ0+Yig+H8Ri+NCZlFnKF6Ys
YlZWCZmeDNK1FKpCDXz//V/QE+kB3TUYEVID1aY91k04Hhlpi+doxAG0D/Tyct12Wu0+UN04ZpR8
4eOhK9dw/5yVZHvTcKsuhBDEEhYba9/ldF8HQlVAJpFCRUgASU+8lyM99SwpnI0qRidhjfisfWaE
010NmFYfMmmSbbl4fNFD/MXcVRQEsjA0HSEEEmgItbK9aT99sU5QNQQShI0UEhwV07KoaDtByBy9
KBhRAA6SjngfsaSJSMTJUnw8Vv417p15Czn+IEJ8kM5sx+a9M0c40nkS3AqKlAj5h+8lipBYOBxp
qyf85wJAAhZJHGnjSqqUF8xnzZyVZPuCQ3J5yIqw43QlXdFWVKkihYotbUjYoEiksEmqkvrQGRoi
HSNp8xyNKAAFyNADuJM2Gd5x3DxlGYX+rCHjJLCz6Si7G/diuxQELpAKPt2HT/MhHAcpBA6SiN3H
1oYKBhKxkbR6jucRk0CQYQTQdC8l2ZMoy5mI5NyeqwRaIj28UruDtlg30nBjKw6BpMPKieXcNLEc
r+mAooHUkIrk3dr99ETDI2n1rEb8EAzoHtKDuQRTcskxgigfOb0TdpL3W46ytWknA7YFqh+cGNma
zlenr+TWonK8EhAghIItNKp6TtES6x5pq8AoAPDpHq4qKGOikYlPDs2yLQPd/O7Ee3REOwfzvp1E
dSRZqQXMTC9hTnoxaanZ4MQYPBMV4maY6vZ64klrpO2OQgS4PFwzvoxJ/pwhkztIKlpr2Hamgqi0
wGWA2U+KrbCk8ApSdB8ZgXSmj5sG4f7BHwmFhGqzpWkfYSs60nZHvhASCMrSS/AJHcPwnPNdd7Sf
TTX/w+lIK7j0wcNOquSkTeDGKYvxaW5UVeXq4nlsqliP8DoIRSINlSPtR2mo3EXKgItYvA+RtEgk
HGTCBscGRUFxaSgeH2ogHT0vDzUnC9XwoOj6OSl4VAEAZASCpPoCaMoH0zvSYUvjXna2HCAmbVQM
pGPi0XSuHDeLSTEds6YGmhvJPVWBEvDhaCrYDlK4OBVu47dP/yPjj9jEzV5stwqagbBBSokUIBQB
tkRoHkTOOPQJBbjnLSCwaDHeokIUzfXJABBC4FLPXawp3MWvDr1OU7QZ6QngJFWkW6I7NlP3HUBs
OEJ7Vx+yoQEj2kD+mgk0pWnIJOAkGfA47Pb10hKXpHoysXxu9EAAzXDhKJBMJElaFqKjCxkKYdXV
or/ZT7T494SWLWL8Y18ntWwefCQSRrUfICUIKYlHB9hRv5/jnfVINBQUHFWCoZB6spPil45ih3Ui
DrgNP5OKZjM7qdOcMJGqiiIdHNumZ1oRoWvvZFr+Fdiqgup2oWgKEonjSGQyiYjFccIhIsePYm57
l8Se/cRfeoUOnx/33+ZijM8dfQASMLs6SdTXY7R2UdVaw9OxnTTq7Qjdh0hoCJdEH4hyU6KARfPm
YOSOQysqwZtXRH5BPms4zeGKn9FgdgyGelLQ5lbYVZLGtbPnoSA/uK+l/ODKSgmOg3/REuLX30Jo
86vYz6wluWM70RWr0LNzUFR1dAA4SZtQzVGiVXsxKytRtu9CrzvNL8v9VF6XhWP4IOLguDXoaWR+
5pU89sA3KZwwHWnoSEU5mzlWcgUbGnbQUNcBLgmaw0C4k+0122mcvJiJ/vEfLPzhsBYCFAWXpqFN
m45MJDDffBPrxCGsUCfScWCkAEjHJtkfxmxuJrxrB7GT9VjVVSQOHUaLWgRcOlsmunl9TioR3YcR
FiRUsBN9ZLoDfHnOCkpLy0B1IeCcfwsGsKyknG1nDtFuRVBUD1JVqOmsY2vdXgrKPoeuXNi+dBys
jnYim98geawWp3Ai7sKJ51z9PwmAPTBA5NRJet7aTHznTsTxE9gdXdiqilqUT/rcRcSnFrPZfZTO
ZD3CdJBy8Epq3f1cW3oLN0xehEu9sIXFhXOYGiygve0guFQwNDrjvew8fZibJ5WT78u8wOZtoo2n
6PjpT4ivfxErHiWwciW+KaUI5dzq5JIBOJZFItRLx/oX6Nv4W2TTcZyWfoQ3BWPOTAKrvoBv4WIC
U2fw1kAd72/eixmLg8uLJRSEGSY/tZDlxUspTBn/sR3fokA2V0+Yx76uKiKOCaoLR4OdLUc51F5P
fslHAUicRJKBY9W0P/0j4i+uR4mD65YbybzvbvTUtCFrXBKARGcHPVveovuF55FV1egDA8icXDyP
Xodv0TLcUybhKZyA4vVSF+nk+apNtIVOgeJGoCGTA6QKL8smLGJlaTmGOjQvf1g+l5vbp17DK4d/
R028DYSCFNDU38zutirK82aQ5h5smCbCfURPnqDv3XcIb3oN5Ug1wp+K76t3kbH6K/jzJ513jWED
iJ4+Tcd//ZDY+pewWttRJuThe/Rh0m+5Fc/kyWiBAEJTAUFSSt6o38s7x9/DREWoLlBtRDxCWXA2
98/5PHmBrAtWZ2fNCZVZ6SXcPPk62g//hl7FQSo6pmLzXOMO5k2ezyqRT3fF+/Qf2EX87S3IqhpU
RUFZXE7q6tWkX3s97ozMIfl/+ACkJNJ4isbvfxfzhU24vX7S7rob35duI3j959DcxkeGS6raT7L+
8Bt02RFQDaSqQKyLbNvDF8puY964UpSLbP4PcqsuHpv/Rbae2Uco2oDqUvFEbNSjR2hqfYb2Jkn4
9deItLWheTy4y6bjXnw1wQcfJjCp9KLzXxRAvLOdjh//CGfdRtwlEwncu4asu+7GnZuL+MiJCtAa
6WHtgY0cat2PbWiDm7ctUuIOt06/kS9OX06q7h3W5gGcZJJ8PYUv5S0k8NphZvXZTOq1mNRtUty1
CbMnSsIjcN90A4ErywncchOeiZNxBVKHNf/HApCOQ/+BfUTffgvN48F331fIeeAB9IyM84637CTv
NB5kS9P7xBSJULwIoaPHOpmdv4C7591Bgf/8J/eHVkU6g8VMoq+bUPURogcPcVPFVhbWdFLcnyQl
puCSgjann77Zs8hb8yC+5UtxZeag+i7tIcrHR4DjYFZX43R2IhbMJ3jbKvT09AsObwi1seHoZhrD
pxCeAA4CzBCZ3hxWTbuRJfllQ059KR2caBQnHsdJWJg9nUQqK4lXHyVRV0uypQW7p4tAKETAlMS8
CrXjDWqyvWz1C4JXTeYfb11BRtqF7/M/HgCgSgWXLbAjPcS7WvEWFKC49SHj2qXJs7Vb2NG5j2Sq
D4QLpAUDfdyx+EFun3EDKgqxgTBKJIqMREj0hzG723FqT2CdasI604J1+hSJMx2oVgThMnCEhpqe
gbf8Guxpk9kQPsS6UDW92Sl0q15SPW2UNmznr2ffhi4uvaz52F8IVcVz1UL6i4pIbttHzz99B/uL
q3HPmIYIZqL5/eiGmx4ZY239Np6rfJlEIkZaMgU97qBFo0w28lndHyRnTzVdzXWET59CtHagnW4l
3lyP2dmOHepH2En0YBDh9SHSM3Fyp5JWvhRXXi7+GTNwF5ag+vxMb9xHz5Yf0mY2IfUAHQMtrK98
iSU5pZTnzrxkAOJib4rakQjdr75M39pnsY4dIqmClpONmj0eV2oQI8VPtxpnX8sxega68Ws6mq2i
JgSGaVEkNIKmBn0mxCIknASO4+D2eFHT03D8XrScweaFXlqKO78Eo7AQvbAAPSt70OSHqrdw0uRf
dj7H2oO/oUs4oCTxWpK7p9zGE8u+Rn7K0C70nwQAwI7FiB4/SfemDcQr9yMbGkn2dKKaFoamI1UF
Qyq4pIqjJIkmTBI2uHw+RMCDpXuwfQFEZhru8ePQs3PRMjNR8/LRMrPwjM9FSwuieL2gaoP1+sfc
z3V9Lfzdlv/k1YZtJDw6xKJMcGfwnWWPsmbmCjRl+J2+YQEAQEqSsQjxujqSp88gQr301R/hrS2v
EI9FSfV4sRRotfpJNTL4/PI7SC8qxg6moOke8HqQaWnowSCulDRUwzi3Lr+EA0xKyTtNVXzr999n
X+gU+FNwR/u4vnA5T133TSal5158kksG8Ac5DtJxiNkWzx/9HU9ufpJesx/D48Uyw4xPKeE7ix5h
5bSlKIYBihj8SEBRQIiLVoDDUcKxefbAJn6w+xnqEh0IzUNqQufxq+7lL+d/mVT38NLhpXeFFQWp
qmxrPc5Te9dRk2LSlp9Cgx7DyJvMwyu+zg3zb0RNTUG4dYTLhVA1hKYhFGVENg/gUlTunHkjq6+4
HVc8CVackGryy0Ov8WbtbhJ2cnjbudSFHSnZ13GcJ7c+xfHOw0iho/bFKAtM43vlj3HfpGvxqkPT
5GgozfDzyNwvcf/c1XiQSGeA+lADPz2wkSNdp4Y1h/rEE088MdwFE06SPa3V/PO2n7G9eQdWig+3
6bA0bwFPXPMoKyYuxDhP53U05XcZzBk/lZBpUt9ZT1xYhM1uEC4W5s2+qJ9LioDanjP8uGId7zTv
Ju4NIGKwIGsu31r8ENcVzb3o39vRUoEvnccXrGbVlM9jJFV64928euJdNhzbTjzx8U+Thl06hawo
vzj4Mtsa9mCpKi5bsjRvPt9e/AhLCsrQRukNjuFIAJPTxvP3i9eAI9hY8zINvbX8qOI5cv1Brpsw
94KRMKxboC3Sy3/sXcevD79AW6yHFHcmNxeU891lD3F13vRLyrujJSEE6UaA+bnTMTQfTaFm6noP
0R2LUhgspjg1+/y/u1ga7IyFeapiHc9UrKXT6iE7WMqdk67n8avuoSh13Ci+wvjHK5owefXkdv59
z1qOtRzj6qKreXLFP1CWPmHI2AsCsKVDc7iTp/dv5FeHn6c91MzM/KXcV7aS+2fdTIrLixACTQzt
CXxatLXpEP9d8Wveq3+P5VOW8u0ljzA1WIj6oYg9LwBbOhzsqOVnezfwyrFNhO1+FuYv428WfIXl
xbMH63kpSXP7R+3trZGQlJIzA928fWo36w++wZSsyfzVwnsoSf/gmcJ5AZzsaeF7O37Cxsp1KEaA
pYXl/Os132Bm9kRMO4EtHfwuY8jLD59W2Y5NY6SLtXs2MS+nlM+VXoX3/1p55wCIJk0OdJzgBzt+
wa6G3aQGgtw183bumno9M7ImfFCuS0asovukJKWkNz7AgBkjaPgIGIOl8lkAzZFO3qp/n7V7nqW6
q55FxUt5eP49LMmdTtDwD7uJ+WmXI+U5ezkL4LEdT/LinldxO0nuXXgPD15xByUpOZ/KU34kdbYQ
6ujpYFHRAh648k6WFcwixeUeS1+fmM5GwNu1FRRn5DMhbdyYVnWftC69H/D/TJ+dS30BXQYw1gbG
WpcBjLWBsdZlAGNtYKz1mQfwv7mvSEyQXG98AAAAAElFTkSuQmCCUEsBAi0AFAAGAAgAAAAhAFqY
rcIMAQAAGAIAABMAAAAAAAAAAAAAAAAAAAAAAFtDb250ZW50X1R5cGVzXS54bWxQSwECLQAUAAYA
CAAAACEACMMYpNQAAACTAQAACwAAAAAAAAAAAAAAAAA9AQAAX3JlbHMvLnJlbHNQSwECLQAUAAYA
CAAAACEAM44I6P0BAADkBAAAEgAAAAAAAAAAAAAAAAA6AgAAZHJzL3BpY3R1cmV4bWwueG1sUEsB
Ai0AFAAGAAgAAAAhAKomDr68AAAAIQEAAB0AAAAAAAAAAAAAAAAAZwQAAGRycy9fcmVscy9waWN0
dXJleG1sLnhtbC5yZWxzUEsBAi0AFAAGAAgAAAAhAGKcVy0VAQAAhgEAAA8AAAAAAAAAAAAAAAAA
XgUAAGRycy9kb3ducmV2LnhtbFBLAQItAAoAAAAAAAAAIQDpU8ARYREAAGERAAAUAAAAAAAAAAAA
AAAAAKAGAABkcnMvbWVkaWEvaW1hZ2UxLnBuZ1BLBQYAAAAABgAGAIQBAAAzGAAAAAA=
">
   <v:imagedata src="image001.png" o:title=""/>
   <x:ClientData ObjectType="Pict">
    <x:SizeWithCells/>
    <x:CF>Bitmap</x:CF>
    <x:AutoPict/>
   </x:ClientData>
  </v:shape><v:shape id="Picture_x0020_2" o:spid="_x0000_s1032" type="#_x0000_t75"
   style='position:absolute;direction:LTR;text-align:left;margin-left:9.75pt;
   margin-top:47.25pt;width:54.75pt;height:20.25pt;z-index:2;visibility:visible'
   o:gfxdata="UEsDBBQABgAIAAAAIQBamK3CDAEAABgCAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbJSRwU7DMAyG
70i8Q5QralM4IITW7kDhCBMaDxAlbhvROFGcle3tSdZNgokh7Rjb3+8vyWK5tSObIJBxWPPbsuIM
UDltsK/5x/qleOCMokQtR4dQ8x0QXzbXV4v1zgOxRCPVfIjRPwpBagArqXQeMHU6F6yM6Rh64aX6
lD2Iu6q6F8phBIxFzBm8WbTQyc0Y2fM2lWcTjz1nT/NcXlVzYzOf6+JPIsBIJ4j0fjRKxnQ3MaE+
8SoOTmUi9zM0GE83SfzMhtz57fRzwYF7S48ZjAa2kiG+SpvMhQ4kvFFxEyBNlf/nZFFLhes6o6Bs
A61m8ih2boF2XxhgujS9Tdg7TMd0sf/X5hsAAP//AwBQSwMEFAAGAAgAAAAhAAjDGKTUAAAAkwEA
AAsAAABfcmVscy8ucmVsc6SQwWrDMAyG74O+g9F9cdrDGKNOb4NeSwu7GltJzGLLSG7avv1M2WAZ
ve2oX+j7xL/dXeOkZmQJlAysmxYUJkc+pMHA6fj+/ApKik3eTpTQwA0Fdt3qaXvAyZZ6JGPIoiol
iYGxlPymtbgRo5WGMqa66YmjLXXkQWfrPu2AetO2L5p/M6BbMNXeG+C934A63nI1/2HH4JiE+tI4
ipr6PrhHVO3pkg44V4rlAYsBz3IPGeemPgf6sXf9T28OrpwZP6phof7Oq/nHrhdVdl8AAAD//wMA
UEsDBBQABgAIAAAAIQCCleJU9AEAAOYEAAASAAAAZHJzL3BpY3R1cmV4bWwueG1srFRta9swEP4+
2H8Q+r76PUtM7BIaOgZlC2X7Aap8jsVsyUhq4v77nSzboVDYaPpNvtPd89xzj7W9HbqWnEAboWRB
o5uQEpBcVUIeC/r71/2XNSXGMlmxVkko6AsYelt+/rQdKp0zyRulCbaQJsdAQRtr+zwIDG+gY+ZG
9SAxWyvdMYuf+hhUmp2xedcGcRiuAtNrYJVpAOzeZ2g59rZndQdtu/MQUAm7MwVFDi463am16vxt
rtoy3gaOlDuOHfDws67LKEmSLFpyLjSmtTqXqQ+74xwbS75G6VyCubFk7H0BtGoBKZOl+RL7F/Dq
beA0jd/EndF6wT2EPB0EP+gJ78fpoImoCppQIlmHa8KsfdZAYhpc7vgKlmOXB8X/mGlx7B1r65iQ
iKXuGiaPsDM9cIv2cWh+CUjJw42fr+g+taK/Fy1uieXufDUN77//cp+qa8Fhr/hzB9J6C2pomUX7
m0b0hhKdQ/cEKKb+Xo0DsdxYDZY31xJ1A9c4+COK5YRaGk+iXYRxPja92y/Lh1p3H4GMo5MBd5SF
6SaLKHkp6GYTrsJpRhgs4ZhfrbN1iK8Ax3ycJe7suToejk+vjf0G6mpOxDVClVEM/J1Zzk4PZpJl
hph08UqMRkLrTn5uBS5wzyybLffqwZgq/QNV/gUAAP//AwBQSwMEFAAGAAgAAAAhAKomDr68AAAA
IQEAAB0AAABkcnMvX3JlbHMvcGljdHVyZXhtbC54bWwucmVsc4SPQWrDMBBF94XcQcw+lp1FKMWy
N6HgbUgOMEhjWcQaCUkt9e0jyCaBQJfzP/89ph///Cp+KWUXWEHXtCCIdTCOrYLr5Xv/CSIXZINr
YFKwUYZx2H30Z1qx1FFeXMyiUjgrWEqJX1JmvZDH3IRIXJs5JI+lnsnKiPqGluShbY8yPTNgeGGK
yShIk+lAXLZYzf+zwzw7TaegfzxxeaOQzld3BWKyVBR4Mg4fYddEtiCHXr48NtwBAAD//wMAUEsD
BBQABgAIAAAAIQAwRUqzGAEAAIgBAAAPAAAAZHJzL2Rvd25yZXYueG1sVJBPT8MwDMXvSHyHyEhc
EEvXdN1Ulk4DCYnDhLQOJLhFbfoHmqRKQlf49LhsYnC0/X7Pz16uBtWSXlrXGM1hOgmASJ2botEV
h6fd/fUCiPNCF6I1WnL4lA5W6fnZUiSF2eut7DNfETTRLhEcau+7hFKX11IJNzGd1DgrjVXCY2kr
WlixR3PV0jAIYqpEo3FDLTp5V8v8PftQHNZTs+0j9XYrrl437KXNxO55E3N+eTGsb4B4OfiT+Eg/
FBwYjKfgGZBivqFd67w2lpRb6ZovDH/ol9YoYs2eQwQkNy2HEMb6sSyd9KiaT6MZ/gFHv62QLcIZ
0NHWmwMcH2Fc+geO5jEK/7GMMbRDlp4y/RSnB6bfAAAA//8DAFBLAwQKAAAAAAAAACEAHVjMzbUg
AAC1IAAAFAAAAGRycy9tZWRpYS9pbWFnZTEucG5niVBORw0KGgoAAAANSUhEUgAAAH8AAAAvCAYA
AADKMxXkAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR4nO2cWXBb15nnfxf7ToAgQIDgApIS
d0qkRFIUtVibJdmWLVtyZDvpdNLVPdU1me509VNP1fT0ZN5maqqmunqWJNNJZtpJ27EtS4pl2Vqt
XSKplRQXcV/AFQBJLMQO3DsPtBTLkhfJsqPq9v8FRfDinu+e3znnnm+5V5AkSeJb/YuQJEnEolG6
e7qYnJwi155LTU0NBqMRQRDuO17xB7DxW31N8vtmab18ibff2c+s10vDqgZ0Wi1V1dUoVar7jv8W
/r8ASZJEOp3mzEeneOPNNzl+6iMsZgu5ublMT0+zvLz864efkSQyYhokibQkIiEgCAICIBdkS58y
OQI8cBn6Vg8vSZJYXFzkSns7+989wJUrV1EplJSWuHHl5aHV6T6zrx8b/AwSM4kgMwtTxBYD+NJJ
0oIcnUqDAjkWhRaTSoNVb8asM6GUyx9X01+bJEl64gdpMpnk+vVr/PrXv+b69ZsUFRRSWVGGyWSk
rKyM5eXlqB4w6+ExwU+JGTwRP8fHWmkbaSfinWA4nQFNFnaDCYUkx6nQ4dJaaSmup85VgVX34E3I
k6DFxUWmpmfQqtXk5uaiVCmfWFt9Ph/79+/n3QMHcOe5ePmlPRQWubjZ0YHBYMDpcHw9M19EIiZm
6Jzp52j3MY4OnmUsOo9GoScpqAgkF+gMxJCnomShId9UQFqlxJntJFtn5EnrTkmSmJ6e5v0jR+jv
66e8vJzdu18gJyfniYQ/Pz/PoUMHOXToEEjw2muvsWnzZrq6bxFPprBkWz/X7q8EP5yK0RGY4ED3
B5y6eoDheQ81ZZt4qmITGqWS7uAoZ8daWVgcJ4gCWVLLcNxPMBH5Ks1+bfL5fBw9epRf/vKXzM/N
s2vXLnbvfuGJBJ9Jp7lx/RrvHTpIOLzIvn37eHHvXmamp7l4uZXCIjfLli3/3HM8MnwRieHANAd6
j/NmxwHm/f1Uu1bz503fZVf5RnRKBW3eHuaCk1yf6WUxFWRWpcWbnCeUjiBJEjxBnZpKpTh//ixv
v/U2nR03sdtsFJcUkZWV9eTBlyQmJzwcPnSIzq5bNDU38Tf//m8wGoz85o036OsfYvdLe8jLy/vc
0zwy/LQo4o3MM+YdJZZKUVa2jh81/ym7lrWQrdKSQUSeBnkkjpAUESQJKRUlmVhkMREhg8STsuWT
RJFIZJHBwSFi8Sh1K1eyZfNmtm97GqVS+Yc27z5FYzHa2lq5eu0aJqOZ1155Fbe7iJOnTjE8PMLK
lSspKy9Hofh8vI8MPyNmSCSTKEUFlbZqXqp7llert2NSaEiLIte8A7zXf47huXFiyEFlRJAgGQsy
FfaxkIyRqzE8avOPV4KAQqFkedlytia2UJCfz5Yt28gvKEAmk32jpkiSRCwWIxwKkc5kMBqN6PV6
5J/wjjyecd5+5126e3r5zndeZsf27fT0dHPk/cPY7Tn84Ic/wO123/ObB+kr3PMl1IKKHE0O2SoL
q7KKMCo0AARTUc5MdHJ64iZ+KY6QlYNMLkdMJglGQ4wGJvDFgk8MfEEQ0Ov1rF+3gcqKKowGA3l5
ecj+AO5oPB6n//ZthoaHECWJFStW4HYX3wWZSiXp6u5iaGiYbGs2TQ0NRBcjnDpxEq/Xy/and1Bd
Xf2F4OErwFfI5Fg0evKNNhSSDJvGjACIksRocIb28RsMzY2g1Bkpzi1BJWiZ9Y4xE5mn0zvAYMBD
qSkXrfxeEyRJIiOKpMQMSBIqhRL5p2bfkv8NfMpfkCSRVCoNgFL5cO6ZIAjY7XbsdvuX/k0mkyGZ
SCBJEmqN5kt1+OdpcXGRixfOc/LECaamp7Hm2CgoLKL4E9cxPT3DldZ2lHIZ65qbMWeZ+PCDI1xp
b6e2upa1LetQqR/s139ajwxfjoxsXRZF2S4S6TQqtRqAFBJTkTk8vhESYT9WYyl1jiqsyiyuxVJc
m5tiNuzDHwuQEtP3wQcIxiPMRxfRqVRk64xoZOr73EJRlJDJ7v02kUji9c4il8uxWnPQaDSPenlf
SovhEJOTE8jlCpxOF0bTo8cu0uk0fX19vLP/HdpaW1GpNGzZmo8tJ+eefYfHM0H/wAAKmYz8vHx8
Pj83btxAJpPR2NREYWHBl27zkeHLZDLsxmzqCipIZdLkGrKRgIVklN7AOPMRP6nwPPnyVezMa6DA
aGVxYZKrvT4W5iRmg36iqRQGhRrZxx2WEtNMBX3cmBoimkpRmVuIWfv7W0MmkyGwsMDo6DCZjEhJ
SSk5NhsAiUSCnp4uLl66iEKmZMOGjVRUVnzhpufT+rJRPZ/Xy5kzH3Hr1i2cTieNjU1U19Sg1eoe
qj1YWuqPHTvKb/75n/noo1M47Lm8+tprvPTSS5SUlCAIApIkkUwm8HjGmJ2eIrq4yNjoGJPTU+h0
WrZs28qa5maMRuOXbvcr+fk6pZqiLBtIoJUrESWRoeAEN6ZuMh+ZQq2QU2hwUG3Iw27MIsdkREyF
Cc3H8cxPEEwlsWmXzhVMROmcGaBjop9QIobDZEOv0qD8xMow7/dz7OiHtLe343A62PvyvrvwOzpu
8LtDB7nc2obD6cJdXEzpstKHgh+NRhBFCa1W+7lLeDwW4+L58+zff4D+/j6qq6rItmSzfPnyh4a/
GA5z/Ngx/vvf/z2dnR2UlhTzJz/8Ia++9l3suQ7uZNwFQSAcDhMKLIAo4pub49yFC5SXL+fPf/Rv
2bRlCxaL5aHa/krwFYIMg1x99++YlOH6TDcdQxcJzQ2Rm1tJWV4lubosDEotxZY8LCYjXu8k3bO3
6Q1M4tAZWIjNc2z4CqcGr6OU5DQ4yql1FFOYZUP1MfxwOMxHJ0/y05/+jLFxDy/t2Y3ZnEUymaTr
Vif/+3/8Tz46c4b5QJBtW7PQ6bSoVCokUSQWi5FKpdDr9Sg+w3Wbn/Nz5Uo7yVSKyspqiouLHzgA
AoEApz/6iNf/6XXOXbxIMLiA1WpGqVKg0WoRRZFwKMRiKIzBaMBgMn3mQPJ5Zzn24VH+/h/+gY7O
TlbX1/Off/If2bxlK6mMhN8/h8FoQP1xbD64EGBhbo5YLIY/GEAmk1FTW8PGp54iJ8d2z0D5Uvy+
1FFfQhIwEJylY6qHOf8YQhKKbGWsyK9Fq9KgEuTUWsuocq9iLrJAn7+PD4YusBiZY2x+iHMTXaQz
Ao2OKprd1VTnutEoVIiShNfr5eSJE/zm9de50dmJyWigqKAAo9HI8NAg//zr1zn8/hEWgkGyLRZc
TgdFhYWImQxd3V103eoknRapr19FeWUlao36Hst9Ph9nPzrNsaNHkWRLgC0WMxZL9j2uXjKZ5OiH
H/CP/+cXtLe3E43HsNmsrFixguqaWhQKJbd7ezl75gxzPj81tTU0NTeT53Ld01eZTAafz8vbb7/D
G2+8QeetWzSvaeKvfvxXbNq6lb6+frq6etHp9bSsa0GTk4OYyTDn93O75zbjk1MgCLyw+wVe+973
MBqN9PZ0s7gYobCoCIfDcU976XQaURTvS/A8FvgSEEzGOD9yjRsj1wlFgtjty1nn3kCDvRSDUo0g
CLhNBZQ5Grk+1stCcIwjPR/QMXINlUzErLewrmAFm4pWszJ3GTqlmnQmw8T0JIcPH+bg/ne5fu06
sViMZe4C5IJEW+slOjo6GBwcQKfXkEwlMGjUOHNsCFKG69ev8fOf/YybN25gNJp47jkvWWYzRcVu
AMRMhkAwwO8OHeTtt/czNjKCTqvGZrWytnktWVlmZDIZkiQxNzdHx80bHD78HsPDQ6QyKRRyGVVl
5Wzbso3CwiIGBgb42c9+yslTp0CUaBpuxGA03AM/nU4zOjrC+0eO8Itf/JKR4WEaVq/mb//2P9DQ
2MgHRz7grbffIZXKsHnTJoR1LUu2iiKe8XE6bt0iEAqxpnkNP/7LH1NVXcPZM2d466230On1fOc7
++6BHwqFmJ2dJR6PU1tb+/jhJzNpeuc9nOw/w+2xG6QUWtav3MOuim04NCYkCWbjQXoWPMxGo0ho
EFNJpn09BDVeNhQ1sbO0mV1lT1FgtCNjaYMzPDTE0ePHOHniOHN+HwoZGDRqBFHk0sWLtLdfwWg2
s/nprTSuaeDD3x3GOz3L1ISHE8eP03O7n49On2Hc41nq+EyGErebgqJCBEFgYnKCttbLvPnb39La
3kYimiA7y0hwYZ50MgkfL6Nzc3McOnSQ3/3uIHqdjh07nqbzZicjw0OUFBfhcrmYnJzg3Xf3c+L4
SfoHB5AkiUg0wrJlpaxtbkarNxAKhRgZGeHAgQO8+dZvmRj30NzUyF//9V/TvKaRy5cv83d/95/o
6b3NytoV7Ny2Da1GgyRJjI+OcPnyRQZHRsjOzmbfd/bRsLqRmdkZfv7zn/Pe+0eoKCujbuVKNm3e
jCAITE9P09HRwfj4ODqd7uuBH0hGueHtZ3iun1gmRG5uOS3l6ymz5rMQXWAwMMXpyQ6ueG/TPnad
eCaOXGtA0urJz3WzvWojT7vXkm+wIUMgkUwy4fHw/sHfcaujg/wcG1XLSxgaHOTKlatMzswSS2co
KS5mw5YtPPvcc/i9PkYHRvGMTnD23Hn6hocwmoysqqvDkZtL7+1ebnV1ceDgu7hLirDaczlx7Bhn
T3+EUqGgpqqSrq4eookkofAiyWQCURSZmZnh4sUL/PbNN5menuRHP/p3VFdVYzQYSaeTKOQKbvf1
MjA8zPXrNykvLyPf5aKz6xZen49r167R2dlBjs3OjZs3OHfuPEePHWd8bIz6FbXs2/sijtwcTp08
xYWLFwgGA6hVKkKhIJ6Jcbyz02REkSPvv8fps2eIxeOsqq9n7dq1SEicPHmSazduApBIxJmamGDO
5yOZSnLq5Ckut7WSnW29D/xjg9/nG+fS6FU8ix6kLD1GRwFJWZrOuQGGJ3o4P9zKxfGrzKXjaAxW
8m1FxFJBFsU0Dr0Vt7kQq86CXJAhSiKj42Mc3H+Am5faKXTlsW3nNvRmHW+/u5/F8xeJxJMss+aw
fedOnnvuefLzC5idniGWSjEXiTAfWSTbYae+vp5VqxoYGxvnyAdHOH/xEqfPnsWYZSTXkUt3dw9I
8OzOZ8ikE/w68QZ9A0N4vV76bvciyOX03u7nzOnTKBQKXnjhRV7Y/SJiWkQpV6CUK5iYmODM6TOM
jo/hyHOx+/nd6DVaDhw8yJtvvcWVq9d4/fVfk2210nu7m+7uHkbHxjBpNSwvLkIURc6ePcv0jBeD
0chLu3fT3tZGX/8AH3z4IciATIZz58/SPzCIWqVi5Ypq8vOcjI2Oce7sGUKBBdRKBeFwiIsXL5Bt
MSPI5Vy7foNoPE5TYxN1dXVfHf5SNm7pUxQl5uIR2ia66J68RSA2j2A0EBNETgyc5nQyjWfqNiMT
PaQTYcw5pTS6m8k1ZdE11UGvp4vQ/BSegI9QThyrykAinuDS5Uu0XrpEjt7Eps2beWrb03QNdjPi
mSIQWqTAlc+Lu19k796XKSwsIpVK0t11i/7+PhKpFJWVlbyw+0V27nyGkpISZqZnUCjk+Px++gaG
+PD4cYrdRZiMJp5+ege7d+8mk0wwOjqG1+ujr7+fd955B/v5c0xOTCNJAruefZ5tO57G5cqn4+ZN
xsbH8M/5mZv3E0smlsC/sJstW7aiUqhIpFJ09/TQduUK7x48hNtdBGRIxuNolQoUMhgeGSaaSCAK
UL+qgR07nkGtUmLOMuGZnOJGRyeRSJR8l4M5n590MoXT4aDU7SYaCdPW2obHM467KB+5TMAzOc3F
1jamp2cpKS0h22pl4/oNbNi4kcLCwvtYyn/yk5/85B64SHdudfe4DBIQz6SYTy4yuehnZH6K9oke
jg23cXzsIrfnB4hLKWRKA4nFRUZGbzE43UconSTPWsAzVTt5pe5FXq19jsqcYgKxMH0TPSSiIYxG
K06bE5fWSnDSR/eNW6iUCjZv28KGrVsQlAoOHj7MgQOHkEnw3dde5U//7M9wu4uRRJHuni5++ctf
0NHRSXFRMX/8/e/z2nf/iGXLl6NSqzFbLOTluVAplQjS0r3fketk3yuv8OyzuygoLMRiyUan1bCw
EKCrp5e+/gH8Pi9Gg5Ht23ew5+WXKSkpYWFhgQ/ef5/3Dx8iEFhAo1HTuKaJV155jS1btmEwGFEo
lRgMJhYWFggGg2REkbKKcpoaVqPX6vF6vSwEQyRSaTRaHU1Nzex5eR81NTU48/LQqFXM+eeIxhMU
Fhby1ManKCurJLq4iEIuYNDp8YyPMzAwSGnpMvbsfZm6+nqisRiRaJRUKk1xcSm7X1yaAPkF+Q+M
d9z3TUYSCScjBGKLxNJpBJlAKpMhmkkwnwwzF11gbH6CmZCfscAMY+FZPNFxQpkoKMzoZVlYJQGl
ToVKqWNZwUqaCuvYVtRAqclBlsZAOBVnzF7DFdtyPP4ROjzXKc5zsExjQ5uSWF1TR2NzI8sqyjCa
TFy/fpWem7ewZ+fgXrWal/bsoaBgaSSHw2GuXLlKW/tVdDoDz+zcwfPPP0+eK+/u4JXJZDhdLnY9
/wJ2ey5DQ0OULlvG9h3bsViy+fggVtSvZsczM4SiUYaHBnE5nbz44h6279yJM88JQN/t25w5e46x
8Qms2WbWb9jI3r37aFyzBq1We7cfbbYctmzditFkZDEaoba2FleunUuXLjLj82PNsVNQkE9LSwvP
PvscVVVVdwEtr6jkxT17qKxZQVFRIU2NTQQWgkxNT3PmzElOnDpFbm4udfWrePbZ51hZX08kuojO
YKCyspNUIsXatS08tWkTOTk5n5mZvA++KImMhXx8OHiFLv8I0XSURDJKJLVIMhUhnUoSSieIkyGc
iRFOhsiIcZRyPUa1iyqrm7rsPErNOeSbXZTbluPKcmBR/N63Nit1NLtquV2+lUPRg/QNtXIhy0S1
cTmb7HU0FKxB0ChAgGQizsK0F7NazYvPPcv6zZtpaGi8GzgJhkJ4PJNkZZmpr69nz969VFRW3lco
IpPJKCktxeFwEIlEMJpM98X+s8wWtmzdhs1uY2pyEqfTydqWFrKyzCBJiGKGgYEBZn1eZEoNTWta
+NFf/JiV9fXIP5WjUKqUrGleQ3VNNSBhNJpIp9LEEylSGQmFXE51VTUr6+ux2e33ALLZ7Dy363m2
xWNotTpUajUzUzPk2G0EwlECgQD6LDNNzWtZWVeHXq9Hr9eze/dLbNzwFIIg+1K5jfvgC8hIixJd
/nE+GrlCOD6PJMZJp8JkEmEkSQYaCzK9DlGWQhLjGNQWioxu1rka2FCwkrJsJy6jFZNSh0auui8r
JwhQYLLT6KylY+QGvslO/AtzDC9MsspRhUVr+v3BEhS43Ty9Ywdmaw7l1VWoP04iSZKEQqGguLiY
PXv2smJFLRVVVUh8Ot/3e2l1OjRa7QOjYDKZgN1uo3lNM6lUEq1Oh06nv2MGmXQag15PdUUlec48
fvDH36eqpvY+8HekUqmwWCx38wWCIFBWXk6OLQetVos9NxedTn+fLYIgoFarUalUd/+XSicxGA3k
5OSg1+tZt249LS0taD6x2ui0erR5uo+v5YvrEO6zWimTY1UbydEasSg1qEQtarkOsyoPo0ZDVC7g
SUTxLc4jRkPIECi1lfBK5Q72VWwh32hFLsiQC5/fuEmpYbW9hJGy9cyEp/DM+7gw1EphloOc4hb0
H4eNVRoNy6sqKa0oRyaT3RcqtVgsbN26hac2PYXt4475vPDmHQif2SEKBVlm84N/J1NQUVmJTq8j
35VPRVUVmUyGcDiMTreUD0in00SjUWQy+d0cwZ32FAoFuQ4Hdrv94/N9dh992k69Xk9tTQ27nnsW
kymLXbuep7Do3oKNL7q2+671QV9mqXW05FUiExP4on5ydNksyy7CZXcxmQlyuO8krd3nWYxEsFjc
NDtq2e5uoshk+0Lodw0FcnVZrC1ayS3/IB/efJ/eqV5uOatoyVuJTvf7NK5cLn9gfFwQBDQaDU6n
E0EQkMlkX2u9nSAIuN3F5BcUEI1EGOjrIxgKolKpyLZmo5DLCQQWmFtYQBDkuPIKsNlyMBh0yGTy
u+cQHiHvb8rKoqGhkaIi91JJdl4ecsVXqx94IHyjSktzXgUFpmyCyQg2jZkicx5qrZ4z/h4y4RCp
gI9cdTbPlG3jezXPUG0t/NLg78ig0lJlK2Z9cSODU734Ij56/cN0z49hVhvQy7+4KEEQhIdO2z6q
5HIZWp2Wubk5Tp48wc2bN9HpdLjyXQQDS0kXhUKBWqcjnRHJMmWxatUq1q5di1L51QamQqHAmZeH
PTcXuVz+WMrLHthrCrkChyEbs8ZAShLRKzVo5EoWMjFujd2gY+g6UjLN+sr1PF/xFCtyS1ArHr7Q
UQCsSj0b8+sYKOnj4LV3aB24SIWtiJrsQvQ661e9vseuaCTCyPAQgcACOTYb2RYL4XCYk8eOMzUx
QcOaJtasW0c0GmPC48Htdj90VdFnSSaTPdaawgfCFwC1QoVasTTzJEkimk6wv/N93jj3/4iFA2yu
fYY/bfkua5xVmJSPXjEjEwTKzU6+t+JZPN5Bjg9d4EjfWUqsxbxathXtl5j936TiiQTJRJLS0mUU
FBQgVyg4/N5h+oeGmZmYYPuOnWxYvwFBJmdgoJ/SktKPCzGSSJKESqX6BMClmMpSwEy8uzFUKBRI
knT3b+nOFvYTT9N/Mn37qAPiS62XiUySM2Nt/PTSPzE6N8naso18f80+1rhqMSu1X3yCLzJCkFFp
dfPd1XtBqaY3MMmB3jNUmd00OSqeqLp5lUqFqyCfIrkSu92Gzz9HeHGRSCyGxWqlrKIcd5EbtUZD
YWEBSoWSmZkZpqemUCgU2B252Gx2FHI5mcxSrUE0FiUWiyITZDidS7X28XicSCSCRqNBr9cTTyQI
hYKIoohSoSCVTJJIJtFqdZjN5rse0MPoC+FnJJHWyU7+5+XXuTUzSFNJM3+x6d+wOb+eLPnDN/hZ
0ik17Fi2jlyjjV/dfJ8Lnlv849WD6Br3Um1f/o2XUH+W7vjUd+zx+WYZGx8jmUxQW1dHZVUVeoMe
QVjyTIaGhrh0+TLpZBK5TECt1VBdU0N5WQUymYyBwUF6e3uIRqOUuN24XPkEQ0Ha2tqYmpikqbGR
sooKfF4v7VdaSaXSaLUa/F4/gfkA7mI3zWvXkudyPXQffS78eDrJde8Qv7rxHgP+SbZWbuH7DXt5
On81evnjf5hBp9TQ4KxkIb7IYiJOu6eHX8n1/LBeToXdjfoz/OlvUp/s4Ehkkc6ODoYG+skyGGhs
aKCwqAhBkBEOhThx/AQXzl9AZ9CzZk0T83N+2ttauX27l+99748pKChgsL+f/W+9TZY5C5dzKYp4
9epV3vjNb0jE4pSXlSETBHw+LxfPnWcxGsVmtxOPxklE42jUGuLxOI/ygpXPHCqRVJzWqV7+V9s7
XBi5xXLbcv5i7R+x092E7msAf0cquZKW/Fpeq95GpbWEkQUvJ4duMjQ3RSqT/trafVhJkoTf56fj
5g0mPB5yc+3Ur1qNPddBLBbl7OnT/Lf/+l84+uGHFOTnU1dXj95gYNIzSceNDubn55eKRLxeOq5f
Jx6N4nA4SCaTtF1uo/XyJRKpBGaLGZlcTjgQZHx4lL7e2wSDIfJcLlY3NlJdU/3Ij5TdN5UkJALJ
KG1Tt3mz8yhnBq+ywl7Cn6zazc7itSi/geXXojHyXFkLRqWB1vE+MqLIyMIMDqMFi8bwhOwBJKYm
J+jp7mZhYYGGxkaqamvQarT0dnfxf3/1K9qvXWP71m3s2LkTS7aFyYlJpqencX1cghaPxZiensFk
NFBft5K8vDw8Y2MMDQygUKpYu7aF/IJC0qkUU5OTRKIRVEoltbUr2LBhA06HA51Wi0qtfqTb4j3w
RUlkdnGB9ulejg5foX/Ow7qiFfxg5TM0F9R8I+DvGiZT0FRQicOQw0TIh06lJplJfXbc9htWOp3G
7/ezEAggCTIKi9zk2u0kEnE6Ozppu3KV7Oxsnt7+NPkF+YyOjnLxwjmmJqfYvGULrrw8xsbHGRob
webMo6KyCkmUuHb1KlNTk5SWLmNtyzp0Oh2THg9DgwMkUglKS5fT1NjIstJSlErlV9oL3QM/GI9w
Zugax4ba8CfCtOTX8HxZC82uGjSKb97lMqi0lNlcOEwW0lIGnUL9xLwtIxAIMDg8zEIgSI7VSnlZ
GWazhVg0yujICF6/j4qyMlasXIFMLudWVwftV64gk6Curh6D0UhPdxf9t/uw2XNQqdQMDw3R3tpK
YH6elatXUVBYQCaTYdwzTl//AAgyCt1unE7HVwYPn4I/5J3EGw6ilKtZ5XTyfMU6amwlfxDwd6SQ
yTFrDIiSiEwQkD1kFPHrkCiKTHgmaG9vY3pmhtKSYhxOJ3K5fOnlSJkUOo0Gk8GASrVUI3DzZgcK
hYIN69dTu3IFqVSK/v4BRkZHSaZTTM9OEY6E8fm8hBcXUSmU6LQ6EokEoyMjjI+PYTJn4XA60Wo/
+z07D6N7l/10BofBSqHNSbXdTanFiVz4wz9IvQT9D28HLJVdz83NceXqFYLBIMtKS6mvX4lBryed
TqPValm7fh37JsaJRmP09HYRS8bItmTzlz/+K1paWigpKSEcXkSpVJDncpJf4MJitWI2Z7Fs2TIC
wSDau5lHCaVShdvtxmrLoby8HIPx8ex77oHvznFiN1vJNmRhUKmfiFn2pCmdTuOf85PKpKmtraW2
tobCgkLUKhXJRByD0cSq1Q0gSFy8cIHJqQk0Wi2rVq1i+fLlZGdbP07yCBQWutm4YSNF7iKqqmvQ
a3XM++YR5HJcrnxUSiVKpYrCoiKa1q4lNzeX8vIKFI/J5RW+fQPnwymZTDI352dufh4BAaVSgVyu
QKVSkWO13q0ViMdj9N3uZdbrxW7PZdmy5RgMS88dLoV7U8xMTxMKBTGbzTjz8hCAWa+X4EIAo8mE
w+lAJpMRCoUIhUKYTCZMJtNjC8L+TqQAAABbSURBVHh9C/8hJYoimUwGUZKQ3c2fL8Xo7+Tu7yzJ
iUSCVCqJUqFEpVbfWxMpSWQyGSRJupuluxPjF0URuUyOTC672yZ8uQKNh9G38P8V69ub+r9ifQv/
X7H+P9b7tD0NToKHAAAAAElFTkSuQmCCUEsBAi0AFAAGAAgAAAAhAFqYrcIMAQAAGAIAABMAAAAA
AAAAAAAAAAAAAAAAAFtDb250ZW50X1R5cGVzXS54bWxQSwECLQAUAAYACAAAACEACMMYpNQAAACT
AQAACwAAAAAAAAAAAAAAAAA9AQAAX3JlbHMvLnJlbHNQSwECLQAUAAYACAAAACEAgpXiVPQBAADm
BAAAEgAAAAAAAAAAAAAAAAA6AgAAZHJzL3BpY3R1cmV4bWwueG1sUEsBAi0AFAAGAAgAAAAhAKom
Dr68AAAAIQEAAB0AAAAAAAAAAAAAAAAAXgQAAGRycy9fcmVscy9waWN0dXJleG1sLnhtbC5yZWxz
UEsBAi0AFAAGAAgAAAAhADBFSrMYAQAAiAEAAA8AAAAAAAAAAAAAAAAAVQUAAGRycy9kb3ducmV2
LnhtbFBLAQItAAoAAAAAAAAAIQAdWMzNtSAAALUgAAAUAAAAAAAAAAAAAAAAAJoGAABkcnMvbWVk
aWEvaW1hZ2UxLnBuZ1BLBQYAAAAABgAGAIQBAACBJwAAAAA=
">
   <v:imagedata src="image002.png" o:title=""/>
   <x:ClientData ObjectType="Pict">
    <x:SizeWithCells/>
    <x:CF>Bitmap</x:CF>
    <x:AutoPict/>
   </x:ClientData>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:1;margin-left:12px;margin-top:4px;width:74px;
  height:86px'><img width=74 height=86 src=kuitansi_files/image006.gif v:shapes="Picture_x0020_1 Picture_x0020_2"></span><![endif]><span
  style='mso-ignore:vglayout2'>
     <table cellpadding=0 cellspacing=0>
       <tr>
         <td height=20 class=xl65 width=72 style='height:15.0pt;width:54pt'>&nbsp;</td>
        </tr>
      </table>
   </span></td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl66>&nbsp;</td>
   <td class=xl67>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td class=xl73 colspan=2 align=left style='mso-ignore:colspan'>PT AMINAH</td>
  <td colspan=5 style='mso-ignore:colspan'></td>
  <td class=xl77 align=left>NO. KS</td>
  <td class=xl75 align="right" id="lastKui" style="color:red"></td>
  <td class=xl77 colspan=2 align=left style='mso-ignore:colspan;border-right:
  1.0pt solid black'><?=$vNoKui?> <input type="hidden" id="hKui" name="hKui" value="" /></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height="20" class=xl68>&nbsp;</td>
  <td></td>
  <td class=xl74 colspan=6 align=left style='mso-ignore:colspan'>Ruko Puri
  Kencana Karah Blok G-1B Jambangan Selatan - Surabaya</td>
  <td colspan=4 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height="20" class=xl68>&nbsp;</td>
  <td colspan=11 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height="20" class=xl68>&nbsp;</td>
  <td colspan=11 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" align=left valign=top><!--[if gte vml 1]><v:shape id="Picture_x0020_4"
   o:spid="_x0000_s1033" type="#_x0000_t75" alt="kwitan.jpg" style='position:absolute;
   direction:LTR;text-align:left;margin-left:7.5pt;margin-top:1.5pt;width:53.25pt;
   height:174.75pt;z-index:3;visibility:visible' o:gfxdata="UEsDBBQABgAIAAAAIQD0vmNdDgEAABoCAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbJSRQU7DMBBF
90jcwfIWJQ4sEEJJuiCwhAqVA1j2JDHEY8vjhvb2OEkrQVWQWNoz7//npFzt7MBGCGQcVvw6LzgD
VE4b7Cr+tnnK7jijKFHLwSFUfA/EV/XlRbnZeyCWaKSK9zH6eyFI9WAl5c4DpknrgpUxHUMnvFQf
sgNxUxS3QjmMgDGLUwavywZauR0ie9yl68Xk3UPH2cOyOHVV3NgpYB6Is0yAgU4Y6f1glIzpdWJE
fWKWHazyRM471BtPV0mdn2+YJj+lvhccuJf0OYPRwNYyxGdpk7rQgYQ3Km4DpK3875xJ1FLm2tYo
yJtA64U8iv1WoN0nBhj/m94k7BXGY7qY/2z9BQAA//8DAFBLAwQUAAYACAAAACEACMMYpNQAAACT
AQAACwAAAF9yZWxzLy5yZWxzpJDBasMwDIbvg76D0X1x2sMYo05vg15LC7saW0nMYstIbtq+/UzZ
YBm97ahf6PvEv91d46RmZAmUDKybFhQmRz6kwcDp+P78CkqKTd5OlNDADQV23eppe8DJlnokY8ii
KiWJgbGU/Ka1uBGjlYYyprrpiaMtdeRBZ+s+7YB607Yvmn8zoFsw1d4b4L3fgDrecjX/YcfgmIT6
0jiKmvo+uEdU7emSDjhXiuUBiwHPcg8Z56Y+B/qxd/1Pbw6unBk/qmGh/s6r+ceuF1V2XwAAAP//
AwBQSwMEFAAGAAgAAAAhAHTtNpEKAgAA9gQAABIAAABkcnMvcGljdHVyZXhtbC54bWysVNtu2zAM
fR+wfxD0vjhxnJsRuwgadBhQbMGwfQAr07FWWzIkNXH/fpTlOCiwAsOyN4qkziF5KG3vuqZmJzRW
apXx2WTKGSqhC6mOGf/54+HTmjPrQBVQa4UZf0XL7/KPH7ZdYVJQotKGEYSyKTkyXjnXplFkRYUN
2IluUVG01KYBR0dzjAoDZwJv6iieTpeRbQ1CYStEtw8RnvfY7qzvsa53gQIL6XY241SD9w45pdFN
yBa6zuNt5IvyZo9AxreyzGfTeL5Jxph39WGjz/kquL158fl4vF6sFmOov9FDX/mcHjny+Yg9+vyV
dbKYv0M7e4d3+gfOC1MrRYBXp4MUBzNwfT0dDJNFxhecKWhIIYq6F4Ms4axAK0iU57MkBSe/2iOP
rtcCCKQE/KjFsx1khH8QsQGpiF7fV6COuLMtCkfL5NmCJFRloOuPbzp4qmX7IGvSDFJv31xG2Ma/
2kVdllLgXouXBpULC2mwBkePwVaytZyZFJsnpPmaL0XfEKTWGXSiurVQ33BJjX+nYflBjcDD0K6D
8VttWy85pF1pmv/BTK2zjjRKVvPNhlbl1duzTRwvvGqQYueYoITlcrVJ6FMQlBDTi41XfQJV6yvx
ma2x7jPqm6tiHojmTOOg5w0pnB7tMJgLxTCZMIt+lWh5h42uJUm4BweXpXvzgQw3w4eV/wYAAP//
AwBQSwMEFAAGAAgAAAAhAFhgsxu6AAAAIgEAAB0AAABkcnMvX3JlbHMvcGljdHVyZXhtbC54bWwu
cmVsc4SPywrCMBBF94L/EGZv07oQkaZuRHAr9QOGZJpGmwdJFPv3BtwoCC7nXu45TLt/2ok9KCbj
nYCmqoGRk14ZpwVc+uNqCyxldAon70jATAn23XLRnmnCXEZpNCGxQnFJwJhz2HGe5EgWU+UDudIM
PlrM5YyaB5Q31MTXdb3h8ZMB3ReTnZSAeFINsH4Oxfyf7YfBSDp4ebfk8g8FN7a4CxCjpizAkjL4
DpvqGkgD71r+9Vn3AgAA//8DAFBLAwQUAAYACAAAACEAg+regBABAACFAQAADwAAAGRycy9kb3du
cmV2LnhtbFRQXU/CQBB8N/E/XNbEN7kCKRTkSoiJCb5oqCbq26W9foTebXN30uKvdwuShseZnZmd
3dW60zU7KOsqNALGowCYMilmlSkEfLw/P0TAnJcmkzUaJeCoHKzj25uVXGbYmp06JL5gFGLcUgoo
vW+WnLu0VFq6ETbK0CxHq6UnaAueWdlSuK75JAhmXMvK0IZSNuqpVOk++dECNm+f3xgdOpzaxdfW
HM1+lrwEQtzfdZtHYF51fhD/u7eZgBD6U+gMiKlfV29MWqJl+U656pfKn/ncomYWWwFzYCnWAibQ
49c8d8qTahGE9AaaXJhFOCGG96Eez9bxxTu98vbKK2sUzokhKx8KncDwvfgPAAD//wMAUEsDBAoA
AAAAAAAAIQBL+YE1lS0AAJUtAAAVAAAAZHJzL21lZGlhL2ltYWdlMS5qcGVn/9j/4AAQSkZJRgAB
AQEASABIAAD/2wBDAAICAgICAgICAgICAgICAwQDAgIDBAUEBAQEBAUGBQUFBQUFBgYHBwgHBwYJ
CQoKCQkMDAwMDAwMDAwMDAwMDAz/2wBDAQMDAwUEBQkGBgkNCwkLDQ8ODg4ODw8MDAwMDAwMDAwM
DAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAEYAFUDAREAAhEBAxEB/8QAHQAB
AAMBAAIDAAAAAAAAAAAAAAcICQYFCgIDBP/EAEIQAAAFAwIDBQQIAwUJAAAAAAECAwQFAAYRBxII
EyEJFCIxQRUyUWEWI0JSYnFygRckM0NzgoORJTREU5OhwdTw/8QAHQEBAAIDAQEBAQAAAAAAAAAA
AAYHBAUIAwIBCf/EAEcRAAECBAMDCAYGCQMEAwAAAAEAAgMEBREGEiExQVEHEyIyYXGBoQgUkbHB
0SMzQmJy8BUWJFKCkqKy4TRDwhdTo9NUY9L/2gAMAwEAAhEDEQA/AN/KIlESiJREoiURKIlESiJR
EoiURKIlESiJREoiURKIlESiJREoiURUx4lOMeB4e7ihrSTs93elwSDIJJ83B6Eei1bKHOmkPNFB
xvOYUzeHaGAwOetR6r4gZT3hmXM7bttYewq4eTnkhmMXy0SaMcQYTXZQcvOFzgATpmZYC41vqd2i
ljQXiBsriBtp1OWsDuPkog5Ebitt7t7yzUUARIOSCJTpqbR2HDzwOQAQEAzqZVYU+zMzaNo4KK46
wFP4RmhBmbOY/Vj29V4G3bqHC4zN3X0JFiuw/i/pT9IHVqDqTYxLlYqCg6gzyjUrkiodBTFMVM7w
HzL5h61kevy+fJzjc3C4utT+qVY9WE16pG5lwuH827KRxvbZwOwqRCmKYoGKIGKYMlMHUBAay1Hi
LL5URKIlESiJREoiURZ08bfCldWsL+H1G04TbyF0RMeEXM22sqRAzxsmodVFRsooJU+YQVDgYpjB
uLjA5Lg0TxHRIk2RFhdYCxHEdi6D5GOVKTw7DiU+o3bBe7O14F8jiAHBwGuU2FiAbG9xY3HK8C/D
vqzpvIag3Le8e6slGehvY0OxVUTM6OuKgKd75aZjgUEduC7+o7hx08/DDVJmJcvfEGW4sOPf4Lac
t3KBRqzClZaScI5hxOccQDlta2S5Avm322W4rJ++LOuawbrm7SvBg4jrhhnJ0ZBFXPjHOQVIYffI
oHiKb7QCA1BpmXfAiFkQWcF1PRKvKVaThzco4OhPFxb3HgW7CNx0XmbO1c1Q0/MT6F39dduIpjkG
TR6qVqP6m4mFI37lr1l5+PL/AFbyPHT2bFh1fClJq/8ArJWHEPFzRm8HdYeBVsbM7RPXa3uUjcqN
q321LgFVHrTuboQD7qrIUkw/dIa3kviybh9ezvI+XyVV1j0fcPTdzLGJAP3XZ2+yJmPseFp/w38T
Vq8RMLJKx8evbd0wHL9vWyuqC+wiudi7dYCk5qYiAhnaUSj0EOpRNM6RWIdQabCzhtHyXNHKJybT
mD47BEcIkGJfJEAtqNrXN1yu37SCNh2gWXrcKuEoiURKIlESiLw9wT8PasHLXJcMghFQcG1Veysi
tnYkgiXccwgACI9A8gDI+QBmvOLFbCaXuNgFlyEjHn5hkvLtLojyGtA3k7PydBvUEQM/w38VkU8W
aMrU1HJBiCDpKTjxI/YgrkS7e8pJrplPgcGJ0Hr1yA1rIUWRqjdLPtxGo9uqnE9IYpwFGaHOiS2f
UZH3Y+3HISxxG8O1HDYoevPs8NBbi5q1u/SixHRsimWPeC6bbh+8k+BY+PkVQtYExhSUidS7e43H
nf3qXUf0gMRSdhMc3HH3m5Xe2HlHtaVUy8+zS1IjOatY98WvdaBMiVrIJqxbkwehSgHeUhH81C1o
pjB8dv1bw7v0PxVq0f0jqXHsJ2WiQjxaRFb/AMHexpU9cEnC1qdozed03vqGlHQ4PoU8HGwiDpN2
orzXKDgzg5kRMQoF7uBShnI7h6BjrtMOUWPJxXRIumlrbd4N/JQXln5TqTiSRgyVPLn5YnOOcWlo
FmOaGjNYm+e50toNt9NKal65zSiJREoiURKIqqcbizhDhe1TO1OcihkopMwk8+WpLsiKh+QkEQH5
VpMRkiQiW7P7grR5F2Ndi6SDuMT2iBEI87Kg3ZmMOZqhqDKd4VL3O1ite6B7h+8vUD7zfMnIwH6h
qL4Ob9O8/d95HyV6+kjHtSZWFbbGvfeMsNwt45te4LqOPniTuVtdY6MWLOvIWNhm6St7P49UyK7l
04KChGYqpiBgTTSMUTAA+Ixtpvdr2xRV3iJ6vDNgOtbeeC1nIVycyr5P9MT0MPe8kQg4XDWtNi+x
0zOdcAkaAXHWWfli6yaoaby6M1Z17XBEukzgZVv3g6rVcA+yu2UEySofIxRqLS1QmJd2aG8j3eIV
91vCFJrUEwZuXY8cbWcO1rhZzT3Fb8cNGvUdxAado3KDZGMuWJW9n3dDJjkiLsCgYFUd3i5SxR3F
z5DuJkRKIjaNHqYn4OfY4aEdvyK4R5R8CxcJVMy180F4zQ3by3gd2Zp0PHR1hmsrD1tVX6URKIlE
SiJRFwmp1js9StPbwsN8oCCN0xbhiR0IbuSscv1K2PXlqAU/7VjTksJmC6EftBbvDVafRalAnmam
E8OtxA6zf4m3HivXOgro1Y4bdRJpODkHll3vBmWiJpEUklyHT3AJkzpLkUSVTNtKco7R+yco+Q1U
sONMU6McpyvGhX9Cp2mUbGlMhmM0R5d9nt1I14gtIc1w1BF+LTvCjiTkpy7p95KyTh9O3FcT0y7t
wbKrh06cnyPQOomOYegB+QViPe+K+51cfMqQy0vL0+WbChgQ4UNtgNjWtaPcAtaNSeDvTqyeEt9I
PIVu21StODSm5W6yqmBU74BKq6bGycCGSADGRIGPQpve85zOUCDBpxJH0jRe/bvHduXKuHeVyp1P
GbYbIhMlFiGG2HbQM2MfsuHaB7jfeR1dkO9mjcS7LVi9rY5okZT9ri9Ml1wdzHu0SpdA+CblXqP/
AJrX4Pi2mHs4t9xHzKl/pH09sSjS8zbpQ42X+GIx1/NjVtbVirjRKIlESiJREoiURVv114ctGtaC
oOr7bkhLjInyY+7mC6bN/wAsnXlmFQDJrELnyUIbbnwiXI1qKnSZWc1i6O4jQ/5ViYI5Q67holsi
c8K9zDcC9l+Oli09rSL772UYaL8DOk2l1zMb69sTF9y0apz7dO/5JWbZQPdWKkiX6xQv2TGNgB6g
XcADWHT8NS8q8RLlxGy+xSXGPLZWa7KOkubbAY7R+W+dw/du7Y07wBc7CbGylDi2tu77u4fdQ4Gy
GjiQnHbZsp7NblEy7hsg6SWcpIlDImOZIhsFDqb3Q6iFZldgxIsm9sPb8L6qM8lNRkqfiWVjzpDY
YJ6R6rXOY5rS7gA4jXYNp0Cz+7N3T6fb6kXzekpCyTCOh4EYdFd2goiUzx46RVEpBOAZMQjY24A8
twZ8wqLYRlXiO+IRoBbxJHyV9ekTX5Z9LlpOFEa5z4vOaEHoMY4a23EvFuNjbYVshVgLkJKIlESi
JREoij/VW9y6bab3tfYtyuz2tDun7VobO1VdMg8hM23qBTKbQEfQOtYs7M+rQHxf3Rdb7C9F/TVU
l5G9udiNaTwaT0iO0NuQvWfvW+Lr1EuKQuu85t9PTkkoJ13jk+doCOQTSL7qaZfIpCgBQDoAVTsx
MxJh5fENyV/SCjUWTo8q2Vk4Yhw27APeTtLjvcdTvXwtq+LzsxcHVo3ZclsON24VYp6u0ER+fJOX
P70gzMWDqxxHcbL9qNFkak3LNwIcUffaHe8FWis7jz4i7UFIj25Iq82aeABpPMk1Bx/ftu7rD/iO
NbqXxPOwtrg7vHysVWdX5DMMT9yyE6C7jDcR/S/O32NC0o4XeMaK1+kn1oTkAnad7smpnrZBBYVm
b9umIAqZETlAxDk3Bkg56eIDDgcTCi19s+TDcMr/ACK5y5TeSKNhOE2bgxedlycpJFnscdma2hBt
1hbXQjUXuzUiVMpREoiURKIlEURa+WpIXvovqba0SQysrLW+8JGIFDIquEyc1JIP1mIBf3rAqkAx
pWIxu0tKlmBapDpddk5qL1GRW5jwaTYnwBuvX04frDhtS9Z7AsW41F0YSdkhJKAkbYodJBJRcyQG
8y8zl7Mh1DPTrVWUuWbMzTIb9hK73x7XI9FoU1Oy9jEYzo31AJIbfty3vwNtVt7N8FHDVNsSsv4c
N4k6SYJoPo148brlx0yI84SnH5qAarHiYdkXi3N27iVxZJcs2KpaJn9bL+x7WOH9tx/CQqwXn2ZN
uOOavp/qVMRRuopR081TekEfu94bd2Eof5Zq0sxg5h+qiEd+vmLe5WZR/SSmmWE/KNd2w3Fn9Ls9
/wCYLzfCrwXX/ovqspfl6T9rOmEWwdNIhvELOVTuFHRQJvUBVFACFKTPQd3i9Oma9aJh6NJzHOxC
LAaW7fALC5UOWOm4lo/qMnCiBznNLi8NAaG62FnOuSbcNPYtL6mC5wSiJREoiURKIuJ1JvEunun9
53ydiaTC04Z5KFjgPy+eZskZQqe/A7QMIYEcDjzwPlWPNzHq8F0S18oJW5w7SDV6lLyWbLzsRrL7
bZja9t9uGl+IXrUSGoD4dS3OpttsWtpSozv0gjGDIxjIM3PO7xtS39dm/wCz5Y6eVU+6aPP88wZT
e/cdq/o5L0GH+ihTZhxjM5vmnF217cuXW2+2/jrtW4ulXHBodfsLEjcd1MLCuxVFMJiFmN7dsm42
hzBRenDkCmJs7RMcDY94oVZEliSUjtGd2V28H57FxRijkVxBSY7/AFeCZiBfouZZzi3deGOnmtts
0i+wlW0iJuGuBmSRgZeMm49X+m+YLpuUTfkokYxR/wBa3rIjYgu03HYqqm5KPKP5uOxzHcHAtPsN
ivKV9rGSiJREoiURKIlEXLXvajC+7Ouiy5Q6qUddUW6i3ayX9RMjpIyQnJ+Iu7IV4zMAR4boZ2OF
vatnRapEpU9BnIXWhPa8X2HKb2PYdiw/vjs+9frXUcqW+zgb+jkjGFBaLdkQcCkA9BO3ecnBseZS
GP8AIRqt5nCs5C6tnDs+Rt8V2pReXvDc8AI7ny7/AL7btv2OZm07XBvcFU+69Or9sRYULzsy57XP
u2lNJsl2xDj+A6hQKb8yiNaOPKRoH1jS3vCtSl4gp1VF5OYhxfwODj4gG48V4WDuO4bYeFkbbnZm
3pAvuvo10q0WDHl9YiYpv+9ecOK+GbsJB7NFmTtPlp5nNzENsRvB7Q4exwIWp3AxxQak3lfh9K9Q
ZtxdrORj3DuBmH2DPm67QN5kzLY3KkOTcPjyYBAMDjIVNcNVmPGjcxFOa40O/T3rmDlt5NKXTqd+
lJCGILmuDXtb1HB2gIbsaQbdWwIOoutZanK5XSiJREoiURKIvBXRIuIe2bil2gJi6i4x27bAoGS8
xBEyhdwdOmQrzjPLGOcNwWdTJdsxNwoTtjntae4uAXr/AEHxtcSkHIqv/wCIaswRwoKi8dJs2i7c
cjnBS8opkw+SZi1VkPEc8w3z37wPz7F3lO8jGFZqEGeq5LbHMc5rv7iHH8QKs5anaXyqiPcNS9LY
aZbLl2O3UK4MgAl9ctHYOCnz8OaFbmBjB2yNDB7vkb+9VrVPRwgh2enTr2EbBEGb+tmQj+Urs/4i
dnlrR0uW1WNgTDv+1XYLQqnMHzMZzEmM3H81TVket0Wc67ch7svm3T2rT/q/ymYa/wBNGMxDHB4j
C3DLGAf/AChWK4eeG/h8sG4Hmo+kt0O70crtjsm70ZZpJNWabjAnKl3RMmBEC4+sEw4zW3pVIk4D
+dgOzeIIHsVfY/5RMS1aWbTqrBEAA5iObdDc8t2Xzk6a/ZACuLW/VRJREoiURKIlEXMXpdMRZFo3
LeE+J/Y1tRrmRkikADHOk3TE5iEKYQATGxtKGeojXjMRmwYbojtgF1sqPTI1TnYMpA+sivDW8LuN
rnsG09iwL0z0SV4qtU7v/hzDx+ltms8yD9FVRR+hHFcGMCCCQYTExlDFEQLkClADYHAAFVfJ079K
TDuaGRu3jZd24kxmMB0iB+kIjpqYPRFgGGJl6zjtsGi1zqSSOJK7q8+zz19tvmrW+lbF+NS5FMIx
6DZztD7yT4G5c/IpzfLr0rJmMKTkPq2d3H52Wjo/L/hycsI/OQD99uZvgYec+Ja1VJvLTi/tPHJG
l82dcdqrLCINhkmiqCa23z5Khi7FA+ZBGtFMSkaXNojS3vVr0jENOrDM8lMQ4oG3I4OI/EBq3xAV
6OzQQlR1fvZ0kk/9hks9ZJ8uUD91B2Z+yFuVQfc5gkBXZnrjfj1qS4PDvWXndl8L3FviqQ9I98H9
CS7SRznrAI/ey83EzW35b5M26+W+5bX1Yq40SiJREoiURKIoh1+th7eeimqFtRqaq8lJ24+CNbp9
TKuEkhVSSDoPvnIBf3rAqkExpWIwbS0qWYEqTKbXpOZiaMbFbmPBpNifAG6yt7OPU63rQv28bHnn
jaNW1FbR/sF2ubaVR9GnX2NQN5AZUrowlz5iXaHiEAGE4SnGQozobtM9rd4vp43XUHpDYamajTpe
dgNLhLF+cDcyIG3f3NLBe2wOvsBI2wqxVxmos1ssq39QNK74tq5GrZdg4iHa6C6oZ7q5QRMog5II
AIlMkcANkPy6gIhWFUZdkeXex+y3s7VJ8GVmZpFYlpmXJDhEaNPtNJAcw8Q4aKiHZqakR7y17y0o
WQbt5iGdjcbBYgYM6aOgTbr7sB1FBQhOoj1BQofZqM4PmwYboG8dLvB08virx9I3DsSHNy9UBJY9
vNH7rm3c234wXacWE71qFUzXM6URKIlESiJREoiw041eFyT01uiS1OsqOcOtO7kdGdyabcufYr5c
+45DgX3UFDjlM3kUR5Y48G6tsRUV0tEMaGOgf6T8uHsXbPI1ymwq1KMps48Cbhizb/7zANCOL2jr
Daevr0ssN2Bxh8QWnaLZjGX26m4hqUCJRE8mSRTApfdKCqv15SgHQAKoAVr5WvzkvoH3HA6/581M
K9yR4arDi+JLBjz9qGebPfYdAntLSuu1H469dNSbXf2i6UtW14uXQM1l1YFoui4coHDCiRlXDhwJ
SnDobl7ch08hEK95vE03Mwyw2aDtt/klanD3Ihh6izbZtvORXsN2844FrXDYbNYy5G7Nex12qdez
NsmWUvG/9RjoKpQbGF+jiDgwYIs6duEHahSD6ikRsXd8N5fjWzwdLO518XdbL4kg+VvNQf0ka1BE
jK0+/wBI6JzpG8Na1zBf8RebfhK2MqfrkRKIlESiJREoi+lddJqgs5XNsRbkMosfAjgpAyI4Dr5V
+E21X0xhe4NG0qoWjPGDpbr/AHTK6dtIWYinzhBweMaTKaCiEo0TD60uCGOAH2ZMKZgxtz1HA1oa
fX5efiGEAQe3ePzuVtYw5JKvhKUZUHRGvaCMxhkgwnHZtA0voHDfbQLktSOz30VvR4vKWwtM6cP1
xMY7aLEi8cJjevdFupP0pqEL8q8JvCsrGN2XYezZ7Pktrh3l9r1NYIcyGTLRvfpE/nbt73Nce1Rr
bHZlWUwkiObt1Ln7kjk1d/s1gwSjBOQPIiiplnY/mJQKPwxWHBwdCaenEJHYLfEqR1P0kp+LCyys
myG63Wc8xLdoGWH4Xv23Wi1o2hbVh27GWpaMQ0grfiE+Uwjm4eEoZyYwiOTGMYRyYxhETD1ERGpZ
AgMgMDGCwC58q1WmqrMvmpuIYkV5uXH82AGwAaAaBdJXstclESiJREoi+pYFhRVBuYhFxIbkGOGS
gfHhEQD0zX4V9MtmGbYvW6urWPiOtK+boaXLqPqDFXW3eLtrhjlX65Ud+cGJ3XdyOXj3AKTbtxt6
Yqoo9QnYUVwfEcHb9fhsX9E6XhDC9Qp8F0tKQHQC0FjgwXtxz9fN+9c5r3zarjNG9Tn2jepNtakR
sY0mXluGdcuMcnMmmqV20WaHATE6hgqwiHzrHp84ZOO2MBe3xFvitxi/DUPEdKjU6I8sbEy9IakZ
XteND2t17Fq1ZnaVaYyvKRvazLqtFwfAHcsjJSjUvxExv5dX/RIanEvjCA76xhb5j4HyXLdY9HKr
QLmSmIcYcHXhO/5t9rgup1f4+tMbUtGIl9LHsdqLPzLrlhFKd4ZlZoJhlVVyVRMipRERApAx16jn
BevtP4ogQoYdB6ZPhbvWswlyE1afnXwqm10tCY3rdF+dx2BhBLTvLjfTQW1Ur8N3FNaHEOyfNGbB
xbV6QiBXEzbC6gLF5Im2d4bLgUnMT3CAGyUolEQAQ6gI51IrUOoAgCzxtHxCi3KJyYTuD4jXPcIs
u82bEAtrtyvbrlda5GpBAOu0C0dbpVklESiJREoiURRVqNoppfqmgt9NLItybkjNzINZpduAPEgw
O0CuU9i20ojnG/FYU3ToE0PpGAnjv9u1SjD2M6tQnD1OYiMZe5aD0Dx6Bu2542WJenvBjqrcerht
Nrxt+5LQhWZXppS+ysDrxxSIpKd3VbrH5aS4LLAQoAU+7Aj5bRxXMrh6YiTPMxAWjXpW07Lcbldn
V/lho8nRf0jKRYcaIcuWDnAiakZg5ou5ha25uW2uBxF5KvLs3tY4UVFbRn7SvZqX+miKh414b/LX
AyIf9esyYwjMs+rId5H5eajlI9IihzOk3CiwD3CIz2ts7+hQUvwdcSzd2DJTSebMsIiAHTXZKpdM
/wBsRwZP0+9WsNAngbc2fL5qcM5XcKvZnE8y3c8H+Usv5LR/gl4VL20Wl5/UDUQzONn5mKGGjrZb
LkcmQbqrpOFlHKqQmT3iZAgFAhjBjORqXYcokWTcYsXQkWtt7dfYud+WflRkMSwYUhT7uhMfzjoh
BbmcGua0NB6VrOdcuA3aLRWpYufEoiURKIlEWLPaVPrvLqfZrB25kCWWNvlcQDYDCDUXwOFSvDgH
kKoF5WfgXb8arzF7onPtB6mXThe+vjsXY/o5QZI0mYe0N9Y52zz9rJlbkH4b57cTm4KVuz512uyc
aXtp7eMnJ3BG2hEBO2+/cGM4ct2yR+Uu13GETnL4yCmX7PUodMAGbhWpxHh8KIbhouONuHyUX5fM
EScq+Xn5RjYb4z+beB0WucRdr+AOhzHfodtyYlP2luqZbjeu0rKsg9rKLG7jCKg6B2mhnwgZ2Vba
J8eY8rHwKFYP64TGe+RuXhrf23+ClQ9HGj+qtYZiNz1tX9HKTv6GW9uAz37VYezO0q0xleUje1mX
VaLg+AO5ZGSlGpfiJjfy6v8AokNbaXxhAd9Ywt8x8D5Kv6x6OVWgXMlMQ4w4OvCd/wA2+1wVs7M4
k9Cb+5RLa1PtVd0tjlRz1f2e6MI+hW70EVDfsFbyXq8pH6kQe4+w2VV1jk5xDSb+sycQAfaaOcb/
ADQ8wHiVNxTFMUDFEDFMGSmDqAgNbJQoiy+VESiJREoiURcDqLpfYerECNt6gW4yuKLA/NblV3EW
bq+XMQXTEqiRsdMlMGQ6DkOlYs3JQZpmSK24/Oxb3D+JqjQJj1iQimG/Ybahw4OabtcO8do1XMaR
6BaX6ItZRDT+AMwXmxL7WknSyjpysVPOxMVFRHBC5HwlwHqORrxkaXAkgeaG3bvK2eK8d1bE72On
4uYM6rQA1ovtNhvPE3Kzu1p7OafcXDKz+jMzA+w5BU7klnSpztlWhjjkUWq5SKJqEz7u/ZtDpk2M
jE6jhJ5eXS5FuB0t3fkLoDBvpCyzJZkCsQ3840W51lnB9vtPaSCDxy5rnWw2Kj958MuvVhc09xaX
3QVqjkVJGPRCSbFL94yzEViFD9QhUbmKPNwOvDPhqPK6uuj8pOHatb1ech3O5x5t38sTKT4XUFnI
dM5k1CmIcgiU5DBgQEPMBCtapsCCLhar9m1qldj6fuvSeTfO5O2GMIadgyODmU7goi5QbqIoiPuk
VBwBtvkAlyAdTZm+EJ2I57oBN22uOzUDzuuXfSKwxJwpaBVYbQ2M6Jzb7aZwWOcHO4luS19tnWOw
LXOp2uUEoiURKIlESiLhdT2lzP8ATe/mVmLqtrtd29JI20ukbYoV8dsoCApnAQ2m342m9B61jTrX
ugPEPrZTbvst3hqLKwqpKvnBeAIrDEB2ZM4zXG8W2jeNF65VgavaraKXU7lLYnpiCmCOTluCGfAY
6LlUpvrU3zVb3jZDAiIAcvoIDVSSs/MSUS7CQd4+Y/JX9DK9hOj4mk2w5mE2JDt0HN2tFtDDe3YO
7oneCFsLoFx06eap9zt++Ba6eXwrhMqbhX/ZT1Ty/lnJ/wCmY3/LV/IpjjU/peJYM10YnQf5HuPw
PmuR8d8iNToWaPJXmJbsH0rB95g2j7zO8tarVXhpVppqAQ5b0sS1blUMGO9vmSKjgv6F9vMJ/hMF
buPIwI/1jAfD4qrqTiiq0k/sczEhdjXEN8W3ynxC/Hp3o5pjpMSRJp5Z0XbIywlGSXQ5iiy2zO0p
lljqH2lyOC5wHwr5lKfAlb802117YgxfVq+WmoR3RcnVBsAL7ei0AXPG11JlZijaURKIlESiJREo
irdrfwsaVa5oLOp2K9h3ds2tL0iylSeAIBgoOAxscEDAdFAyAdCmLmtRUqJLz2rhZ37w2+PFWJgv
lPrGFnBsB+eBvhP1Z/DvYfw6X6wcsZ9bOEXVzRZV2+eRJ7rs1DJk7xh0zKoET+LpHqo3EPXd4M9A
Oaq+qNBmZPUjM3iPjw/Oq7BwZysUXEoaxj+amD/tP0N/uO6r+y3S4tC6vQPjW1L0c7nAzait/WEj
hMsG/VHvTNPp/uTswGMUCh5JnyT0DZ517UvEUeT6Lukzgdo7j8Ni1eO+RqlYjzR4P7PMn7bR0Xn/
AOxmgP4hZ3HNsW2Ok+rlka0Wohd9jSQvGJj8l+xWDlu2TgAATIOUsjtMGfQRAQ6lEQ61Y0jPwpyH
zkM6eY71xlirCc/hqcMpOss7aCNWvb+807x5jYQCpNrMUbSiJREoiURKIuA1VumQsjTLUC8YlqR7
KWvb8jJxzY5ROQyzVudQm8pcCJAEMm+WaxZ6MYMB8Ru0NJ9gW9wvTIdTq0rKRTZkWKxhO+znAG3b
w7VhOfjn4pDHMYNTSpgYREEywsLgPkGWIjVafrLUP+55N+S7gHIlhED/AEf/AJY3/tXxHjk4pBAQ
HVDID5h7EhP/AEK/P1kqH/c8m/8A5X7/ANE8I/8Aw/8Ayxv/AGqt903TL3lMOJ6d9lDJu+rlSPjm
UYmc3mJzIsEEEtw+ptuR9RrURo7ozszrX7AB7gFYlMpcGmwBAgZsg2ZnviEdmaI5zrcBew3LQXsz
HU4XVDUBkgLr6NLWsC0oAAPJ78k9QKz3D5buWo42/LdUqwcXc+8fZy+dxb4qg/SRhS5pEq8254Rr
N45DDdnt2ZhDv4LaSrDXHKURKIlESiJRF+d01bPmrlk9bou2bxI6DtqsUDpqJqBtOQ5R6CBgHAgN
fjgHCxX3CiuhPD2GzgbgjQgjYR2rJzWfs4F+c8nNEZ5EUTiZX6ETaglMT12NH2BA3wKVYAx6qjUG
qGET1pY/wn4H5+1dUYO9IhuVsGtQ9dnOwxt7Xw/eWX7GBZl3nYd5aeTKtv3vbctbMulke6PkhT3l
DpvSP7ihPgYgiA/GodMS0WXdliNIK6So9ckaxAEeSjNis4tN7dhG1p7CAVazRPVDhWcFaQOt+iMT
HLhtSJe0OtJKIDjpudtO9mUKPqJkt2R/swrd06dp56MzBH4hfzF/d7FV2M8M4wYXR6LUXOG3mniG
D3MfzYB7A+34ytptJ7e0pg7SaONHY612lozX82g9gwIZJ0b3N6ipcmUOXG0d45LjaOMYqxJGFLsh
/s4GU8N643xVP1ianXNq74hjs0tEvdu+wGwA7dBY7VJtZijaURKIlESiJRF4O5riirRtyeuqcXFt
DW3HuJOUXANwlQapmVUEpfUdpegeo9K840VsJhe7YBf2LNptPjVCahysEXiRHBjfxONgs4pjtN7F
QOqEBpjdkomUwgkd+8bMRMXr1EEwdY9PjURiYyhDqwye82+a6HlPRsqDgOfnITfwtc/35FDF7doR
DagRy8HdfDta1wwS3ux8rKi6EgiGBORTuJBIb4GJgQ+PrWvmMVNmBlfABHab/BTGjcgUekRRGlar
EhxBvZDy37COdNxxBuCs+rukrYlppd/aVsurQiV/EWCVkDSRUTZHIJLqIpKbMYwB9xvxD6RWO+G5
12Nyjhe6vulS83LwAybjCM8fbDObv3tDnC/4co+6tGezPvieLed86bncqrW05gzXEg1OIiRu8bOm
zUwph5F5pHHi+OwvwqW4PmX86+F9m1/G4HnfyXPXpIUSXMjLVEC0YROav+8xzHv1/CWacMxWxlT9
ciJREoiURKIvpXcINUjLuVkm6BMb1lTAQoZHAZEennX4TbavpjHPNmi5Xh7otyLvC25+1JtI60Pc
sc5jJNMg7TCg6SMkptN1wODdB9Br4jQmxmFjthFvasymVCLTpqFNQTaJCe17e9puPDTVYtzfZv60
t7geMbfm7JlLfA4jHTrxys1MZMR6c5uVFYxDgHmBdwfAaruJhGaD7NLSOOzysuxpL0iKC+Wa+PDj
Ni72NaHa/ddmaCOF7HsXUxHZk6hLbPb2pVmRuf6ncG7t7jp6c0rXPWvdmDox60Ro7rn5LWTfpJ0x
v1EpFd+ItZ7ucUpxHZiWqjt9v6sXBJff9nxiDHPn5c1Z3j0/+8s2Hg2GOtEJ7hb4lRib9JWcd9RI
sb+J5f7mw1cfQ3ht024f2smWzEZR9LTW0spccsqms8USIOSolFJNIhEwHrgpAz03CbAYkFNpECQB
5u9zvO1VBjblFqmLXs9cLWsZ1WMBDAT9rUuJd2k6brXKn+tooIlESiJREoizR7Sa0b5mrLse44Mj
95Z1rOXxrvZNxMJEVHIIFaO1kyj4ik2qE3CHg3fjGofi+BFfCY9vVbe/jax/OxdH+jpVqfLT8zLx
rCYihvNE7w3NnY07ibtNvtZfuqqvCtxnzekS7KydQl31w6ZqmBNquOVXkLn7SH2lEPvJZ8Pmn1yU
+komIXSn0cXWH5t/x2exWhyocjsviFrp2QAhzm8bGRux25r+D9+x+5zdwYKehbnh4+4LdlGM1CSq
QLx0ozUBVFZMfUpy9PPoPwHoPWrIhRWxWhzDcFcVT0jHkY7oEwwsiMNnNcLEHuX5Lnu217Ki1Zu7
rhhraiUffkJJwm2SzjO0oqCG4w+hQ6j6V8xo8OC3M9wA7V7U2lTdTjCDKQnxXncwFx8tg7ToFQPU
/tHdN7dFeP0zgZK/5Ag7Sy7ndHRofiLzCi4Ux8OWQB9DVF53FsCHpBGY8dg+fuV74a9HiqTlolSi
tl2/uj6SJ5HI3+Z3cpj4XeK+F4iEZeIdQoWte9voFdvYgq3PQctDGBMXLc4lKYAIcxSnKYPDuLgx
s9M+i1xtQu0jK8buI4hRDlM5LI+DyyK2JzsvENg62VzXbcrhqNRctI22Ogtrbut8qnSiJREoiURf
Q5bNnrZwzeN0HbN2mZF01WKCiaqagbTkOQ2QMBgHAgNfhAIsV9w4joTg9hIcDcEaEEbCDuIWIXGF
weudLXL3UjTdku703dqb5eIJlRSDUUH9xM2MI+E32PdN6CNcV+gGVPPQfq94/d/x7l2lyR8rja61
tOqLgJsDou2CMB7og3j7W0bwKoaf66auaWNHMfYV+TdvRzs29aNTEizbePmcqK5VCFMPqYoAI+ta
OVqUzKi0J5A/PFWnXsEUWuvESelmRHD7WodbhmaQSOwmy4y6rzu2+ZQ81eVyTVzyqn/GyTlRwcof
dJvEdpfgUuAD0rHjzESO7NEcSe1bml0eSpcLmZOEyEzgwBo8bbT2nVdvphoTqrrC7BCwrPkpVoU+
xzOKADeOQ+PMdq7U8h57QETD6FGsiSpkxOH6Jt+3d7VpcS44o+HWZp6O1rtzOtEPcwXd4mzeJC2M
4TeEFXh+kZO8rjudCdvKaizRKrKPIYse0bqLJLqFKoqAKLGE6BPEJSYDIbR86sCh0H1AmI913EW0
2D57Oxch8qnK0MXQmScvBMOXY/Pd31jnBrmjQaNFnHS7r8dyvHUkVKJREoiURKIsv+0Y1D1Os8un
EVac9PWxbE0R8rJv4pdRqdy7QMlsRVWREp9pCG3AXODZERAdoYhmLZuPB5sMJDTfZpqul/R6w/Sa
j63FmoTIsZmQNDwHBrHZruDTpckWJtcWtpm1oXafF/xCWkj3ImoL65Yo5BScxNyJpy6SyYhgSHO6
KdbaIdMAoFRiBXpyFpnuODul79VelV5JcNVB2cyohv2h0ImEQeIDLNv3tVcn7vv756+7s0Zd9XUX
7m1Jy0EuYYTctInXaQucFD0CtQ52Y3VhQIXNQ2suTYAXOpNt5O8nerFcKK2jKGrjM+uSUcpagRzj
2YMkBjR5ZMDJiiLwgAIGT5YKBg4bdwlzW2oZlRM/tPVtv2X7fNV9ypMrrqK4UQu5/OM2X6zm9c2Q
7nXy7NbXsvYLtC47Hn4pv9A5y1piFaplI2LBOG67dIge6UoNjCUoB8KtSBFhRG/REEdn+FwRVqdU
JSMfXocRkQ7ecDg4n+LUrrK91qkoiURKIlESiLgdSNMrK1athxaN9wyUzDLHBdIoiJFW65AEpF0F
S4MmcoGEMh6CIDkBEKxZuThTcPJFFwt7h3Ek/h+bE3IxMkQacQ5u9rgdCDbZ3EagLPO8+zJtxxzV
9P8AUqYijdRSjp5qm9II/d7w27sJQ/yzVFJjBzD9VEI79fMW9yv+j+klNMsJ+Ua7thuLP6XZ7/zB
VMvPgJ4ibU5qrCAh72ZpZEXMC9IY+3+4dA2WEfkUpq0cxhidhbAHdx+dirUo/LphifsHxXQHcIjT
/czO32kKq9y2VeNmOe5XfatxWu6EcFQlWS7Qxsfd5xC5/atJGl4kE2iNLe8WVoU2syNSZnlI0OKO
LHB/9pK8LHyMhEukn8W/eRr5AcovGqpkVSD+E5BAQrza8tNwbFZseXhx2FkVoc07iLj2FbAdn9xD
3zf8lcell9Sz651IWJ9t29PvTiq7Igiui2XbrrGETK+JwQxBNkweIBEQ2gE9wtVYscugxDewuDv4
W81yTy88n9PpMKFVJFghZ3829jdGlxa5zXNbsboxwcBoejpe99P6ma5oSiJREoiURKIlESiL8j1i
ykmyrKRZtX7NcNq7RymVVI4fAxDgIDX45ocLFesGPEgvD4bi1w3g2I8Qq53nwgcO1781R/prDw7x
TIg/gRPFHKYftctqYiJh/UQa1ExQZKNthgd2nu0VhUflaxPTLBk257eES0Xzfdw8HBeU0V4ZdLdB
XMvIWQzlV5ebSBs8mZRwDhwDYDAfkJ7SJlKQTAAjguREAyI4DH3TqNLyJJh3ud59yxsZcpNXxW1k
Odc0MYbhrBlbm2Zjckk20Gthc2GpVg62qgKURKIlESiJREoiURKIlESiJREoiURKIlESiJREoiUR
KIlESiJREoiURKIlESiJREoiURKIlESiJRF//9lQSwECLQAUAAYACAAAACEA9L5jXQ4BAAAaAgAA
EwAAAAAAAAAAAAAAAAAAAAAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLAQItABQABgAIAAAAIQAIwxik
1AAAAJMBAAALAAAAAAAAAAAAAAAAAD8BAABfcmVscy8ucmVsc1BLAQItABQABgAIAAAAIQB07TaR
CgIAAPYEAAASAAAAAAAAAAAAAAAAADwCAABkcnMvcGljdHVyZXhtbC54bWxQSwECLQAUAAYACAAA
ACEAWGCzG7oAAAAiAQAAHQAAAAAAAAAAAAAAAAB2BAAAZHJzL19yZWxzL3BpY3R1cmV4bWwueG1s
LnJlbHNQSwECLQAUAAYACAAAACEAg+regBABAACFAQAADwAAAAAAAAAAAAAAAABrBQAAZHJzL2Rv
d25yZXYueG1sUEsBAi0ACgAAAAAAAAAhAEv5gTWVLQAAlS0AABUAAAAAAAAAAAAAAAAAqAYAAGRy
cy9tZWRpYS9pbWFnZTEuanBlZ1BLBQYAAAAABgAGAIUBAABwNAAAAAA=
">
   <v:imagedata src="image004.png" o:title=""/>
   <x:ClientData ObjectType="Pict">
    <x:SizeWithCells/>
    <x:CF>Bitmap</x:CF>
    <x:AutoPict/>
   </x:ClientData>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:3;margin-left:10px;margin-top:2px;width:71px;
  height:233px'><img width=71 height=233 src=kuitansi_files/image007.gif alt=kwitan.jpg
  v:shapes="Picture_x0020_4"></span><![endif]><span style='mso-ignore:vglayout2'>
    <table cellpadding=0 cellspacing=0>
      <tr>
        <td height=25 class=xl68 width=72 style='height:18.75pt;width:54pt'>&nbsp;</td>
        </tr>
      </table>
  </span></td>
  <td></td>
  <td class=xl75 colspan=2 align=left style='mso-ignore:colspan'>Telah terima
  dari</td>
  <td class=xl75 align=left>&nbsp;&nbsp;: <?=$vName?></td>
  <td colspan=7 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td class=xl75 colspan=2 align=left style='' nowrap>Untuk
  Pembayaran</td>
  <td colspan="8" align=left class=xl75>&nbsp;&nbsp;: 
  <?
      echo $vPayFor;

  ?>
  </td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=10 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=10 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td class=xl75 colspan=2 align=left style='mso-ignore:colspan'>Uang Sejumlah</td>
  <td colspan="8" align=left class=xl75>&nbsp;&nbsp;: <?
  
  $vNom = Terbilang($vNominal);
  if (trim($vNom) == '') echo "Nol";
  echo $vNom;
  
  ?> Rupiah</td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=10 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=4 class="xl78" bgcolor="#CCCCCC" ><div style="border: 1px solid #666;display:block;text-align:right;vertical-align:middle;padding:5px 5px 5px 5px">Rp <?=number_format($vNominal,0,",",".")?></div></td>
  <td colspan=4 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl75 colspan=2 align=left style='mso-ignore:colspan'>Surabaya, <?=date("d-m-Y")?></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=9 style='mso-height-source:userset;height:6.75pt'>
  <td height="9" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=4  >&nbsp;</td>
  <td colspan=6 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=10 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height="25" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=10 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl69>&nbsp;</td>
 </tr>
 <tr height=32 style='mso-height-source:userset;height:24.0pt'>
  <td height="32" class=xl68>&nbsp;</td>
  <td></td>
  <td colspan=8 class=xl75 style='mso-ignore:colspan'></td>
  <td class=xl75 colspan=3 align=left style='mso-ignore:colspan;border-right:
  1.0pt solid black'>............................................</td>
 </tr>
 <tr height=8 style='mso-height-source:userset;height:6.0pt'>
  <td height="8" class=xl70>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl71>&nbsp;</td>
  <td class=xl72>&nbsp;</td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=101 style='width:54pt'></td>
  <td width=99 style='width:54pt'></td>
  <td width=106 style='width:54pt'></td>
  <td width=159 style='width:69pt'></td>
  <td width=83 style='width:54pt'></td>
  <td width=106 style='width:54pt'></td>
  <td width=106 style='width:54pt'></td>
  <td width=106 style='width:54pt'></td>
  <td width=99 style='width:54pt'></td>
  <td width=99 style='width:54pt'></td>
  <td width=99 style='width:54pt'></td>
  <td width=99 style='width:54pt'></td>
  <td width=102 style='width:54pt'></td>
 </tr>
 <![endif]>
</table>
</div>
<br>
<div class="row">
<div class="col-lg-12" style="padding-left:20px">
<div id="divPrint"><input name="btnPrint" type="button" value="Print&nbsp;" onClick="printKui()" class="btn btn-success"></div>
</div>
</div>
</body>

</html>
