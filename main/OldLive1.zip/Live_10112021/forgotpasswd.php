<?php
       session_start();
        include_once("../server/config.php");
        require_once '../simage/securimage.php';
		require_once '../classes/systemclass.php';
		require_once '../classes/memberclass.php';
		
		$vSess = $_GET['s'];
		$vUser = $_GET['u'];
		$vSQL = "select * from m_anggota where fidmember='$vUser' and fsession='$vSess' ";
		$db->query($vSQL);
		$db->next_record();
		if ($db->num_rows() <=0) {
			$oSystem->jsAlert('Link reset password tidak ditemukan atau sudah expired!');
			$oSystem->jsLocation('../main/forgotpasswm.php');
		   
		   exit;
		   
		} else {
			
		;	
		}
 ?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans'>

      <link rel="stylesheet" href="../css/style-login.css">

  
</head>

<body>
  <div class="cont">
  <div class="demo" style="height:95%">
    <div class="login" >
      <div class="login__logo"><img src="../images/login-logonew.png" width="120" height="62"></div>
      
  <form class="form-signin" id="asdfg" action="forgotpassx.php" method="post" >    
<span  onClick="document.location.href='/xsystem/main/loginform.php'" ><li class="fa fa-home" style="cursor:pointer;font-size:24px;color:white"> </li><span style="font-size:12px;color:white"> Login</span></span>
      <div class="login__form">
       <span style="font-size:4em;color:white">Reset Password</span>
        <div class="login__row">
          <svg class="login__icon name svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 a10,8 0 0,1 20,0z M10,0 a4,4 0 0,1 0,8 a4,4 0 0,1 0,-8" />
          </svg>
          <input name="tfUser" id="tfUser" type="text" class="login__input name" value="<?=$vUser?>" readonly placeholder="Username"/>
        </div>


        <div class="login__row">
          <svg class="login__icon pass svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 20,20 20,8 0,8z M10,13 10,16z M4,8 a6,8 0 0,1 12,0" />
          </svg>
          <input name="tfNewPass" id="tfNewPass" type="password" class="login__input name" placeholder="Password Baru"/>
          <input name="hSess" id="hSess" type="hidden" value="<?=$vSess?>"  />
        </div>

        <div class="login__row">
          <svg class="login__icon pass svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 20,20 20,8 0,8z M10,13 10,16z M4,8 a6,8 0 0,1 12,0" />
          </svg>
          <input name="tfPassConf" id="tfPassConf" type="password" class="login__input pass" placeholder="Confirm Password Baru"/><br>
  
  		<input type="hidden" name="hPost" value="1">

        <button type="submit" class="login__submit">Ubah Password</button>
        <p style="display:none" class="login__signup">Belum bergabung? &nbsp;<a href="../main/register.php">Sign up</a></p>
      </div>
      <br><br><br>
    </div>
    </form>
    <div class="app">
      <div class="app__top">
        <div class="app__menu-btn">
          <span></span>
        </div>
        <svg class="app__icon search svg-icon" viewBox="0 0 20 20">
          <!-- yeap, its purely hardcoded numbers straight from the head :D (same for svg above) -->
          <path d="M20,20 15.36,15.36 a9,9 0 0,1 -12.72,-12.72 a 9,9 0 0,1 12.72,12.72" />
        </svg>
        <p class="app__hello">Good Morning!</p>
        <div class="app__user">
          <img src="//s3-us-west-2.amazonaws.com/s.cdpn.io/142996/profile/profile-512_5.jpg" alt="" class="app__user-photo" />
          <span class="app__user-notif">3</span>
        </div>
        <div class="app__month">
          <span class="app__month-btn left"></span>
          <p class="app__month-name">March</p>
          <span class="app__month-btn right"></span>
        </div>
      </div>
      <div class="app__bot">
        <div class="app__days">
          <div class="app__day weekday">Sun</div>
          <div class="app__day weekday">Mon</div>
          <div class="app__day weekday">Tue</div>
          <div class="app__day weekday">Wed</div>
          <div class="app__day weekday">Thu</div>
          <div class="app__day weekday">Fri</div>
          <div class="app__day weekday">Sad</div>
          <div class="app__day date">8</div>
          <div class="app__day date">9</div>
          <div class="app__day date">10</div>
          <div class="app__day date">11</div>
          <div class="app__day date">12</div>
          <div class="app__day date">13</div>
          <div class="app__day date">14</div>
        </div>
        <div class="app__meetings">
          <div class="app__meeting">
            <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/profile/profile-80_5.jpg" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">Feed the cat</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">8 - 10am</span>
              <span class="app__meeting-place">Real-life</span>
            </p>
          </div>
          <div class="app__meeting">
            <img src="//s3-us-west-2.amazonaws.com/s.cdpn.io/142996/profile/profile-512_5.jpg" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">Feed the cat!</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">1 - 3pm</span>
              <span class="app__meeting-place">Real-life</span>
            </p>
          </div>
          <div class="app__meeting">
            <img src="//s3-us-west-2.amazonaws.com/s.cdpn.io/142996/profile/profile-512_5.jpg" alt="" class="app__meeting-photo" />
            <p class="app__meeting-name">H</p>
            <p class="app__meeting-info">
              <span class="app__meeting-time">This button  ></span>
            </p>
          </div>
        </div>
      </div>
      <div class="app__logout">
        <svg class="app__logout-icon svg-icon" viewBox="0 0 20 20">
          <path d="M6,3 a8,8 0 1,0 8,0 M10,0 10,12"/>
        </svg>
      </div>
    </div>
  </div>
</div>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="../js/index.js"></script>

</body>
</html>
